package omni.activemq.util;

import java.io.ByteArrayOutputStream;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import omni.activemq.bean.Product;

import org.apache.cxf.transport.jms.util.JMSUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

public class SimpleMessageProducer {

	@Autowired
	@Qualifier("myJmsTemplate")
	private JmsTemplate jmsTemplate;

	protected int numberOfMessages = 100;

	public void sendMessages(final Product message) throws JMSException {

		jmsTemplate.send(new MessageCreator() {

			@Override
			public Message createMessage(javax.jms.Session session)
					throws JMSException {
				//TextMessage msg = session.createTextMessage();
				JAXBContext c;
				Message msg = null;
				try {

					msg = JMSUtil.createAndSetPayload(writeProduct(message), session, "text");
					
					msg.setStringProperty("org.apache.cxf.request.uri",
							"/receiveMessage");
					msg.setStringProperty("org.apache.cxf.request.method", "GET");
					
				} catch (JAXBException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				return msg;
			}

			private String  writeProduct(Product b) throws JAXBException {
				JAXBContext c = JAXBContext
						.newInstance(new Class[] { Product.class });
				Marshaller m = c.createMarshaller();
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				m.marshal(b, bos);
				return bos.toString();
			}

		});

	}

}