package omni.activemq.service;

import javax.jms.JMSException;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import omni.activemq.bean.Product;
import omni.activemq.util.SimpleMessageProducer;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//http://www.vogella.com/tutorials/REST/article.html
@Component
@Path("/")
public class JMSService {

	final static Logger logger = Logger.getLogger(JMSService.class);

	@Autowired
	SimpleMessageProducer producer;

	@GET
	@Produces("application/json")
	public String defaultService() {
		return "Default";
	}

	@GET
	@Path("/sendMessage")
	@Produces("application/json")
	@Consumes({ "application/xml", "application/json",
			"application/x-www-form-urlencoded" })
	public String sendMessage(@QueryParam("message") String message) {
		try {
			logger.info("Sending the MQ Message");
			Product prd = new Product("1", message);
			prd.setProductID("1");
			prd.setProductName(message);
			producer.sendMessages(prd);
		} catch (JMSException e) {
			e.printStackTrace();
		}
		return message;
	}

	 @GET
	 @Path("/receiveMessage")
	 @Consumes(MediaType.TEXT_XML)
	 @Produces(MediaType.TEXT_XML)
	 public String executeRestService(Product prd) {
	 String id = "DON";
	 logger.info("Received the Message" +prd.getProductName());
	 return id;
	 }

}
