import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { ITestCase } from './testcase';
import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http';

@Injectable()
export class TestCaseService {
    private _producturl = 'api/testCaseList.json';
     constructor(private _http: Http){ } 
 
     getTestCases(): Observable<ITestCase[]> {
 
         let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
   
         return this._http.post(this._producturl, JSON.stringify({ currentPage: 1 }), options)
            .map((response: Response) => <ITestCase[]>response.json())
            .do(data => console.log(JSON.stringify(data)));
     
}
     }