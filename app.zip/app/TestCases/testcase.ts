export interface ITestCase {
   TestCaseId: string;
   testCaseTitle: string;
}
