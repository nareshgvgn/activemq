import { Component } from '@angular/core';

import { ITestCase } from './TestCases/testcase';
import { TestCaseService } from './TestCases/testcase.service';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Component({
    selector: 'my-app',
    template: `<h1>Hello {{name}}</h1> <br/><input type="text" [(ngModel)] = "name"/>`,
    providers: [TestCaseService]
})
export class AppComponent {
        name = 'Angular';
    iTestCases: ITestCase[];
    constructor(private _testCase: TestCaseService) {
    }

    ngOnInit(): void {
        this._testCase.getTestCases()
            .subscribe(iTestCases => this.iTestCases = iTestCases);
    }

}
