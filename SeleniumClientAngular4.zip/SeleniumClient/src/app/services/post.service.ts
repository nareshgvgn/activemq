import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import {TestrunModel} from './../testrunmodel';
import {Observable} from 'rxjs/observable';
import 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class PostService {

  constructor(private http: HttpClient) { }

  postTestrun(requestModel:any) : Observable<TestrunModel[]>
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'my-auth-token'
      })
    };
    return this.http.post('http://192.168.100.118:8080/SeleniumClient/testCaseList.json',requestModel,httpOptions)
    .map(res => res['list'] || {});
    
  }
}
