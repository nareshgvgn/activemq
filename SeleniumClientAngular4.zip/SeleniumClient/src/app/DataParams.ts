export class DataParams{
    public currentPage : string;
    constructor (currentPage:string){
        this.currentPage=currentPage;
    }
}