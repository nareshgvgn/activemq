import { RouterModule, Routes } from '@angular/router';
/*
 * Customer Files Starts
 */
import { AppComponent } from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { TestcaseComponent } from './components/testcase/testcase.component';
import { TestrunComponent } from './components/testrun/testrun.component';

const appRoutes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'testcases', component: TestcaseComponent }, //always last
  { path: 'testrun', component: TestrunComponent },
];

export const AppRouting = RouterModule.forRoot(appRoutes, { 
  useHash: true
});
