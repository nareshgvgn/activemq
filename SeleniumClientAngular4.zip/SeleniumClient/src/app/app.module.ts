import { PostService } from './services/post.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRouting } from './app.routing';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';

/*
 * Customer Files Starts
 */
import { AppComponent } from './app.component';
import { HeaderbarComponent } from './components/headerbar/headerbar.component';
import { SidemenubarComponent } from './components/sidemenubar/sidemenubar.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { TestcaseComponent } from './components/testcase/testcase.component';
import { TestrunComponent } from './components/testrun/testrun.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderbarComponent,
    SidemenubarComponent,
    DashboardComponent,
    TestcaseComponent,
    TestrunComponent
  ],
  imports: [
    BrowserModule,
    AppRouting,
    HttpClientModule,
    AgGridModule.withComponents([])

  ],
  providers: [
    PostService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
