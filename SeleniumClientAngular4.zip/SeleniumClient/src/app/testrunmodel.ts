export class TestrunModel{
    testCaseId :string;
    testCaseTitle :string;
    testcaseDescription :string;
    testcaseComponent :string;
    testcaseTestSteps :string;

    constructor(testCaseId : string,testCaseTitle : string, testcaseDescription : string,  
        testcaseComponent : string, testcaseTestSteps : string){
            this.testCaseId =testCaseId;
            this.testCaseTitle = testCaseTitle;
            this.testcaseDescription = testcaseDescription;
            this.testcaseComponent = testcaseComponent;
            this.testcaseTestSteps = testcaseTestSteps;
    }
}

