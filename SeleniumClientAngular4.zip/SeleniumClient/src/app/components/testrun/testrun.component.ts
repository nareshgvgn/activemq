import { TestrunModel } from './../../testrunmodel';
import { PostService } from './../../services/post.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { AgGridNg2 } from 'ag-grid-angular';
import {DataParams} from './../../DataParams';

@Component({
  selector: 'app-testrun',
  templateUrl: './testrun.component.html',
  styleUrls: ['./testrun.component.css']
})
export class TestrunComponent implements OnInit {

  private testrunmodel : TestrunModel[];
  @ViewChild('agGrid') agGrid: AgGridNg2;
  
  columnDefs = [
    {headerName: 'Action',checkboxSelection: true },
    {headerName: 'Test Case Id', field: 'testCaseId'},
    {headerName: 'Title', field: 'testCaseTitle' },
    {headerName: 'Description', field: 'testcaseDescription'},
    {headerName: 'Component', field: 'testcaseComponent' },
    {headerName: 'Test Steps', field: 'testcaseTestSteps' }
    ];

  rowData: any;
  dataparam : DataParams;
  constructor(private http: HttpClient,
              private postService : PostService            
  ) { 
      this.dataparam =  new DataParams('1');
  }

  ngOnInit() {
  
  this.setTestRunDataToGrid();
     
//this.rowData = [{"recordId":"46674671-0","version":0,"testCaseIds":null,"type":"TESTCASE","testCaseId":"CTEST","priority":0,"moduleName":"view","testDesinedBy":"Naresh","testCaseTitle":"Chinmay Test","testcaseDescription":"Added by Chinmay","testcasesPreExecute":[],"projectId":"PRJ001","projectName":"GCP","sequenceNo":null,"lstTestSteps":[{"recordId":"ab0c14e8-0","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"1","testCaseId":null,"sequenceNo":1,"keyword":"GOTOURL","description":"Opening URL","inputData":"http://192.168.100.7:8080/gcpuscashadmin/loginform.action","objectName":"","objectType":"LINK","parentRecordKey":"46674671-0"},{"recordId":"c3b089bf-0","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"2","testCaseId":null,"sequenceNo":2,"keyword":"WAITFORPAGELOAD","description":"wait added","inputData":"10","objectName":"wait","objectType":null,"parentRecordKey":"46674671-0"},{"recordId":"f016f518-0","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"3","testCaseId":null,"sequenceNo":3,"keyword":"SETTEXT","description":"set username","inputData":"admin1","objectName":"txtUser","objectType":"ID","parentRecordKey":"46674671-0"},{"recordId":"09d0575e-0","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"4","testCaseId":null,"sequenceNo":4,"keyword":"CLICK","description":"click on login button","inputData":null,"objectName":"btnLogin","objectType":"ID","parentRecordKey":"46674671-0"}]},{"recordId":"887f477f-5","version":0,"testCaseIds":null,"type":"TESTCASE","testCaseId":"TST001","priority":0,"moduleName":"Security","testDesinedBy":"Naresh","testCaseTitle":"User Category List","testcaseDescription":"User Category List","testcasesPreExecute":[],"projectId":null,"projectName":null,"sequenceNo":null,"lstTestSteps":[{"recordId":"887f477f-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP001","testCaseId":null,"sequenceNo":1,"keyword":"GOTOURL","description":"Go to Login Page","inputData":"${baseUrl}/gcpuscash/loginform.action","objectName":null,"objectType":null,"parentRecordKey":"887f477f-5"},{"recordId":"9b2743af-5","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP002","testCaseId":null,"sequenceNo":2,"keyword":"SETTEXT","description":"Set text in User Code","inputData":"MARK","objectName":"txtUser","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"dce83836-5","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP003","testCaseId":null,"sequenceNo":3,"keyword":"CLICK","description":"Click on Login Button","inputData":"","objectName":"btnLogin","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"fc5c75b1-5","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP004","testCaseId":null,"sequenceNo":4,"keyword":"GOTOURL","description":"Goto Role List","inputData":"${baseUrl}/gcpuscash/userAdminCategoryList.form","objectName":null,"objectType":null,"parentRecordKey":"887f477f-5"},{"recordId":"3b9bd9f0-5","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP005","testCaseId":null,"sequenceNo":5,"keyword":"FILTER_EXT_AUTOCOMPLETER","description":"Filter Auto Completer","inputData":"Code:GULFROLE2","objectName":null,"objectType":null,"parentRecordKey":"887f477f-5"},{"recordId":"f1620983-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP006","testCaseId":null,"sequenceNo":6,"keyword":"CLICK","description":"CLick Create role Button","inputData":null,"objectName":"addNewUserCategoryT4","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"1696e7f3-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP010","testCaseId":null,"sequenceNo":7,"keyword":"WAITFORPAGELOAD","description":"Wait for Page Load","inputData":null,"objectName":null,"objectType":null,"parentRecordKey":"887f477f-5"},{"recordId":"42538a1b-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP007","testCaseId":null,"sequenceNo":8,"keyword":"SETTEXT","description":"Set Role ID","inputData":"NAR_ROLE_2","objectName":"roleId","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"5c814121-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP008","testCaseId":null,"sequenceNo":9,"keyword":"SETTEXT","description":"Set Role Description","inputData":"Naresh Role 1","objectName":"roleDesc","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"d0c56e88-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP009","testCaseId":null,"sequenceNo":10,"keyword":"JQUERY_MULTISEL_CHECKALL","description":"Check All Subsidiries","inputData":null,"objectName":"subsidiaries","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"d756c196-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP011","testCaseId":null,"sequenceNo":11,"keyword":"WAITFORPAGELOAD","description":"Wait for Page","inputData":null,"objectName":null,"objectType":null,"parentRecordKey":"887f477f-5"},{"recordId":"ba97df43-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP012","testCaseId":null,"sequenceNo":12,"keyword":"CLICK","description":"CLick Save Button","inputData":null,"objectName":"saveUpdate","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"daa2a6e2-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP013","testCaseId":null,"sequenceNo":13,"keyword":"WAITFORPAGELOAD","description":"Wait","inputData":null,"objectName":null,"objectType":null,"parentRecordKey":"887f477f-5"},{"recordId":"e80f0bb6-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP014","testCaseId":null,"sequenceNo":14,"keyword":"CLICK","description":"Click on next button","inputData":null,"objectName":"Next","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"69c629f4-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP015","testCaseId":null,"sequenceNo":15,"keyword":"WAITFORPAGELOAD","description":"Wait","inputData":null,"objectName":null,"objectType":null,"parentRecordKey":"887f477f-5"},{"recordId":"c1930b15-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP016","testCaseId":null,"sequenceNo":16,"keyword":"CLICK","description":"Click All priviliage","inputData":null,"objectName":"prevAll_03","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"f458a565-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP017","testCaseId":null,"sequenceNo":17,"keyword":"CLICK","description":"Click the All Interface Checkbox","inputData":null,"objectName":"interfaceAll_03","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"13c96780-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP018","testCaseId":null,"sequenceNo":18,"keyword":"CLICK","description":"Click all Message","inputData":"","objectName":"messageAll_03","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"25c1340f-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP019","testCaseId":null,"sequenceNo":19,"keyword":"CLICK","description":"Click All reprots","inputData":null,"objectName":"reportsAll_03","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"4126c036-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP020","testCaseId":null,"sequenceNo":20,"keyword":"CLICK","description":"Click save and verify Button","inputData":null,"objectName":"saveAndVerify","objectType":"ID","parentRecordKey":"887f477f-5"},{"recordId":"d50c51d5-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP021","testCaseId":null,"sequenceNo":21,"keyword":"WAITFORPAGELOAD","description":"Wait","inputData":"55000","objectName":null,"objectType":null,"parentRecordKey":"887f477f-5"},{"recordId":"5e3bb293-6","version":0,"testCaseIds":null,"type":"TESTSTEP","testStepId":"TSP022","testCaseId":null,"sequenceNo":22,"keyword":"CLICK","description":"CLick on Submit","inputData":null,"objectName":"submit","objectType":"ID","parentRecordKey":"887f477f-5"}]}];
  }
  setTestRunDataToGrid(){
    this.postService.postTestrun( this.dataparam).subscribe(testrunmodel =>{
      this.testrunmodel = testrunmodel;
      console.log(this.testrunmodel);
      this.rowData = this.testrunmodel;
    });
  }
  getSelectedRowsAndRun() {
    const selectedNodes = this.agGrid.api.getSelectedNodes();
    const selectedData = selectedNodes.map( node => node.data );
    const selectedDataStringPresentation = selectedData.map( node => node.testCaseId + ' ' + node.testCaseTitle).join(', ');
    alert(`Selected nodes: ${selectedDataStringPresentation}`);
  }

}
