import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidemenubar',
  templateUrl: './sidemenubar.component.html',
  styleUrls: ['./sidemenubar.component.css']
})
export class SidemenubarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
