package com.javainuse.websocket.rest;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class Resource {

}
