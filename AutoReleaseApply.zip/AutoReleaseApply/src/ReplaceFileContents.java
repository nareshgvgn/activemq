import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReplaceFileContents {

	private String rootPath = "D:/Backendrelease/HOTFIX_DE35688/Backend/Install/";

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public void replace(List<String> variables) {
		String oldFileName = "define.sql";
		String tmpFileName = "define_new.sql";

		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			br = new BufferedReader(new FileReader(rootPath + oldFileName));
			bw = new BufferedWriter(new FileWriter(rootPath + tmpFileName));
			String line;
			while ((line = br.readLine()) != null) {
//				if (line.contains("1313131"))
//					line = line.replace("1313131", "" + System.currentTimeMillis());
				bw.write(line + "\n");
			}
			
			for(String s : variables)
			{
				bw.write(s + "\n");
			}
			
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException e) {
				System.out.println(e);
			}
			try {
				if (bw != null)
					bw.close();
			} catch (IOException e) {
				System.out.println(e);
			}
		}
		// Once everything is complete, delete old file..
		File oldFile = new File(rootPath + oldFileName);
		oldFile.delete();

		// And rename tmp file's name to old file name
		File newFile = new File(rootPath + tmpFileName);
		newFile.renameTo(oldFile);

	}

	public static void main(String a[]) {
		
		ReplaceFileContents fileConents = new ReplaceFileContents();
		List<String> varList = new ArrayList<String>();
		varList.add("DEF seller_code = 'TH'");
		varList.add("DEF p_maker_code = 'TCITEST1'");
		varList.add("DEF p_checker_code = 'TCITEST2'");
		varList.add("DEF disp_bank_cd = 'UBPTH'");
		fileConents.replace(varList);
	}
}