import java.io.FileWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/*----------------------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : 
 * FILE     : ReadDataFromResponse.java
 * CREATED  : Dec 20, 2017 2:45:23 PM
 * AUTHOR   : nmahajan
 *--------------------------------------------------------------------------------------------------------------------------------*/

public class ReadDataFromResponse {

	public static void main(String[] args) {

	}

	public static List<FileData> readFiles(String response) {

		 // For Testing
		 	try
		 	{
		 		FileWriter fw = new FileWriter("/home/ftdbuser/ScheduleBackEndrelease/fw.log");
		 		fw.write(response);
		 		fw.close();
		 	}
		 	catch(Exception ex){
		 		
		 	}
			
		 //
		
		
		String excludekeywords = "Parent Directory,Name,Last modified,Size,	Description";
		List<FileData> fileList = new ArrayList<FileData>();
		Document doc = Jsoup.parse(response);
		Element table = doc.select("table").first();

		Elements rows = table.select("tr");

		Elements columns = null;
		FileData fileData = null;
		try {
			for (Element row : rows) {
				fileData = new FileData();
				if (row.select("td").size() > 0) {

					if (row.selectFirst("td").html().contains("/icons/compressed.gif")) {
						columns = row.select("td");

						Element column = row.selectFirst("td");
						if (column.html().contains("/icons/compressed.gif")) {
							column = column.nextElementSibling();
							if (column.html().contains("href")) {
								Element aElement = column.selectFirst("a");
								fileData.setFileName(aElement.html());
								column = column.nextElementSibling();
								fileData.setCreationDate(formatDate(column.html()));
								column = column.nextElementSibling();
								fileData.setFileZise(formatFileSize(column.html()));
							}
						}
						if (fileData != null && null != fileData.getFileName() && null != fileData.getCreationDate()) {
							fileList.add(fileData);
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return fileList;
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param html
	 * @return
	 * </pre></p>
	 */
	private static Double formatFileSize(String html) {
		int multiplier = 1;
		if(html.contains("G"))
		{
			multiplier = 1000000;
		}
		else if(html.contains("M"))
		{
			multiplier = 1000;
		}
		else if(html.contains("K"))
		{
			multiplier = 1;
		}
		html = html.replace("G", "");
		html = html.replace("M", "");
		html = html.replace("K", "");
		return Double.valueOf(html) * multiplier;
	}

	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style=
	 * "padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;"
	 * >
	 * &#64;param html
	 * &#64;return
	 * </pre>
	 * </p>
	 */
	private static Date formatDate(String strDate) {
		// 19-Dec-2017 15:30
		SimpleDateFormat sd = new SimpleDateFormat("d-MMM-yyyy HH:mm");
		try {
			return sd.parse(strDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
