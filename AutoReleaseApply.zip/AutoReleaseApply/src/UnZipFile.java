import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/*----------------------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : 
 * FILE     : UnZipFile.java
 * CREATED  : Dec 20, 2017 8:20:40 PM
 * AUTHOR   : nmahajan
 *--------------------------------------------------------------------------------------------------------------------------------*/

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style=
 * "padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;"
 * >
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre>
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style=
 * "background-color:white;border:1px solid silver;border-collapse:collapse;"
 * cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration
 * File</td>
 * <td style="border:1px dotted silver;">
 * <code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author nmahajan
 * @version $Id$
 */
public class UnZipFile {
	public static void main(String[] args) {
		UnZipFile ob = new UnZipFile();
		String zipFilePath = "D:/Shared/selenium-node.zip";

		String destDir = "D:/Shared";

		try {
			ob.unzip(zipFilePath, destDir);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
//		Properties ps = new Properties();
//		try {
//			ps.load(new FileInputStream(new File("config.properties")));
//			System.out.println(ps.getProperty("FTPBASEURL"));
//		} catch (FileNotFoundException e1) {
//			System.out.println(e1);
//		} catch (IOException e1) {
//			System.out.println(e1);
//		}
	}

	/**
	 * Size of the buffer to read/write data
	 */
	private static final int BUFFER_SIZE = 4096;

	/**
	 * Extracts a zip file specified by the zipFilePath to a directory specified
	 * by destDirectory (will be created if does not exists)
	 * 
	 * @param zipFilePath
	 * @param destDirectory
	 * @throws IOException
	 */
	public void unzip(String zipFilePath, String destDirectory) throws IOException {
		ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
		ZipEntry entry = zipIn.getNextEntry();
		destDirectory = destDirectory.replaceAll(".zip", "");
		File destDir = new File(destDirectory);
		if (!destDir.exists()) {
			destDir.mkdir();
		}
		// iterates over entries in the zip file
		while (entry != null) {
			String filePath = destDirectory + File.separator + entry.getName();
			if (!entry.isDirectory()) {
				// if the entry is a file, extracts it
				extractFile(zipIn, filePath);
			} else {
				// if the entry is a directory, make the directory
				File dir = new File(filePath);
				dir.mkdir();
			}
			zipIn.closeEntry();
			entry = zipIn.getNextEntry();
		}
		zipIn.close();
	}

	/**
	 * Extracts a zip entry (file entry)
	 * 
	 * @param zipIn
	 * @param filePath
	 * @throws IOException
	 */
	private void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
		byte[] bytesIn = new byte[BUFFER_SIZE];
		int read = 0;
		while ((read = zipIn.read(bytesIn)) != -1) {
			bos.write(bytesIn, 0, read);
		}
		bos.close();
	}
}
