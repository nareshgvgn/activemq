import java.math.BigDecimal;
import java.util.Date;

/*----------------------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : 
 * FILE     : FileData.java
 * CREATED  : Dec 20, 2017 3:21:52 PM
 * AUTHOR   : nmahajan
 *--------------------------------------------------------------------------------------------------------------------------------*/

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style=
 * "padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;"
 * >
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre>
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style=
 * "background-color:white;border:1px solid silver;border-collapse:collapse;"
 * cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration
 * File</td>
 * <td style="border:1px dotted silver;">
 * <code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author nmahajan
 * @version $Id$
 */
public class FileData {

	private String fileName;
	private Date creationDate;
	private Double fileZise;

	public Double getFileZise() {
		return fileZise;
	}

	public void setFileZise(Double fileZise) {
		this.fileZise = fileZise;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

}
