import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;

/*----------------------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : 
 * FILE     : AutoreleaseApply.java
 * CREATED  : Dec 20, 2017 12:10:22 PM
 * AUTHOR   : nmahajan
 *--------------------------------------------------------------------------------------------------------------------------------*/

/**
 * <p>
 * Class for Scan the DB release and apply on database
 * <h3>Configuration</h3>
 * 
 * <pre style=
 * "padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;"
 * >
 * </pre>
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style=
 * "background-color:white;border:1px solid silver;border-collapse:collapse;"
 * cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration
 * File</td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author nmahajan
 * @version $Id$
 */
public class AutoReleaseApply {
	public static void main(String a[]) {
		String localDownloadDirPath = "D:/Backendrelease";
		Properties ps = new Properties();
		try {
			ps.load(new FileInputStream(new File("config.properties")));
		} catch (FileNotFoundException e1) {
			System.out.println(e1);
		} catch (IOException e1) {
			System.out.println(e1);
		}
		
		String directory = "";
		try {
			Date today = new Date();
			today.setHours(0);
			today.setMinutes(0);
			today.setSeconds(0);
			localDownloadDirPath = ps.getProperty("LOCALRELEASEDWNDIR");
			FileUtils.cleanDirectory(new File(localDownloadDirPath));
			List<FileData> files = HttpDownloadUtility.listDirectories(ps.getProperty("FTPURL"));
			UnZipFile unzipFile = new UnZipFile();
			ReplaceFileContents fileConents = new ReplaceFileContents();
			List<String> varList = readDynamicVariableList(ps);
			InvokeSqlPlusCmd invoke = new InvokeSqlPlusCmd();
			String[] schemaList = getSchemaList(ps);
			for (FileData releaseFile : files) {
				if (releaseFile.getCreationDate().compareTo(today) > 0 && releaseFile.getFileZise() < 10000) // Logical
																												// Value
				{
					HttpDownloadUtility.downloadFile(ps.getProperty("FTPBASEURL") + releaseFile.getFileName(),
							localDownloadDirPath);
					unzipFile.unzip(localDownloadDirPath + "/" + releaseFile.getFileName(),
							localDownloadDirPath + "/" + releaseFile.getFileName());
					directory = releaseFile.getFileName().replaceAll(".zip", "");
					fileConents.setRootPath(localDownloadDirPath+"/" + directory + "/Backend/Install/");
					fileConents.replace(varList);
					//invoke.runScript("cd "+localDownloadDirPath+"/" + directory + "/Backend/Install/");
					//Runtime.getRuntime().exec("/bin/bash cd "+localDownloadDirPath+"/" + directory + "/Backend/Install/");
					for(String schema : schemaList){
						invoke.runScript(ps, localDownloadDirPath+"/" + directory + "/Backend/Install", schema, releaseFile.getFileName(), localDownloadDirPath+"/" + directory + "/Backend/Logs/logs.zip");
					}
				}
			}
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param ps
	 * @return
	 * </pre></p>
	 */
	private static List<String> readDynamicVariableList(Properties ps) 
	{
		Set<Object> keys = ps.keySet();
		List<String> mailList = new ArrayList<String>();
		for(Object key : keys)
		{
			if(key.toString().contains("release.definedvariables"))
			{
				mailList.add(ps.getProperty(key.toString()));
			}
		}
		return mailList;
	}

	private static String[] getSchemaList(Properties ps) throws FileNotFoundException, IOException
	{
		Set<Object> keys = ps.keySet();
		List<String> mailList = new ArrayList<String>();
		for(Object key : keys)
		{
			if(key.toString().contains("SCHEMACONNECTURL"))
			{
				mailList.add(ps.getProperty(key.toString()));
			}
		}
		
		String arry[] = new String[mailList.size()];
		
		for(int i= 0; i < mailList.size(); i++)
		{
			arry[i] = mailList.get(i);
		}
		return arry;
	}
}
