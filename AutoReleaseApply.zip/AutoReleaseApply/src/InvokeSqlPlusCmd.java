import java.io.IOException;
import java.util.Properties;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
/*----------------------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : 
 * FILE     : InvokeSqlPlusCmd.java
 * CREATED  : Dec 21, 2017 6:00:02 PM
 * AUTHOR   : nmahajan
 *--------------------------------------------------------------------------------------------------------------------------------*/

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author nmahajan
 * @version $Id$
 */
public class InvokeSqlPlusCmd {

	int iExitValue;
    String sCommandString;

    public void runScript(Properties config, String changeDirectory, String schemaConnectUrl, String fileName, String logDirectoryPath){
    	
        sCommandString = config.getProperty("EXECUTIONFILE");
        CommandLine oCmdLine = CommandLine.parse(sCommandString+" "+changeDirectory+" "+schemaConnectUrl+" "+config.getProperty("BASEPATH") +" "+ fileName+" "+logDirectoryPath);
        DefaultExecutor oDefaultExecutor = new DefaultExecutor();
        oDefaultExecutor.setExitValue(0);
        try {
            iExitValue = oDefaultExecutor.execute(oCmdLine);
        } catch (ExecuteException e) {
            System.err.println("Execution failed.");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("permission denied.");
            e.printStackTrace();
        }
    }
    
    public void runScript(String sCommandString){
    	
        CommandLine oCmdLine = CommandLine.parse(sCommandString);
        DefaultExecutor oDefaultExecutor = new DefaultExecutor();
        oDefaultExecutor.setExitValue(0);
        try {
            iExitValue = oDefaultExecutor.execute(oCmdLine);
        } catch (ExecuteException e) {
            System.err.println("Execution failed.");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("permission denied.");
            e.printStackTrace();
        }
    }

    public static void main(String args[]){
    	InvokeSqlPlusCmd testScript = new InvokeSqlPlusCmd();
    	Properties config = new Properties();
    	config.put("EXECUTIONFILE", "sh /home/ftdbuser/ScheduleBackEndrelease/installDBRelease.sh");
    	//Accessible in Sh File as $1 : /home/ftdbuser/ScheduleBackEndrelease/installDBRelease.sh
    	//$2 : TTPREQC45NONUS/TTPREQC45NONUS@ORCL
    	//
        testScript.runScript(config, "", "", "", "");
    }
}
