package com.selenium.controller;

import com.selenium.bean.CommonFilterBean;

public class TestCaseFilter extends CommonFilterBean{
	String testCaseId;

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}
	
}
