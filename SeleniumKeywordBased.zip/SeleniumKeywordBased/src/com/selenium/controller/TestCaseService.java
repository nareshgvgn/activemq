package com.selenium.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.selenium.bean.ActionResult;
import com.selenium.bean.TestCaseBean;
import com.selenium.dao.TestCaseDao;

@RestController
public class TestCaseService {

	@Autowired
	private TestCaseDao testCaseDao;
	
	@RequestMapping("/addTestCase.json")
	public @ResponseBody ActionResult addTestCase(@RequestBody TestCaseBean testCaseBean)
	{
		testCaseDao.addRecord(testCaseBean);
		return null;
		
	}
	
	@RequestMapping("/testCaseList.json")
	public @ResponseBody Map<String,Object> testCaseList(TestCaseFilter testCaseFilterBean)
	{
		Map<String,Object> result = new HashMap<String, Object>();
		List<TestCaseBean> list = new ArrayList<TestCaseBean>();
		list = testCaseDao.readTestCaseList(testCaseFilterBean);
		result.put("list",list);
		result.put("totalRows",list.size());
		return result;
		
	}
	
}
