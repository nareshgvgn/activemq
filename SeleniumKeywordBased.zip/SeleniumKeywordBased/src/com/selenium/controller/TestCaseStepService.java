package com.selenium.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.selenium.bean.ActionResult;
import com.selenium.bean.TestCaseBean;
import com.selenium.bean.TestCaseStep;
import com.selenium.dao.TestCaseDao;
import com.selenium.dao.TestCaseStepDao;

@RestController
public class TestCaseStepService {

	@Autowired
	private TestCaseStepDao testCaseStepDao;
	
	@RequestMapping("/addTestCaseStep.json")
	public @ResponseBody ActionResult addTestCase(@RequestBody TestCaseStep testCaseBean)
	{
		testCaseStepDao.addRecord(testCaseBean);
		return null;
		
	}
	
	@RequestMapping("/testCaseStepList.json")
	public @ResponseBody Map<String,Object> testCaseList(@RequestBody TestCaseFilter testCaseFilterBean)
	{
		Map<String,Object> result = new HashMap<String, Object>();
		List<TestCaseStep> list = new ArrayList<TestCaseStep>();
		list = testCaseStepDao.readTestCaseSteps(testCaseFilterBean.getTestCaseId());
		result.put("list",list);
		result.put("totalRows",list.size());
		return result;
	}
	
}

