'use strict';

/* Services */


// Demonstrate how to register services
// In this case it is a simple value service.
angular.module('seleniumAutomationApp.services', ['ngResource']).
   factory('holidayService', [ '$resource', function($resource){
        return $resource('/holidayList', {}, {
            query: {method:'POST',q: '*',isArray:true}
        });
    }])
    .service('testCaseService', [ '$resource','$filter','$http', function($resource, $filter, $http){

        this.getList = function () {
            return $resource('userLeavesOfCurrentYear', {}, {
                query: {method: 'POST', q: '*', isArray: true}
            }).query();
        }

    }]);