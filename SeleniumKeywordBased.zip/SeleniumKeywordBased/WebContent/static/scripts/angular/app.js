'use strict';

/** 
 * Declare's application level module which depends on directives, controllers, filters and services 
*/
var app = angular.module('seleniumAutomationApp', [ 'ui.router','ui.bootstrap','seleniumAutomationApp.filters',
    'seleniumAutomationApp.directives', 'seleniumAutomationApp.controllers','seleniumAutomationApp.services',
    'smart-table','daterangepicker','am.multiselect','toaster','ngAnimate','ui.calendar','angular-loading-bar','mgcrea.ngStrap.popover']);

/**
 * Application route configuration
 */
app.config(function($stateProvider, $urlRouterProvider) {
    //
    // For any unmatched url, redirect to /state1
       //
    $urlRouterProvider.otherwise('dashBoard');
    $stateProvider
        .state('dashBoard', {
        	url : '/dashBoard',
           templateUrl: "static/partials/dashBoard.html",
            controller : 'dashboardController'
        })
        .state('testCase', {
            url :'/testCase',
            templateUrl: "static/partials/testCase.html",
        })
        .state('testCase.list', {
            url :'/testCaselist',
            templateUrl: "static/partials/testCaseList.html",
            controller: 'TestCaseListController'
        })
        .state('testRun', {
            url :'/testRun',
            templateUrl: "static/partials/testRun.html",
            controller: 'TestRunService'
        })
        .state('testRun.list', {
            url :'/testRunlist',
            templateUrl: "static/partials/testRunList.html",
            controller: 'TestRunListController'
        })
        .state('addTestCase', {
            url :'/addTestCase',
            templateUrl: "static/partials/addTestCase.html",
            controller: 'TestCaseListController'
        })
        .state('testCaseStepList', {
            url :'/testCaseStepList/:testCaseID',
            templateUrl: "static/partials/TestCaseStepList.html",
            controller: 'TestCaseStepListController'
        })

});


app.config(function ($httpProvider, $provide) {
    $provide.factory('myHttpInterceptor', function ($q, $location, $injector) {
        return {
            'request': function(config) {
                $('#Searching_Modal').modal('show');
                return config;
            },

            // optional method
            'requestError': function(rejection) {
                // do something on error
                if (canRecover(rejection)) {
                    return responseOrNewPromise
                }
                return $q.reject(rejection);
            },
            'response': function (response) {
                console.log("In Response");
                //you can handle you sucess response here.
                return response;
            },
            'responseError': function (rejection) {

              //  $state.go("sessionExpired",{}, {reload: true, inherit: false});
                    $('body').html(rejection.data);

            }
        };
    });
    $httpProvider.interceptors.push('myHttpInterceptor');
});

app.config(['cfpLoadingBarProvider', function(cfpLoadingBarProvider) {
    //cfpLoadingBarProvider.spinnerTemplate = '<div><span class="fa fa-spinner">Loading...</div>';
}]);