'use strict';

/**
 * Module listing all application Controllers
 */
angular.module('seleniumAutomationApp.controllers', []).controller(
		'MainController',
		[
				'$scope',
				'$location',
				'$anchorScroll',
				'holidayService',
				'$http',
				function($scope, $location, $anchorScroll, holidayService,
						$http) {
					$scope.menuList = [
					 {"id": "dashBoard", "name"
					 :"Dashboard","target":"dashBoard","class"
					 : "active"},
					{
						"id" : "testCases",
						"name" : "Test Case",
						"target" : "testCase.list",
						"class" : ""
					},
					{
						"id" : "testResults",
						"name" : "Test Results",
						"target" : "testResults.list",
						"class" : ""
					},
					{
						"id" : "testRun",
						"name" : "Test Run",
						"target" : "testRun.list",
						"class" : ""
					}];
					
					
					$scope.selectedMenu = $scope.menuList[0];

			        $scope.toggleMenu = function(id)
			        {
			            $scope.activeMenu = id;
			        };
					
				} ])
				
.controller('dashboardController',
		[ '$scope', '$location', '$state', function($scope, $location, $state) {
			
			
		} ])

.controller(
		'TestCaseListController',
		[ '$scope', '$location', 'testCaseService','$http',
				function($scope, $location, testCaseService, $http) {
			
			$scope.testCaseInfo = {};
			$scope.headers = [
			                  {
			                      label: 'Actions',
			                      width : '10'

			                  },{
			                      label: 'Test Case ID',
			                      width : '13'

			                  },{
			                      label: 'Title',
			                      width : '12'
			                  },{
			                      label: 'Description',
			                      width : '16'
			                  },{
			                      label: 'Project',
			                      width : '10'
			                  },{
			                      label: 'Component',
			                      width : '10'
			                  },{
			                      label: 'Test Steps',
			                      width : '15'
			                  }

			              ];
			
			$scope.listTestCase = function()
			{
			    $http.post("testCaseList.json",$scope.testCaseInfo).success( function(response) {
			        $scope.contents = response.list;
			        $scope.totalItems = response.totalRows;
			    });

			    //$scope.contents = leaveService.searchLeaves($scope.leaveInfo);
			};
			
			$scope.addTestCase = function(){
				$http.post("addTestCase.json",$scope.testCaseInfo).success( function(response) {
			    });
			};
			
			$scope.listTestCase();
			
				} ])
.controller(
		'TestRunService',
		[ '$scope', '$location', 'testCaseService','$http',
				function($scope, $location, testCaseService, $http) {
			
			
			$scope.startTestRun = function(){
				 $http.post("startTestRun.json",$scope.testRunInfo).success( function(response) {
				    });
			};
		}])
.controller(
		'TestRunListController',
		[ '$scope', '$location', 'testCaseService','$http',
				function($scope, $location, testCaseService, $http) {
			
			$scope.testRunInfo = {};
			$scope.headers = [
			                  {
			                      label: 'Actions',
			                      width : '10'

			                  },{
			                      label: 'Test Case ID',
			                      width : '13'

			                  },{
			                      label: 'Title',
			                      width : '12'
			                  },{
			                      label: 'Description',
			                      width : '16'
			                  },{
			                      label: 'Project',
			                      width : '10'
			                  },{
			                      label: 'Component',
			                      width : '10'
			                  },{
			                      label: 'Test Steps',
			                      width : '15'
			                  }

			              ];
			
			$scope.listTestCase = function()
			{
			    $http.post("testCaseList.json",$scope.testRunInfo).success( function(response) {
			        $scope.contents = response.list;
			        $scope.totalItems = response.totalRows;
			    });

			};
			
			$scope.startTestRun = function(){
				 $http.post("startTestRun.json",$scope.testRunInfo).success( function(response) {
				    });
			};
			
			$scope.listTestCase();
			
				} ])
.controller(
		'TestCaseStepListController',
		[ '$scope', '$location', 'testCaseService','$http','$stateParams',
				function($scope, $location, testCaseService, $http, $stateParams) {
			
			$scope.testRunInfo = {};
			$scope.testRunInfo.testCaseId = $stateParams.testCaseID;
			$scope.headers = [
			                  {
			                      label: 'Actions',
			                      width : '10'

			                  },{
			                      label: 'TestCase Step ID',
			                      width : '13'

			                  },{
			                      label: 'Sequence No',
			                      width : '13'

			                  },{
			                      label: 'Keyword',
			                      width : '12'
			                  },{
			                      label: 'Description',
			                      width : '16'
			                  },{
			                      label: 'Input Data',
			                      width : '10'
			                  },{
			                      label: 'Object Name',
			                      width : '10'
			                  },{
			                      label: 'Object Type',
			                      width : '15'
			                  }

			              ];
			
			$scope.listTestCaseSteps = function()
			{
			    $http.post("testCaseStepList.json",$scope.testRunInfo).success( function(response) {
			        $scope.contents = response.list;
			        $scope.totalItems = response.totalRows;
			    });

			    //$scope.contents = leaveService.searchLeaves($scope.leaveInfo);
			};
			
			$scope.listTestCaseSteps();
			
				} ]);

