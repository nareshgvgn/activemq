'use strict';

/** 
 * Module listing all application Filters
 */
angular.module('seleniumAutomationApp.filters', []).

/** 
 * Filter for getting tooltip for completed agents. This should be moved to directives.
 */
filter('colorFilter', [ function() {
  return function(status) {
    var bgColorClass = '';
    if(status.toUpperCase() == 'PENDING')
    {
        bgColorClass = 'md-status-pending';
    }
    else if(status.toUpperCase() == 'APPROVED')
    {
        bgColorClass = 'md-status-approved';
    }
    else if(status.toUpperCase() == 'REJECTED')
    {
        bgColorClass = 'md-status-rejected';
    }
    else if(status.toUpperCase() == 'CANCELLED')
    {
        bgColorClass = 'md-status-cancelled';
    }
    return bgColorClass;
  };
} ])
    ;

