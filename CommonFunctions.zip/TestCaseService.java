package com.selenium.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.selenium.bean.ActionResult;
import com.selenium.bean.FilterBean;
import com.selenium.bean.Operation;
import com.selenium.bean.TestCaseBean;
import com.selenium.dao.TestCaseDao;
import com.selenium.dao.UtilDao;

@RestController
public class TestCaseService {

	@Autowired
	private TestCaseDao testCaseDao;
	
	@Autowired
	UtilDao utilDao;
	
	@RequestMapping("/addTestCase.json")
	public @ResponseBody ActionResult addTestCase(@RequestBody TestCaseBean testCaseBean)
	{
		testCaseBean.setRecordId(utilDao.getUniqueId());
		testCaseBean.setTestDesinedBy("Naresh");
		testCaseDao.addRecord(testCaseBean);
		return null;
		
	}
	
	@RequestMapping("/updateTestCase.json")
	public @ResponseBody ActionResult updateTestCase(@RequestBody TestCaseBean testCaseBean)
	{
		testCaseBean.setTestDesinedBy("Naresh");
		testCaseDao.updateRecord(testCaseBean);
		return null;
		
	}
	
	@RequestMapping("/testCaseList.json")
	public @ResponseBody Map<String,Object> testCaseList(TestCaseFilter testCaseFilterBean)
	{
		Map<String,Object> result = new HashMap<String, Object>();
		List<TestCaseBean> list = new ArrayList<TestCaseBean>();
		list = testCaseDao.readTestCaseList(testCaseFilterBean);
		result.put("list",list);
		if(list != null)
		result.put("totalRows",list.size());
		return result;
		
	}
	
	@RequestMapping("/valuelist/{keyValue}.json")
	public @ResponseBody List<FilterBean> getValueList(@PathVariable String keyValue, FilterBean filterBean)
	{
		List<FilterBean> lstresults = testCaseDao.getValueList(keyValue, filterBean);
		return lstresults;
	}
	
	@RequestMapping("/keywordList.json")
	public @ResponseBody List<FilterBean> getKeywordList(FilterBean filterBean)
	{
		List<FilterBean> keywordList = new ArrayList<FilterBean>();
		Operation oprList[] = Operation.values();
		for(Operation operation : oprList)
		{
			if(operation.isExternal())
				keywordList.add(new FilterBean(operation.getCode(), operation.getDescription()));
		}
		List<FilterBean> lstresults = testCaseDao.getValueList("KEYWORD", filterBean);
		keywordList.addAll(lstresults);
		return keywordList;
	}
}
