angular.module('sbAdminApp').service('CommonUtilityService', [ function() {

	this.getTreeModelOfTestCaseList = function(testCaseList) {
		var treeModel = [];
		angular.forEach(testCaseList, function(item){
			var obj = {};
			obj.isTestCase = true;
			obj.label = item.testCaseId + ' - '+(item.testCaseTitle != null ? item.testCaseTitle : '') ;
			obj.nodeId = item.testCaseId;
			obj.detailObj = item;
			obj.children = [];
			angular.forEach(item.lstTestSteps, function(innerItem){
				var innerObj = {};
				innerObj.label = innerItem.testStepId + ' - '+(innerItem.description != null ? innerItem.description : '');
				innerObj.nodeId = innerItem.testStepId;
				innerObj.detailObj = innerItem;
				innerObj.isTestCase = false;
				obj.children.push(innerObj);
			});
			treeModel.push(obj);
		});
		return treeModel;
	};

} ]);


angular.module('sbAdminApp').factory('httpService', function($http) {
	  var promise;
	  var myService = {
			  async: function() {
	      if ( !promise ) {
	        // $http returns a promise, which has a then function, which also returns a promise
	        promise = $http.get('keywordList.json').then(function (response) {
	          // The then function here is an opportunity to modify the response
	          // The return value gets picked up by the then in the controller.
	          return response.data;
	        });
	      }
	      // Return the promise to the controller
	      return promise;
	    }
	  };
	  return myService;
	});
