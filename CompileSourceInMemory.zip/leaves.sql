/*
SQLyog Ultimate v8.55 
MySQL - 5.1.39-community 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `keyword_mst` (
	`keyword` varchar (45),
	`javacode` blob ,
	`class_name` varchar (90)
); 
insert into `keyword_mst` (`keyword`, `javacode`, `class_name`) values('CLICK_BTN','import org.openqa.selenium.By;\r\nimport org.openqa.selenium.WebDriver;\r\n\r\npublic class BtnClickHandler {\r\n	public void executeKeyword(WebDriver driver)\r\n	{\r\n		driver.findElement(By.name(\"btnI\")).click();\r\n	}\r\n}\r\n','BtnClickHandler');
