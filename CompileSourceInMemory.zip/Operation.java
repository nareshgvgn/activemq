package com.selenium.bean;

public enum Operation {
	CLICK, SETTEXT, GOTOURL, GETTEXT, CLICK_BTN, WAITFORPAGELOAD
}
