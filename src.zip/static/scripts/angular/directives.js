'use strict';

/**
 * Module listing all application Directives
 */
angular.module('seleniumAutomationApp.directives', []);

/**
 * Tooltip directive used for showing validation errors on tooltip. As soon as input error gets
 * resolved tooltip is destroyed/removed
 */
