appController.controller('dashboardController', [ '$scope', '$location',
		'$state', function($scope, $location, $state) {

		} ]);