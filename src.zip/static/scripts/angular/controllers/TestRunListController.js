appController.controller('TestRunListController', [
		'$scope',
		'$location',
		'testCaseService',
		'$http',
		function($scope, $location, testCaseService, $http) {

			$scope.testRunInfo = {};
			$scope.headers = [ {
				label : 'Actions',
				width : '10'

			}, {
				label : 'Test Case ID',
				width : '13'

			}, {
				label : 'Title',
				width : '12'
			}, {
				label : 'Description',
				width : '16'
			}, {
				label : 'Project',
				width : '10'
			}, {
				label : 'Component',
				width : '10'
			}, {
				label : 'Test Steps',
				width : '15'
			}

			];

			$scope.listTestCase = function() {
				$http.post("testCaseList.json", $scope.testRunInfo).success(
						function(response) {
							$scope.contents = response.list;
							$scope.totalItems = response.totalRows;
						});

			};

			$scope.startTestRun = function() {
				$http.post("startTestRun.json", $scope.testRunInfo).success(
						function(response) {
						});
			};

			$scope.listTestCase();

		} ]);