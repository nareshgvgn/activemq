appController.controller('AddTestCaseStepController', [
		'$scope',
		'$location',
		'testCaseService',
		'$http',
		'$stateParams',
		function($scope, $location, testCaseService, $http, $stateParams) {
			$scope.keywords = [ {
				"value" : "CLICK",
				"description" : "Click"
			}, {
				"value" : "SETTEXT",
				"description" : "Set Text"
			}, {
				"value" : "GOTOURL",
				"description" : "Go To URL"
			}, {
				"value" : "GETTEXT",
				"description" : "Get Text"
			} ];
			
			$scope.objectTypes = [ {
				"value" : "XPATH",
				"description" : "Xpath"
			}, {
				"value" : "CLASSNAME",
				"description" : "Class Name"
			}, {
				"value" : "NAME",
				"description" : "By Name"
			}, {
				"value" : "LINK",
				"description" : "Link"
			},{
				"value" : "ID",
				"description" : "Id"
			},{
				"value" : "PARTIALLINK",
				"description" : "Partial Link"
			} ];
			
			$scope.testStepInfo = {};
			$scope.testStepInfo.testCaseId = $stateParams.testCaseID;
			
			$scope.addTestCaseStep = function() {
				$http.post("addTestCaseStep.json", $scope.testStepInfo)
						.success(function(response) {
						});
			};
			$scope.setTestCaseStep = function(testStepId) {
				$http.post("readTestCaseStep.json", {'testStepId' : testStepId,'testCaseId':$scope.testStepInfo.testCaseId})
						.success(function(response) {
							$scope.testStepInfo = response;
						});
			};
			
			if(undefined != $stateParams.testStepId && null != $stateParams.testStepId){
				$scope.setTestCaseStep( $stateParams.testStepId);
			}
			
		} ]);
