appController.controller('MainController', [ '$scope', '$location',
		'$anchorScroll', 'holidayService', '$http',
		function($scope, $location, $anchorScroll, holidayService, $http) {
			$scope.menuList = [ {
				"id" : "dashBoard",
				"name" : "Dashboard",
				"target" : "dashBoard",
				"class" : "active"
			}, {
				"id" : "testCases",
				"name" : "Test Case",
				"target" : "testCase.list",
				"class" : ""
			}, {
				"id" : "testResults",
				"name" : "Test Results",
				"target" : "testResults.list",
				"class" : ""
			}, {
				"id" : "testRun",
				"name" : "Test Run",
				"target" : "testRun.list",
				"class" : ""
			},
			{
				"id" : "customKeyword",
				"name" : "Keyword",
				"target" : "keywordList",
				"class" : ""
			}];

			$scope.selectedMenu = $scope.menuList[0];

			$scope.toggleMenu = function(id) {
				$scope.activeMenu = id;
			};

		} ]);