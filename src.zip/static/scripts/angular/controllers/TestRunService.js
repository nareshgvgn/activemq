appController.controller(
		'TestRunService',
		[ '$scope', '$location', 'testCaseService','$http',
				function($scope, $location, testCaseService, $http) {
			
			$scope.selectedList = {};
			$scope.testRunInfo = {};
			$scope.startTestRun = function(){
				$scope.testRunInfo.testCaseIds = $scope.filterArray($scope.selectedList);
				 $http.post("startTestRun.json",$scope.testRunInfo).success( function(response) {
				 });
			};
			
			$scope.selectDeselectCheckbox = function(content){
				$scope.selectedList[content.testCaseId] = content.isSelected;
			};
			
			$scope.isSelected = function(content){
				return $scope.selectedList[content.testCaseId] ? $scope.selectedList[content.testCaseId] : false;
			};
			
			$scope.filterArray = function(){
				$scope.selectedArray = [];
				 angular.forEach($scope.selectedList, function(isSelected,testcaseId){
		                if(isSelected){
		                	$scope.selectedArray.push(testcaseId);
		                }
		            });
				 return $scope.selectedArray;
			};
		}]);