appController.controller(
		'TestRunService',
		[ '$scope', '$location', 'testCaseService','$http',
				function($scope, $location, testCaseService, $http) {
			
			$scope.selectedList = [];
			
			$scope.startTestRun = function(){
				 $http.post("startTestRun.json",$scope.selectedList).success( function(response) {
				    });
			};
		}]);