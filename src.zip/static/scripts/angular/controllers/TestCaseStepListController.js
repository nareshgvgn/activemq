appController.controller('TestCaseStepListController', [
		'$scope',
		'$location',
		'testCaseService',
		'$http',
		'$stateParams',
		function($scope, $location, testCaseService, $http, $stateParams) {

			$scope.testStepInfo = {};
			$scope.testStepInfo.testCaseId = $stateParams.testCaseID;
			$scope.headers = [ {
				label : 'Actions',
				width : '10'

			}, {
				label : 'TestCase Step ID',
				width : '13'

			}, {
				label : 'Sequence No',
				width : '13'

			}, {
				label : 'Keyword',
				width : '12'
			}, {
				label : 'Description',
				width : '16'
			}, {
				label : 'Input Data',
				width : '10'
			}, {
				label : 'Object Name',
				width : '10'
			}, {
				label : 'Object Type',
				width : '15'
			}

			];

			$scope.listTestCaseSteps = function() {
				$http.post("testCaseStepList.json", $scope.testStepInfo)
						.success(function(response) {
							$scope.contents = response.list;
							$scope.totalItems = response.totalRows;
						});

				// $scope.contents =
				// leaveService.searchLeaves($scope.leaveInfo);
			};

			$scope.listTestCaseSteps();

		} ]);


