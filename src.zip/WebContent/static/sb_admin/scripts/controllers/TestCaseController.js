angular.module('sbAdminApp').controller(
		'TestCaseController',
		[ '$scope', '$location','$http','CommonUtilityService','toaster',
				function($scope, $location, $http, CommonUtilityService, toaster) {
			$scope.toaster ={};
			$scope.testCaseInfo = {};
			$scope.treeId = 'testCaseTreeView';
			$scope.testCaseView = true;
			$scope[$scope.treeId] = {};
			
			$scope[$scope.treeId].selectNodeLabel = function(node){
				if( $scope[$scope.treeId].currentNode && $scope[$scope.treeId].currentNode.selected ) {
					$scope[$scope.treeId].currentNode.selected = undefined;
				}
				node.selected = 'selected';
				$scope[$scope.treeId].currentNode = node;
				
				if(node.detailObj['testStepId'] != undefined && node.detailObj['testStepId'] != null){
					$scope.testCaseView = false;
				}
				else{
					$scope.testCaseView = true;
					$scope.testCaseInfo = node.detailObj;
				}
			};
			
			$scope.toggle = function(node){
				console.log(node);
			};
			$scope.selectNode = function(node, $event){
				if($event.target.className.indexOf('tree-icon') > -1)
					return false;
				
				$scope.testCaseInfo = {};
				$scope.testStepInfo = {};
				if(node.detailObj['testStepId'] != undefined && node.detailObj['testStepId'] != null){
					$scope.testCaseView = false;
					$scope.testStepInfo = node.detailObj;
				}
				else{
					$scope.testCaseView = true;
					$scope.testCaseInfo = node.detailObj;
				}
			};
			
			$scope.addNewNode = function(node){
				$scope.testCaseInfo = {};
				$scope.testStepInfo = {};
				$scope.testStepInfo.parentRecordKey = node.detailObj['recordId'];
				$scope.testCaseView = false;
			};
			
			$scope.showAddTestCaseForm = function(){
				$scope.testCaseInfo = {};
				$scope.testStepInfo = {};
				$scope.testCaseView = true;
			};
			
			$scope.listTestCase = function()
			{
			    $http.post("testCaseList.json",$scope.testCaseInfo).success( function(response) {
			        $scope.contents = response.list;
			        $scope.totalItems = response.totalRows;
			        $scope.treeModel = CommonUtilityService.getTreeModelOfTestCaseList($scope.contents);
			    });
			};
			
			$scope.addTestCase = function(){
				$http.post("addTestCase.json",$scope.testCaseInfo).success( function(response) {
					if(response.status=='SUCCESS')
						$scope.listTestCase();
					else
						$scope.showErrorMsg(response.errors);
			    });
			};
			
			$scope.updateTestCase = function(){
				$http.post("updateTestCase.json",$scope.testCaseInfo).success( function(response) {
					$scope.listTestCase();
			    });
			};
			
			$scope.addTestCaseStep = function() {
				$http.post("addTestCaseStep.json", $scope.testStepInfo)
						.success(function(response) {
							$scope.listTestCase();
						});
			};
			
			$scope.updateTestCaseStep = function() {
				$http.post("updateTestCaseStep.json", $scope.testStepInfo)
						.success(function(response) {
							$scope.listTestCase();
						});
			};
			
			$scope.showErrorMsg = function(errors){

	            toaster.clear();
	            $scope.toaster.errors = {"errorList" : errors};

	            toaster.pop('error', "Errors ", "{template: 'static/templates/errors.html', data: toaster.errors}", 15000, 'templateWithData');
	            //  toaster.pop('error', "Errors ", "{template: 'assets/partials/errors.html', data: bar}", 0, 'templateWithData');

	        };
	        
			$scope.treeOptions = {
					    accept: function(sourceNode, destNodes, destIndex) {
					    	if(destNodes.$modelValue.length == 0)
					    		return false;
					    	 var data = sourceNode.$modelValue.detailObj; 
					    	 var destType = destNodes.$modelValue[0].detailObj.type; 
					    	 return (data.type == destType); // only accept the same type }
					    },
					  };
			
			$scope.init = function(){
				$scope.keywords = [ {
					"value" : "CLICK",
					"description" : "Click"
				}, {
					"value" : "SETTEXT",
					"description" : "Set Text"
				}, {
					"value" : "GOTOURL",
					"description" : "Go To URL"
				}, {
					"value" : "GETTEXT",
					"description" : "Get Text"
				},
				{
					"value" : "VERIFY_TEXT",
					"description" : "Verfiy Text"
				},
				{
					"value" : "CREATE_VARIABLE",
					"description" : "Create Variable"
				}];
				
				$scope.objectTypes = [ {
					"value" : "XPATH",
					"description" : "Xpath"
				}, {
					"value" : "CLASSNAME",
					"description" : "Class Name"
				}, {
					"value" : "NAME",
					"description" : "By Name"
				}, {
					"value" : "LINK",
					"description" : "Link"
				},{
					"value" : "ID",
					"description" : "Id"
				},{
					"value" : "PARTIALLINK",
					"description" : "Partial Link"
				} ];
				$scope.listTestCase();
			};
			
			$scope.init();
			
				} ]);