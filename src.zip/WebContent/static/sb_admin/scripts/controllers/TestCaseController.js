angular.module('sbAdminApp').controller(
		'TestCaseController',
		[ '$scope', '$location','$http','CommonUtilityService',
				function($scope, $location, $http, CommonUtilityService) {
			
			$scope.testCaseInfo = {};
			$scope.treeId = 'testCaseTreeView';
			$scope.testCaseView = true;
			$scope.headers = [
			                  {
			                      label: 'Actions',
			                      width : '10'

			                  },{
			                      label: 'Test Case ID',
			                      width : '13'

			                  },{
			                      label: 'Title',
			                      width : '12'
			                  },{
			                      label: 'Description',
			                      width : '16'
			                  },{
			                      label: 'Project',
			                      width : '10'
			                  },{
			                      label: 'Component',
			                      width : '10'
			                  },{
			                      label: 'Test Steps',
			                      width : '15'
			                  }

			              ];
			
			$scope[$scope.treeId] = {};
			
			$scope[$scope.treeId].selectNodeLabel = function(node){
				if( $scope[$scope.treeId].currentNode && $scope[$scope.treeId].currentNode.selected ) {
					$scope[$scope.treeId].currentNode.selected = undefined;
				}
				node.selected = 'selected';
				$scope[$scope.treeId].currentNode = node;
				
				if(node.detailObj['testStepId'] != undefined && node.detailObj['testStepId'] != null){
					$scope.testCaseView = false;
				}
				else{
					$scope.testCaseView = true;
					$scope.testCaseInfo = node.detailObj;
				}
			};
			
			$scope.toggle = function(node){
				console.log(node);
			};
			$scope.selectNode = function(node, $event){
				if($event.target.className.indexOf('tree-icon') > -1)
					return false;
				
				$scope.testCaseInfo = {};
				$scope.testStepInfo = {};
				if(node.detailObj['testStepId'] != undefined && node.detailObj['testStepId'] != null){
					$scope.testCaseView = false;
					$scope.testStepInfo = node.detailObj;
				}
				else{
					$scope.testCaseView = true;
					$scope.testCaseInfo = node.detailObj;
				}
			};
			
			$scope.addNewNode = function(node){
				$scope.testCaseInfo = {};
				$scope.testStepInfo = {};
				$scope.testStepInfo.parentRecordKey = node.detailObj['recordId'];
				$scope.testCaseView = false;
			};
			
			$scope.listTestCase = function()
			{
			    $http.post("testCaseList.json",$scope.testCaseInfo).success( function(response) {
			        $scope.contents = response.list;
			        $scope.totalItems = response.totalRows;
			        $scope.treeModel = CommonUtilityService.getTreeModelOfTestCaseList($scope.contents);
			    });
			};
			
			$scope.addTestCase = function(){
				$http.post("addTestCase.json",$scope.testCaseInfo).success( function(response) {
			    });
			};
			
			$scope.updateTestCase = function(){
				$http.post("updateTestCase.json",$scope.testCaseInfo).success( function(response) {
			    });
			};
			
			$scope.addTestCaseStep = function() {
				$http.post("addTestCaseStep.json", $scope.testStepInfo)
						.success(function(response) {
						});
			};
			
			$scope.init = function(){
				$scope.keywords = [ {
					"value" : "CLICK",
					"description" : "Click"
				}, {
					"value" : "SETTEXT",
					"description" : "Set Text"
				}, {
					"value" : "GOTOURL",
					"description" : "Go To URL"
				}, {
					"value" : "GETTEXT",
					"description" : "Get Text"
				} ];
				
				$scope.objectTypes = [ {
					"value" : "XPATH",
					"description" : "Xpath"
				}, {
					"value" : "CLASSNAME",
					"description" : "Class Name"
				}, {
					"value" : "NAME",
					"description" : "By Name"
				}, {
					"value" : "LINK",
					"description" : "Link"
				},{
					"value" : "ID",
					"description" : "Id"
				},{
					"value" : "PARTIALLINK",
					"description" : "Partial Link"
				} ];
				$scope.listTestCase();
			};
			
			$scope.init();
			
				} ]);