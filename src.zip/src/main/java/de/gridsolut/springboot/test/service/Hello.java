package de.gridsolut.springboot.test.service;

import javax.jms.JMSException;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.gridsolut.springboot.test.util.SimpleMessageProducer;

//http://www.vogella.com/tutorials/REST/article.html
@Component
@Path("/activeMQ")
public class Hello {

	@Autowired
	SimpleMessageProducer producer;
	
	@GET
    //@Path("/post/{id}")
    @Produces("application/json")
    public String getCustomerId() {
		String id = "DON";
		try {
			producer.sendMessages(id);
		} catch (JMSException e) {
			e.printStackTrace();
		}
		return id;
    }
	
	@PUT
    public void getCustomer() {
		System.out.println("Receive");
    }
}
