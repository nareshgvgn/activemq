package de.gridsolut.springboot.test.util;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

public class SimpleMessageProducer {

	@Autowired
	@Qualifier("myJmsTemplate")
	private JmsTemplate jmsTemplate;

	protected int numberOfMessages = 100;

	public void sendMessages( final String message) throws JMSException {

		jmsTemplate.send(new MessageCreator() {

			@Override
			public Message createMessage(javax.jms.Session session)
					throws JMSException {
				TextMessage msg = session.createTextMessage();
				msg.setStringProperty("org.apache.cxf.request.uri", "/services/activeMQ");
				msg.setStringProperty("org.apache.cxf.request.method", "PUT");
				msg.setText(message);
				return msg;
			}

		});

	}

}