package com.selenium.bean;

import java.util.List;

public class TestRunBean extends BaseTestCaseBean{
	
	
	
}
