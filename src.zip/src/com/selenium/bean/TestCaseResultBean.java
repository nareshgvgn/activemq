package com.selenium.bean;

public class TestCaseResultBean extends TestCaseBean {
	private String testCaseId;

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}
}
