package com.selenium.bean;

import java.util.List;

public class BaseTestCaseBean {
	private List<String> testCaseIds;

	public List<String> getTestCaseIds() {
		return testCaseIds;
	}

	public void setTestCaseIds(List<String> testCaseIds) {
		this.testCaseIds = testCaseIds;
	}
}
