package com.selenium.bean;

public class KeywordBean {
	private String keyword;
	private String className;
	private String javaCode;
	private String description;
	private String reportSucessMessage;
	private String reportErrorMessage;
	
	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getJavaCode() {
		return javaCode;
	}

	public void setJavaCode(String javaCode) {
		this.javaCode = javaCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReportSucessMessage() {
		return reportSucessMessage;
	}

	public void setReportSucessMessage(String reportSucessMessage) {
		this.reportSucessMessage = reportSucessMessage;
	}

	public String getReportErrorMessage() {
		return reportErrorMessage;
	}

	public void setReportErrorMessage(String reportErrorMessage) {
		this.reportErrorMessage = reportErrorMessage;
	}

}
