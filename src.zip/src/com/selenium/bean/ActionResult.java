package com.selenium.bean;

public class ActionResult {

}
