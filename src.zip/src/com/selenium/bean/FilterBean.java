package com.selenium.bean;

import java.util.Map;

public class FilterBean {
	private String value;
	private String description;
	private Map<String, Object> objMap;
	
	public FilterBean()
	{
		
	}
	public FilterBean(String value, String description)
	{
		this.value = value;
		this.description = description;
	}
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Map<String, Object> getObjMap() {
		return objMap;
	}
	public void setObjMap(Map<String, Object> objMap) {
		this.objMap = objMap;
	}
}
