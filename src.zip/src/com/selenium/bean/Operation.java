package com.selenium.bean;

public enum Operation {
	CLICK, SETTEXT, GOTOURL, GETTEXT, WAITFORPAGELOAD
}
