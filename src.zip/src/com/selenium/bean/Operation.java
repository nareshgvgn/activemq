package com.selenium.bean;

public enum Operation {
	CUSTOM, CLICK, SETTEXT, GOTOURL, GETTEXT, WAITFORPAGELOAD, CLICK_BTN;
	
	public static Operation valueOfKeyword(String keyword)
	{
		Operation result = null;
		try
		{
			result = Operation.valueOf(keyword);
		}
		catch(Exception exc)
		{
			result = Operation.CUSTOM;
		}
		return result;
	}
}
