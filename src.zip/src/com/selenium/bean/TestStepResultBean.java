package com.selenium.bean;

public class TestStepResultBean extends TestCaseStep {
	private String testStepId;
	private DetailInfo details;
	
	public String getTestStepId() {
		return testStepId;
	}

	public void setTestStepId(String testStepId) {
		this.testStepId = testStepId;
	}

	public DetailInfo getDetails() {
		return details;
	}

	public void setDetails(DetailInfo details) {
		this.details = details;
	}

}
