package com.selenium.bean;

public class TestStepResultBean extends TestCaseStep {
	private String testStepId;

	public String getTestStepId() {
		return testStepId;
	}

	public void setTestStepId(String testStepId) {
		this.testStepId = testStepId;
	}

}
