package com.selenium.controller;

import com.selenium.bean.AbstractSeleniumBean;

public class TestCaseFilter extends AbstractSeleniumBean{
	String testCaseId;

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}
	
}
