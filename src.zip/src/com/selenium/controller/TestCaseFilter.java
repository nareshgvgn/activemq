package com.selenium.controller;

import com.selenium.bean.BaseTestCaseBean;

public class TestCaseFilter extends BaseTestCaseBean{
	String testCaseId;

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}
	
}
