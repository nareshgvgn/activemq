package com.selenium.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.selenium.bean.ActionResult;
import com.selenium.bean.KeywordBean;
import com.selenium.bean.TestCaseStep;
import com.selenium.dao.KeywordExecuterDao;
import com.selenium.dao.TestCaseStepDao;
import com.selenium.dao.UtilDao;
import com.selenium.util.CompileSourceInMemory;

@RestController
public class TestCaseStepService {

	@Autowired
	private TestCaseStepDao testCaseStepDao;
	
	@Autowired
	UtilDao utilDao;
	
	@Autowired
	KeywordExecuterDao keywordExecuterDao;
	
	@RequestMapping("/addTestCaseStep.json")
	public @ResponseBody ActionResult addTestCase(@RequestBody TestCaseStep testCaseBean)
	{
		testCaseBean.setRecordId(utilDao.getUniqueId());
		testCaseStepDao.addRecord(testCaseBean);
		return null;
	}
	
	@RequestMapping("/testCaseStepList.json")
	public @ResponseBody Map<String,Object> testCaseList(@RequestBody TestCaseFilter testCaseFilterBean)
	{
		Map<String,Object> result = new HashMap<String, Object>();
		List<TestCaseStep> list = new ArrayList<TestCaseStep>();
		list = testCaseStepDao.readTestCaseSteps(testCaseFilterBean.getTestCaseId());
		result.put("list",list);
		if(list != null)
		result.put("totalRows",list.size());
		return result;
	}
	
	@RequestMapping("/readTestCaseStep.json")
	public @ResponseBody TestCaseStep readTestCaseStep(@RequestBody TestCaseStep bean)
	{
		TestCaseStep result = testCaseStepDao.readRecord(bean.getTestStepId());
		return result;
	}
	
	@RequestMapping("/dummy.json")
	public @ResponseBody TestCaseStep executeKeyword()
	{
		try
		{
			String exePath = "/Drivers/chromedriver.exe";
			boolean testCaseSuccess = true;
			boolean success = true;
			System.setProperty("webdriver.chrome.driver", exePath);
		KeywordBean kBean = keywordExecuterDao.getJavaCode("CLICK_BTN");
		String javaCode = kBean.getJavaCode();
		WebDriver webdriver = new ChromeDriver();
		CompileSourceInMemory.executeJavaCode(javaCode, kBean.getClassName(), webdriver);
		}
		catch(Exception exc)
		{
			
		}
		return null;
	}
	
}

