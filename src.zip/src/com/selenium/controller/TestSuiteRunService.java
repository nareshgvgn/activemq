package com.selenium.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.selenium.bean.ActionResult;
import com.selenium.bean.TestRunBean;
import com.selenium.util.TestSuiteUtility;

@RestController
public class TestSuiteRunService {
	
	@Autowired
	TestSuiteUtility testSuiteUtility;
	@RequestMapping("/startTestRun.json")
	public @ResponseBody ActionResult startTestRun(TestRunBean testCaseBean)
	{
		testSuiteUtility.startTestRun(testCaseBean);
		return null;
	}
}
