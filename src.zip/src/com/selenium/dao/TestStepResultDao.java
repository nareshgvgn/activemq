package com.selenium.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.selenium.bean.BaseTestCaseBean;
import com.selenium.bean.SeleniumAutomationStatus;
import com.selenium.bean.TestRunBean;
import com.selenium.bean.TestStepResultBean;

public class TestStepResultDao extends JdbcDaoSupport {

	/** The Constant _log. */
	private static final Logger _log = LoggerFactory
			.getLogger(TestStepResultDao.class.getName());

	public void addRecord(final TestStepResultBean bean) {
		String strSQL = "INSERT INTO testcasestepresult(TestRunID,TestCaseID,TestStepId,Status)"
				+ " VALUES (?, ?, ?, ?)";

		try {

			if (_log.isInfoEnabled())
				_log.info("Inserting new tcw_client_drawer_mst record!");

			getJdbcTemplate().execute(strSQL, new PreparedStatementCallback() {
				public Object doInPreparedStatement(PreparedStatement ps)
						throws SQLException, DataAccessException {

					ps.setString(1, bean.getTestRunID());
					ps.setString(2, bean.getTestCaseId());
					ps.setString(3, bean.getTestStepId());
					ps.setInt(4, bean.getStatus().ordinal());
					if (_log.isDebugEnabled())
						_log.info("About to execute the insert prepared statement!");
					ps.execute();
					return bean;
				}
			});
			if (_log.isInfoEnabled())
				_log.info("Inserted new record in Test case master!");
		} finally {
			strSQL = null;
		}
	}

	public void updateRecord(final TestStepResultBean bean) {
		String strSQL = "UPDATE testcasestepresult set status=? where TestRunID = ? and TestCaseID=? AND TestStepId=?";

		try {

			if (_log.isInfoEnabled())
				_log.info("Inserting new testcasestepresult record!");

			getJdbcTemplate().execute(strSQL, new PreparedStatementCallback() {
				public Object doInPreparedStatement(PreparedStatement ps)
						throws SQLException, DataAccessException {
					int i = 1;
					ps.setInt(i++, bean.getStatus().ordinal());
					ps.setString(i++, bean.getTestRunID());
					ps.setString(i++, bean.getTestCaseId());
					ps.setString(i++, bean.getTestStepId());
					if (_log.isDebugEnabled())
						_log.info("About to execute the insert prepared statement!");
					ps.execute();
					return bean;
				}
			});
			if (_log.isInfoEnabled())
				_log.info("Inserted new record in Beneficiary master!");
		} finally {
			strSQL = null;
		}
	}

	public TestStepResultBean readRecord(TestStepResultBean filterBean) {
		String sql = "select t.* from testcasestepresult t where TestRunID=? and TestCaseID=? AND TestStepId=?";
		List<Object> lstArgs = null;
		List<TestStepResultBean> lstRet = null;
		lstArgs = new ArrayList<Object>(4);
		lstArgs.add(filterBean.getTestRunID());
		lstArgs.add(filterBean.getTestCaseId());
		lstArgs.add(filterBean.getTestStepId());
		lstRet = getJdbcTemplate().query(sql, lstArgs.toArray(),
				new RowMapper() {

					@Override
					public Object mapRow(ResultSet rs, int arg1)
							throws SQLException {
						TestStepResultBean bean = new TestStepResultBean();
						bean.setStatus(SeleniumAutomationStatus.valueOf(rs
								.getInt("status")));
						bean.setTestRunID(rs.getString("TestRunID"));
						bean.setTestCaseId(rs.getString("TestCaseID"));
						bean.setTestStepId(rs.getString("TestStepId"));
						return bean;
					}

				});
		if (null != lstRet && lstRet.size() > 0)
			return lstRet.get(0);
		return null;
	}

	public List<TestStepResultBean> readList(
			TestRunBean testCaseFilterBean) {
		String sql = "select t.*,mst.* from testcasestepresult t,testcase_steps_mst mst where mst.testcase_id =t.TestCaseID AND mst.teststep_id=t.TestStepId AND t.TestRunID=? and t.TestCaseID=?";
		List<Object> lstArgs = null;
		List<TestStepResultBean> lstRet = null;
		lstArgs = new ArrayList<Object>(4);
		lstArgs.add(testCaseFilterBean.getTestRunID());
		lstArgs.add(testCaseFilterBean.getTestCaseId());
		lstRet = getJdbcTemplate().query(sql, lstArgs.toArray(),
				new RowMapper() {

					@Override
					public Object mapRow(ResultSet rs, int arg1)
							throws SQLException {
						TestStepResultBean bean = new TestStepResultBean();
						bean.setStatus(SeleniumAutomationStatus.valueOf(rs
								.getInt("status")));
						bean.setTestRunID(rs.getString("TestRunID"));
						bean.setTestCaseId(rs.getString("TestCaseID"));
						bean.setTestStepId(rs.getString("TestStepId"));
						bean.setDescription(rs.getString("description"));
						bean.setKeyword(rs.getString("keyword"));
						bean.setInputData(rs.getString("input_data"));
						bean.setObjectName(rs.getString("object_name"));
						bean.setObjectType(rs.getString("object_type"));
						return bean;
					}

				});
		if (null != lstRet && lstRet.size() > 0)
			return lstRet;
		return null;
	}
}

