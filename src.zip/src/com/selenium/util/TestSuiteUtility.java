package com.selenium.util;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.selenium.bean.SeleniumAutomationStatus;
import com.selenium.bean.TestCaseBean;
import com.selenium.bean.TestCaseResultBean;
import com.selenium.bean.TestCaseStep;
import com.selenium.bean.TestRunBean;
import com.selenium.bean.TestStepResultBean;
import com.selenium.dao.TestCaseDao;
import com.selenium.dao.TestCaseResultDao;
import com.selenium.dao.TestCaseStepDao;
import com.selenium.dao.TestRunResultDao;
import com.selenium.dao.TestStepResultDao;
import com.selenium.dao.UtilDao;

@Component
public class TestSuiteUtility {

	@Autowired
	TestCaseDao testCaseDao;

	@Autowired
	TestCaseStepDao testCaseStepDao;

	@Autowired
	TestRunResultDao testRunResultDao;

	@Autowired
	TestCaseResultDao testCaseResultDao;

	@Autowired
	TestStepResultDao testStepResultDao;

	@Autowired
	UtilDao utilDao;
	
	public void startTestRun(TestRunBean testRunBean) {
		// bean = new TestRunBean();
		// List<String> lst = new ArrayList<String>();
		// lst.add("TST001");
		// bean.setTestCaseIds(lst);
		testRunBean.setTestRunBy("Naresh");
		testRunBean.setStatus(SeleniumAutomationStatus.INPROGRESS);
		testRunBean.setTestRunID(utilDao.getUniqueId());
		testRunResultDao.addRecord(testRunBean);
		List<TestCaseBean> testCaseList = testCaseDao
				.readTestCaseList(testRunBean);
		try {
			startExecution(testCaseList, testRunBean);
		} catch (Exception e) {
			e.printStackTrace();
		}
		testRunBean.setStatus(SeleniumAutomationStatus.COMPLETED);
		testRunResultDao.updateRecord(testRunBean);
	}

	public void startExecution(List<TestCaseBean> testCaseList,
			TestRunBean testRunBean) throws Exception {
		TestCaseResultBean testCaseResultBean = null;
		TestStepResultBean testStepResultBean = null;
		String exePath = "/Drivers/chromedriver.exe";
		boolean testCaseSuccess = true;
		boolean success = true;
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver webdriver = new ChromeDriver();
		for (TestCaseBean bean : testCaseList) {
			testCaseSuccess = true;
			success = true;
			testCaseResultBean = new TestCaseResultBean();
			testCaseResultBean.setTestRunID(testRunBean.getTestRunID());
			testCaseResultBean.setTestCaseId(bean.getTestCaseId());
			testCaseResultBean.setStatus(SeleniumAutomationStatus.INPROGRESS);
			testCaseResultDao.addRecord(testCaseResultBean);
			List<TestCaseStep> steps = testCaseStepDao.readTestCaseSteps(bean
					.getTestCaseId());
			for (TestCaseStep step : steps) {
				testStepResultBean = new TestStepResultBean();
				testStepResultBean.setTestRunID(testCaseResultBean
						.getTestRunID());
				testStepResultBean.setTestCaseId(testCaseResultBean
						.getTestCaseId());
				testStepResultBean.setTestStepId(step.getTestStepId());
				KeywordExecuter executer = new KeywordExecuter(webdriver);
				try {
					executer.perform(null, step.getKeyword(),
							step.getObjectName(), step.getObjectType(),
							step.getInputData());
				} catch (Exception exc) {
					success = false;
				}
				if (success) {
					testStepResultBean
							.setStatus(SeleniumAutomationStatus.PASSED);
					testStepResultDao.addRecord(testStepResultBean);
				} else {
					testStepResultBean
							.setStatus(SeleniumAutomationStatus.FAILED);
					testCaseSuccess = false;
					testStepResultDao.addRecord(testStepResultBean);
					break;
				}
			}
			if (testCaseSuccess) {
				testCaseResultBean.setStatus(SeleniumAutomationStatus.PASSED);
			} else {
				testCaseResultBean.setStatus(SeleniumAutomationStatus.FAILED);
			}
			testCaseResultDao.updateRecord(testCaseResultBean);
		}
	}

	public static void main(String a[]) {
		TestSuiteUtility t = new TestSuiteUtility();
		try {
			t.startExecution(null, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
