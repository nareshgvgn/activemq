package com.selenium.util;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.selenium.bean.TestCaseBean;
import com.selenium.bean.TestCaseStep;
import com.selenium.bean.TestRunBean;
import com.selenium.dao.TestCaseDao;
import com.selenium.dao.TestCaseStepDao;

@Component
public class TestSuiteUtility {
	
	@Autowired
	TestCaseDao testCaseDao;
	
	@Autowired
	TestCaseStepDao testCaseStepDao;
	
	public void startTestRun(TestRunBean bean) {
//		bean = new TestRunBean();
//		List<String> lst = new ArrayList<String>();
//		lst.add("TST001");
//		bean.setTestCaseIds(lst);
		List<TestCaseBean> testCaseList = testCaseDao.readTestCaseList(bean);
		try {
			startExecution(testCaseList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void startExecution(List<TestCaseBean> testCaseList) throws Exception
	{
		String exePath = "/Drivers/chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver webdriver = new ChromeDriver();
		for(TestCaseBean bean : testCaseList){
			List<TestCaseStep> steps = testCaseStepDao.readTestCaseSteps(bean.getTestCaseId());
			for(TestCaseStep step : steps){
				KeywordExecuter executer  = new KeywordExecuter(webdriver);
				executer.perform(null, step.getKeyword(), step.getObjectName(), step.getObjectType(), step.getInputData());
			}
		}
	}
	
	public static void main(String a[]){
		TestSuiteUtility t = new TestSuiteUtility();
		try {
			t.startExecution(null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
