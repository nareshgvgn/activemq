import { Component } from '@angular/core';

@Component({
    selector: 'header-notification',
    templateUrl :'headerNotification.component.html'
})
export class HeaderNotificationComponent {
}