import { Component } from '@angular/core';

import { ITestCase } from './TestCases/testcase';
import { TestCaseService } from './TestCases/testcase.service';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {HeaderComponent} from './header/header.component';

@Component({
    selector: 'my-app',
    //template: `<h1>Hello {{name}}</h1> <br/><input type="text" [(ngModel)] = "name"/> {{iTestCases | json}}<ul><li *ngFor="let doc of iTestCases">{{doc.testCaseId}}</li></ul>`,
    templateUrl:'app.component.html',
    providers: [TestCaseService]
})
export class AppComponent {
        name = 'Angular';
    iTestCases: ITestCase[];
    constructor(private _testCase: TestCaseService) {
    }

    ngOnInit(): void {
        this._testCase.getTestCases()
            .subscribe(iTestCases => this.iTestCases = iTestCases);
      console.log(this.iTestCases);
    }

}
