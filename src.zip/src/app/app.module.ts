import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent }  from './app.component';
import {HeaderComponent} from './header/header.component';
import {HeaderNotificationComponent} from './header/headerNotification.component';
import { SidebarComponent } from './header/sidebar/sidebar.component';
import { TestcaseListComponent } from './TestCases/testcase-list/testcase-list.component';
import { RouterModule } from '@angular/router';
import { AppRoutes } from './app.route';
import { TreeModule } from 'angular2-tree-component';
@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpModule, RouterModule.forRoot(AppRoutes),TreeModule  ],
  declarations: [ AppComponent, HeaderComponent, HeaderNotificationComponent, SidebarComponent, TestcaseListComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
