import { TestcaseListComponent } from './TestCases/testcase-list/testcase-list.component';



export const AppRoutes = [
 
  { path: 'testcase-list', component: TestcaseListComponent }
];