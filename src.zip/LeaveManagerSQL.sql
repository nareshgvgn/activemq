/*
SQLyog Ultimate v8.55 
MySQL - 5.6.10 : Database - seleniumkeyword
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`seleniumkeyword` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `seleniumkeyword`;

/*Table structure for table `keyword_mst` */

DROP TABLE IF EXISTS `keyword_mst`;

CREATE TABLE `keyword_mst` (
  `keyword` varchar(45) DEFAULT NULL,
  `javacode` blob,
  `class_name` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `keyword_mst` */

insert  into `keyword_mst`(`keyword`,`javacode`,`class_name`) values ('CLICK_BTN','import org.openqa.selenium.By;\r\nimport org.openqa.selenium.WebDriver;\r\n\r\npublic class BtnClickHandler {\r\n	public void executeKeyword(WebDriver driver)\r\n	{\r\n		driver.findElement(By.name(\"btnI\")).click();\r\n	}\r\n}\r\n','BtnClickHandler');

/*Table structure for table `project_mst` */

DROP TABLE IF EXISTS `project_mst`;

CREATE TABLE `project_mst` (
  `project_id` varchar(10) NOT NULL,
  `project_name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `project_mst` */

insert  into `project_mst`(`project_id`,`project_name`) values ('PRJ001','GCP'),('PRJ002','Leave Manager');

/*Table structure for table `testcase_mst` */

DROP TABLE IF EXISTS `testcase_mst`;

CREATE TABLE `testcase_mst` (
  `testcase_id` varchar(10) NOT NULL,
  `priority` int(1) DEFAULT NULL,
  `module_name` varchar(100) DEFAULT NULL,
  `test_designed_by` varchar(200) NOT NULL,
  `testcase_title` varchar(255) NOT NULL,
  `testcase_description` varchar(800) DEFAULT NULL,
  `testcase_preexecute` varchar(100) DEFAULT NULL COMMENT 'comma seperated Test case Ids which should be executed before this test case',
  `project_id` varchar(10) DEFAULT NULL,
  `record_id` varchar(10) NOT NULL,
  `version` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`record_id`),
  UNIQUE KEY `uk_testcaseId` (`testcase_id`),
  KEY `FK_testcase_mst` (`project_id`),
  CONSTRAINT `FK_testcase_mst` FOREIGN KEY (`project_id`) REFERENCES `project_mst` (`project_id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `testcase_mst` */

insert  into `testcase_mst`(`testcase_id`,`priority`,`module_name`,`test_designed_by`,`testcase_title`,`testcase_description`,`testcase_preexecute`,`project_id`,`record_id`,`version`) values ('TST001',0,'Security','Naresh','Login','Login Test','',NULL,'887f477f-5',0),('TST002',0,'Payment','Naresh','Payment Entry','Payment Entry','',NULL,'8d661301-5',0);

/*Table structure for table `testcase_steps_mst` */

DROP TABLE IF EXISTS `testcase_steps_mst`;

CREATE TABLE `testcase_steps_mst` (
  `sequence_no` int(4) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `description` varchar(400) NOT NULL,
  `input_data` varchar(200) DEFAULT NULL,
  `teststep_id` varchar(10) NOT NULL,
  `object_name` varchar(100) DEFAULT NULL,
  `object_type` varchar(100) DEFAULT NULL,
  `record_id` varchar(10) NOT NULL,
  `version` int(10) NOT NULL DEFAULT '0',
  `parent_record_id` varchar(10) NOT NULL,
  PRIMARY KEY (`record_id`),
  UNIQUE KEY `uk_teststepid` (`teststep_id`),
  KEY `FK_testcase_steps_mst` (`parent_record_id`),
  CONSTRAINT `FK_testcase_steps_mst` FOREIGN KEY (`parent_record_id`) REFERENCES `testcase_mst` (`record_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `testcase_steps_mst` */

insert  into `testcase_steps_mst`(`sequence_no`,`keyword`,`description`,`input_data`,`teststep_id`,`object_name`,`object_type`,`record_id`,`version`,`parent_record_id`) values (1,'CLICK','CLick Test',NULL,'TST003',NULL,NULL,'887f477f-5',0,'887f477f-5'),(5,'CLICK','5',NULL,'345',NULL,NULL,'9b2743af-5',0,'887f477f-5');

/*Table structure for table `testcaseresult` */

DROP TABLE IF EXISTS `testcaseresult`;

CREATE TABLE `testcaseresult` (
  `TestRunID` varchar(10) NOT NULL,
  `TestCaseRecordID` varchar(10) NOT NULL,
  `Status` int(1) DEFAULT NULL,
  PRIMARY KEY (`TestRunID`,`TestCaseRecordID`),
  CONSTRAINT `FK_testcaseresult` FOREIGN KEY (`TestRunID`) REFERENCES `testrunresult` (`TestRunID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `testcaseresult` */

/*Table structure for table `testcasestepresult` */

DROP TABLE IF EXISTS `testcasestepresult`;

CREATE TABLE `testcasestepresult` (
  `TestRunID` varchar(10) NOT NULL,
  `TestCaseRecordID` varchar(10) NOT NULL,
  `TestStepRecordId` varchar(10) NOT NULL,
  `Status` int(1) DEFAULT NULL,
  PRIMARY KEY (`TestRunID`,`TestCaseRecordID`,`TestStepRecordId`),
  CONSTRAINT `FK_testcasestepresult` FOREIGN KEY (`TestRunID`, `TestCaseRecordID`) REFERENCES `testcaseresult` (`TestRunID`, `TestCaseRecordID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `testcasestepresult` */

/*Table structure for table `testrunresult` */

DROP TABLE IF EXISTS `testrunresult`;

CREATE TABLE `testrunresult` (
  `TestRunID` varchar(10) NOT NULL,
  `TestRunBy` varchar(100) DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `Status` int(1) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `machine` varchar(50) DEFAULT NULL,
  `browser` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`TestRunID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `testrunresult` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
