SET FOREIGN_KEY_CHECKS=0;

drop table leaves;

SET FOREIGN_KEY_CHECKS=1;

