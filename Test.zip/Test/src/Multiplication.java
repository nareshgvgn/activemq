
public class Multiplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int result = multilication(5, 6);
		System.out.println(multilication(result, 10));
	}
	
	public static int multilication(int no1, int no2)
	{
		if(no2 == 0)
			return 0;
		return multilication(no1, no2 - 1) + no1;
		
	}
	
}
