import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class HttpUrlConnectionTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String targetURL = "http://localhost:8080/gcpuscash/loginform.action";
		
		StringBuilder sb = new StringBuilder();
		String urlParameters ="";
		try {
			addParam(sb, "user", "MARK");
			addParam(sb, "txtpassword", "");
			addParam(sb, "salt", "N76mwxoC");
			addParam(sb, "password", "ccbe91b1f19bd31a1365363870c0eec2296a61c1");
			addParam(sb, "hashPassword", "627390f698c31e9cde5a220985b59e82243f1490");
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String st = excutePost(targetURL,sb.toString());
		System.out.println(st);
		// TODO Auto-generated method stub

	}

	private static void addParam(StringBuilder urlParameters, String name,
			String value) throws UnsupportedEncodingException {
		if(urlParameters.length() > 1)
		{
			urlParameters.append("&");
		}
		urlParameters.append(name).append("=").append(URLEncoder.encode(value, "UTF-8"));
	}

	public static String excutePost(String targetURL, String urlParameters) {
		URL url;
		HttpURLConnection connection = null;
		try {
			// Create connection
			url = new URL(targetURL);
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");

			connection.setRequestProperty("Content-Length",
					"" + Integer.toString(urlParameters.getBytes().length));
			connection.setRequestProperty("Content-Language", "en-US");

			connection.setUseCaches(false);
			connection.setDoInput(true);
			connection.setDoOutput(true);

			// Send request
			DataOutputStream wr = new DataOutputStream(
					connection.getOutputStream());
			wr.writeBytes(urlParameters);
			wr.flush();
			wr.close();

			// Get Response
			InputStream is = connection.getInputStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			String line;
			StringBuffer response = new StringBuffer();
			while ((line = rd.readLine()) != null) {
				response.append(line);
				response.append('\r');
			}
			rd.close();
			return response.toString();

		} catch (Exception e) {

			e.printStackTrace();
			return null;

		} finally {

			if (connection != null) {
				connection.disconnect();
			}
		}
	}
}
