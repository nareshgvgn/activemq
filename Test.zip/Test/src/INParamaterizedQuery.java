
public class INParamaterizedQuery {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		StringBuilder sb = new StringBuilder("");
		String strAccounts ="263,1,260,') or ('1'='1";
		 sb.append(" AND account_id IN (");
         String[] arrAccounts = strAccounts.split(",");
         for (int i = 0; i < arrAccounts.length; i++)
         {
             	 sb.append("?");
             	 
                // sb.append("'"+arrAccounts[i]+"'");
                 if (i < arrAccounts.length - 1) sb.append(",");
             
         }
         sb.append(")");
         System.out.println(sb.toString());

	}

}
