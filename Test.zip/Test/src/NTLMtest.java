import java.text.MessageFormat;

import com.fundtech.core.util.StringUtils;



public class NTLMtest {

	/**
	 * @param args
	 */
	public static void main(String[] args111) {
		String str = "if (!StringUtils.isEmpty(bean.getEnrichCode{0}()))<bean.setEnrichValue{0}(formatEnrichValue(bean.getEnrichValue{0}()));>";
		String str1 = "if(checkColumnExistInResultSet(rsMetaData, \"ENRICH_VALUE_{0}\"))<bean.setEnrichValue{0}(rs.getString(\"ENRICH_VALUE_{0}\"));>";
		String strR= "";
		
		for(int i = 1; i<15;i++)
		{
			Object[] args = {(i+1), (i+1), (i+1), (i+1), (i+1), (i+1), (i+1) , (i+1), (i+1)};
			MessageFormat fmt = new MessageFormat(str);
			//strR = strR + fmt.format(args).replace("<", "{").replace(">", "}");
			
			//fmt = new MessageFormat(str1);
			System.out.println(fmt.format(args).replace("<", "{").replace(">", "}"));
			
		}
		
	}

}
