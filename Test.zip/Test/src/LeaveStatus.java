
public enum LeaveStatus {
    PENDING,
    APPROVED,
    CANCELLED,
    REJECTED
}

