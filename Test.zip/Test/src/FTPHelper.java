/*----------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.common.utils
 * FILE     : FTPHelper.java
 * CREATED  : May 25, 2010 1:02:20 PM
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *--------------------------------------------------------------------------------------------------------------------*/

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

/**
 * A class containing utility functions for FTP & SFTP
 * @author Prasad P. Khandekar
 * @version $Id$
 */
public final class FTPHelper
{
	private static Logger log = LoggerFactory.getLogger(FTPHelper.class.getName());

	public static final int PROTOCOL_FTP = 1;
	public static final int PROTOCOL_SFTP = 2;
	public static final int TRANSFER_BINARY = 1;
	public static final int TRANSFER_DEFAULT = 2;

	private String _strHost;
	private int _intPort = 0;
	private String _strUser;
	private String _strPassword;
	private int _intProtocol = PROTOCOL_FTP;

	public FTPHelper(String host, int port, int protocol, String username, String password)
	{
		_strHost = host;
		_intPort = port;
		_strUser = username;
		_strPassword = password;
		_intProtocol = protocol;
	}



/*----------------------------------------------------------------------------------------------------------------------
 * CLEANUP ROUTINES
 *--------------------------------------------------------------------------------------------------------------------*/
	private FTPClient connectUsingFTP() throws Exception
	{
		FTPClient ftp = new FTPClient();

		ftp.connect(_strHost, _intPort);
		if (log.isDebugEnabled()) log.debug("Connected to FTP Server!");

		ftp.login(_strUser, _strPassword);
		int reply = ftp.getReplyCode();
		if (log.isDebugEnabled())
			log.debug("Login with reply code " + reply + " and reply string " + ftp.getReplyString());

		if (!FTPReply.isPositiveCompletion(reply))
		{
			if(log.isDebugEnabled())
				log.debug("Not able to connect to FTP Server!");
			ftp.disconnect();
			throw new Exception();
		}

		if (log.isDebugEnabled())
			log.debug("Connected to FTP Server!");
		return ftp;
	}

	private ChannelSftp connectUsingSFTP() throws Exception
	{
		JSch jsch = null;
		Session session = null;
		Channel channel =  null;
		Hashtable<String, String> opts = null;

        try
        {
            opts = new Hashtable<String, String>();
            opts.put("StrictHostKeyChecking", "no");
	        jsch =  new JSch();
	        JSch.setConfig(opts);

	        if (log.isDebugEnabled())
	        	log.debug("Establishing SFTP session!");
	        session = jsch.getSession(_strUser, _strHost, _intPort);
	        session.setPassword(_strPassword);
	        session.connect();
	        if (log.isDebugEnabled())
	        	log.debug("Session Connected to SFTP Server!");

	        channel = session.openChannel("sftp");
	        channel.connect();
	        if (log.isDebugEnabled())
	        	log.debug("Channel Connected to SFTP Server");

	        return (ChannelSftp) channel;
        }
        finally
        {
        	if (session != null) session = null;
        	if (jsch != null) jsch = null;
        }
	}

	private void doClose(FTPClient ftp)
	{
		if (null == ftp) return;

		try
		{
			if (ftp.isConnected())
			{
				ftp.logout();
				ftp.disconnect();
			}
		}
		catch (IOException ex)
		{
			
		}
	}
	
	public void uploadFile(String remoteDir, String remoteFileName,
			String localDir, String localFileName, InputStream localFile,
			int transferType) throws Exception {
		boolean blnCWD = false;
		boolean isSuccess = false;
		FTPClient ftp = null;
		ChannelSftp channelSftp = null;

		try {
			if (log.isInfoEnabled())
				log.info("Uploading file " + remoteFileName);

			if (StringUtils.isEmpty(remoteFileName))
				remoteFileName = localFileName;

			if (_intProtocol == PROTOCOL_FTP) {
				ftp = connectUsingFTP();
				if (transferType == TRANSFER_BINARY)
					ftp.setFileType(FTPClient.BINARY_FILE_TYPE);

				if (!StringUtils.isEmpty(remoteDir)) {
					blnCWD = ftp.changeWorkingDirectory(remoteDir);
					if (blnCWD) {
						isSuccess = ftp.storeFile(remoteFileName, localFile);
						if (!isSuccess)
							throw new TransferException("TRFR-0006",
									new Object[] { remoteFileName },
									"Error while uploading file {0}!", null);
					} else
						throw new TransferException("TRFR-0004",
								new Object[] { remoteDir },
								"Unable to change working directory to {0}!",
								null);
				} else {
					isSuccess = ftp.storeFile(remoteFileName, localFile);
					if (!isSuccess)
						throw new TransferException("TRFR-0006",
								new Object[] { remoteFileName },
								"Error while uploading file {0}!", null);
				}
			} else if (_intProtocol == PROTOCOL_SFTP) {
				channelSftp = connectUsingSFTP();

				if (!StringUtils.isEmpty(localDir)) {
					if (log.isDebugEnabled())
						log.debug("Changing local directory to " + localDir);
					channelSftp.lcd(localDir);
				}

				if (!StringUtils.isEmpty(remoteDir)) {
					if (log.isDebugEnabled())
						log.debug("Changing remote directory to " + remoteDir);
					channelSftp.cd(remoteDir);
				}

				channelSftp.put(localFile, remoteFileName);
			}
			if (log.isInfoEnabled())
				log.info("File Upload completed!!");
		} finally {
			doClose(ftp);
			// doClose(channelSftp);
		}
	}
	
	final class TransferException extends Exception
	{
		private static final long serialVersionUID = 9144016234810683661L;

		/**
		 * Constructs a new exception instance and initializes it with the supplied data.
		 * @param strCode The error code
		 * @param args The additional error message enriching data
		 * @param strMsg The default error message.
		 * @param cause The root cause of this exception
		 */
		public TransferException(String strCode, Object[] args, String strMsg, Throwable cause)
		{
			super(strCode);
		}
	}
	
	public static void main(String a[]) throws Exception
	{
		FTPHelper f = new FTPHelper("192.168.100.67", 21,1, "naresh", "naresh");
		FTPClient cl = f.connectUsingFTP();
		System.out.println(cl.isConnected());
		InputStream inputStream = new FileInputStream("D:/poAdd.txt");
		f.uploadFile("/", "poAddnaresh.txt", null, null, inputStream, 2);
	}
}
