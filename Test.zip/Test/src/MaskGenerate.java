import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.Assert;

import com.fundtech.core.security.Mask;
import com.fundtech.core.util.EncodeUtils;
import com.fundtech.core.util.StringUtils;
import com.fundtech.customer.common.bo.ACLMaskUpdator;

public class MaskGenerate
{
    /**
     * @param args
     */
    Connection con = null;

    public MaskGenerate() throws ClassNotFoundException, SQLException
    {
      //IWebRequestContext
        Class.forName("oracle.jdbc.OracleDriver");
        String connection = "jdbc:oracle:thin:@192.168.100.199:1521:CASHTECH";
        String userName = "GCPANZ";
        String password = "GCPANZ";
        con = DriverManager.getConnection(connection, userName, password);
    }

    public String getUpdatedMask(String strACLSerials, String strHexMask)
    {
       // MenuProvider
        int intWeight = 0;
        String strTemp = "";
        Integer intSerial = Integer.valueOf(0);
        Integer intMaxWeight = Integer.valueOf(0);
        JSONObject jsonSerials = null;
        StringBuilder sbBinaryMask = null;
        HashMap<Integer, Integer> mapSerialWeights = null;

        Assert.notNull(strACLSerials, "ACL Serials can not be null, can not provide new mask!");
        try
        {
            intMaxWeight = Integer.valueOf(this.getMaxWeight());
            mapSerialWeights = this.getSerialWeights();
            jsonSerials = (JSONObject) JSONSerializer.toJSON(strACLSerials);

            if (strHexMask == null)
            {
                strTemp = StringUtils.padLeft(strTemp, '0', intMaxWeight.intValue());
                sbBinaryMask = new StringBuilder(strTemp);
                sbBinaryMask = sbBinaryMask.reverse();
            }
            else
            {
                strTemp = EncodeUtils.hexToBinary(strHexMask);
                strTemp = StringUtils.padLeft(strTemp, '0', intMaxWeight.intValue());
                sbBinaryMask = new StringBuilder(strTemp);
            }

            if (jsonSerials.isEmpty())
            {
                if (strHexMask == null)
                {
                    String str1 = EncodeUtils.binaryToHex(sbBinaryMask.toString());
                    return str1;
                }
                String str1 = strHexMask;
                return str1;
            }

            sbBinaryMask = sbBinaryMask.reverse();

            for (Iterator localIterator = jsonSerials.keySet().iterator(); localIterator.hasNext();)
            {
                Object objKey = localIterator.next();

                if (mapSerialWeights.containsKey(Integer.valueOf(objKey.toString())))
                {
                    intSerial = Integer.valueOf(objKey.toString());
                    intWeight = ((Integer) mapSerialWeights.get(intSerial)).intValue();
                }

                if (Boolean.parseBoolean(jsonSerials.get(objKey).toString()))
                {
                    sbBinaryMask.setCharAt(intWeight - 1, '1');
                }
                else
                    {
                    sbBinaryMask.setCharAt(intWeight - 1, '0');
                }
            }
            sbBinaryMask = sbBinaryMask.reverse();
        }
        catch (Exception ex)
        {
        }
        finally
        {
            mapSerialWeights.clear();
            mapSerialWeights = null;
            intSerial = null;
            intMaxWeight = null;
            jsonSerials = null;
        }
        mapSerialWeights = null;
        intSerial = null;
        intMaxWeight = null;
        jsonSerials = null;
        return EncodeUtils.binaryToHex(sbBinaryMask.toString());
    }

    public final HashMap<Integer, Integer> getSerialWeights() throws SQLException
    {
        if (con == null)
        {
            System.out.println("NOT CONNECTED");
        }
        else
        {
            System.out.println("CONNECTED");
        }
        String strSQL = "SELECT rmserial, rmweight FROM rightsmaster WHERE rmapplicable = 'Y' ";
        PreparedStatement ps = con.prepareStatement(strSQL);
        HashMap<Integer, Integer> results = new HashMap<Integer, Integer>(16);
        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            results.put(Integer.valueOf(rs.getInt(1)), Integer.valueOf(rs.getInt(2)));
        }
        return results;
    }

    public int getMaxWeight() throws SQLException
    {
        
        if (con == null)
        {
            System.out.println("NOT CONNECTED");
        }
        else
        {
            System.out.println("CONNECTED");
        }
        String strSQL = "SELECT MAX(rmweight) FROM rightsmaster WHERE rmapplicable = 'Y'";
        PreparedStatement ps = con.prepareStatement(strSQL);
        ResultSet rs = ps.executeQuery();
        if (rs.next())
        {
            return rs.getInt(1);
        }
        return 0;
    }

    public static void main(String[] args) throws ClassNotFoundException, SQLException
    {
    	ApplicationContext context =  new ClassPathXmlApplicationContext("beans.xml");
    	ACLMaskUpdator maskUpdator = (ACLMaskUpdator) context.getBean("aclMaskUpdator");
        String series1 ="{\"94\":true}";
    	String generatedMask = maskUpdator.getUpdatedMask(series1, "40400001000000000060000028a00000000000000000000000000000000000000000000018000000000000000000000000000000140000000000000000000000000000000000000000000000001003");
    	System.out.println(generatedMask);
    	Mask m = new Mask(generatedMask);
    	System.out.println(m.isEnabled(13));
    }
}
