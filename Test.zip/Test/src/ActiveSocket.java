import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;


public class ActiveSocket {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for(int i = 7000; i < 8000; i++){
			try
			{
				//available(i);
			}
			catch(Exception e){
				
			}
		}
		
		available(7777);

	}
	
	private static boolean available(int port) {
	   // System.out.println("--------------Testing port " + port);
	    Socket s = null;
	    try {
	        s = new Socket("192.168.100.118", port);
	        
	        byte[] messageByte = new byte[1000];
	        boolean end = false;
	        String dataString = "";

	        try 
	        {
	            DataInputStream in = new DataInputStream(s.getInputStream());

	            String messageString = "";;
				while(!end)
	            {
	                int bytesRead = in.read(messageByte);
	                messageString  += new String(messageByte, 0, bytesRead);
	                end = true;
	            }
	            System.out.println("MESSAGE: " + messageString);
	        }
	        catch (Exception e)
	        {
	            e.printStackTrace();
	        }
	        
	        
	        System.out.println("--------------Port " + port + " is not available");
	        return false;
	    } catch (IOException e) {
	        System.out.println("--------------Port " + port + " is available");
	        return true;
	    } finally {
	        if( s != null){
	            try {
	                s.close();
	            } catch (IOException e) {
	                throw new RuntimeException("You should handle this error." , e);
	            }
	        }
	    }
	}
}
