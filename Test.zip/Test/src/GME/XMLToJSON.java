package GME;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import net.sf.json.JSON;
import net.sf.json.JSONSerializer;
import net.sf.json.xml.XMLSerializer;

import org.xml.sax.SAXException;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import atg.taglib.json.util.XML;

public class XMLToJSON {
	public static void main(String a[]) throws IOException, JSONException, SAXException {
		JSONObject json = null;
		String xmlText = null;
		if(isValidMappingXML("ExcelToDelimMapping.xml", "mapping.xsd"))
		{
			json = xmlToJSON("ExcelToDelimMapping.xml");
			System.out.println("******** JSON *******");
			System.out.println(json);
			System.out.println("******* END ***************");
			
//			xmlText = JSONtoXML(json.toString());
//			//xmlText = XML.toString(json);
//			System.out.println("******** XML *******");
//			System.out.println(xmlText);
//			System.out.println("******* END ***************");
		}
		else
		{
			System.out.println("Mapping XML is not valid");
		}
	    
	}
	
	static JSONObject xmlToJSON(String fileName) throws JSONException, IOException
	{
		  BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
          StringBuilder responseStrBuilder = new StringBuilder();
          String inputStr;
          while ((inputStr = bufferedReader.readLine()) != null) {
              responseStrBuilder.append(inputStr);
          }
          JSONObject jsonObject = XML.toJSONObject(responseStrBuilder.toString());
          
          return jsonObject;
	}
	
	static boolean isValidMappingXML(String xmlPath, String xsdPath) throws SAXException, IOException
	{
		try {
            SchemaFactory factory = 
                    SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(new File(xsdPath));
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(new File(xmlPath)));
            
            
        } catch (SAXException e) {
            return false;
        }
        return true;
	}
	
	static String JSONtoXML(String jsonString) throws JSONException, IOException
	{
		XMLSerializer serializer = new XMLSerializer();
		serializer.setRootName("SampleJSON");
		JSON json = JSONSerializer.toJSON(jsonString);
		return serializer.write(json);
	}
}
