import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;

public class Numbertest {
   public static void main(String args[]) {
      // create an array list
     
	   
	 try
	 {
		 String str = null;
		 str.toUpperCase();
	 }
	 catch(NullPointerException exc)
	 {
		 System.out.println("In Null pointer Exc");
	 }
	 catch(Exception exc)
	 {
		 System.out.println("In Exc");
	 }
   }
}
