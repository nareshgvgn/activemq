/*** Eclipse Class Decompiler plugin, copyright (c) 2012 Chao Chen (cnfree2000@hotmail.com) ***/

import java.io.Serializable;
import java.util.BitSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

public final class MaskDuplicate implements Serializable {
	private static final long serialVersionUID = -7402553876337300806L;
	private static final Logger _log = LoggerFactory.getLogger(MaskDuplicate.class
			.getName());
	private static final int BIT_0 = 1;
	private static final int BIT_1 = 2;
	private static final int BIT_2 = 4;
	private static final int BIT_3 = 8;
	private static final int BIT_4 = 16;
	private static final int BIT_5 = 32;
	private static final int BIT_6 = 64;
	private static final int BIT_7 = 128;
	private BitSet _bits = null;

	public MaskDuplicate(String mask) {
		int cntr = 0;
		int i = 0;
		int len = 0;
		int digit = 0;

		Assert.notNull(mask, "Mask can not be null!");

		len = mask.length();
		if (_log.isDebugEnabled())
			_log.debug("Bit length of mask is " + (len * 4));
		this._bits = new BitSet(len * 4);
		for (i = len - 1; i > -1; --i) {
			digit = Integer.parseInt(Character.toString(mask.charAt(i)), 16);

			this._bits.set(cntr * 4, (digit & 0x1) == 1);
			this._bits.set(cntr * 4 + 1, (digit & 0x2) == 2);
			this._bits.set(cntr * 4 + 2, (digit & 0x4) == 4);
			this._bits.set(cntr * 4 + 3, (digit & 0x8) == 8);
			++cntr;
		}
		
		if (_log.isDebugEnabled())
			_log.debug("Mask initialization is complete!");
	}
	
	public String getBitSet()
	{
		String str = "";
		for(int i = 0; i < this._bits.length(); i++)
		{
			str = str + (this._bits.get(i) ? "1":"0");
		}
		return str;
	}
	
	public Boolean isEnabled(Integer weight) {
		if (weight == null)
			return Boolean.FALSE;
		return Boolean.valueOf(isEnabled(weight.intValue()));
	}

	public boolean isEnabled(int weight) {
		if (this._bits == null) {
			if (_log.isDebugEnabled())
				_log.debug("Mask is not initialized, will return false for weight "
						+ weight);
			return false;
		}

		if ((weight < 0) || (weight > this._bits.length())) {
			if (_log.isDebugEnabled())
				_log.debug("Weight " + weight
						+ " is outside the permitted limits!");
			return false;
		}

		return this._bits.get(weight - 1);
	}

	public int length() {
		if (this._bits == null)
			return 0;
		return this._bits.length();
	}

	public void overlayAnd(MaskDuplicate mask) {
		Assert.notNull(mask, "Mask can not be null!");
		int lenThis = length();
		int lenThat = mask.length();
		int len = (lenThis > lenThat) ? lenThis : lenThat;
		for (int i = 0; i < len; ++i) {
			if (!(mask.isEnabled(i + 1)))
				this._bits.set(i, false);
		}
	}

	public void overlayOr(MaskDuplicate mask) {
		int i = 0;

		Assert.notNull(mask, "Mask can not be null!");
		int lenThis = length();
		int lenThat = mask.length();
		int len = (lenThis > lenThat) ? lenThis : lenThat;
		for (i = 0; i < len; ++i) {
			if (mask.isEnabled(i + 1))
				this._bits.set(i, true);
		}
	}

	public String toHex() {
		int i = 0;
		int len = 0;
		int msk = 0;
		int rem = 0;
		int bitCntr = 0;
		char[] chars = (char[]) null;
		try {
			len = length();
			if (len < 1)
				return null;
			i = len % 4;
			if (i != 0)
				len += 4 - i;
			bitCntr = len / 4;
			chars = new char[bitCntr];
			for (i = 0; i < len; ++i) {
				rem = i % 4;
				if (isEnabled(i + 1))
					msk |= getWeight(rem);
				if (rem != 3)
					continue;
				chars[(bitCntr - 1)] = Integer.toString(msk, 16).charAt(0);
				msk = 0;
				--bitCntr;
			}

			return String.valueOf(chars);
		} finally {
			if (chars != null)
				chars = (char[]) null;
		}
	}

	private int getWeight(int bitPos) {
		int retVal = 0;
		Assert.isTrue((bitPos > -1) && (bitPos < 8), "Invalid bit position "
				+ bitPos);
		switch (bitPos) {
		case 0:
			retVal = 1;
			break;
		case 1:
			retVal = 2;
			break;
		case 2:
			retVal = 4;
			break;
		case 3:
			retVal = 8;
			break;
		case 4:
			retVal = 16;
			break;
		case 5:
			retVal = 32;
			break;
		case 6:
			retVal = 64;
			break;
		case 7:
			retVal = 128;
		}

		return retVal;
	}
}