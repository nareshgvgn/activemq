/**
 * Created by nareshdon on 03-11-2015.
 */

import java.lang.reflect.Array;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "leaves")
public class Leave {

	@Id
	@Column(name = "leaveid")
	private int leaveId;

	@Column(name = "employeeId")
	// @Constraints.Required(message = "Please Provide the UserName")
	private String employeeId;

	@Column(name = "fromDate")
	private Date fromDate;

	@Column(name = "toDate")
	private Date toDate;

	@Column(name = "approverId")
	private String approverId;

	@Column(name = "leaveReason")
	private String leaveReason;

	@Column(name = "status")
	@Enumerated(EnumType.ORDINAL)
	private LeaveStatus status;

	@Column(name = "leavetype")
	// @Constraints.Required(message = "Please Provide the Leave Type")
	private String leaveType;

	@Transient
	private int leaveDays;

	@Column(name = "maker")
	private String maker;

	static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	static String weekDays[] = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat",
			"Sun" };

	public static int yearlyLeaves = 20;

	public Leave() {

	}

	public int getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getApproverId() {
		return approverId;
	}

	public void setApproverId(String approverId) {
		this.approverId = approverId;
	}

	public String getLeaveReason() {
		return leaveReason;
	}

	public void setLeaveReason(String leaveReason) {
		this.leaveReason = leaveReason;
	}

	public LeaveStatus getStatus() {
		return status;
	}

	public void setStatus(LeaveStatus status) {
		this.status = status;
	}

	public int getLeaveDays() {
		return leaveDays;
	}

	public void setLeaveDays(int leaveDays) {
		this.leaveDays = leaveDays;
	}

	public static int getCurrentYear() {
		Calendar calendar = Calendar.getInstance();
		int currentYear = calendar.get(Calendar.YEAR);
		return currentYear;
	}

	/**
	 * It returns start date of the current year.
	 * 
	 * @param currentYear
	 * @return
	 */
	public static Date getStartDateOfCurrentYear(int currentYear) {
		String startDate = currentYear + "0101";
		try {
			return sdf.parse(startDate);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * It returns end date of the current year.
	 * 
	 * @param currentYear
	 * @return
	 */
	public static Date getEndDateOfCurrentYear(int currentYear) {
		String startDate = currentYear + "1231";
		try {
			return sdf.parse(startDate);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * It returns days between 2 dates including startDate and endDate
	 * 
	 * @param maxDate
	 * @param minDate
	 * @return
	 */
	private static long daysBetween(Date maxDate, Date minDate) {
		return ((maxDate.getTime() - minDate.getTime()) / 86400000) + 1;
	}

	/**
	 * It returns no. of week ends in between fromDate and toDate
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	private static int getWeekendsFromDates(Date fromDate, Date toDate) {
		int weekends = 0, intLeaves;
		/*
		 * Resolved Bug 61 reordered some statements in the for loop to include
		 * weekends at the start or end of the date range
		 */
		long diff = daysBetween(toDate, fromDate);
		Long temp = new Long(diff);
		intLeaves = Integer.parseInt(temp.toString());
		String leaveDays[] = new String[intLeaves];

		String day = getDayFromDate(fromDate);
		for (int i = 0; i < intLeaves; i++) {
			leaveDays[i] = day;
			day = getNextDayFromWeekDays(day);
		}
		weekends = getNoOfWeekends(leaveDays);
		return weekends;
	}

	/**
	 * It returns a day , given a date.
	 * 
	 * @param fromDate
	 * @return
	 */
	private static String getDayFromDate(Date fromDate) {
		String dateString = fromDate.toString();
		String day = "";
		if (dateString.contains("Mon"))
			day = "Mon";
		else if (dateString.contains("Tue"))
			day = "Tue";
		else if (dateString.contains("Wed"))
			day = "Wed";
		else if (dateString.contains("Thu"))
			day = "Thu";
		else if (dateString.contains("Fri"))
			day = "Fri";
		/*
		 * Added cases for sat and sun as it can also be a part in the applied
		 * date range
		 */
		else if (dateString.contains("Sat"))
			day = "Sat";
		else if (dateString.contains("Sun"))
			day = "Sun";
		return day;
	}

	/**
	 * It returns next day from the given day.(e.g Tue for Mon)
	 * 
	 * @param day
	 * @return
	 */
	private static String getNextDayFromWeekDays(String day) {
		int index = getIndexFromWeekDays(day);
		if (index == 6)
			return Array.get(weekDays, 0).toString();
		else
			// changed index from index+1
			return Array.get(weekDays, index + 1).toString();
	}

	/**
	 * It returns index of the array 'weekDays' given a day
	 * 
	 * @param day
	 * @return
	 */
	private static int getIndexFromWeekDays(String day) {
		int indexOfDay = 0;
		for (int i = 0; i < weekDays.length; i++) {
			if (weekDays[i].equals(day))
				indexOfDay = i;
		}
		return indexOfDay;
	}

	/**
	 * It returns no. of week ends given an array of days (e.g 2 for
	 * {'Fri','Sat','Sun','Mon'})
	 * 
	 * @param leaveDays
	 * @return
	 */
	private static int getNoOfWeekends(String leaveDays[]) {
		int noOfWeekends = 0;
		for (int i = 0; i < leaveDays.length; i++) {
			String day = leaveDays[i];
			if (day.equals("Sat") || day.equals("Sun"))
				noOfWeekends++;
		}
		return noOfWeekends;
	}

	public static void main(String a[]) {
		for (int i = 0; i < 50; i++) {
			int currentYear = Leave.getCurrentYear();
			Date startDate = Leave.getStartDateOfCurrentYear(currentYear);
			Date endDate = Leave.getEndDateOfCurrentYear(currentYear);
			System.out.println(startDate);
		}
	}
}
