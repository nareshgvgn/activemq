import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public abstract class DateRange implements Serializable
{
    /** The Constant TODAY. */
    public static final DateRange TODAY = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
            final Calendar cal = Calendar.getInstance();
            Date dtToday = new Date();
            cal.setTime(dtToday);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            return cal.getTime();
        }

        public Date getToDate()
        {
            return null;
        }

    };

    /** The Constant YESTERDAY. */
    public static final DateRange YESTERDAY = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
            final Calendar cal = Calendar.getInstance();
            try
            {
            	Date dtToday = new Date();
            	cal.setTime(dtToday);
//            cal.roll(Calendar.DAY_OF_YEAR, false);
//            cal.set(Calendar.HOUR_OF_DAY, 0);
//            cal.set(Calendar.MINUTE, 0);
//            cal.set(Calendar.SECOND, 0);
//            cal.set(Calendar.MILLISECOND, 0);
            	return cal.getTime();
            }
            catch(Exception e)
            {
            	
            }
			return null;
        }

        public Date getToDate()
        {
           return null;
        }

    };

    /** The Constant THIS_WEEK. */
    public static final DateRange THIS_WEEK = new DateRange()
    {
        /**
         *
         */
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
            final Calendar cal = DateRange.getStartPoint();
            cal.set(Calendar.DAY_OF_WEEK, cal.getActualMinimum(Calendar.DAY_OF_WEEK));
            return cal.getTime();
        }

        public Date getToDate()
        {
            final Calendar cal = DateRange.getEndPoint();
            cal.set(Calendar.DAY_OF_WEEK, cal.getActualMaximum(Calendar.DAY_OF_WEEK));
            return cal.getTime();
        }

    };

    /** The Constant THIS_MONTH. */
    public static final DateRange THIS_MONTH = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
            final Calendar cal = DateRange.getStartPoint();
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
            return cal.getTime();
        }

        public Date getToDate()
        {
            final Calendar cal = DateRange.getEndPoint();
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            return cal.getTime();
        }

    };

    /** The Constant LAST_WEEK. */
    public static final DateRange LAST_WEEK = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
            final Calendar cal = DateRange.getStartPoint();
            if (1 == cal.get(Calendar.WEEK_OF_YEAR))
            {
                cal.roll(Calendar.YEAR, false);
            }
            cal.roll(Calendar.WEEK_OF_YEAR, false);
            cal.set(Calendar.DAY_OF_WEEK, cal.getActualMinimum(Calendar.DAY_OF_WEEK));
            return cal.getTime();
        }

        public Date getToDate()
        {
            final Calendar cal = DateRange.getEndPoint();
            if (1 == cal.get(Calendar.WEEK_OF_YEAR))
            {
                cal.roll(Calendar.YEAR, false);
            }
            cal.roll(Calendar.WEEK_OF_YEAR, false);
            cal.set(Calendar.DAY_OF_WEEK, cal.getActualMaximum(Calendar.DAY_OF_WEEK));
            return cal.getTime();
        }

    };

    /** The Constant LAST_MONTH. */
    public static final DateRange LAST_MONTH = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
            final Calendar cal = DateRange.getStartPoint();
            if (0 == cal.get(Calendar.MONTH))
            {
                cal.roll(Calendar.YEAR, false);
            }
            cal.roll(Calendar.MONTH, false);
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
            return cal.getTime();
        }

        public Date getToDate()
        {
            final Calendar cal = DateRange.getEndPoint();
            if (0 == cal.get(Calendar.MONTH))
            {
                cal.roll(Calendar.YEAR, false);
            }
            cal.roll(Calendar.MONTH, false);
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            return cal.getTime();
        }

    };
    
    public static final DateRange LAST_MONTH_TODAY = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
        	final Calendar cal = DateRange.getStartPoint();
            if (0 == cal.get(Calendar.MONTH))
            {
                cal.roll(Calendar.YEAR, false);
            }
            cal.roll(Calendar.MONTH, false);
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
            return cal.getTime();
        }

        public Date getToDate()
        {
        	final Calendar cal = DateRange.getEndPoint();
        	return cal.getTime();
        }

    };
    
    public static final DateRange THIS_QUARTER = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
        	final Calendar cal = DateRange.getStartPoint();
        	cal.set(Calendar.MONTH,Quarter.valueOf(cal.get(Calendar.MONTH)).startMonth());
        	cal.set(Calendar.DAY_OF_MONTH,1);
        	cal.set(Calendar.HOUR_OF_DAY,0);
    		cal.set(Calendar.MINUTE,0);
    		cal.set(Calendar.SECOND,0);
    		cal.set(Calendar.MILLISECOND,0);
            return cal.getTime();
        }

        public Date getToDate()
        {
        	final Calendar cal = DateRange.getEndPoint();
        	cal.set(Calendar.MONTH,Quarter.valueOf(cal.get(Calendar.MONTH)).endMonth());
        	cal.set(Calendar.DAY_OF_MONTH,cal.getActualMaximum(Calendar.DAY_OF_MONTH));
        	cal.set(Calendar.HOUR_OF_DAY,23);
    		cal.set(Calendar.MINUTE,59);
    		cal.set(Calendar.SECOND,59);
    		cal.set(Calendar.MILLISECOND,999);
            return cal.getTime();
        }

    };
    
    public static final DateRange LAST_QUATER = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
        	final Calendar cal = DateRange.getStartPoint();
        	final Quarter prevQtr = Quarter.valueOf(cal.get(Calendar.MONTH)).previous();
        	if(prevQtr.equals(Quarter.FOURTH))
        	{
        		cal.roll(Calendar.YEAR,-1);
        	}
        	cal.set(Calendar.MONTH,prevQtr.startMonth());
    		cal.set(Calendar.DAY_OF_MONTH,1);
        	cal.set(Calendar.HOUR_OF_DAY,0);
    		cal.set(Calendar.MINUTE,0);
    		cal.set(Calendar.SECOND,0);
    		cal.set(Calendar.MILLISECOND,0);
            return cal.getTime();
        }

        public Date getToDate()
        {
        	final Calendar cal = DateRange.getEndPoint();
        	cal.set(Calendar.MONTH,Quarter.valueOf(cal.get(Calendar.MONTH)).endMonth());
        	cal.set(Calendar.DAY_OF_MONTH,cal.getActualMaximum(Calendar.DAY_OF_MONTH));
        	cal.set(Calendar.HOUR_OF_DAY,23);
    		cal.set(Calendar.MINUTE,59);
    		cal.set(Calendar.SECOND,59);
    		cal.set(Calendar.MILLISECOND,999);
            return cal.getTime();
        }

    };
    
    public static final DateRange LAST_QUATER_TODAY = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
        	final Calendar cal = DateRange.getStartPoint();
        	final Quarter prevQtr = Quarter.valueOf(cal.get(Calendar.MONTH)).previous();
        	if(prevQtr.equals(Quarter.FOURTH))
        	{
        		cal.roll(Calendar.YEAR,-1);
        	}
        	cal.set(Calendar.MONTH,prevQtr.startMonth());
    		cal.set(Calendar.DAY_OF_MONTH,1);
        	cal.set(Calendar.HOUR_OF_DAY,0);
    		cal.set(Calendar.MINUTE,0);
    		cal.set(Calendar.SECOND,0);
    		cal.set(Calendar.MILLISECOND,0);
            return cal.getTime();
        }

        public Date getToDate()
        {
        	final Calendar cal = DateRange.getEndPoint();
        	return cal.getTime();
        }

    };
    
    public static final DateRange THIS_YEAR = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
            final Calendar cal = DateRange.getStartPoint();
            cal.set(Calendar.DAY_OF_YEAR, cal.getActualMinimum(Calendar.DAY_OF_YEAR));
            return cal.getTime();
        }

        public Date getToDate()
        {
            final Calendar cal = DateRange.getEndPoint();
            cal.set(Calendar.DAY_OF_YEAR, cal.getActualMaximum(Calendar.DAY_OF_YEAR));
            return cal.getTime();
        }
    };
    
    public static final DateRange LAST_YEAR = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
        	final Calendar cal = DateRange.getStartPoint();
            cal.roll(Calendar.YEAR, false);
            cal.set(Calendar.DAY_OF_YEAR, cal.getActualMinimum(Calendar.DAY_OF_YEAR));
            return cal.getTime();
        }

        public Date getToDate()
        {
        	final Calendar cal = DateRange.getStartPoint();
            cal.roll(Calendar.YEAR, false);
            cal.set(Calendar.DAY_OF_YEAR, cal.getActualMaximum(Calendar.DAY_OF_YEAR));
            return cal.getTime();
        }

    };
    
    public static final DateRange LAST_YEAR_TODAY = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
        	final Calendar cal = DateRange.getStartPoint();
            cal.roll(Calendar.YEAR, false);
            cal.set(Calendar.DAY_OF_YEAR, cal.getActualMinimum(Calendar.DAY_OF_YEAR));
            return cal.getTime();
        }

        public Date getToDate()
        {
        	final Calendar cal = DateRange.getEndPoint();
        	return cal.getTime();
        }

    };
    
    
    public static final DateRange LAST_WEEK_TODAY = new DateRange()
    {
        private static final long serialVersionUID = 1L;

        public Date getFromDate()
        {
        	final Calendar cal = DateRange.getStartPoint();
            if (1 == cal.get(Calendar.WEEK_OF_YEAR))
            {
                cal.roll(Calendar.YEAR, false);
            }
            cal.roll(Calendar.WEEK_OF_YEAR, false);
            cal.set(Calendar.DAY_OF_WEEK, cal.getActualMinimum(Calendar.DAY_OF_WEEK));
            return cal.getTime();
        }

        public Date getToDate()
        {
        	final Calendar cal = DateRange.getEndPoint();
        	return cal.getTime();
        }

    };
    
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /**
     * Gets the from date.
     *
     * @return the from date
     */
    public abstract Date getFromDate();

    /**
     * Gets the to date.
     *
     * @return the to date
     */
    public abstract Date getToDate();

    /**
     * Gets the start point.
     *
     * @return the start point
     */
    private static Calendar getStartPoint()
    {
        final Calendar cal = Calendar.getInstance();
        Date dtToday = new Date();
        cal.setTime(dtToday);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        return cal;
    }

    /**
     * Gets the end point.
     *
     * @return the end point
     */
    private static Calendar getEndPoint()
    {
        final Calendar cal = Calendar.getInstance();
        Date dtToday = new Date();
        cal.setTime(dtToday);
        final Integer days = 23;
        final Integer minutes = 59;
        final Integer seconds = 59;
        cal.set(Calendar.HOUR_OF_DAY, days);
        cal.set(Calendar.MINUTE, minutes);
        cal.set(Calendar.SECOND, seconds);
        return cal;
    }
    
    /**
     * Enumeration of the four quarters of a year.
     * @author nmahajan
     *
     */
    enum Quarter 
    {

    	FIRST(Calendar.JANUARY,Calendar.MARCH),
    	SECOND(Calendar.APRIL,Calendar.JUNE),
    	THIRD(Calendar.JULY,Calendar.SEPTEMBER),
    	FOURTH(Calendar.OCTOBER,Calendar.DECEMBER);

    	private final int startMonth, endMonth;

    	/**
    	 * Creates a quarter with the given start and end month.
    	 *
    	 * @param startMonth the first month of the quarter
    	 * @param endMonth the last month of the quarter
    	 */
    	private Quarter(final int startMonth, final int endMonth)
    	{
    		this.startMonth = startMonth;
    		this.endMonth = endMonth;
    	}

    	/**
    	 * Used to retrieve the first month of the quarter.
    	 *
    	 * @return the first month of the quarter
    	 */
    	public int startMonth()
    	{
    		return(startMonth);
    	}

    	/**
    	 * Used to retrieve the last month of the quarter.
    	 *
    	 * @return the last month of the quarter
    	 */
    	public int endMonth()
    	{
    		return(endMonth);
    	}

    	/**
    	 * Used to convert the month value to its corresponding Quarter object. The values
    	 * are 0-based (as they would come from a GregorianCalendar object).
    	 *
    	 * @param month the number of the month (0-based)
    	 * @return the Quarter containing the given month
    	 */
    	public static Quarter valueOf(final int month)
    	{
    		Quarter qtr = null;
    		if(month < 3){qtr = Quarter.FIRST;}
    		else if(month > 2 && month < 6){qtr = Quarter.SECOND;}
    		else if(month > 5 && month < 9){qtr = Quarter.THIRD;}
    		else if(month > 8){qtr = Quarter.FOURTH;}
    		return(qtr);
    	}

    	/**
    	 * Used to retrieve the quarter that comes before this quarter.
    	 *
    	 * @return the previous quarter
    	 */
    	public Quarter previous()
    	{
    		final Quarter[] qtrs = values();
    		int idx = ordinal()-1;
    		if(idx < 0){idx = qtrs.length-1;}
    		return(qtrs[idx]);
    	}

    	/**
    	 * Used to retrieve the quarter that follows this quarter.
    	 *
    	 * @return the next quarter
    	 */
    	public Quarter next()
    	{
    		final Quarter[] qtrs = values();
    		int idx = ordinal()+1;
    		if(idx >= qtrs.length){idx = 0;}
    		return(qtrs[idx]);
    	}
    }
}
