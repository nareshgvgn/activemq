import java.util.ArrayList;
import java.util.List;

public class CompratorTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	List<User> lstUser = new ArrayList<User>();
		User user = new User("Naresh");
		lstUser.add(user);
		user = new User("Rruchita");
		lstUser.add(user);
		user = new User("Pranita");
		lstUser.add(user);
		
		java.util.Collections.sort(lstUser);
		
		for(User u : lstUser)
		{
			System.out.println(u.getUserName());
		}
	}

}
