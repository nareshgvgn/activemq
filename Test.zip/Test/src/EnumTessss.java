import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

import com.cashtech.phoenix.utils.encryption.CryptoUtils;

public class EnumTessss {

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		java.sql.Timestamp t = new java.sql.Timestamp(System.currentTimeMillis());
		System.out.println(t);
		String encrupted = encrypt("phoenix.password.key", "naresh");
		System.out.println(encrupted);
		System.out.println(decrypt("phoenix.password.key", encrupted));
		
		}
	
	public static String encrypt(String key, String data)
    {
        key = CryptoUtils.intersperse(key, CryptoUtils.getSeed());
        char tmp[] = (new String(Base64.encodeBase64(encrypt(key.getBytes(), data.getBytes())))).toCharArray();
        char result[] = new char[tmp.length];
        for(int i = 0; i < tmp.length; i++)
            result[computeOffset(i, tmp.length)] = tmp[i];

        return new String(result);
    }
	
	public static byte[] encrypt(byte key[], byte data[])
    {
        byte resultbytes[] = new byte[data.length];
        int datalen = data.length;
        for(int i = 0; i < datalen; i++)
        {
            int keyint = key[i % key.length];
            int sum = data[i] + keyint;
            if(sum > MAXVALUE)
                sum -= MAXVALUE + 1;
            resultbytes[computeOffset(i, datalen)] = (byte)sum;
        }

        return resultbytes;
    }

    public static int computeOffset(int i, int datalen)
    {
        int retval;
        if(i % 2 == 0)
            retval = datalen - i / 2 - 1;
        else
            retval = datalen - (i + datalen) / 2 - 1;
        return retval;
    }
    
    public static String decrypt(String key, String encryptedData)
    {
        key = CryptoUtils.intersperse(key, CryptoUtils.getSeed());
        char tmp[] = encryptedData.toCharArray();
        char result[] = new char[tmp.length];
        for(int i = 0; i < tmp.length; i++)
            result[computeReverseOffset(i, tmp.length)] = tmp[i];

        return new String(decrypt(key.getBytes(), Base64.decodeBase64((new String(result)).getBytes())));
    }

    public static byte[] decrypt(byte keybytes[], byte databytes[])
    {
        byte result[] = new byte[databytes.length];
        int datalen = databytes.length;
        for(int i = 0; i < datalen; i++)
        {
            int reverseOffset = computeReverseOffset(i, datalen);
            int resultint = databytes[reverseOffset];
            int keyint = keybytes[computeReverseOffset(reverseOffset, datalen) % keybytes.length];
            int delta = resultint < 0 ? (resultint + MAXVALUE + 1) - keyint : resultint - keyint;
            if(delta < 0)
                delta += MAXVALUE;
            result[computeReverseOffset(reverseOffset, datalen)] = (byte)delta;
        }

        return result;
    }

    public static int computeReverseOffset(int i, int datalen)
    {
        int retval;
        if(i < datalen / 2)
            retval = datalen - 1 - datalen % 2 - i * 2;
        else
            retval = (datalen - i - 1) * 2;
        return retval;
    }

    private static final long serialVersionUID = -6666575064860463043L;
    
    private static int MAXVALUE = 255;
}
