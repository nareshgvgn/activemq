import com.fundtech.core.util.StringUtils;


public class CRLFTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String src = "%0d%0aContent-Type: text/html%0d%0aHTTP/1.1 200 OK%0d%0aContent-Type: text/html%0d%0a%0d%0a%3Chtml%3EHacker Content%3C/html%3E";
		System.out.println(sanitizeCRLF(src));

	}
	
	/**
	 * Remove CR and LF characters from Source String
	 * @param source
	 * @return
	 */
	public static final String sanitizeCRLF(String source) 
	{
		
		if (null == source) {
			return null;
		}
		source = StringUtils.replace(source, "\n", "");
		source = StringUtils.replace(source, "\r", "");
		return source;
	}
	
}
