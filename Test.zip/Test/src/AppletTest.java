import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JLabel;

public class AppletTest extends JApplet {
   private Image logo1;  
   private ImageIcon logo2;   

   // load the image when the applet is loaded
   public void init()
   {
      logo1 = getImage( getDocumentBase(), "images/loading.gif" );
      JLabel btn = new JLabel("CLick Me");
      btn.setIcon(new ImageIcon(logo1));
      add(btn);
   }

}