import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

import org.springframework.util.Assert;

import com.fundtech.core.util.EncodeUtils;
import com.fundtech.core.util.StringUtils;

public class MaskTest
{
    /**
     * @param args
     */
   public Connection con = null;

    public MaskTest() throws ClassNotFoundException, SQLException
    {
      //IWebRequestContext
        Class.forName("oracle.jdbc.driver.OracleDriver");
        String connection = "jdbc:oracle:thin:@192.168.100.199:1521/CASHTECH";
        String userName = "QCBDBR4";
        String password = "QCBDBR4";
        con = DriverManager.getConnection(connection, userName, password);
    }

    public String getUpdatedMask(String strACLSerials, String strHexMask)
    {
       // MenuProvider
        int intWeight = 0;
        String strTemp = "";
        Integer intSerial = Integer.valueOf(0);
        Integer intMaxWeight = Integer.valueOf(0);
        JSONObject jsonSerials = null;
        StringBuilder sbBinaryMask = null;
        HashMap<Integer, Integer> mapSerialWeights = null;

        Assert.notNull(strACLSerials, "ACL Serials can not be null, can not provide new mask!");
        try
        {
            intMaxWeight = Integer.valueOf(this.getMaxWeight());
            mapSerialWeights = this.getSerialWeights();
            jsonSerials = (JSONObject) JSONSerializer.toJSON(strACLSerials);

            if (strHexMask == null)
            {
                strTemp = StringUtils.padLeft(strTemp, '0', intMaxWeight.intValue());
                sbBinaryMask = new StringBuilder(strTemp);
                sbBinaryMask = sbBinaryMask.reverse();
            }
            else
            {
                strTemp = EncodeUtils.hexToBinary(strHexMask);
                strTemp = StringUtils.padLeft(strTemp, '0', intMaxWeight.intValue());
                sbBinaryMask = new StringBuilder(strTemp);
            }

            if (jsonSerials.isEmpty())
            {
                if (strHexMask == null)
                {
                    String str1 = EncodeUtils.binaryToHex(sbBinaryMask.toString());
                    return str1;
                }
                String str1 = strHexMask;
                return str1;
            }

            sbBinaryMask = sbBinaryMask.reverse();

            for (Iterator localIterator = jsonSerials.keySet().iterator(); localIterator.hasNext();)
            {
                Object objKey = localIterator.next();

                if (mapSerialWeights.containsKey(Integer.valueOf(objKey.toString())))
                {
                    intSerial = Integer.valueOf(objKey.toString());
                    intWeight = ((Integer) mapSerialWeights.get(intSerial)).intValue();
                }

                if (Boolean.parseBoolean(jsonSerials.get(objKey).toString()))
                {
                    sbBinaryMask.setCharAt(intWeight - 1, '1');
                }
                else
                    {
                    sbBinaryMask.setCharAt(intWeight - 1, '0');
                }
            }
            sbBinaryMask = sbBinaryMask.reverse();
        }
        catch (Exception ex)
        {
        }
        finally
        {
            mapSerialWeights.clear();
            mapSerialWeights = null;
            intSerial = null;
            intMaxWeight = null;
            jsonSerials = null;
        }
        mapSerialWeights = null;
        intSerial = null;
        intMaxWeight = null;
        jsonSerials = null;
        return EncodeUtils.binaryToHex(sbBinaryMask.toString());
    }

    public final HashMap<Integer, Integer> getSerialWeights() throws SQLException
    {
        if (con == null)
        {
            System.out.println("NOT CONNECTED");
        }
        else
        {
            System.out.println("CONNECTED");
        }
        String strSQL = "SELECT rmserial, rmweight FROM rightsmaster WHERE rmapplicable = 'Y' ";
        PreparedStatement ps = con.prepareStatement(strSQL);
        HashMap<Integer, Integer> results = new HashMap<Integer, Integer>(16);
        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            results.put(Integer.valueOf(rs.getInt(1)), Integer.valueOf(rs.getInt(2)));
        }
        return results;
    }

    public int getMaxWeight() throws SQLException
    {
        
        if (con == null)
        {
            System.out.println("NOT CONNECTED");
        }
        else
        {
            System.out.println("CONNECTED");
        }
        String strSQL = "SELECT MAX(rmweight) FROM rightsmaster WHERE rmapplicable = 'Y'";
        PreparedStatement ps = con.prepareStatement(strSQL);
        ResultSet rs = ps.executeQuery();
        if (rs.next())
        {
            return rs.getInt(1);
        }
        return 0;
    }
    
    private String toHex(BitSet mask)
    {
        int i = 0;
        int len = 0;
        int msk = 0;
        int rem = 0;
        int bitCntr = 0;
        char[] chars = null;

        try
        {
            len = mask.length();
            if (len < 1) return null;
            i = len % 4;
            if (i != 0) len = len + (4 - i);
            bitCntr = len / 4;
            chars = new char[bitCntr];
            for (i = 0; i < len; i++)
            {
                rem = i % 4;
                if (mask.get(i + 1)) msk = msk | getWeight(rem);
                if (rem == 3)
                {
                    chars[bitCntr - 1] = Integer.toString(msk, 16).charAt(0);
                    msk = 0;
                    bitCntr--;
                }
            }
            return String.valueOf(chars);
        }
        finally
        {
            if (chars != null) chars = null;
        }
    }
    
    private int getWeight(int bitPos)
    {
        int retVal = 0;
        Assert.isTrue((bitPos > -1 && bitPos < 8), "Invalid bit position " + bitPos);
        switch (bitPos)
        {
        case 0:
            retVal = 1;
            break;
        case 1:
            retVal = 2;
            break;
        case 2:
            retVal = 4;
            break;
        case 3:
            retVal = 8;
            break;
        case 4:
            retVal = 16;
            break;
        case 5:
            retVal = 32;
            break;
        case 6:
            retVal = 64;
            break;
        case 7:
            retVal = 128;
            break;
        }
        return retVal;
    }
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException
    {
    	//ACLMaskUpdator maskUpdator = new ACLMaskUpdator();
        //String mask="{"2":false,"3":false,"12":false,"13":false,"14":false,"15":false,"19":false,"20":false,"21":false,"22":false,"23":false,"24":false,"27":false,"28":false,"29":false,"30":false,"32":false,"33":false,"34":false,"35":false,"38":false,"39":false,"43":false,"44":false,"45":false,"47":false,"48":false,"50":false,"51":false,"52":false,"53":false,"89":false,"90":false,"91":false,"93":false,"95":false,"96":false,"97":true,"98":false,"99":false,"100":false,"101":false,"103":false,"104":false,"105":false,"106":false,"107":false,"108":false,"111":false,"112":false,"113":false,"116":false,"117":false,"118":false,"121":false,"122":false,"124":false,"126":false,"127":false,"129":false,"130":false,"132":false,"134":false,"135":false,"137":false,"138":false,"140":false,"141":false,"151":false,"152":false,"153":false,"154":false,"155":false,"156":false,"161":false,"162":false,"163":false,"164":false,"165":false,"166":false,"167":false,"168":false,"169":false,"194":false,"195":false,"196":false,"197":false,"198":false,"199":false,"200":false,"201":false,"202":false,"203":false,"204":false,"205":false,"208":false,"209":false,"210":false,"211":false,"212":false,"213":false,"214":false,"215":false,"216":false,"217":false,"218":false,"219":false,"221":false,"222":false,"224":false,"225":false,"226":false,"228":false,"229":false,"230":false,"232":false,"233":false,"234":false,"236":false,"237":false,"238":false,"240":false,"241":false,"242":false,"243":false,"244":false,"245":false,"247":false,"248":false,"249":false,"251":false,"252":false,"253":false,"254":false,"257":true}"
//        MaskGenerate m=new MaskGenerate();
//       
        String series1 ="{\"75\":true}";
//        String mask=m.getUpdatedMask(series1, null);
//        System.out.println("*****");
//        System.out.println(mask);
        try
        {
    	MaskDuplicate m = new MaskDuplicate("000000000C07C10011C0000000000000000000000000000000000011000000000000000000000000000100000000000001830000000000000000008000040006000000000000001000000000000F8002FA000DFE501810000000000800040000101C0440299CC000000000200000000000001E0800000000000035000000D283");
    	System.out.println(m.getBitSet());
    	//System.out.println(maskUpdator.getUpdatedMask(series1, "0000000850000040000000000000000000000000000000000010000000000000000000000000000000000000000004040000000000000006000002020000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000800000000000031010000428B"));
        //binaryMask=binaryMask.reverse();
        //System.out.println(binaryMask);
       // System.out.println(binaryMask.charAt(12));
    	//System.out.println(m.isEnabled(13));
        System.out.println(m.isEnabled(531));
        }
        catch(Exception e){
        	System.out.println(e);
        }
        //00000000000000000000000000001000010100000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000001000000000000000000000000000000000000000001100000000000000000000000101000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000001100010000000000000000000000000101001010001011
        //							  1000010100000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000001000000000000000000000000000000000000000001100000000000000000000000101000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000001100010000000000000000000000000101001010001011
    }

}
