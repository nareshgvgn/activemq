import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

import org.springframework.jdbc.core.CallableStatementCallback;

import com.fundtech.core.security.context.IWebRequestContext;
import com.fundtech.core.security.context.RequestContextHolder;
import com.fundtech.core.util.DateUtils;


public class ConnectionTest
{
    public static void main(String a[])
    {
        try
        {
            // String driverClass = "com.mysql.jdbc.Driver";
            // String userName = "root";
            // String password = "naresh";
            // String connection = "jdbc:mysql://localhost:3306/liquidise";
            /* Oracle */
            String driverClass = "oracle.jdbc.driver.OracleDriver";
            String userName = "FCM46SYSUS";
            String password = "FCM46SYSUS";
            String connection = "jdbc:oracle:thin:@192.168.100.118:1521/FUNDTECH";
            
            Class.forName(driverClass);
            Connection con = DriverManager.getConnection(connection, userName, password);
            if (con == null)
            {
                System.out.println("NOT CONNECTED");
            }
            else
            {
                System.out.println(" CONNECTED\n");
            }
            Date applicationDate = null;
            //applicationDate =getSellerApplDate(con, "IN");
            
            
            getNextBusinessDay(con, new TyObjHoliday(), 2);
            
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }
    
    public static Date getSellerApplDate(Connection pobjCnn, String sellerCode) throws SQLException
	{
		Date              dtRet     = null;
		String            strCmd    = null;
		CallableStatement lobjStmt  = null;
		strCmd = "{? = call GENERIC.GET_SELLER_APPL_DATETIME(?)}";
		try
		{
			lobjStmt = pobjCnn.prepareCall(strCmd);
			lobjStmt.registerOutParameter(1, Types.DATE);
			lobjStmt.setString(2, sellerCode);
			lobjStmt.execute();
			System.out.println(lobjStmt.getDate(1));
			dtRet = lobjStmt.getDate(1);
			if (dtRet == null)
			{
				dtRet = new Date(System.currentTimeMillis());
			}
		}
		catch (SQLException se)
		{
			throw se;
		}
		finally
		{
			try
			{
				if (lobjStmt != null)
				{
					lobjStmt.close();
					lobjStmt = null;
				}
			}
			catch (SQLException SQLe)
			{
				//do nothing
			}
		}
		return dtRet;
	}
    
    /**
     * Gets the next business day.
     *
     * @param tyHoliday
     *            the ty holiday
     * @param prenoteuntilldays
     *            the prenoteuntilldays
     * @return the next business day
     * @throws SQLException 
     */
    public static Date getNextBusinessDay(Connection con,final TyObjHoliday tyHoliday, final int prenoteuntilldays) throws SQLException
    {
    	java.util.Date dt = new java.util.Date();
        Date nextBusinessDay = null;
        CallableStatement cstmt  = null;
        String strCmd = "{call get_business_date(?,?,?,?,?,?)}";
        cstmt = con.prepareCall(strCmd);
        cstmt.setDate(1, new java.sql.Date(dt.getTime()));
        cstmt.setObject(2, tyHoliday);
        cstmt.setInt(3, prenoteuntilldays);
        cstmt.registerOutParameter(4, Types.DATE);
        cstmt.registerOutParameter(5, Types.VARCHAR);
        cstmt.registerOutParameter(6, Types.VARCHAR);
        cstmt.executeQuery();
        System.out.println(cstmt.getDate(4));
        System.out.println(cstmt.getString(5));
        return cstmt.getDate(4);
    }
}
