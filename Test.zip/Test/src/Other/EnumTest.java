package Other;

public class EnumTest {

	enum ExpenseReportStatus {
		
		CREATED("CREATED"),
		SUBMITTED("SUBMITTED"),
		APPROVED("APPROVED"),
		REJECTED("REJECTED"),
		READY_FOR_PAYMENT("READY_FOR_PAYMENT"),
		PAID("PAID");
		
		String status;
		
		ExpenseReportStatus(String status)
		{
			this.status = status;
		}
		
		public String toString()
		{
			return this.status;
		}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		ExpenseReportStatus f = ExpenseReportStatus.READY_FOR_PAYMENT;
		System.out.println(f.toString());
	}

}
