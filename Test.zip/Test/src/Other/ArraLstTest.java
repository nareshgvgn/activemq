package Other;

import java.util.ArrayList;
import java.util.List;


public class ArraLstTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<CBean> cLst = new ArrayList<CBean>();
		cLst.add(new CBean("C1"));
		cLst.add(new CBean("C2"));
		cLst.add(new CBean("C3"));
		cLst.add(new CBean("C4"));
		
		System.out.println(cLst);
		cLst.remove(new CBean("C4"));
		System.out.println(cLst);
	}

}
