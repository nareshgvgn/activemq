package Other;

import java.math.BigDecimal;


public class BigDecimalTest
{

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        BigDecimal bd = new BigDecimal("99999999999999999999");
        BigDecimal bd1 = new BigDecimal("400");
        System.out.println(bd.longValue());
        
    }

}
