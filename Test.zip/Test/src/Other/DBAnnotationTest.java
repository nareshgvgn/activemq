package Other;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DBAnnotationTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			CBean ob = new CBean();
			Map<String,String> columnMap = new HashMap<String,String>();
			Map<String,String> duplicateColumnMap = new HashMap<String,String>();
			Class firstClass = ob.getClass();
			Method[] firstClassMethodsArr = firstClass.getMethods();

			for (int i = 0; i < firstClassMethodsArr.length; i++) {
				Method firstClassMethod = firstClassMethodsArr[i];
				if (firstClassMethod.getName().startsWith("get")) 
				{
					Annotation[] annos = firstClassMethod.getAnnotations();
					if(null !=annos && annos.length > 0)
					{
						Annotation anColumn = annos[0];
						String strAnnotation = anColumn.toString();
						strAnnotation = strAnnotation.replace(')', ' ');
						int columnStrIndex = strAnnotation.indexOf("column");
						strAnnotation = strAnnotation.replace("column=", " ");
						String columnName = strAnnotation.substring(columnStrIndex);
						if(columnMap.get(columnName) != null)
						{
							duplicateColumnMap.put(columnName, columnName);
						}
						columnMap.put(columnName, columnName);
					}
				}
			}
			
			System.out.println("*** Duplicate Column Annoatation **");
			Iterator it = duplicateColumnMap.entrySet().iterator();
		    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		        System.out.println(pairs.getKey());
		    }

		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}

}
