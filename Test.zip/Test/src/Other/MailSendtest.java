package Other;

import java.util.Properties;

import javax.mail.internet.MimeMessage;

import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

public class MailSendtest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		JavaMailSenderImpl mailSender = null;
		mailSender = new JavaMailSenderImpl();
        mailSender.setUsername("nmahajan@omniscient.co.in");
        mailSender.setPassword("NAR#$12");
        mailSender.setHost("smtp.office365.com");
        mailSender.setPort(587);
        Properties ps = new Properties();
        ps.put("mail.smtp.starttls.enable", "true");
        ps.put("mail.smtp.ssl.enable", "false");
        ps.put("mail.smtp.auth", "true");
        mailSender.setJavaMailProperties(ps);
        //System.out.println(mailSender.get);
		MimeMessage mimeMessage = mailSender.createMimeMessage();
        try
        {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setFrom("naresh.mahajan@omniscient.co.in");
            helper.setTo("naresh.mahajan@omniscient.co.in");
            helper.setSubject("Leave Manager test");
            helper.setText("Leave SSS Mail", true);
            mailSender.send(mimeMessage);
        }
        catch (MailException exc)
        {
            exc.printStackTrace();
        }
        catch (Exception exc)
        {
        	exc.printStackTrace();
        }
	

	}

}
