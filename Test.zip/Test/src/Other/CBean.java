
package Other;
// TODO: Auto-generated Javadoc
/**
 * The Class CponCommonFilterBean.
 */
public class CBean
{

    /** The _str name. */
    private String _strName;

    /** The _str value. */
    private String _strValue;

    /** The _bln is assigned. */
    private Boolean _blnIsAssigned;

    /** The _bln is assigned. */
    private Boolean _blnIsAutoApproved;

    /** The _str profile id. */
    private String _strProfileId;
    
    /** The _bln is updated. */
    private Boolean _blnIsUpdated;
    
    /** The _str feature subset code. */
    private String _strFeatureSubsetCode;
    
    /** The _str feature type. */
    private String _strFeatureType;
    
    /** The sequence no. */
    private int sequenceNo;
    
    /** The feature value. */
    private String featureValue;
    
    /** The _int updated. */
    private int _intUpdated;
    
    /** The is read only. */
    private boolean isReadOnly = false;
    
    /** The _str feature id. */
    //ADDED FOR UNDO BUFFER HANDLING. NOT BEING USED IN DATABASE
    private String _strFeatureId;
    
    /** The is mandotary. */
    private String isMandotary;
    
    /** The _str configurable flag. */
    private String _strConfigurableFlag;
    
    /** The _str applicable flag. */
    private String _strApplicableFlag;
    
    /** The _str feature module. */
    private String _strFeatureModule;
    
    /** The _srt priv param. */
    private String _srtPrivParam;
    
    /** The is read only. */
    private boolean isReadOnlyAutoApproved = false;
    
    CBean(String value)
    {
    	_strValue = value;
    }
    /**
     * Gets the name.
     * 
     * @return the name
     */
    public String getName()
    {
        return _strName;
    }

    /**
     * Sets the name.
     * 
     * @param strName
     *            the new name
     */
    public void setName(String strName)
    {
        this._strName = strName;
    }

    /**
     * Gets the value.
     * 
     * @return the value
     */
    public String getValue()
    {
        return _strValue;
    }

    /**
     * Sets the value.
     * 
     * @param strValue
     *            the new value
     */
    public void setValue(String strValue)
    {
        this._strValue = strValue;
    }

    /**
     * Gets the checks if is assigned.
     * 
     * @return the checks if is assigned
     */
    public Boolean getIsAssigned()
    {
        return _blnIsAssigned;
    }

    /**
     * Sets the checks if is assigned.
     * 
     * @param _blnIsAssigned
     *            the new checks if is assigned
     */
    public void setIsAssigned(Boolean _blnIsAssigned)
    {
        this._blnIsAssigned = _blnIsAssigned;
    }

    /**
     * Gets the checks if is auto approved.
     * 
     * @return the checks if is auto approved
     */
    public Boolean getIsAutoApproved()
    {
        return _blnIsAutoApproved;
    }

    /**
     * Sets the checks if is auto approved.
     * 
     * @param _blnIsAutoApproved
     *            the new checks if is auto approved
     */
    public void setIsAutoApproved(Boolean _blnIsAutoApproved)
    {
        this._blnIsAutoApproved = _blnIsAutoApproved;
    }

    /**
     * Gets the profile id.
     * 
     * @return the profile id
     */
    public String getProfileId()
    {
        return _strProfileId;
    }

    /**
     * Sets the profile id.
     * 
     * @param _strProfileId
     *            the new profile id
     */
    public void setProfileId(String _strProfileId)
    {
        this._strProfileId = _strProfileId;
    }

    /**
     * Gets the checks if is updated.
     *
     * @return the checks if is updated
     */
    public Boolean getIsUpdated()
    {
        return _blnIsUpdated;
    }

    /**
     * Sets the checks if is updated.
     *
     * @param _blnIsUpdated the new checks if is updated
     */
    public void setIsUpdated(Boolean _blnIsUpdated)
    {
        this._blnIsUpdated = _blnIsUpdated;
    }

    /**
     * Gets the feature subset code.
     *
     * @return the feature subset code
     */
    public String getFeatureSubsetCode() {
        return _strFeatureSubsetCode;
    }

    /**
     * Sets the feature subset code.
     *
     * @param featureSubsetCode the new feature subset code
     */
    public void setFeatureSubsetCode(String featureSubsetCode) {
        this._strFeatureSubsetCode = featureSubsetCode;
    }

    /**
     * Gets the feature type.
     *
     * @return the feature type
     */
    public String getFeatureType() {
        return _strFeatureType;
    }

    /**
     * Sets the feature type.
     *
     * @param featureType the new feature type
     */
    public void setFeatureType(String featureType) {
        this._strFeatureType = featureType;
    }

    /**
     * Gets the sequence no.
     *
     * @return the sequence no
     */
    public int getSequenceNo() {
        return sequenceNo;
    }

    /**
     * Sets the sequence no.
     *
     * @param sequenceNo the new sequence no
     */
    public void setSequenceNo(int sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    /**
     * Gets the feature value.
     *
     * @return the feature value
     */
    public String getFeatureValue() {
        return featureValue;
    }

    /**
     * Sets the feature value.
     *
     * @param featureValue the new feature value
     */
    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    CBean()
    {
    	
    }

    /* (non-Javadoc)
     * @see java.lang.Object#clone()
     */
    public CBean clone()
    {
    	CBean  srcBean = this;
    	CBean destBean = new CBean();
        destBean.setFeatureSubsetCode(srcBean.getFeatureSubsetCode());
        destBean.setName(srcBean.getName());
        destBean.setValue(srcBean.getValue());
        destBean.setFeatureType(srcBean.getFeatureType());
        destBean.setFeatureValue(srcBean.getFeatureValue());
        destBean.setIsAssigned(srcBean.getIsAssigned());
        destBean.setProfileId(srcBean.getProfileId());
        destBean.setSequenceNo(srcBean.getSequenceNo());
        destBean.setReadOnly(srcBean.getReadOnly());
        return destBean;
    }

    /**
     * Gets the updated.
     *
     * @return the updated
     */
    public int getUpdated()
    {
        return _intUpdated;
    }

    /**
     * Sets the updated.
     *
     * @param _intUpdated the new updated
     */
    public void setUpdated(int _intUpdated)
    {
        this._intUpdated = _intUpdated;
    }

	/**
	 * Gets the read only.
	 *
	 * @return the read only
	 */
	public boolean getReadOnly() {
		return isReadOnly;
	}

	/**
	 * Sets the read only.
	 *
	 * @param isReadOnly the new read only
	 */
	public void setReadOnly(boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

    /**
     * Gets the feature id.
     *
     * @return the feature id
     */
    public String getFeatureId()
    {
        return _strFeatureId;
    }

    /**
     * Sets the feature id.
     *
     * @param _strFeatureId the new feature id
     */
    public void setFeatureId(String _strFeatureId)
    {
        this._strFeatureId = _strFeatureId;
    }

    /**
     * Gets the checks if is mandotary.
     *
     * @return the checks if is mandotary
     */
    public String getIsMandotary()
    {
        return isMandotary;
    }

    /**
     * Sets the checks if is mandotary.
     *
     * @param isMandotary the new checks if is mandotary
     */
    public void setIsMandotary(String isMandotary)
    {
        this.isMandotary = isMandotary;
    }

	/**
	 * Gets the configurable flag.
	 *
	 * @return the _strConfigurableFlag
	 */
	public String getConfigurableFlag() {
		return _strConfigurableFlag;
	}

	/**
	 * Sets the configurable flag.
	 *
	 * @param _strConfigurableFlag the _strConfigurableFlag to set
	 */
	public void setConfigurableFlag(String _strConfigurableFlag) {
		this._strConfigurableFlag = _strConfigurableFlag;
	}

	/**
	 * Gets the applicable flag.
	 *
	 * @return the _strApplicableFlag
	 */
	public String getApplicableFlag() {
		return _strApplicableFlag;
	}

	/**
	 * Sets the applicable flag.
	 *
	 * @param _strApplicableFlag the _strApplicableFlag to set
	 */
	public void setApplicableFlag(String _strApplicableFlag) {
		this._strApplicableFlag = _strApplicableFlag;
	}

	/**
	 * Gets the feature module.
	 *
	 * @return the _strFeatureModule
	 */
	public String getFeatureModule() {
		return _strFeatureModule;
	}

	/**
	 * Sets the feature module.
	 *
	 * @param _strFeatureModule the _strFeatureModule to set
	 */
	public void setFeatureModule(String _strFeatureModule) {
		this._strFeatureModule = _strFeatureModule;
	}

    /**
     * Sets the priv param.
     *
     * @param strPrivParam the new priv param
     */
    public void setPrivParam(String strPrivParam)
    {
        this._srtPrivParam = strPrivParam;
    }

    /**
     * Gets the priv param.
     *
     * @return the priv param
     */
    public String getPrivParam()
    {
        return _srtPrivParam;
    }

    public boolean getReadOnlyAutoApproved()
    {
        return isReadOnlyAutoApproved;
    }

    public void setReadOnlyAutoApproved(boolean isReadOnlyAutoApproved)
    {
        this.isReadOnlyAutoApproved = isReadOnlyAutoApproved;
    }
    
    public boolean equals(Object other) 
    {
    	CBean otherData = (CBean)other;
        return otherData.getValue() == this.getValue();
    }
}
