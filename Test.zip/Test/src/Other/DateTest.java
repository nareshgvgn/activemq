package Other;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.taglibs.standard.tag.common.fmt.FormatDateSupport;

import com.fundtech.core.util.StringUtils;

public class DateTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//   30/11/2014
		
		Date d = new Date();
		System.out.println(formatDate(d));
	}
	
	/**
	 * Format Date like TO_DATE('12/12/2015','MM/dd/YYYY')
	 * @param strDate
	 * @return
	 */
	private static String formatDate(Object inputDate) 
	{
		String strDate = null;
		String dateFormat ="dd/MM/yyyy";
		if(inputDate instanceof String)
		{
			strDate = (String) inputDate;
		}
		else if(inputDate instanceof java.util.Date)
		{
			DateFormat st = new SimpleDateFormat(dateFormat);
			strDate = st.format(inputDate);
		}
		if (true)
		{
			String result = "TO_DATE({0}, {1})";
			strDate = "'".concat(strDate).concat("'");
			dateFormat = "'".concat(dateFormat).concat("'");
			String formattedDate = StringUtils.formatString(result, new Object[]{strDate, dateFormat});
			strDate = formattedDate;
		}
		return strDate;
	}

}
