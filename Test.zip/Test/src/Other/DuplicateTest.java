package Other;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;


public class DuplicateTest {
	public static void main(String a[])
	{
		String s="140623003I, 140623003I,sdfdsf,dsfdsf";
		List<String> items = Arrays.asList(s.split("\\s*,\\s*"));
		System.out.println(items);
		Set<String> set = new LinkedHashSet<String>(items);
		Iterator<String> i = set.iterator();
		String dt = "";
		while(i.hasNext())
		{
			dt = dt.concat((String) i.next());
			dt = dt.concat(",");
		}
		System.out.println(dt);
		final StringTokenizer clientArray = new StringTokenizer(dt, ",");
		while(clientArray.hasMoreElements())
        {
			 String clientCode= String.valueOf(clientArray.nextElement());
			System.out.println("*");
        }
	}
}
