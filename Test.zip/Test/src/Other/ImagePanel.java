package Other;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class ImagePanel extends JPanel
{

	Image loaderImage;
	Image applyImage;
	Image blankImage;
	int parentWidth;
	int parentHeight;
	String strCurrentTime = null;
	List<WaterReminderBean> times = null;
	public List<WaterReminderBean> getTimes() {
		return times;
	}

	public void setTimes(List<WaterReminderBean> times) {
		this.times = times;
	}

	public ImagePanel(int parentWidth, int parentHeight, String strCurrentTime,List<WaterReminderBean> times)
	{
		setBackground(Color.white);
		this.parentWidth = parentWidth;
		this.parentHeight = parentHeight;
		this.strCurrentTime = strCurrentTime;
		this.times = times;
		loaderImage = Toolkit.getDefaultToolkit().createImage(
				"images/upload_progress.gif");
		applyImage=Toolkit.getDefaultToolkit().createImage(
				"images/water_reminder.png");
		blankImage=Toolkit.getDefaultToolkit().createImage(
				"images/blank.PNG");
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		if (true)
		{
			Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			int x = (int) ((parentWidth - loaderImage.getWidth(null)) / 2);
			g.drawImage(applyImage, 10, 10, this);
			g.drawImage(loaderImage, x-60, applyImage.getHeight(null)+90, this);
			g.setFont(new Font("Arial", Font.BOLD+Font.ITALIC, 50));
			g.setColor(Color.CYAN);
			g.drawString(strCurrentTime, x - 160, 130);
			int count = 0;
			g.setFont(new Font("Arial", Font.BOLD+Font.ITALIC, 20));
			int xco = applyImage.getWidth(null) + 20;
			int yco = 30;
			for(WaterReminderBean bean : getTimes())
			{
				g.setColor(bean.getStatus().color);
				
				if(count <= 6)
				{
					g.drawString(bean.getTime(), xco, yco + (30 * count));
				}
				else
				{
					g.drawString(bean.getTime(), xco + 140, yco + (30 * (count % 6)));
				}
				count ++;
			}
			
			//g.drawImage(blankImage, x+10, loaderImage.getHeight(null)-10, this);
		}
	}

}
