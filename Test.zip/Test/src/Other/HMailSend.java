package Other;

import java.util.Properties;

import javax.mail.internet.MimeMessage;

import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

public class HMailSend {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		JavaMailSenderImpl mailSender = null;
		mailSender = new JavaMailSenderImpl();
        mailSender.setUsername("nareshdon@don.com");
        mailSender.setPassword("naresh");
        mailSender.setHost("192.168.100.109");
        mailSender.setPort(25);
        Properties ps = new Properties();
        ps.put("mail.transport.protocol", "smtp");
        ps.put("mail.smtp.starttls.enable", "false");
        ps.put("mail.smtp.ssl.enable", "false");
        ps.put("mail.smtp.auth", "true");
        mailSender.setJavaMailProperties(ps);
        //System.out.println(mailSender.get);
		MimeMessage mimeMessage = mailSender.createMimeMessage();
        try
        {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setFrom("naresh@don.com");
            helper.setTo("naresh@omniservices.com");
            helper.setSubject("Leave Manager test");
            helper.setText("Leave SSS Mail", true);
            mailSender.send(mimeMessage);
        }
        catch (MailException exc)
        {
            exc.printStackTrace();
        }
        catch (Exception exc)
        {
        	exc.printStackTrace();
        }
	

	}

}
