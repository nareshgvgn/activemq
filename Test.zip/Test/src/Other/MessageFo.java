package Other;
import java.text.MessageFormat;


public class MessageFo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="My Name Is {0}{1}";
		MessageFormat m = new MessageFormat(s);
		m.formatToCharacterIterator("[");
		System.out.println(m.format(new Object[]{"Naresh","Don"}));
	}

}
