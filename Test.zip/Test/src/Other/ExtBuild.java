package Other;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class ExtBuild{
    public static void main(String[] args) {
        
    	Object a[]={"Naresh","OK"};
    	Object b[] = null;
    	System.arraycopy(b, 0, a, 0, b.length);
    }
}