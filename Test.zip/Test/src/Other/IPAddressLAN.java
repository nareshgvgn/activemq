package Other;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class IPAddressLAN {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		getIPAddressList();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	public static Map<String, String> getIPAddressList() throws IOException {
		Map<String,String> ipAddressList = new HashMap<String,String>();
		try
		{ 
            Process p=Runtime.getRuntime().exec("arp -a"); 
            BufferedReader reader=new BufferedReader(
                new InputStreamReader(p.getInputStream())
            ); 
            String line;
            StringBuilder sb = new StringBuilder("");
            while((line = reader.readLine()) != null) 
            { 
            	line = line.trim();
            	if(line.startsWith("192.168"))
            	{
            		fetchIPAddessAndHostName(line, ipAddressList);
            	}
            } 
        }
        catch(IOException e1)
        {
        	System.out.println(e1);
        }
		return null; 
	}

	private static void fetchIPAddessAndHostName(String line, Map<String,String> ipAddressList) 
	{
		String ipAddress = fetchIPAddess(line);
		String machineName = findMachineNameFromLAN(ipAddress);
		System.out.println(ipAddress+" "+machineName);
		ipAddressList.put(ipAddress, machineName);
	}

	private static String findMachineNameFromLAN(String ipAddress) {
		try
		{ 
            Process p=Runtime.getRuntime().exec("cmd /c NBTSTAT -A "+ipAddress); 
            BufferedReader reader=new BufferedReader(
                new InputStreamReader(p.getInputStream())
            ); 
            String line;
            StringBuilder sb = new StringBuilder("");
            while((line = reader.readLine()) != null) 
            { 
                //System.out.println(line);
            	sb.append("\n"+line);
            } 
            return fetchMachineName(sb.toString());
        }
        catch(IOException e1)
        {
        	System.out.println(e1);
        }
		return null;
	}
	
	/*
	  Name               Type         Status
  ---------------------------------------------
  NARESH-PC      <00>  UNIQUE      Registered 
  OMNISCIENT     <00>  GROUP       Registered 
  NARESH-PC      <20>  UNIQUE      Registered 
  OMNISCIENT     <1E>  GROUP       Registered 
	 */
	static String fetchMachineName(String line)
	{
		String machineName = "";
		int index = 0;
		String currentLine = "";
		while(index < line.length())
		{
			if(line.charAt(index)=='\n')
			{
				if(currentLine.indexOf("UNIQUE") > 0)
				{
					//Finding Index of < character in <00>
					int xmlChar = currentLine.indexOf('<');
					machineName =  currentLine.substring(0, xmlChar);
					return machineName;
				}
				currentLine = "";
			}
			currentLine = currentLine + line.charAt(index);
			index++;
		}
		return null;
	}
	
	private static String fetchIPAddess(String line) 
	{
		return line.substring(0, 15).trim();
	}
}
