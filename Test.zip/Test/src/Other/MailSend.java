package Other;

import java.util.Properties;

import javax.mail.internet.MimeMessage;

import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.fundtech.core.util.StringUtils;


public class MailSend
{
    private static SimpleMailMessage _message;

    public static void main(String[] args) 
    {
        String password = "";
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        //mailSender.setUsername("naresh_mahajan@omniscient.co.in");
        mailSender.setPassword("***");
        mailSender.setHost("webmail.omniscient.co.in");
        mailSender.setPort(25);
        Properties ps = new Properties();
        //ps.setProperty("mail.smtp.starttls.enable", "true");
        ps.put("mail.smtp.auth", "true");
        mailSender.setJavaMailProperties(ps);
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        try
        {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setFrom("naresh_mahajan@omniscient.co.in");
            helper.setTo("naresh_mahajan@omniscient.co.in");
            String subject = "test1\r\nContent-Type: text/html; charset = \"iso-8859-1\"\r\n\r\n<html><body>Hacked</body></html><!--";
            String mailText = "SENT FROM JAVA PROGRAM <br/><br/>"+ "Reagards<br/>"+"Naresh Mahajan";
            helper.setText(mailText, true);
            helper.setSubject(removeCRLF(subject));
            mailSender.send(mimeMessage);
        }
        catch (MailException exc)
        {
            exc.printStackTrace();
        }
        catch (Exception exc)
        {
        	exc.printStackTrace();
        }
        
    }
    
public static final String removeCRLF(String source) {
		
		source = StringUtils.replace(source, "\n", "");
		source = StringUtils.replace(source, "\r", "");
		return source;
	}
}
