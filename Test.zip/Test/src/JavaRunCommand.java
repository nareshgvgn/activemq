import java.io.*;
 
public class JavaRunCommand {
 
    public static void main(String args[]) {
 
        String s = null;
 
        try {
             
        // run the Unix "ps -ef" command
            // using the Runtime exec method:
        	String ipAddress="192.168.100.52";
            //Process p = Runtime.getRuntime().exec("cmd dir");
            Process p = Runtime.getRuntime().exec("cmd /c c:");
            
            p = Runtime.getRuntime().exec("cmd /c D:/apache-tomcat-7.0.27-Temp/bin/startup.bat");
            BufferedReader reader = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(
            		p.getErrorStream()));
			String line;
			StringBuilder sb = new StringBuilder("");
			while ((line = reader.readLine()) != null) {
				// System.out.println(line);
				System.out.println(line);
			}
			System.out.println("Error Starts");
			while ((line = errorReader.readLine()) != null) {
				// System.out.println(line);
				System.out.println(line);
			}
            System.exit(0);
        }
        catch (IOException e) {
            System.out.println("exception happened - here's what I know: ");
            e.printStackTrace();
            System.exit(-1);
        }
    }
}