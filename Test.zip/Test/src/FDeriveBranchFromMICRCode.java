package com.dh.iris.admin.functions;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

/**
 * 
 * <p>Derive The Branch Code From MICR Code
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author nmahajan
 * @version $Id$
 */
public class FDeriveBranchFromMICRCode extends AdminLoggerPlugin
{
	private final Logger	logger	= LoggerFactory.getLogger(FDeriveBranchFromMICRCode.class.getName());
	@Override
	public Object execute(Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		Statement statement = null;
		ResultSet resultSet = null;
		String sql = null;
        String micrCode = null;
        String mop = null;
	
		try
		{
			micrCode = (String) params.get("VALUE");
			if (micrCode == null || micrCode.isEmpty())
				return micrCode;
			else
				mop = micrCode;
			sql = "SELECT drawee_branch_code FROM drawee_bank_branch_mst  WHERE valid_flag='Y' AND micr_branch_code='" + micrCode + "'";

			statement = dbConnection.createStatement();
			resultSet = statement.executeQuery(sql);
			if (resultSet.next())
			{
				mop = resultSet.getString(1);
			}
		}
		catch (Exception exp)
		{
			logger.error("Exception while Deriving the Branch Code", exp);
		}
		finally
		{
			HelperUtils.doClose(resultSet);
			HelperUtils.doClose(statement);
		}
		return mop;
	}
}
