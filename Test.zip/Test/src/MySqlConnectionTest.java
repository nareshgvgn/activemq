import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;
import javax.swing.JOptionPane;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


public class MySqlConnectionTest
{
    public static void main(String a[])
    {
        try
        {
            // String driverClass = "com.mysql.jdbc.Driver";
            // String userName = "root";
            // String password = "naresh";
            // String connection = "jdbc:mysql://localhost:3306/liquidise";
            /* End Oracle */
            String driverClass = "com.mysql.jdbc.Driver";
            String userName = "root";
            String password = "naresh";
            String dbName = "seleniumkeyword";
            String connection = "jdbc:mysql://192.168.100.109:3306/";
            //userName = JOptionPane.showInputDialog("Enter Username", "root");
          //  password = JOptionPane.showInputDialog("Enter Password","naresh");
        //    dbName =  JOptionPane.showInputDialog("Enter Password","AZCLOUD");
            Class.forName(driverClass);
            Connection con = DriverManager.getConnection(connection + dbName, userName, password);
            if (con == null)
            {
            	 System.out.println("NOT CONNECTED");
            	
            	//JOptionPane.showMessageDialog(null, "Unable To Connect", "MYSQL Connection", JOptionPane.ERROR_MESSAGE );
            }
            else
            {
            	 System.out.println(" CONNECTED\n");
            	 System.out.println(getUniqueId(con));
            	//JOptionPane.showMessageDialog(null, "Connected Suceesfully", "MYSQL Connection", JOptionPane.INFORMATION_MESSAGE );
            }
            
        }
        catch (Exception e)
        {
        	System.out.println(e);
        }
    }
    
    public static String getUniqueId(Connection con) {
    	
    	 String driverClass = "com.mysql.jdbc.Driver";
         String userName = "root";
         String password = "naresh";
         String dbName = "seleniumkeyword";
         String connection = "jdbc:mysql://192.168.100.109:3306/seleniumkeyword";
    	
		//String sql = "SELECT LEFT(UUID(), 10)";
		DriverManagerDataSource ds = new DriverManagerDataSource(connection, userName, password);
		ds.setDriverClassName(driverClass);
		List<Object> lstArgs = new ArrayList<Object>();
		JdbcTemplate jdbc = new JdbcTemplate(ds);

		String sql = "SELECT LEFT(UUID(), 10)";
		try
		{
			return jdbc.queryForObject(sql, lstArgs.toArray(), String.class);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
	
	}
    
}
