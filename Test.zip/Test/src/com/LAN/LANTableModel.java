package com.LAN;

import javax.swing.table.DefaultTableModel;


class LANTableModel extends DefaultTableModel {
	  public static final int IMG_COL = 0;

	  public String[] m_colNames = { "Sr.No", "Ip Address", "Machine Name" };

	  public Class[] m_colTypes = { Integer.class, String.class, String.class };
	  
	  public LANTableModel() {
	    super();

	  }

	  public int getColumnCount() {
	    return m_colNames.length;
	  }
	  
	  public String getColumnName(int col) {
	    return m_colNames[col];
	  }
	}