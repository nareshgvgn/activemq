package com.LAN;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LanMachineName {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(findMachineNameFromLAN("192.168.100.9"));
	}
	
	static String findMachineNameFromLAN(String ipAddress) {
		try {
			Process p = Runtime.getRuntime().exec(
					"cmd /c NBTSTAT -A " + ipAddress);
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			String line;
			StringBuilder sb = new StringBuilder("");
			while ((line = reader.readLine()) != null) {
				// System.out.println(line);
				sb.append("\n" + line);
			}
			return fetchMachineName(sb.toString());
		} catch (IOException e1) {
			System.out.println(e1);
		}
		return null;
	}

	/*
	 * Name Type Status --------------------------------------------- NARESH-PC
	 * <00> UNIQUE Registered OMNISCIENT <00> GROUP Registered NARESH-PC <20>
	 * UNIQUE Registered OMNISCIENT <1E> GROUP Registered
	 */
	static String fetchMachineName(String line) {
		String machineName = "";
		int index = 0;
		String currentLine = "";
		while (index < line.length()) {
			if (line.charAt(index) == '\n') {
				if (currentLine.indexOf("Host not found") > 0) {
					return currentLine.substring(0,
							currentLine.indexOf("Host not found"));
				}
				if (currentLine.indexOf("UNIQUE") > 0) {
					// Finding Index of < character in <00>
					int xmlChar = currentLine.indexOf('<');
					machineName = currentLine.substring(0, xmlChar);
					return machineName.trim();
				}
				currentLine = "";
			}
			currentLine = currentLine + line.charAt(index);
			index++;
		}
		return null;
	}
}
