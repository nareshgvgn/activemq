package com.LAN;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

public class IPAddressLAN {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		JFrame demoFrame = new JFrame("LAN Demo");
		JButton save = new JButton("Save Output to File");
		JButton refresh = new JButton("Refresh ALL");
		JPanel buttonPanel = new JPanel();
		final LANTableModel imageTableModel = new LANTableModel();
		save.setBackground(Color.red);
		refresh.setBackground(Color.red);
		JTable imageTable = new JTable(imageTableModel);
		// imageTable.getColumnModel().getColumn(0).setCellRenderer(new
		// LANTableCellRenderer());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 1.0;
		// c.gridwidth = 2;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		demoFrame.setLayout(new GridBagLayout());

		demoFrame.getContentPane().add(new JScrollPane(imageTable));
		demoFrame.getContentPane().add(buttonPanel);
		buttonPanel.add(refresh);
		buttonPanel.add(save);
		demoFrame.pack();
		demoFrame.setVisible(true);
		 // Reload Table Model from File
		 try {
		 FileInputStream fin = new FileInputStream("ipAddressList.txt");
		 ObjectInputStream ois = new ObjectInputStream(fin);
		 final LANTableModel tempModel = (LANTableModel) ois.readObject();
		
		 for(int index = 0; index < tempModel.getRowCount(); index++)
		 SwingUtilities.invokeLater(new Runnable() {
		 public void run() {
		 imageTableModel.addRow(tempModel.getDataVector());
		 // tableModel.addRow(new Object[]{ipAddressList.size(),
		 // ipAddress, machineName});
		 }
		 });
		
		 } catch (Exception e) {
		 }
		getIPAddressList(imageTableModel, imageTable);

	}

	public static void getIPAddressList(final LANTableModel tableModel,
			final JTable tableRef) throws IOException {
		final Map<String, String> ipAddressList = new HashMap<String, String>();
		try {
//			  Process p=Runtime.getRuntime().exec("arp -a"); BufferedReader
//			  reader=new BufferedReader( new
//			  InputStreamReader(p.getInputStream()) ); String line;
//			  StringBuilder sb = new StringBuilder(""); while((line =
//			  reader.readLine()) != null) { line = line.trim();
//				if (line.startsWith("192.168")) {
//					fetchIPAddessAndHostName(line, ipAddressList, tableModel,tableRef);
//				}
//			}
			 
			
			Thread queryThread = new Thread() {
			      public void run() {
			       
			    	  for (int index = 20; index <= 254; index++) {
							final String line = "192.168.100." + index;
							SwingUtilities.invokeLater(new Runnable() {
								public void run() {
									Map<String, String> map = fetchIPAddessAndHostName(
											line, ipAddressList, tableModel, tableRef);
									
								}
							});
						}
			    	  
			    	  
			      }
			    };
			    queryThread.start();

		} catch (Exception e1) {
			System.out.println(e1);
		}

	}

	private static Map<String, String> fetchIPAddessAndHostName(final String line,
			final Map<String, String> ipAddressList,
			final LANTableModel tableModel, final JTable tableRef) {
		final Map<String, String> map = new HashMap<String, String>();
		Thread queryThread = new Thread() {
		      public void run() {
		
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				final String ipAddress = fetchIPAddess(line);
				final String machineName = findMachineNameFromLAN(ipAddress);
				if (!"Host not found".equals(machineName))
					ipAddressList.put(ipAddress, machineName);
				map.put("IP_ADDRESS", ipAddress);
				map.put("MACHINE_NAME", machineName);
				tableModel.addRow(new Object[] { 1,
						map.get("IP_ADDRESS"), map.get("MACHINE_NAME") });
				System.out.println(map.get("IP_ADDRESS") + " MAP " + map.get("MACHINE_NAME"));
			}
		});
		      }
		};
		queryThread.start();
		return map;
	}

	private static String findMachineNameFromLAN(String ipAddress) {
		try {
			Process p = Runtime.getRuntime().exec(
					"cmd /c NBTSTAT -A " + ipAddress);
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			String line;
			StringBuilder sb = new StringBuilder("");
			while ((line = reader.readLine()) != null) {
				// System.out.println(line);
				sb.append("\n" + line);
			}
			return fetchMachineName(sb.toString());
		} catch (IOException e1) {
			System.out.println(e1);
		}
		return null;
	}

	/*
	 * Name Type Status --------------------------------------------- NARESH-PC
	 * <00> UNIQUE Registered OMNISCIENT <00> GROUP Registered NARESH-PC <20>
	 * UNIQUE Registered OMNISCIENT <1E> GROUP Registered
	 */
	static String fetchMachineName(String line) {
		String machineName = "";
		int index = 0;
		String currentLine = "";
		while (index < line.length()) {
			if (line.charAt(index) == '\n') {
				if (currentLine.indexOf("Host not found") > 0) {
					return currentLine.substring(0,
							currentLine.indexOf("Host not found"));
				}
				if (currentLine.indexOf("UNIQUE") > 0) {
					// Finding Index of < character in <00>
					int xmlChar = currentLine.indexOf('<');
					machineName = currentLine.substring(0, xmlChar);
					return machineName;
				}
				currentLine = "";
			}
			currentLine = currentLine + line.charAt(index);
			index++;
		}
		return null;
	}

	private static String fetchIPAddess(String line) {
		if (line.length() > 15)
			return line.substring(0, 15).trim();
		else
			return line.substring(0, line.length()).trim();
	}
}
