package com.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import net.sf.json.JSONObject;

public class XmlMain {

	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {
		
		InputStream in = new FileInputStream(new File("C:/Users/nmahajan/Downloads/pain.001.001.06/pain.001.001.06.xsd"));
		MyXSDTreeCreator creator = new MyXSDTreeCreator();
        JSONObject json = creator.create(in);
        System.out.println(json);

	}

}
