package com.xml;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.w3c.dom.ls.LSInput;


import org.apache.xerces.impl.dv.XSSimpleType;
import org.apache.xerces.impl.xs.XMLSchemaLoader;
import org.apache.xerces.xs.XSAttributeDeclaration;
import org.apache.xerces.xs.XSAttributeUse;
import org.apache.xerces.xs.XSComplexTypeDefinition;
import org.apache.xerces.xs.XSConstants;
import org.apache.xerces.xs.XSElementDeclaration;
import org.apache.xerces.xs.XSModel;
import org.apache.xerces.xs.XSModelGroup;
import org.apache.xerces.xs.XSNamedMap;
import org.apache.xerces.xs.XSObject;
import org.apache.xerces.xs.XSObjectList;
import org.apache.xerces.xs.XSParticle;
import org.apache.xerces.xs.XSSimpleTypeDefinition;
import org.apache.xerces.xs.XSTerm;
import org.apache.xerces.xs.XSTypeDefinition;

public class MyXSDTreeCreator
{

    private final List<XSElementDeclaration> elements = new ArrayList<XSElementDeclaration>();
    private final Stack<String> elementStack = new Stack<String>();

    /**
     * This method is not thread safe. So caller has to ensure thread safety.
     */
    public JSONObject create(InputStream is)
    {
        elements.clear();
        elementStack.clear();
        JSONObject json = new JSONObject();
        XMLSchemaLoader loader = new XMLSchemaLoader();
        try
        {
	        XSModel model = (XSModel) loader.load(new Input(is));
	        XSNamedMap map = model.getComponents(XSConstants.ELEMENT_DECLARATION);
	        if (map != null)
	        {
	            JSONArray elementJson = new JSONArray();
	            for (int j = 0; j < map.getLength(); j++)
	            {
	                XSElementDeclaration element = (XSElementDeclaration) map.item(j);
	                create(element, "1", "1",elementJson);
	            }
	            json.element("data", elementJson);
	        }
        }
        catch(Exception exc)
        {
        	System.out.println(exc);
        }
        return json;
    }

    private void create(XSElementDeclaration element, String minOccur, String maxOccur, JSONArray elementJson)
    {
        if (elements.contains(element))
        {
            // To avoid infinite looping of elements
            return;
        }
        elements.add(element);
        StringBuffer elementName = new StringBuffer(element.getName());
        if (isRepeating(minOccur, maxOccur))
        {
            //elementName.append("[").append(minOccur).append("..").append(maxOccur).append("]");
        	/*
        	 * To keep the logic similar for XML and XSD.
        	 */
        	elementName.append("[..]");
        }
        elementStack.push(elementName.toString());
        JSONObject json = new JSONObject();
        json.element("data", elementName.toString());
        JSONObject attrJson = new JSONObject();
        attrJson.element("xpath", getCurrentXpath());
        /*IRISADM-150 : Implicit DataType conversion*/
        XSTypeDefinition typeDefinition = element.getTypeDefinition();
        if (typeDefinition.getTypeCategory() == XSTypeDefinition.SIMPLE_TYPE)
        {
            XSSimpleTypeDefinition sdef = (XSSimpleTypeDefinition) typeDefinition;
            short primitiveType = sdef.getBuiltInKind();
            String dataType = fetchDataType(primitiveType);
            attrJson.element("dataType", dataType);
        }
        if(typeDefinition.getTypeCategory() == XSTypeDefinition.COMPLEX_TYPE)
        {
            XSTypeDefinition baseType = typeDefinition.getBaseType();
            if(baseType.getTypeCategory() == XSTypeDefinition.SIMPLE_TYPE)
            {
                XSSimpleTypeDefinition sdef = (XSSimpleTypeDefinition) baseType;
                short primitiveType = sdef.getBuiltInKind();
                String dataType = fetchDataType(primitiveType);
                attrJson.element("dataType", dataType);
            }
        }
        json.element("attr", attrJson);

        JSONArray jsonAttrChildren = new JSONArray();
        if (typeDefinition.getTypeCategory() == XSTypeDefinition.COMPLEX_TYPE)
        {
            JSONArray jsonChildren = new JSONArray();
            jsonAttrChildren = getAttributes((XSComplexTypeDefinition) typeDefinition,elementJson,elementName.toString());            
            jsonChildren.addAll(getChildElements((XSComplexTypeDefinition) typeDefinition,elementJson));
            if (!jsonChildren.isEmpty())
            {
                json.element("state", "closed");
                json.element("children", jsonChildren);
            }
        }
        elementStack.pop();
        elementJson.add(json);
        elementJson.addAll(jsonAttrChildren);
        return;
    }

    /*IRISADM-150 : Implicit DataType conversion*/
    /**
     * Fetch data type.
     *
     * @param primitiveType 
     *              the primitive type
     * @return the data type
     */
    private String fetchDataType(short primitiveType)
    {
        String dataType = "anyType";
        switch(primitiveType)
            {
                case XSConstants.STRING_DT :
                case XSConstants.NORMALIZEDSTRING_DT:
                               dataType  = "STRING";
                     break;
                case XSConstants.DECIMAL_DT :
                case XSConstants.DOUBLE_DT  :
                case XSConstants.FLOAT_DT :
                case XSConstants.LONG_DT :
                               dataType  = "DECIMAL";
                     break;
                case XSConstants.INTEGER_DT :
                case XSConstants.INT_DT :
                case XSConstants.POSITIVEINTEGER_DT :
                case XSConstants.NEGATIVEINTEGER_DT :
                case XSConstants.NONPOSITIVEINTEGER_DT :
                case XSConstants.NONNEGATIVEINTEGER_DT :
                case XSConstants.UNSIGNEDINT_DT :
                case XSConstants.UNSIGNEDLONG_DT :
                case XSConstants.SHORT_DT :
                case XSConstants.UNSIGNEDSHORT_DT :
                case XSConstants.BYTE_DT :
                case XSConstants.UNSIGNEDBYTE_DT :
                               dataType = "NUMBER";
                     break;
                case XSConstants.DATE_DT:
                               dataType = "DATE";
                     break;
                case XSConstants.DATETIME_DT :
                case XSConstants.TIME_DT:
                               dataType = "DATETIME";
                     break;
                default :
            }
        return dataType;
    }

    private JSONArray getAttributes(XSComplexTypeDefinition typeDefinition, JSONArray elementJson, String elementName)
    {
        JSONArray jsonChildren = new JSONArray();
        XSObjectList attr = typeDefinition.getAttributeUses();        
        for (int i = 0; i < attr.getLength(); i++)
        {
            XSAttributeDeclaration attrDeclaration = ((XSAttributeUse) attr.item(i)).getAttrDeclaration();
            jsonChildren.add(create(attrDeclaration,elementName));
        }
        return jsonChildren;
    }

    private JSONObject create(XSAttributeDeclaration attrDeclaration, String parentName)
    {
        JSONObject json = new JSONObject();
        json.element("data",parentName + "@" + attrDeclaration.getName());
        JSONObject attrJson = new JSONObject();
        attrJson.element("rel", "Attribute");
        attrJson.element("xpath", getCurrentXpath() + "[@" + attrDeclaration.getName() + "]");
        
        /*IRISADM-150 : Implicit DataType conversion*/
        String type = "anyType";
        if(attrDeclaration.getType() == XSSimpleType.PRIMITIVE_STRING)
        {  
            type="STRING";
        }
        if(attrDeclaration.getType() == XSSimpleType.PRIMITIVE_DECIMAL
                        || attrDeclaration.getType() == XSSimpleType.PRIMITIVE_DOUBLE
                        || attrDeclaration.getType() == XSSimpleType.PRIMITIVE_FLOAT)
        {  
            type="NUMBER";
        }
        if(attrDeclaration.getType() == XSSimpleType.PRIMITIVE_DATE)
        {  
            type="DATE";
        }
        if(attrDeclaration.getType() == XSSimpleType.PRIMITIVE_DATETIME || attrDeclaration.getType() == XSSimpleType.PRIMITIVE_TIME)
        {  
            type="DATETIME";
        }
        attrJson.element("dataType", type);
        json.element("attr", attrJson); // xs:element[@type]
         
        return json;
    }

    private JSONArray getChildElements(XSComplexTypeDefinition typeDefinition, JSONArray elementJson)
    {
        JSONArray jsonChildren = new JSONArray();
        XSParticle particle = typeDefinition.getParticle();
        if (particle != null)
        {
            if (particle.getTerm().getType() == XSConstants.MODEL_GROUP)
            {
                XSModelGroup group = (XSModelGroup) particle.getTerm();
                int count = group.getParticles().getLength();
                for (int i = 0; i < count; i++)
                {
                    XSObject element2 = group.getParticles().item(i);
                    String minOccur = getMinOccur((XSParticle) element2);
                    String maxOccur = getMaxOccur((XSParticle) element2);
                    XSTerm term = ((XSParticle) element2).getTerm();
                    if (term.getType() == XSConstants.ELEMENT_DECLARATION)
                    {
                       create((XSElementDeclaration) term, minOccur, maxOccur,jsonChildren);
                    }
                }
            }
            else if (particle.getTerm().getType() == XSConstants.ELEMENT_DECLARATION)
            {
                String minOccur = getMinOccur(particle);
                String maxOccur = getMaxOccur(particle);
                create((XSElementDeclaration) particle.getTerm(), minOccur, maxOccur,jsonChildren);
            }

        }
        return jsonChildren;
    }

    private String getMaxOccur(XSParticle particle)
    {
        String maxOccur = "";
        if (particle.getMaxOccursUnbounded())
        {
            maxOccur = "n";
        }
        else
        {
            maxOccur = particle.getMaxOccurs() + "";
        }
        return maxOccur;
    }

    private String getMinOccur(XSParticle particle)
    {
        String minOccur = "";
        minOccur = particle.getMinOccurs() + "";
        return minOccur;
    }

    private boolean isRepeating(String minOccur, String maxOccur)
    {
        return !"1".equals(maxOccur);
    }

    private String getCurrentXpath()
    {
        Iterator<String> elements = elementStack.iterator();
        StringBuffer xpath = new StringBuffer();
        while (elements.hasNext())
        {
            xpath.append("/").append(elements.next());
        }
        return xpath.toString();
    }

    public static class Input implements LSInput
    {

        /** The is. */
        private InputStream is;

        /**
         * Instantiates a new input.
         * 
         * @param is
         *            the is
         */
        public Input(InputStream is)
        {
            this.is = is;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#getCharacterStream()
         */
        public Reader getCharacterStream()
        {
            return null;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#setCharacterStream(java.io.Reader)
         */
        public void setCharacterStream(Reader reader)
        {

        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#getByteStream()
         */
        public InputStream getByteStream()
        {
            return is;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#setByteStream(java.io.InputStream)
         */
        public void setByteStream(InputStream inputstream)
        {
            is = inputstream;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#getStringData()
         */
        public String getStringData()
        {
            return null;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#setStringData(java.lang.String)
         */
        public void setStringData(String s)
        {

        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#getSystemId()
         */
        public String getSystemId()
        {
            return null;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#setSystemId(java.lang.String)
         */
        public void setSystemId(String s)
        {

        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#getPublicId()
         */
        public String getPublicId()
        {
            return null;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#setPublicId(java.lang.String)
         */
        public void setPublicId(String s)
        {

        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#getBaseURI()
         */
        public String getBaseURI()
        {
            return null;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#setBaseURI(java.lang.String)
         */
        public void setBaseURI(String s)
        {

        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#getEncoding()
         */
        public String getEncoding()
        {
            return null;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#setEncoding(java.lang.String)
         */
        public void setEncoding(String s)
        {

        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#getCertifiedText()
         */
        public boolean getCertifiedText()
        {
            return false;
        }

        /*
         * (non-Javadoc)
         * @see org.w3c.dom.ls.LSInput#setCertifiedText(boolean)
         */
        public void setCertifiedText(boolean flag)
        {

        }
    }

}
