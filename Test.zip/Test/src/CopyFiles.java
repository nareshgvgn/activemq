import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.CharBuffer;

import org.apache.commons.io.IOUtils;

public class CopyFiles {

	private static final String FILENAME = "classpath.txt";

	public static void main(String[] args) {

		BufferedReader br = null;
		FileReader fr = null;

		try {

			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);

			String sCurrentLine;

			br = new BufferedReader(new FileReader(FILENAME));
			int cnt = 0;
			while ((sCurrentLine = br.readLine()) != null) {
				FileInputStream is = new FileInputStream(sCurrentLine);
				File file = new File(sCurrentLine);
				
				FileOutputStream os = new FileOutputStream("D://logs/"+file.getName());
				IOUtils.copy(is , os);
				is.close();
				os.close();
			}

		} catch (IOException e) {

			System.out.println(e);

		} finally {

			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}

	}
}
