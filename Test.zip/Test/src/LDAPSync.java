import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.*;

public class LDAPSync {

	public static final String ldapURL = "172.16.1.4";
	public static final String domainName = "ou=People,o=omniscient,c=in";
	public static final String port = "389";

	private static final String bindUser = "jirabind@omniscient.co.in";
	private static final String bindUserPassword = "Windows#123";

	private static final String ldapSearchBase = "OU=UserAccounts|OU=AdminUsers,OU=Omni-Pune,DC=omniscient,DC=co,DC=in";

	private static final String serviceBaseDN = "OU=UserAccounts,OU=Omni-Pune,DC=omniscient,DC=co,DC=in";

	private static final String searchFilter = "(&(objectClass=user)(sAMAccountName=%s))";
	private static final String securityAuth = null;

	public LDAPSync() {
	}

	public static String getUserDN(String ldapAccountToLookup)
			throws NamingException {
		LdapContext ctx = null;
        String userCompleteDN = null;
        try {
            ctx = getContext(bindUser, bindUserPassword);
            SearchResult srLdapUser = findAccountByAccountName(ctx,ldapSearchBase.trim(), ldapAccountToLookup.trim());

            if (srLdapUser != null) {
                userCompleteDN = srLdapUser.getNameInNamespace();
            }
        } finally {
            if (ctx != null) {
                try {
                    ctx.close();
                } catch (NamingException e) {
                    System.out.println("Failed to close the LDAP context....");
                }
            }
        }
        return userCompleteDN;
	}

	public static SearchResult findAccountByAccountName(DirContext ctx,
			String ldapSearchBase, String accountName) throws NamingException {
		SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(2);
		String formattedSearchFilter = String.format(searchFilter,
				new Object[] { accountName });
		System.out.println("Search Filter : " + formattedSearchFilter);
		NamingEnumeration<?> results = ctx.search(ldapSearchBase,
				formattedSearchFilter, searchControls);
		SearchResult searchResult = null;
		System.out.println("Results After Search " + results.hasMoreElements());
		if (results.hasMoreElements()) {
			searchResult = (SearchResult) results.nextElement();

			if (results.hasMoreElements()) {
				System.out
						.println("Matched multiple users for the accountName: "
								+ accountName);
				return null;
			}
		}

		return searchResult;
	}

	public static LdapContext getContext(String ldapUsername,
			String ldapPassword) throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("java.naming.factory.initial",
				"com.sun.jndi.ldap.LdapCtxFactory");
		if (ldapUsername != null) {
			env.put("java.naming.security.principal", ldapUsername);
		}
		if (ldapPassword != null) {
			env.put("java.naming.security.credentials", ldapPassword);
		}
		if (securityAuth != null) {
			// env.put("java.naming.security.authentication",
			// this.securityAuth.trim());
		}
		env.put("java.naming.factory.initial",
				"com.sun.jndi.ldap.LdapCtxFactory");
		String providerURL = "ldap://" + ldapURL.trim() + ":" + port.trim();
		System.out.println("Connecting to : " + providerURL);
		env.put("java.naming.provider.url", providerURL);

		env.put("java.naming.ldap.attributes.binary", "objectSID");

		LdapContext ctx = new InitialLdapContext(env, null);
		System.out.println("Connected To Ldap" + ldapUsername);
		return ctx;
	}

	public static User getUserInformation(LdapContext context,
			String userCompleteDN) {
		User user = new User();
		String displayName = null;
		String userID = null;
		Attributes attributes = null;
		Attribute attr = null;
		try {
			attributes = context.getAttributes(userCompleteDN);
			user.setUserId(getAttributeValue(attributes, "sAMAccountName"));
			user.setUserName(getAttributeValue(attributes, "displayName"));
			user.setEmailId(getAttributeValue(attributes, "mail"));
			if (null != attributes.get("directReports")) {
				user.setIsApprover("Y");
			}
			attr = attributes.get("memberOf");
			int size = attr.size();
			for (int i = 0; i < size; i++) {
				String groupName = attr.get(i).toString();
				if (groupName
						.equals("CN=HR,OU=UserGroups,OU=Omni-Pune,DC=omniscient,DC=co,DC=in")) {
					user.setIsAdmin("Y");
					break;
				}
			}
		} catch (NamingException exc) {
			System.out.println("Exception while Fetching info from LDAP");
		}
		return user;
	}

	public static String getAttributeValue(Attributes attributes,
			String attributeName) {
		String result = null;
		try {
			Attribute attr = attributes.get(attributeName);
			result = attr.get().toString();
		} catch (Exception exc) {
			System.out.println("Exception while Fetching " + attributeName
					+ " Attribute info from LDAP");
		}
		return result;
	}

	public static User getUserInfoFromDN(String userDN) {
		User approverUser = null;
		LdapContext context = null;
		try {
			context = getContext(bindUser, bindUserPassword);
			approverUser = getUserInformation(context, userDN);
		} catch (Exception exc) {
			System.out.println("Exception while fetching approver Info");
			exc.printStackTrace();
		} finally {
			if (context != null) {
				try {
					context.close();
				} catch (NamingException e) {
					System.out.println("Failed to close the LDAP context....");
				}
			}
		}
		return approverUser;
	}

	public static User getUserFromID(String userID) {
		String userDN = null;
		User userInfo = null;
		try {
			userDN = getUserDN(userID);
			userInfo = getUserInfoFromDN(userDN);
		} catch (Exception exc) {
			System.out.println("Exception while fetching approver Info");
		}
		return userInfo;
	}

	public static List<User> getAllEmployeeList() {
		LdapContext ctx = null;
		List<User> userList = null;
		try {
			ctx = getContext(bindUser, bindUserPassword);
			userList = new ArrayList<User>();
			SearchControls searchControls = new SearchControls();
			searchControls.setSearchScope(2);
			String formattedSearchFilter = "(&(objectClass=user)(sAMAccountName=*))";
			NamingEnumeration<?> results = ctx.search(ldapSearchBase,
					formattedSearchFilter, searchControls);
			SearchResult searchResult = null;
			User user = null;
			while (results.hasMoreElements()) {
				searchResult = (SearchResult) results.nextElement();
				Attributes attributes;
				attributes = searchResult.getAttributes();
				// (getAttributeValue(attributes, "sAMAccountName"));
				user = new User();
				user.setUserId(getAttributeValue(attributes, "sAMAccountName"));
				user.setUserName(getAttributeValue(attributes, "displayName"));
				user.setEmailId(getAttributeValue(attributes, "mail"));
				Attribute attr = attributes.get("memberOf");
				String strGroup = "";
				if (null != attr) {
					int size = attr.size();
					for (int i = 0; i < size; i++) {
						String groupName = attr
								.get(i)
								.toString()
								.replace(
										",OU=UserGroups,OU=Omni-Pune,DC=omniscient,DC=co,DC=in",
										"");
						strGroup = strGroup + groupName;

						if (i < size - 1) {
							strGroup = strGroup + ",";
						}
					}
					user.setGroup(strGroup);
					userList.add(user);
				}
			}

			/* Add the Admin USers */
			results = ctx.search(
					"OU=AdminUsers,OU=Omni-Pune,DC=omniscient,DC=co,DC=in",
					formattedSearchFilter, searchControls);
			while (results.hasMoreElements()) {
				searchResult = (SearchResult) results.nextElement();
				Attributes attributes;
				attributes = searchResult.getAttributes();
				// (getAttributeValue(attributes, "sAMAccountName"));
				user = new User();
				user.setUserId(getAttributeValue(attributes, "sAMAccountName"));
				user.setUserName(getAttributeValue(attributes, "displayName"));
				Attribute attr = attributes.get("memberOf");
				String strGroup = "";
				if (null != attr) {
					int size = attr.size();
					for (int i = 0; i < size; i++) {
						String groupName = attr
								.get(i)
								.toString()
								.replace(
										",OU=UserGroups,OU=Omni-Pune,DC=omniscient,DC=co,DC=in",
										"");
						strGroup = strGroup + groupName;

						if (i < size - 1) {
							strGroup = strGroup + ",";
						}
					}
					user.setGroup(strGroup);
					userList.add(user);
				}
			}

		} catch (Exception exc) {
			System.out.println("Error While Fetching the LDAP Attribute");
		} finally {
			if (ctx != null) {
				try {
					ctx.close();
				} catch (NamingException e) {
					System.out.println("Failed to close the LDAP context....");
				}
			}
		}
		return userList;
	}

	public static void main(String a[]) throws NamingException {

		boolean result = false;
		User user = null;
		LdapContext userCtx = null;
		try {
			String userCompleteDN = getUserDN("NMahajan");
			System.out.println("DN "+userCompleteDN);
			userCtx = getContext(userCompleteDN, "NAR1234@#");

		} catch (NamingException e) {
			System.out.println(e);

		} finally {

		}

	}

}
