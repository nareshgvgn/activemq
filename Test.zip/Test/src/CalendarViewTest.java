import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


public class CalendarViewTest {

	public static void main(String[] args) {
		String days[] = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
		Date [][] dates = new Date[6][7];
		Date today = new Date();
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.set(Calendar.DATE, 1);
		int firstDay = calendar.get(Calendar.DAY_OF_WEEK);
		firstDay = firstDay - 1;
		int lastDate = calendar.getActualMaximum(Calendar.DATE);
		calendar.add(Calendar.DATE, - (6-firstDay));
		Date calendarViewFirstDate = calendar.getTime();
		calendar = new GregorianCalendar();
		calendar.set(Calendar.DATE, (41-firstDay));
		Date calendarViewLastDate = calendar.getTime();
		
		System.out.println(calendarViewFirstDate);
		System.out.println(calendarViewLastDate);
		int count = 1;
		for(int i = 0; i < 6; i++)
		{
			int start = 0;
			for(int j = start; j < 7; j++)
			{
				dates[i][j] = calendar.getTime();
				calendar.add(Calendar.DATE, 1);
			}
		}
		
		for(int i =0;i<days.length;i++)
		{
			System.out.format("%13s",days[i]);
		}
		System.out.println();
		SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
		for(int i = 0; i < 6; i++)
		{
			for(int j = 0; j < 7; j++)
			{
				if(null != dates[i][j])
				System.out.print(sd.format(dates[i][j])+"    ");
				else
					System.out.format("              ");
			}
			System.out.println();
		}
		//int currentMonthFirstDate = Calendar.
	}

}
