import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;


public class EncodeDecode {

	/**
	 * @param args
	 * @throws UnsupportedEncodingException 
	 */
	public static void main(String[] args) throws UnsupportedEncodingException {
		String encodedString ="ata:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAdCAYAAABi6qYTAAAAO0lEQVR42mNgoAHw8fH5j1UQQwImiCKBLAiXQBcESxBUSdh2Wnobr8+wexWrN3EGCk7v4vQyDbyNHwAA6H9eV/d3IL4AAAAASUVORK5CYII=";
		System.out.println("DEOCED\n"+URLDecoder.decode(encodedString, "UTF-8"));

	}

}
