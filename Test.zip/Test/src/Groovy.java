import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Groovy {
	public ClassLoader loader = null;
	public Groovy(){
		loader = this.getClass().getClassLoader();
	}
	public static void main(String args[]) throws ScriptException, IOException {
		Groovy g = new Groovy();
		File f = new File("JavaCode.txt");
		System.out.println(f.getName());
		String[] roots = new String[] { f.getAbsolutePath() };
		GroovyScriptEngine ge = new GroovyScriptEngine(roots, g.loader);
		FileReader fr = new FileReader(new File("JavaCode.txt"));
		int i;
		StringBuilder sb = new StringBuilder();
		while ((i = fr.read()) != -1) {
			sb.append(((char) i));
		}
		fr.close();
		try
		{
			Binding binding = new Binding();
			ge.run(f.getName(), binding);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
