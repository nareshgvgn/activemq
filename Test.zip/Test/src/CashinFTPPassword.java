import com.cashtech.phoenix.utils.encryption.CashTechEncryptor;

/**
 * 
 */

/**
 * @author nmahajan
 *
 */
public class CashinFTPPassword {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		CashTechEncryptor c  = new CashTechEncryptor();
		System.out.println(c.encrypt("phoenix.password.key", "naresh"));

	}

}
