
public class EnumTest {

	/**
	 * The Enum Operator.
	 */
	enum DateOperator
	{
		TODAY(DateRange.TODAY, "${TODAY}"), 
		YESTERDAY(DateRange.YESTERDAY, "${YESTERDAY}"), 
		THIS_WEEK(DateRange.THIS_WEEK, "${THIS_WEEK}"), 
		LAST_WEEK(DateRange.LAST_WEEK, "${LAST_WEEK}"), 
		LAST_WEEK_TODAY(DateRange.LAST_WEEK_TODAY, "${LAST_WEEK_TODAY}"), 
		THIS_MONTH(DateRange.THIS_MONTH, "${THIS_MONTH}"), 
		LAST_MONTH(DateRange.LAST_MONTH, "${LAST_MONTH}"), 
		LAST_MONTH_TODAY(DateRange.LAST_MONTH_TODAY, "${LAST_MONTH_TODAY}"), 
		THIS_QUARTER(DateRange.THIS_QUARTER, "${THIS_QUARTER}"),
		LAST_QUATER(DateRange.LAST_QUATER, "${LAST_QUATER}"), 
		LAST_QUATER_TODAY(DateRange.LAST_QUATER_TODAY, "${LAST_QUATER_TODAY}"), 
		THIS_YEAR(DateRange.THIS_YEAR, "${THIS_YEAR}"), 
		LAST_YEAR(DateRange.LAST_YEAR, "${LAST_YEAR}"), 
		LAST_YEAR_TODAY(DateRange.LAST_YEAR_TODAY, "${LAST_YEAR_TODAY}"), 
		DATE_RANGE("BETWEEN", "${BT}"), 
		AS_OF_DATE("${AS_OF_DATE}"),
	    LESS_THAN_EQUAL("<=", "${LQ}"),
	    GREATER_THAN_EQUAL(">=", "${GQ}"),
	    LESS_THAN("<", "${LT}"),
	    GREATER_THAN(">", "${GT}"),
	    EQUAL("=", "${EQ}"),
	    NOT_EQUAL_TO("<>", "${NQ}");

	    /** The opr string. */
	    private final String _strOprString;
	    
	    private final String _strAlias;
	    
	    /** The _range. */
	    private final DateRange _objRange;
	    
	    /**
	     * Instantiates a new operator.
	     *
	     * @param operator
	     *            the operator
	     */
	    private DateOperator(String alias)
	    {
	    	_strOprString = this.toString();
	    	_strAlias = alias;
	    	_objRange = null;
	    }
	    
	    /**
	     * Instantiates a new operator.
	     *
	     * @param operator
	     *            the operator
	     */
	    private DateOperator(DateRange dtRange, String alias)
	    {
	    	_strOprString = this.toString();
	    	_strAlias = alias;
	    	_objRange = dtRange;
	    }
	    
	    /**
	     * Instantiates a new operator.
	     *
	     * @param operator
	     *            the operator
	     */
	    private DateOperator(final String operator, final String alias)
	    {
	        this._strOprString = operator;
	        this._strAlias = alias;
	        this._objRange = null;
	    }

	    /**
	     * Value of.
	     *
	     * @param position
	     *            the position
	     * @return the operator
	     */
	    public static DateOperator valueOf(final int position)
	    {
	        return DateOperator.values()[position];
	    }
	    
	    /**
	     * Value of.
	     *
	     * @param position
	     *            the position
	     * @return the operator
	     */
	    public static DateOperator valueFromAlias(final String alias)
	    {
	    	DateOperator resultValue = null;
	    	DateOperator values [] = DateOperator.values();
	    	for(DateOperator value : values)
	    	{
	    		if(null !=value.getAlias() && value.getAlias().equals(alias))
	    		{
	    			resultValue = value;
	    			break;
	    		}
	    	}
	        return resultValue;
	    }

	    /**
	     * Gets the String.
	     *
	     * @return String
	     */
	    public String getAlias()
	    {
	        return this._strAlias;
	    }
	    
	    /**
	     * Gets the String.
	     *
	     * @return String
	     */
	    public String getOpearatorSymbol()
	    {
	        return this._strOprString;
	    }
	    
	    /**
	     * Gets the String.
	     *
	     * @return String
	     */
	    public DateRange getDateRange()
	    {
	        return this._objRange;
	    }
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		DateOperator dt[] = DateOperator.values();
		System.out.println(DateOperator.valueOf(0));
		for(DateOperator d : dt)
		System.out.println(d);
				
				String s ="1100000001111100000100000000000100011100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000110000011000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000100000000000000011000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000011111000000000000010111110100000000000001101111111100101000000011000000100000000000000000000000000000000000000001000000000000000010000000000000000000001000000011100000001000100000000101001100111001100000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000001111000001000000000000000000000000000000000000000000000000000001101010000000000000000000000001101001010000011";
				StringBuilder sb = new StringBuilder(s);
				
				System.out.println(sb.reverse());
		
	}

}
