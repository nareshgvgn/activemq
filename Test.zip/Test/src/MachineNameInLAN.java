import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class MachineNameInLAN {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{ 
            Process p=Runtime.getRuntime().exec("cmd /c NBTSTAT -A 192.168.100.9"); 
            BufferedReader reader=new BufferedReader(
                new InputStreamReader(p.getInputStream())
            ); 
            String line;
            StringBuilder sb = new StringBuilder("");
            while((line = reader.readLine()) != null) 
            { 
                //System.out.println(line);
            	sb.append("\n"+line);
            } 
            fetchMachineName(sb.toString());
        }
        catch(IOException e1)
        {
        	System.out.println(e1);
        } 
        System.out.println("Done"); 

	}
	
	/*
	  Name               Type         Status
    ---------------------------------------------
    NARESH-PC      <00>  UNIQUE      Registered 
    OMNISCIENT     <00>  GROUP       Registered 
    NARESH-PC      <20>  UNIQUE      Registered 
    OMNISCIENT     <1E>  GROUP       Registered 
	 */
	static String fetchMachineName(String line)
	{
		String machineName = "";
		int index = 0;
		String currentLine = "";
		while(index < line.length())
		{
			if(line.charAt(index)=='\n')
			{
				if(currentLine.indexOf("UNIQUE") > 0)
				{
					//Finding Index of < character in <00>
					int xmlChar = currentLine.indexOf('<');
					machineName =  currentLine.substring(0, xmlChar);
					return machineName;
				}
				currentLine = "";
			}
			currentLine = currentLine + line.charAt(index);
			index++;
		}
		return null;
	}
}
