import java.net.InetAddress;
import java.net.UnknownHostException;

public class GetHostnameFromIPAddress {
	
	public static void main(String[] args) {
		
		try {
			InetAddress inetAddress = null;
			String pcName = "orcle-services";
			inetAddress = InetAddress.getByName(pcName);
			displayStuff(pcName, inetAddress);
			System.out.print("--------------------------");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

	public static void displayStuff(String whichHost, InetAddress inetAddress) {
		System.out.println("--------------------------");
		System.out.println("Which Host:" + whichHost);
		System.out.println("Canonical Host Name:" + inetAddress.getCanonicalHostName());
		System.out.println("Host Name:" + inetAddress.getHostName());
		System.out.println("Host Address:" + inetAddress.getHostAddress());
	}
}