create table leaves (
  leaveid                   integer auto_increment not null,
  employeeId                varchar(255),
  fromDate                  datetime,
  toDate                    datetime,
  approverId                varchar(255),
  leaveReason               varchar(255),
  status                    varchar(255),
  constraint pk_leaves primary key (leaveid))
;



