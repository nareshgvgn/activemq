/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : SecurityProviderFactory.java
 * CREATED: Jul 2, 2013 11:14:27 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;

import com.fundtech.iris.admin.exceptions.NotSupportedException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: SecurityProviderFactory.java,v 1.5 2017/03/17 11:34:20 ramap Exp $
 * @since 1.0.0
 */
public class SecurityProviderFactory implements ISecurityProvider, InitializingBean
{
	public final static String PGP_VENNDOR = "PGP";
	private Map<String, IAsymmetricSecurityProvider> asySecurityProviders = null;
	private Map<String, ISymmetricSecurityProvider> sySecurityProviders = null;
	
	public  SecurityProviderFactory()
	{
	}
	
	public ISymmetricSecurityProvider getSymmetricInstance (String algorithm) throws NotSupportedException
	{
		ISymmetricSecurityProvider securityProvider = null;
		NotSupportedException nExp = null;
		
		if (sySecurityProviders.containsKey(algorithm))
			securityProvider = sySecurityProviders.get(algorithm);
		else
		{
			nExp = new NotSupportedException(algorithm + "Not Supported");
			throw nExp;
		}
		// else if( algorithm.equalsIgnoreCase("RC5") )
		// {
		// securityProvider = new RC5SecurityProvider();
		// }
		// else if( algorithm.equalsIgnoreCase("RSA") )
		// {
		// securityProvider = new DESSecurityProvider();
		// }
		// else if( algorithm.equalsIgnoreCase("ADLER32") )
		// {
		// symmetricSecurityProvider = new Adler32Provider();
		// }
		
		return securityProvider;
	}
	
	public IAsymmetricSecurityProvider getAsymmetricInstance (String vendor) throws NotSupportedException
	{
		IAsymmetricSecurityProvider securityProvider = null;
		
		if ( asySecurityProviders.containsKey(vendor))
			securityProvider  = asySecurityProviders.get(vendor);
		else
			throw new NotSupportedException("Vendor :" + vendor + " not supported!!");
		
		return securityProvider;
	}

	/**
	 * @return the asySecurityProviders
	 */
	public Map<String, IAsymmetricSecurityProvider> getAsySecurityProviders ()
	{
		return asySecurityProviders;
	}

	/**
	 * @param asySecurityProviders the asySecurityProviders to set
	 */
	public void setAsySecurityProviders (Map<String, IAsymmetricSecurityProvider> asySecurityProviders)
	{
		this.asySecurityProviders = asySecurityProviders;
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet () throws Exception
	{
		Map<String, IAsymmetricSecurityProvider> tempasySecurityProviders = new HashMap<String, IAsymmetricSecurityProvider>();;
		Map<String, ISymmetricSecurityProvider> tempsySecurityProviders = new HashMap<String, ISymmetricSecurityProvider>();
		
		tempasySecurityProviders.put(PGP_VENNDOR, new PgpSecurityProvider());
		
		tempsySecurityProviders.put( "AES", new AESSecurityProvider());
		tempsySecurityProviders.put( "DES", new DESSecurityProvider());
		tempsySecurityProviders.put( "DESede", new DESedeSecurityProvider());
		tempsySecurityProviders.put( "RC2", new RC2SecurityProvider());
		tempsySecurityProviders.put( "RC4", new RC4SecurityProvider());
		
		if (null == getAsySecurityProviders())
			asySecurityProviders =  tempasySecurityProviders;
		else
		{
			tempasySecurityProviders.putAll(asySecurityProviders);
			asySecurityProviders = tempasySecurityProviders;
		}
			
		
		if ( null == getSySecurityProviders())
			sySecurityProviders =  tempsySecurityProviders;
		else
		{
			tempsySecurityProviders.putAll(sySecurityProviders);
			sySecurityProviders = tempsySecurityProviders;
		}
		
		
	}

	/**
	 * @return the sySecurityProviders
	 */
	public Map<String, ISymmetricSecurityProvider> getSySecurityProviders ()
	{
		return sySecurityProviders;
	}

	/**
	 * @param sySecurityProviders the sySecurityProviders to set
	 */
	public void setSySecurityProviders (Map<String, ISymmetricSecurityProvider> sySecurityProviders)
	{
		this.sySecurityProviders = sySecurityProviders;
	}

	
}
