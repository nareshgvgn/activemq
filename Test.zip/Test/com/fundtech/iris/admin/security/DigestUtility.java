/*------------------------------------------------------------------------------
 * PACKAGE: com.cashtech.iris.security
 * FILE   : DigestUtility.java
 * CREATED: May 16, 2011 2:31:39 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * This helper class creates the digest
 * 
 * @author Babu Paluri
 * @version $Id: DigestUtility.java,v 1.3 2014/07/20 04:58:18 ramap Exp $
 * @since 1.0.0
 */
public class DigestUtility
{
	public DigestUtility()
	{
	}
	
	/**
	 * This helper method creates the digest for given target by using given Algo & SALT
	 * 
	 * @param target
	 * @param salt
	 * @param algorithm
	 * @return byte[]
	 * @throws NoSuchAlgorithmException
	 * @throws UnsupportedEncodingException
	 */
	public byte[] getDigest (byte[] target, byte[] salt, String algorithm) throws NoSuchAlgorithmException, UnsupportedEncodingException
	{
		byte[] obj = null;
		MessageDigest digest = null;
		digest = MessageDigest.getInstance(algorithm);
		digest.reset();
		if (salt != null)
			digest.update(salt);
		obj = digest.digest(target);
		return obj;
		
	}
	
	/**
	 * This helper method creates the digest for given target by using given Algo
	 * 
	 * @param target
	 *            input string
	 * @param algorithm
	 * @return Object
	 * @throws UnsupportedEncodingException
	 * @throws NoSuchAlgorithmException
	 */
	public byte[] getDigest (byte[] target, String algorithm) throws NoSuchAlgorithmException, UnsupportedEncodingException
	{
		byte[] obj = null;
		
		obj = getDigest(target, null, algorithm);
		return obj;
	}
	
	/**
	 * This helper method converts byte[] to HEX string
	 * 
	 * @param byte[]
	 * @return hexString
	 */
	public String toHexString (byte b[])
	{
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < b.length; i++)
		{
			result.append(Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1));
		}
		return result.toString();
	}
	
	public static void main (String[] args) throws Exception
	{
		// String target = "My name is babu";
		// DigestUtility utility = null;
		//
		// utility = new DigestUtility();
		// System.out.println(utility.toHexString(utility.getDigest(target.getBytes(), "SHA-256")));
	}
	
}
