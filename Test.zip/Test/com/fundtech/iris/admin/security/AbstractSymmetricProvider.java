/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : AbstractSymmetricProvider.java
 * CREATED: Jul 2, 2013 11:26:39 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.security.Security;

import javax.crypto.spec.IvParameterSpec;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: AbstractSymmetricProvider.java,v 1.2 2014/07/20 04:58:18 ramap Exp $
 * @since 1.0.0
 */
public abstract class AbstractSymmetricProvider implements ISymmetricSecurityProvider
{
	protected final String MODE = "CBC";
	protected final String PADDING = "PKCS5Padding";
	
	protected final byte[] salt8 =
	{ (byte) 0xc7, (byte) 0x73, (byte) 0x21, (byte) 0x8c, (byte) 0x7e, (byte) 0xc8, (byte) 0xee, (byte) 0x99 };
	
	protected final byte[] salt16 =
	{ (byte) 0xc7, (byte) 0x73, (byte) 0x21, (byte) 0x8c, (byte) 0x7e, (byte) 0xc8, (byte) 0xee, (byte) 0x99, (byte) 0xc7, (byte) 0x73, (byte) 0x21,
			(byte) 0x8c, (byte) 0x7e, (byte) 0xc8, (byte) 0xee, (byte) 0x99 };
	
	protected IvParameterSpec iv_8 = new IvParameterSpec(salt8);
	protected IvParameterSpec iv_16 = new IvParameterSpec(salt16);
	protected final int itrcount = 30;
	
	static
	{
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	}
}
