/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.security
 * FILE   : CompareHash.java
 * CREATED: 04-Jul-2013 4:30:19 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.NotSupportedException;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.ReverseFileReader;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Maharshi Chavda
 * @version $Id: SymmetricSigning.java,v 1.11 2017/03/17 11:34:20 ramap Exp $
 * @since 1.0.0
 */
public class SymmetricSigning
{
	private static Logger logger = LoggerFactory.getLogger(SymmetricSigning.class);
	
	/**
	 * Computes hash of the file contents and compare with the hash value stored at the bottom of the file
	 * 
	 * @param paramMap
	 * @return 
	 * @throws Exception
	 */
	public boolean executeUpload (ExecutionJobData jobData) throws ExecutionException
	{
		File inputFile = null;
		String uploadFileName = null;
		String[] retVal = null;
		int offset = -1;
		String algo = null;
		IHashProvider hashProvider = null;
		InputStream inputStream = null;
		byte[] buff = null;
		String fileHash = null;
		String inputHash = null;
		ExecutionException eExp = null;
		
		try
		{
			uploadFileName = jobData.getMediaDetails();
			inputFile = new File(uploadFileName);
			algo = jobData.getInterfaceMap().getSecurityProfile().getSiginingAlgo();
			assert (algo != null && !"".equals(algo));
			// Check if File exists
			assert (inputFile.exists()) && inputFile.isFile() && inputFile.canRead();
			
			// get the Hash Value and Current Offset
			retVal = getHashCodeAndOffset(inputFile);
			inputHash = retVal[0];
			offset = Integer.parseInt(retVal[1]) + 1;
			hashProvider = getHashFactory().getHashFactoryProvider(algo);
			inputStream = new FileInputStream(inputFile);
			buff = new byte[offset];
			inputStream.read(buff, 0, offset);
			fileHash = hashProvider.calculate(buff);
			HelperUtils.doClose(inputStream);
			if (!inputHash.equals(fileHash))
			{
				logger.error("Input Hash:" + inputHash + " & FileHash:" + fileHash);
				return false;
			}
			
			createNewFile(inputFile, buff);
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			eExp = new ExecutionException("error.iris.admin.hash", new Object[]
			{ algo, uploadFileName }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(inputStream);
			buff = null;
			retVal = null;
		}
		return true;
	}
	
	/**
	 * TODO
	 * 
	 * @param file
	 * @throws Exception
	 */
	public void executeDownload (ExecutionJobData jobData) throws ExecutionException
	{
		String uploadFileName = null;
		String checkSumValue = null;
		OutputStream outStream = null;
		OutputStreamWriter writer = null;
		String charSet = null;
		ExecutionException eExp = null;
		
		try
		{
			uploadFileName = jobData.getMediaDetails();
			checkSumValue = generateChecksum(jobData);
			outStream = new FileOutputStream(uploadFileName, true);
			charSet = jobData.getCharSet();
			writer = new OutputStreamWriter(outStream, charSet);
			writer.write(jobData.getLinSeparator());
			writer.write(checkSumValue);
			writer.flush();
		}
		
		catch (FileNotFoundException exp)
		{
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]
			{ uploadFileName }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (UnsupportedEncodingException exp)
		{
			eExp = new ExecutionException("error.iris.admin.unsupportedencoding", new Object[]
			{ uploadFileName }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IOException exp)
		{
			eExp = new ExecutionException("error.iris.admin.io", new Object[]
			{ uploadFileName }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (NotSupportedException exp)
		{
			eExp = new ExecutionException("error.iris.admin.unsupportedalgo", new Object[]	{ uploadFileName }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(writer);
			HelperUtils.doClose(outStream);
		}
	}
	
	/**
	 * Generates checksum.
	 * 
	 * @param jobData
	 * @return
	 * @throws ExecutionException
	 * @throws FileNotFoundException
	 */
	private String generateChecksum (ExecutionJobData jobData) throws ExecutionException, FileNotFoundException, NotSupportedException
	{
		String checkSumValue = null;
		IHashProvider hashProvider = null;
		String algorithm = null;
		String uploadFileName = null;
		File file = null;
		InputStream inputStream = null;
		
		try
		{
			algorithm = jobData.getInterfaceMap().getSecurityProfile().getSiginingAlgo();
			uploadFileName = jobData.getMediaDetails();
			file = new File(uploadFileName);
			hashProvider = getHashFactory().getHashFactoryProvider(algorithm);
			inputStream = new FileInputStream(file);
			checkSumValue = hashProvider.calculate(inputStream);
		}
		catch (ExecutionException e)
		{
			throw e;
		}
		catch (FileNotFoundException fe)
		{
			throw fe;
		}
		catch (NotSupportedException e)
		{
			throw e;
		}
		finally
		{
			HelperUtils.doClose(inputStream);
		}
		return checkSumValue;
	}
	
	/**
	 * Extract and return the hashCode present at the End of File
	 * 
	 * @param file
	 * @return
	 * @throws Exception
	 */
	private String[] getHashCodeAndOffset (File file) throws Exception
	{
		String hashline = null;
		long offset = Long.MIN_VALUE;
		ReverseFileReader revfreader = null;
		
		revfreader = new ReverseFileReader(file);
		
		hashline = revfreader.readLine();
		while (hashline == null || hashline.trim().length() == 0)
		{
			hashline = revfreader.readLine();
		}
		offset = revfreader.getCurrentOffset();
		// Close ReverseFileReader
		revfreader.closeFileReader();
		return new String[]
		{ hashline, Long.toString(offset) };
	}
	
	private void createNewFile (File source, byte[] buff) throws Exception
	{
		FileOutputStream fStream = null;
		try
		{
			fStream = new FileOutputStream(source);
			fStream.write(buff);
		}
		catch (Exception exp)
		{
			throw exp;
		}
		finally
		{
			HelperUtils.doClose(fStream);
		}
	}
	
	private HashProviderFactory getHashFactory()
	{
		HashProviderFactory factory = null;
		
		try
		{
			factory = (HashProviderFactory) ContextManager.getInstance().getBeanObject(HashProviderFactory.class);
		}
		catch ( Exception exp)
		{
			logger.warn("Error:",exp);
			factory = new HashProviderFactory();
		}
		
	return factory;
	}
}
