/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : IHashProvider.java
 * CREATED: Jun 30, 2013 10:04:07 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.InputStream;

import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * This Class computes Checksum Using MD5 or CRC32 or Adler32 Algorithm for a given file
 * 
 * @author Babu Paluri
 * @version $Id: IHashProvider.java,v 1.3 2014/07/20 04:58:18 ramap Exp $
 * @since 1.0.0
 */
public interface IHashProvider
{
	public String calculate (InputStream inStream) throws ExecutionException;
	
	public String calculate (byte[] buffer) throws ExecutionException;
	
}
