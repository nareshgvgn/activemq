/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : HashProviderFactory.java
 * CREATED: Jun 30, 2013 10:00:54 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;

import com.fundtech.iris.admin.exceptions.NotSupportedException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: HashProviderFactory.java,v 1.1 2017/03/17 11:34:20 ramap Exp $
 * @since 1.0.0
 */
public class HashProviderFactory implements InitializingBean
{
	private Map<String, IHashProvider> hashProviders = null;
	
	public HashProviderFactory()
	{
	}
	
	public IHashProvider getHashFactoryProvider (String algorithm) throws NotSupportedException
	{
		IHashProvider hashProvider = null;
		NotSupportedException nExp = null;
		
		if (hashProviders.containsKey(algorithm))
			hashProvider = hashProviders.get(algorithm);
		else 
		{
			nExp = new NotSupportedException(algorithm + "Not Supported");
			throw nExp;
		}
		
		return hashProvider;
	}

	/**
	 * @return the hashProviders
	 */
	public Map<String, IHashProvider> getHashProviders ()
	{
		return hashProviders;
	}

	/**
	 * @param hashProviders the hashProviders to set
	 */
	public void setHashProviders (Map<String, IHashProvider> hashProviders)
	{
		this.hashProviders = hashProviders;
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet () throws Exception
	{
		Map<String , IHashProvider> temp = new HashMap<String, IHashProvider>();
		temp.put("CRC32", new CRC32Provider());
		temp.put("MD5", new  MD5Provider());
		temp.put("ADLER32", new Adler32Provider());
		temp.put("SHA-1", new SHA1Provider());
		temp.put("SHA-256", new SHA256Provider());
		temp.put("SHA-384", new SHA384Provider());
		temp.put("SHA-512", new Adler32Provider());
		
		if (null == hashProviders)
			hashProviders = temp;
		else
		{
			temp.putAll(hashProviders);
			hashProviders = temp;
		}
		
	}
	
}
