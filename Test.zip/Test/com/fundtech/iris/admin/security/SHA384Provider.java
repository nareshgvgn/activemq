/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.security
 * FILE   : SHA384Provider.java
 * CREATED: Mar 15, 2017 5:54:04 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.InputStream;
import java.security.MessageDigest;

import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: SHA384Provider.java,v 1.1 2017/03/17 11:34:20 ramap Exp $
 */
public class SHA384Provider implements IHashProvider
{
private static Logger logger = LoggerFactory.getLogger(SHA384Provider.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.ICheckSum#calualte(java.io.InputStream)
	 */
	public String calculate (InputStream inStream) throws ExecutionException
	{
		MessageDigest mdigest = null;
		String checkSum = null;
		byte[] buffer = null;
		byte[] md5hash = null;
		ExecutionException eExp = null;
		
		try
		{
			buffer = new byte[1024];
			mdigest = MessageDigest.getInstance("SHA-384");
			int numRead = 0;
			do
			{
				numRead = inStream.read(buffer);
				if (numRead > 0)
					mdigest.update(buffer, 0, numRead);
			}
			while (numRead != -1);
			md5hash = mdigest.digest();
			checkSum = new String(Hex.encodeHex(md5hash));
			return checkSum;
			
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.chesum.SHA-384", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			mdigest = null;
			buffer = null;
			md5hash = null;
		}
	}
	
	public String calculate (byte[] buffer) throws ExecutionException
	{
		MessageDigest mdigest = null;
		String checkSum = null;
		byte[] md5hash = null;
		ExecutionException eExp = null;
		
		try
		{
			mdigest = MessageDigest.getInstance("SHA-384");
			mdigest.update(buffer);
			md5hash = mdigest.digest();
			checkSum = new String(Hex.encodeHex(md5hash));
			return checkSum;
			
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.chesum.SHA-384", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			mdigest = null;
			buffer = null;
			md5hash = null;
			buffer = null;
		}
	}
}
