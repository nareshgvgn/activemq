/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : MD5Provider.java
 * CREATED: Jun 30, 2013 10:12:54 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.InputStream;
import java.security.MessageDigest;

import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: MD5Provider.java,v 1.4 2014/07/20 04:58:18 ramap Exp $
 * @since 1.0.0
 */
public class MD5Provider implements IHashProvider
{
	private static Logger logger = LoggerFactory.getLogger(MD5Provider.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.ICheckSum#calualte(java.io.InputStream)
	 */
	public String calculate (InputStream inStream) throws ExecutionException
	{
		MessageDigest mdigest = null;
		String checkSum = null;
		byte[] buffer = null;
		byte[] md5hash = null;
		ExecutionException eExp = null;
		
		try
		{
			buffer = new byte[1024];
			mdigest = MessageDigest.getInstance("MD5");
			int numRead = 0;
			do
			{
				numRead = inStream.read(buffer);
				if (numRead > 0)
					mdigest.update(buffer, 0, numRead);
			}
			while (numRead != -1);
			md5hash = mdigest.digest();
			checkSum = new String(Hex.encodeHex(md5hash));
			return checkSum;
			
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.chesum.MD5", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			mdigest = null;
			buffer = null;
			md5hash = null;
		}
	}
	
	public String calculate (byte[] buffer) throws ExecutionException
	{
		MessageDigest mdigest = null;
		String checkSum = null;
		byte[] md5hash = null;
		ExecutionException eExp = null;
		
		try
		{
			mdigest = MessageDigest.getInstance("MD5");
			mdigest.update(buffer);
			md5hash = mdigest.digest();
			checkSum = new String(Hex.encodeHex(md5hash));
			return checkSum;
			
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.chesum.MD5", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			mdigest = null;
			buffer = null;
			md5hash = null;
			buffer = null;
		}
	}
}
