/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.security
 * FILE   : IAsymmetricSecurityProvider.java
 * CREATED: Sep 14, 2015 1:29:58 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.IOException;

import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IAsymmetricSecurityProvider.java,v 1.2 2017/03/17 11:34:20 ramap Exp $
 */
public interface IAsymmetricSecurityProvider
{
	public String getDestFileName();
	public String getDestFolder();
	public String getErrMessage();
	public String getOutMessage();
	public String getPassPhrase();
	public String getPGPCommandName();
	public String getPgpHome();
	public String getSrcFileName();
	public String getSrcFolder();
	public String getSigner();
	public String getRecipient();
	public IAsymmetricSecurityProvider setDestFileName(String destFileName);
	public IAsymmetricSecurityProvider setDestFolder(String destFolder);
	public void setErrMessage(String errMessage);
	public void setOutMessage(String outMessage);
	public IAsymmetricSecurityProvider setPassPhrase(String passPhrase);
	public IAsymmetricSecurityProvider setPGPCommandName(String pGPCommandName);
	public IAsymmetricSecurityProvider setPgpHome(String pgpHome);
	public IAsymmetricSecurityProvider setSrcFileName(String srcFileName);
	public IAsymmetricSecurityProvider setSrcFolder(String srcFolder);
	public IAsymmetricSecurityProvider setSigner(String signer);
	public IAsymmetricSecurityProvider setRecipient(String recipient);
	public int decrypt() throws IOException, InterruptedException;
	public int encrypt() throws IOException, InterruptedException;
	public int verify() throws IOException, InterruptedException;
	public int sign() throws IOException, InterruptedException;
	public int signAndEncrypt() throws IOException, InterruptedException;
	public void setJobData(ExecutionJobData jobData);

}
