package com.fundtech.iris.admin.security;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * 
 * This helper class encrypt/ decrypt the string using AES
 * 
 * @author Babu Paluri
 * @version $Id: Security.java,v 1.3 2014/07/20 04:58:18 ramap Exp $
 * @since 1.0.0
 */
public class Security
{
	
	/**
	 * If you want to change the key make sure that you give 16 char length
	 */
	private final String key = "ft.iris@fundtech";
	
	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception
	{
		String mode = null;
		String input = null;
		Security sec = null;
		String output = null;
		
		if (args == null || args.length != 2)
		{
			usage();
			return;
		}
		mode = args[0];
		input = args[1];
		sec = new Security();
		if (mode.equals("-encrypt"))
		{
			output = sec.encrypt(input);
			System.out.println("Encrypted Value:" + output);
		}
		else if (mode.equals("-decrypt"))
		{
			output = sec.decrypt(input);
			System.out.println("Decrypted Value:" + output);
		}
		else
			usage();
		
	}
	
	/**
	 * 
	 * This method encrypts the given string
	 * 
	 * @param strIn
	 * @return hexvalue
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public String encrypt (String strIn) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException
	{
		byte[] arrKey = null;
		byte[] encrypted = null;
		Cipher cipher = null;
		SecretKeySpec sks = null;
		
		try
		{
			arrKey = key.getBytes();
			sks = new SecretKeySpec(arrKey, "AES");
			cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, sks);
			encrypted = cipher.doFinal(strIn.getBytes());
			if (encrypted != null)
				return toHexString(encrypted);
		}
		finally
		{
			if (encrypted != null)
				encrypted = null;
			if (arrKey != null)
				arrKey = null;
			if (cipher != null)
				cipher = null;
			if (sks != null)
				sks = null;
		}
		return null;
	}
	
	/**
	 * 
	 * This method decrypts the given string
	 * 
	 * @param strIn
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public String decrypt (String strIn) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException
	{
		byte[] arrKey = null;
		byte[] input = null;
		byte[] decrypted = null;
		Cipher cipher = null;
		SecretKeySpec sks = null;
		
		try
		{
			arrKey = key.getBytes();
			input = toByte(strIn);
			sks = new SecretKeySpec(arrKey, "AES");
			cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, sks);
			decrypted = cipher.doFinal(input);
			if (decrypted != null)
				return new String(decrypted);
		}
		finally
		{
			if (input != null)
				input = null;
			if (arrKey != null)
				arrKey = null;
			if (decrypted != null)
				decrypted = null;
			if (cipher != null)
				cipher = null;
			if (sks != null)
				sks = null;
		}
		return null;
	}
	
	/**
	 * This helper method converts bytes to HEX TODO
	 * 
	 * @param arr
	 * @return
	 */
	private final String toHexString (byte[] arr)
	{
		StringBuffer buf = null;
		try
		{
			if (null == arr)
				return null;
			
			buf = new StringBuffer(512);
			for (int i = 0; i < arr.length; i++)
			{
				if (((int) arr[i] & 0xff) < 0x10)
					buf.append("0");
				buf.append(Long.toString((int) arr[i] & 0xff, 16));
			}
			return buf.toString();
		}
		finally
		{
			if (buf != null)
			{
				buf.delete(0, buf.length());
				buf = null;
			}
		}
	}
	
	/**
	 * This helper method converts HEX String to Bytes
	 * 
	 * @param skey
	 * @return
	 */
	private final byte[] toByte (String skey)
	{
		byte[] arrKey = null;
		int maxLen = 0;
		
		maxLen = skey.length() / 2;
		arrKey = new byte[maxLen];
		for (int i = 0; i < maxLen; i++)
		{
			int sPos = i * 2;
			String hex = skey.substring(sPos, sPos + 2);
			arrKey[i] = Integer.valueOf(hex, 16).byteValue();
		}
		return arrKey;
	}
	
	private static void usage ()
	{
		System.out.println("if wants to encrypt Usage: -encrypt <String to be encrypted>");
		System.out.println("if wants to decrypt Usage: -decrypt <String to be decrypted> ");
	}
}
