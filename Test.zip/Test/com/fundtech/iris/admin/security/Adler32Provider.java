/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : Adler32Provider.java
 * CREATED: Jun 30, 2013 10:13:05 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.InputStream;
import java.util.zip.Adler32;
import java.util.zip.CheckedInputStream;

import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: Adler32Provider.java,v 1.6 2014/07/20 04:58:18 ramap Exp $
 * @since 1.0.0
 */
public class Adler32Provider implements IHashProvider
{
	public String calculate (InputStream inStream) throws ExecutionException
	{
		CheckedInputStream cis = null;
		Long checkSum = Long.MIN_VALUE;
		try
		{
			cis = new CheckedInputStream(inStream, new Adler32());
			byte[] buf = new byte[1024];
			
			while (cis.read(buf) >= 0)
				;
			checkSum = cis.getChecksum().getValue();
		}
		catch (Exception e)
		{
			throw new ExecutionException("error.app.FailedToCalculateCheckSum", new Object[] {}, e);
		}
		finally
		{
		}
		return checkSum.toString();
	}
	
	public String calculate (byte[] buffer) throws ExecutionException
	{
		Adler32 adler32 = null;
		String checkSum = null;
		long hash;
		ExecutionException eExp = null;
		
		try
		{
			adler32 = new Adler32();
			adler32.update(buffer);
			hash = adler32.getValue();
			checkSum = new String(Long.toHexString(hash));
			return checkSum;
			
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.checksum.Adler32", new Object[] {}, e);
			throw eExp;
		}
		finally
		{
			buffer = null;
		}
	}
}
