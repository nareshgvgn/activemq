/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.security
 * FILE   : HmacSHA256.java
 * CREATED: Jul 15, 2011 6:35:26 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: Hmac.java,v 1.3 2015/11/03 04:22:12 ramap Exp $
 * @since 1.0.0
 */
public class Hmac
{
	
	/**
	 * This helper method creates the digest for given target by using given Algo
	 * 
	 * @param target
	 * @param algorithm
	 * @param key
	 *            SecretKeySpec
	 * @return byte[]
	 * @throws NoSuchAlgorithmException
	 * @throws UnsupportedEncodingException
	 * @throws InvalidKeyException
	 */
	public byte[] getDigest (byte[] target, String algorithm, SecretKeySpec key) throws NoSuchAlgorithmException, UnsupportedEncodingException,
			InvalidKeyException
	{
		byte[] obj = null;
		Mac digest = null;
		digest = Mac.getInstance(algorithm);
		digest.reset();
		digest.init(key);
		obj = digest.doFinal(target);
		return obj;
		
	}
	
	/**
	 * This method loads the key from java KeyStore by using given keyStorePath, keyStorePass and keyAlias. Once Key is loaded, this method converts
	 * the Key as SecretKeySpec by using given Algorithm.
	 * 
	 * @param keyStorePath
	 * @param keyStorePass
	 * @param keyAlias
	 * @param algo
	 * @return SecretKeySpec
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 * @throws UnrecoverableKeyException
	 * @throws NoSuchProviderException
	 */
	public SecretKeySpec getKeySpec (String keyStorePath, String keyStorePass, String keyAlias, String algo, String providerClass, String providerName)
			throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableKeyException, NoSuchProviderException
	{
		SecretKeySpec keySpec = null;
		File certificateFile = null;
		FileInputStream fis = null;
		KeyStore keyStore = null;
		Key key = null;
		
		try
		{
			if (providerClass != null)
				java.security.Security.setProperty("security.provider.1", providerClass);
			if (providerName != null)
				keyStore = KeyStore.getInstance("jceks", providerName);
			else
				keyStore = KeyStore.getInstance("jceks");
			
			certificateFile = new File(keyStorePath);
			fis = new FileInputStream(certificateFile);
			keyStore.load(fis, keyStorePass.toCharArray());
			key = keyStore.getKey(keyAlias, keyStorePass.toCharArray());
			keySpec = new SecretKeySpec(key.getEncoded(), algo);
			
		}
		finally
		{
			CleanUpUtils.doClose(fis);
			fis = null;
		}
		return keySpec;
	}
	
	/**
	 * Helper function to convert a byte array to hex encoded string.
	 * 
	 * @param arr
	 *            The byte array
	 * @return the hex encoded string ot null if input array is null.
	 */
	public static final String toHexString (byte[] arr)
	{
		StringBuffer buf = null;
		
		try
		{
			if (null == arr)
				return null;
			
			buf = new StringBuffer(512);
			for (int i = 0; i < arr.length; i++)
			{
				if (((int) arr[i] & 0xff) < 0x10)
					buf.append("0");
				buf.append(Long.toString((int) arr[i] & 0xff, 16));
			}
			return buf.toString();
		}
		finally
		{
			if (buf != null)
			{
				buf.delete(0, buf.length());
				buf = null;
			}
		}
	}
	/**
	 * TODO
	 * 
	 * @param args
	 */
	/*
	 * public static void main(String[] args) throws Exception { Hmac util = null; SecretKeySpec secKeySpec = null; String name = "Babu Paluri";
	 * byte[] digest = null; String out = null;
	 * 
	 * util = new Hmac(); // secKeySpec = util.getKeySpec("D:/test.jceks", "babu987", "aestest","HmacSHA256"); secKeySpec =
	 * util.getKeySpec("C:/test.jceks", "123456", "aestest","HmacSHA256"); digest = util.getDigest(name.getBytes(), "HmacSHA256", secKeySpec); out =
	 * Hmac.toHexString(digest); System.out.println(out);
	 * 
	 * }
	 */
	
}
