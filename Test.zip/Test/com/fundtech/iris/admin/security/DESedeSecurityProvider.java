/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.security
 * FILE   : DESedeSecurityProvider.java
 * CREATED: Jul 2, 2013 5:05:14 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.security;

import java.io.InputStream;
import java.io.OutputStream;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.exceptions.SecurityException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: DESedeSecurityProvider.java,v 1.4 2015/07/15 05:32:37 ramap Exp $
 * @since 1.0.0
 */
public class DESedeSecurityProvider extends AbstractSymmetricProvider
{
	
	private static Logger logger = LoggerFactory.getLogger(DESSecurityProvider.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.ISymmetricSecurityProvider#decrypt(javax.crypto.spec.SecretKeySpec, java.lang.String,
	 * java.io.InputStream, java.io.OutputStream)
	 */
	public boolean decrypt (SecretKeySpec key, InputStream in, OutputStream out) throws SecurityException
	{
		Cipher cipher = null;
		int blockSize = Integer.MIN_VALUE;
		int outputSize = Integer.MIN_VALUE;
		byte[] inBytes = null;
		byte[] outBytes = null;
		int inLength = Integer.MIN_VALUE;
		boolean more = true;
		SecurityException sExp = null;
		try
		{
			cipher = Cipher.getInstance("DESede/" + MODE + "/" + PADDING, "BC");
			cipher.init(Cipher.DECRYPT_MODE, key, iv_8);
			
			blockSize = 16;
			outputSize = cipher.getOutputSize(blockSize);
			inBytes = new byte[blockSize];
			outBytes = new byte[outputSize];
			
			while (more)
			{
				inLength = in.read(inBytes);
				if (inLength == blockSize)
				{
					int outLength = cipher.update(inBytes, 0, blockSize, outBytes);
					out.write(outBytes, 0, outLength);
				}
				else
					more = false;
			}
			if (inLength > 0)
				outBytes = cipher.doFinal(inBytes, 0, inLength);
			else
				outBytes = cipher.doFinal();
			out.write(outBytes);
			out.flush();
		}
		catch (Exception exp)
		{
			sExp = new SecurityException("error.iris.admin.security", new Object[] {}, exp);
			logger.error(IRISLogger.getText(sExp));
			throw sExp;
			
		}
		finally
		{
			HelperUtils.doClose(out);
			HelperUtils.doClose(in);
		}
		return true;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.ISymmetricSecurityProvider#generateKey(java.lang.String, java.lang.String, java.lang.String)
	 */
	public SecretKeySpec generateKey (String password, int keySize) throws SecurityException
	{
		ParametersWithIV ivparam = null;
		KeyParameter keyParam = null;
		PKCS5S2ParametersGenerator generator = null;
		SecurityException sExp = null;
		try
		{
			
			char[] charArrayPassword = password.toCharArray();
			byte bytePassword[] = PBEParametersGenerator.PKCS5PasswordToBytes(charArrayPassword);
			
			generator = new PKCS5S2ParametersGenerator();
			generator.init(bytePassword, salt8, itrcount);
			
			ivparam = new ParametersWithIV(generator.generateDerivedParameters(keySize), new byte[128]);
			keyParam = (KeyParameter) ivparam.getParameters();
		}
		catch (Exception exp)
		{
			sExp = new SecurityException("error.iris.admin.security", new Object[] {}, exp);
			logger.error(IRISLogger.getText(sExp));
			throw sExp;
		}
		finally
		{
			ivparam = null;
			generator = null;
		}
		return new SecretKeySpec(keyParam.getKey(), "DESede");
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.security.ISymmetricSecurityProvider#encrypt(javax.crypto.spec.SecretKeySpec, java.io.InputStream,
	 * java.io.OutputStream)
	 */
	public boolean encrypt (SecretKeySpec key, InputStream in, OutputStream out) throws SecurityException
	{
		Cipher cipher = null;
		int blockSize = Integer.MIN_VALUE;
		int outputSize = Integer.MIN_VALUE;
		byte[] inBytes = null;
		byte[] outBytes = null;
		int inLength = Integer.MIN_VALUE;
		boolean more = true;
		SecurityException sExp = null;
		
		try
		{
			cipher = Cipher.getInstance("DESede/" + MODE + "/" + PADDING, "BC");
			cipher.init(Cipher.ENCRYPT_MODE, key, iv_8);
			blockSize = 16;
			outputSize = cipher.getOutputSize(blockSize);
			inBytes = new byte[blockSize];
			outBytes = new byte[outputSize];
			
			while (more)
			{
				inLength = in.read(inBytes);
				if (inLength == blockSize)
				{
					int outLength = cipher.update(inBytes, 0, blockSize, outBytes);
					out.write(outBytes, 0, outLength);
				}
				else
					more = false;
			}
			if (inLength > 0)
				outBytes = cipher.doFinal(inBytes, 0, inLength);
			else
				outBytes = cipher.doFinal();
			out.write(outBytes);
			out.flush();
		}
		catch (Exception exp)
		{
			sExp = new SecurityException("error.iris.admin.security", new Object[] {}, exp);
			logger.error(IRISLogger.getText(sExp));
			throw sExp;
			
		}
		finally
		{
			HelperUtils.doClose(out);
			HelperUtils.doClose(in);
		}
		
		return true;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.security.ISymmetricSecurityProvider#decrypt(java.lang.String, int, java.io.InputStream, java.io.OutputStream)
	 */
	public boolean decrypt (String password, int keySize, InputStream in, OutputStream out) throws SecurityException
	{
		SecretKeySpec key = null;
		boolean status = false;
		
		key = generateKey(password, keySize);
		status = decrypt(key, in, out);
		return status;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.security.ISymmetricSecurityProvider#encrypt(java.lang.String, int, java.io.InputStream, java.io.OutputStream)
	 */
	public boolean encrypt (String password, int keySize, InputStream in, OutputStream out) throws SecurityException
	{
		SecretKeySpec key = null;
		boolean status = false;
		
		key = generateKey(password, keySize);
		status = encrypt(key, in, out);
		return status;
	}
	
}
