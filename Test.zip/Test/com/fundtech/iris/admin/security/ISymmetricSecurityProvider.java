package com.fundtech.iris.admin.security;

import java.io.InputStream;
import java.io.OutputStream;

import javax.crypto.spec.SecretKeySpec;

import com.fundtech.iris.admin.exceptions.SecurityException;

public interface ISymmetricSecurityProvider
{
	public SecretKeySpec generateKey (String password, int keySize) throws SecurityException;
	
	public boolean encrypt (SecretKeySpec key, InputStream in, OutputStream out) throws SecurityException;
	
	public boolean decrypt (SecretKeySpec key, InputStream in, OutputStream out) throws SecurityException;
	
	public boolean encrypt (String password, int keySize, InputStream in, OutputStream out) throws SecurityException;
	
	public boolean decrypt (String password, int keySize, InputStream in, OutputStream out) throws SecurityException;;
	
}
