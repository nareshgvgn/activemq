package com.fundtech.iris.admin.security;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Map;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * 
 * <p>
 * This is not a thread safe implementation Each thread should be designed to create unique instance of this object Should not be used as a singleton
 * This component is designed with fluent api, fast fail and single use. This is not thread safe. You have to create independent instances for each
 * thread. It is single use once you call decrypt it will destroy the password in memory, hence take care to destroy current instance and create a new
 * instance has to be created for next decryption. Tested with pgp command line version 10.1. It will fail with run-time exception as soon as you set
 * a wrong folder of file. Always set folder before setting fileName. 
 * This class originally written by <b><u>Anurag Mishra </u></b>, later corrected and tested by  <b><u>Shirish Kulkarni </u></b>. Thanks for their good work
 * 
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author  This class originally written by <b><u>Anurag Mishra </u></b>, later corrected and tested by  <b><u>Shirish Kulkarni </u></b>.
 * @version $Id: PgpSecurityProvider.java,v 1.2 2017/03/27 11:45:12 ramap Exp $
 */
public class PgpSecurityProvider implements IAsymmetricSecurityProvider
{
	private String _strPgpHome = null;;
	private String _strSrcFolder = null;
	private String _strDestFolder = null;
	private String _strSrcFileName = null;
	private String _strDestFileName = null;
	private String _strPGPCommandName = null;
	private String _strOutMessage = null;
	private String _strErrMessage = null;
	private String _strSigner = null;
	private String _strRecipient = null;;
	private String _strPassPhrase = null;
	private ExecutionJobData jobData = null;
	private static Logger logger = LoggerFactory.getLogger(PgpSecurityProvider.class.getName());
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getDestFileName()
	 */
	public String getDestFileName ()
	{
		return _strDestFileName;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getDestFolder()
	 */
	public String getDestFolder ()
	{
		if (null == _strDestFolder)
		{
			return "";
		}
		else
		{
			return _strDestFolder;
		}
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getErrMessage()
	 */
	public String getErrMessage ()
	{
		return _strErrMessage;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getOutMessage()
	 */
	public String getOutMessage ()
	{
		return _strOutMessage;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getPassPhrase()
	 */
	public String getPassPhrase ()
	{
		return _strPassPhrase;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getPGPCommandName()
	 */
	public String getPGPCommandName ()
	{
		return _strPGPCommandName;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getPgpHome()
	 */
	public String getPgpHome ()
	{
		return _strPgpHome;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getSrcFileName()
	 */
	public String getSrcFileName ()
	{
	
		if (null == _strSrcFileName)
			_strSrcFileName = "";
		
		return _strSrcFileName;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#getSrcFolder()
	 */
	public String getSrcFolder ()
	{
		return _strSrcFolder;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setDestFileName(java.lang.String)
	 */
	public IAsymmetricSecurityProvider setDestFileName (String destFileName)
	{
		File destFile = new File(getDestFolder() + destFileName);
		if (destFile.exists())
		{
			throw new RuntimeException("Destination file already exists :" + getDestFolder() + destFileName);
		}
		_strDestFileName = destFile.getAbsolutePath();
		return this;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setDestFolder(java.lang.String)
	 */
	public IAsymmetricSecurityProvider setDestFolder (String destFolder)
	{
		_strDestFolder = destFolder;
		File destDir = new File(destFolder);
		if (!destDir.exists())
		{
			throw new RuntimeException("Destination folder does not exist : " + destFolder);
		}
		return this;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setErrMessage(java.lang.String)
	 */
	public void setErrMessage (String errMessage)
	{
		_strErrMessage = errMessage;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setOutMessage(java.lang.String)
	 */
	public void setOutMessage (String outMessage)
	{
		this._strOutMessage = outMessage;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setPassPhrase(java.lang.String)
	 */
	public IAsymmetricSecurityProvider setPassPhrase (String passPhrase)
	{
		_strPassPhrase = passPhrase;
		return this;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setPGPCommandName(java.lang.String)
	 */
	public IAsymmetricSecurityProvider setPGPCommandName (String pGPCommandName)
	{
		_strPGPCommandName = pGPCommandName;
		return this;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setPgpHome(java.lang.String)
	 */
	public IAsymmetricSecurityProvider setPgpHome (String pgpHome)
	{
		_strPgpHome = pgpHome;
		return this;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setSrcFileName(java.lang.String)
	 */
	public IAsymmetricSecurityProvider setSrcFileName (String srcFileName)
	{
		File srcFile = null;
		if(!(null == getSrcFolder() || "".equals(getSrcFolder())))
			srcFile = new File(srcFileName);
		else
			{
				srcFile = new File(srcFileName);
				setSrcFolder(srcFile.getParent());
			}
		if (!srcFile.exists())
		{
			throw new RuntimeException("Source file  does not exist : " + srcFile + ":" + getSrcFolder());
		}
		_strSrcFileName = srcFile.getAbsolutePath();
		return this;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see IAsymmetricSecurityProvider#setSrcFolder(java.lang.String)
	 */
	public IAsymmetricSecurityProvider setSrcFolder (String srcFolder)
	{
		_strSrcFolder = srcFolder;
		File srcDir = new File(srcFolder);
		if (!srcDir.exists())
			throw new RuntimeException("Source folder does not exist : " + srcFolder);
		return this;
	}
	
	public int decrypt () throws IOException, InterruptedException
	{
		int intExitCode = 0;
		Process process = null;
		Map<String, String> environment = null;
		String commandString[] = new String[4];
		String unixCommandString= null;
		ProcessBuilder builder = null;
		
		try
		{
			if(!System.getProperty("os.name").contains("Windows"))
			{
				unixCommandString = "pgp --decrypt "  + getSrcFileName() + " -o "  + getDestFileName() + " --passPhrase " +getPassPhrase();
				process = Runtime.getRuntime().exec(unixCommandString);
			}
			else
			{
				commandString[0] = "cmd";
				commandString[1] = "/c";
				commandString[2] = " pgp --decrypt "  + getSrcFileName() + " -o "  + getDestFileName();
				commandString[3] = " --passPhrase " + getPassPhrase();
				
				builder = new ProcessBuilder(commandString);
				builder.directory(new File(getSrcFolder()));
				environment = builder.environment();
				process = builder.start();
			}
			
			process.waitFor();
			setOutMessage(getString(process.getErrorStream()));
			setErrMessage(getString(process.getInputStream()));
			
			intExitCode = process.exitValue();
			logger.info("Exit code " +intExitCode );
			
			process.destroy();
		}
		catch (Exception e)
		{
			logger.error("Error" + e);
		}
		finally
		{
			Random random = new Random();
			int intRandom = random.nextInt();
			// destroy the password in memory
			process = null;
			setPassPhrase("" + intRandom);
			setPassPhrase(null);
			environment = null;
			builder = null;
			commandString = null;
			unixCommandString = null;
		}
		intExitCode = validateDecryptedFile();
		return intExitCode;
	}
	
	public int verifyDecrypt () throws IOException, InterruptedException
	{
		int intExitCode = 0;
		ProcessBuilder builder = null;
		Map<String, String> environment = null;
		String[] commandString = new String[4];
		String unixCommandString= null;
		Process process = null;
		
		try
		{
			if(!System.getProperty("os.name").contains("Windows"))
			{
				unixCommandString = "pgp --decrypt "  + getSrcFileName() + " -o "  + getDestFileName() + " --passPhrase " +getPassPhrase();
				process = Runtime.getRuntime().exec(unixCommandString);
			}
			else
			{
				commandString[0] = "cmd";
				commandString[1] = "/c";
				commandString[2] = " pgp --decrypt "  + getSrcFileName() + "   -o "  + getDestFileName();
				commandString[3] = " --passPhrase " + getPassPhrase();
				builder = new ProcessBuilder(commandString);
				builder.directory(new File(getSrcFolder()));
				environment = builder.environment();
				process = builder.start();
			}
			
			process.waitFor();
			
			setOutMessage(getString(process.getErrorStream()));
			setErrMessage(getString(process.getInputStream()));
			intExitCode = process.exitValue();
			process.destroy();
		}
		catch (Exception e)
		{
			logger.error("Error" + e);
		}
		finally
		{
			Random random = new Random();
			int intRandom = random.nextInt();
			// destroy the password in memory
			setPassPhrase("" + intRandom);
			setPassPhrase(null);
			builder = null;
			environment = null;
			commandString = null;
			unixCommandString = null;
		}
		intExitCode = validateDecryptedFile();
		return intExitCode;
	}
	
	private int validateDecryptedFile ()
	{
		File decryptedFile = null;
		int intExitCode = 0;
		decryptedFile = new File(getDestFolder() + getDestFileName());
		
		if (!decryptedFile.exists() || !decryptedFile.isFile())
		{
			intExitCode = -1;
		}
		if (decryptedFile.length() <= 0)
		{
			intExitCode = -1;
		}
		
		return intExitCode;
	}
	
	static String getString (InputStream inputStr) throws IOException
	{
		StringBuffer stream = null;
		int size = 1024;
		InputStreamReader inStr = null;
		int read;
		inStr = new InputStreamReader(inputStr);
		char[] c = new char[size];
		stream = new StringBuffer();
		while ((read = inStr.read(c, 0, size - 1)) > 0)
		{
			stream.append(c, 0, read);
			if (read < size - 1)
				break;
		}
		return stream.toString();
	}
	
	static void getString (OutputStream outputStr) throws IOException
	{
		int size = 1024;
		OutputStreamWriter inStr = null;
		inStr = new OutputStreamWriter(outputStr);
		char[] c = new char[size];
		inStr.write(c, 0, size - 1);
	}
	
	public int encrypt () throws IOException, InterruptedException
	{
		int intExitCode = 0;
		ProcessBuilder builder = null;
		Process process = null;
		Map<String, String> environment = null;
		String[] commandString = new String[3];
		String unixCommandString= null;
		
		
		try
		{
			if(!System.getProperty("os.name").contains("Windows"))
			{
				unixCommandString = "pgp --encrypt " + getSrcFileName() + "  --recipient " + getRecipient() ;
				process = Runtime.getRuntime().exec(unixCommandString);
			}
			else
			{
				commandString[0] = "cmd";
				commandString[1] = "/c";
				commandString[2] = " pgp --encrypt " + getSrcFileName() + "  --recipient " + getRecipient();
				
				builder = new ProcessBuilder(commandString);
				builder.directory(new File(getSrcFolder()));
				environment = builder.environment();
				process = builder.start();
			}
			process.waitFor();
			setOutMessage(getString(process.getErrorStream()));
			setErrMessage(getString(process.getInputStream()));
			intExitCode = process.exitValue();
			process.destroy();
		}
		catch (Exception e)
		{
			logger.error("Error" + e);
		}
		finally
		{
			Random random = new Random();
			int intRandom = random.nextInt();
			// destroy the password in memory
			setPassPhrase("" + intRandom);
			setPassPhrase(null);
			builder = null;
			environment = null;
			commandString = null;
			unixCommandString = null;
		}
		return intExitCode;
	}
	
	public int sign () throws IOException, InterruptedException
	{
		int intExitCode = 0;
		ProcessBuilder builder = null;
		Map<String, String> environment = null;
		String[] commandString = new String[4];
		String unixCommandString= null;
		Process process = null;
		
		try
		{
			if(!System.getProperty("os.name").contains("Windows"))
			{
				unixCommandString = "pgp --sign " + getSrcFileName() + " --signer " + getSigner() + " --passphrase " + getPassPhrase() 
									+ " --output " + getSrcFileName() + ".pgp";
				process = Runtime.getRuntime().exec(unixCommandString);
			}
			else
			{
				commandString[0] = "cmd";
				commandString[1] = "/c";
				commandString[2] = " pgp --sign " + getSrcFileName();
				commandString[3] = " --signer " + getSigner() + " --passphrase " + getPassPhrase() + " --output " + getSrcFileName()
									+ ".pgp";
					
				builder = new ProcessBuilder(commandString);
				builder.directory(new File(getSrcFolder()));
				environment = builder.environment();
				
				process = builder.start();
			}
			process.waitFor();
			
			setOutMessage(getString(process.getErrorStream()));
			setErrMessage(getString(process.getInputStream()));
			intExitCode = process.exitValue();
			process.destroy();
		}
		catch (Exception e)
		{
			logger.error("Error" + e);
		}
		finally
		{
			Random random = new Random();
			int intRandom = random.nextInt();
			// destroy the password in memory
			setPassPhrase("" + intRandom);
			setPassPhrase(null);
			builder = null;
			environment = null;
			commandString = null;
			unixCommandString = null;
		}
		return intExitCode;
	}
	
	public int signAndEncrypt () throws IOException, InterruptedException
	{
		int intExitCode = 0;
		ProcessBuilder builder = null;
		Map<String, String> environment = null;
		String[] commandString = new String[4];
		String unixCommandString= null;
		Process process = null;
		
		try
		{
			if(!System.getProperty("os.name").contains("Windows"))
			{
				unixCommandString =" pgp -es " + getSrcFileName() + " --signer " + getSigner() + " --passphrase " + getPassPhrase() + " --recipient " 
								+ getRecipient() + " --output " + getSrcFileName() + ".pgp";
				process = Runtime.getRuntime().exec(unixCommandString);
			}
			else
			{
				commandString[0] = "cmd";
				commandString[1] = "/c";
				commandString[2] = " pgp -es " + getSrcFileName();
				commandString[3] = " --signer " + getSigner() + " --passphrase " + getPassPhrase() + " --recipient " + getRecipient() + " --output "
						+ getSrcFileName() + ".pgp";
					
				builder = new ProcessBuilder(commandString);
				builder.directory(new File(getSrcFolder()));
				environment = builder.environment();
				
				process = builder.start();
			}
			process.waitFor();
			
			setOutMessage(getString(process.getErrorStream()));
			setErrMessage(getString(process.getInputStream()));
			intExitCode = process.exitValue();
			process.destroy();
		}
		catch (Exception e)
		{
			logger.error("Error" + e);
		}
		finally
		{
			Random random = new Random();
			int intRandom = random.nextInt();
			// destroy the password in memory
			setPassPhrase("" + intRandom);
			setPassPhrase(null);
			builder = null;
			environment = null;
			commandString = null;
			unixCommandString = null;
		}
		return intExitCode;
	}
	
	public int verify () throws IOException, InterruptedException
	{
		int intExitCode = 0;
		ProcessBuilder builder = null;
		Map<String, String> environment = null;
		String[] commandString = new String[4];
		String unixCommandString= null;
		Process process = null;
		
		try
		{
			if(!System.getProperty("os.name").contains("Windows"))
			{
				unixCommandString ="pgp --verify " + getSrcFileName() +" --output " + getPassPhrase();
				process = Runtime.getRuntime().exec(unixCommandString);
			}
			else
			{
				commandString[0] = "cmd";
				commandString[1] = "/c";
				commandString[2] = " pgp --verify " + getSrcFileName();
				commandString[3] = " --output " + getPassPhrase();
	
				builder = new ProcessBuilder(commandString);
				builder.directory(new File(getSrcFolder()));
				environment = builder.environment();
				
				process = builder.start();
			}
			
			process.waitFor();
			setOutMessage(getString(process.getErrorStream()));
			setErrMessage(getString(process.getInputStream()));
			intExitCode = process.exitValue();
			process.destroy();
		}
		catch (Exception e)
		{
			logger.error("Error" + e);
		}
		finally
		{
			Random random = new Random();
			int intRandom = random.nextInt();
			// destroy the password in memory
			setPassPhrase("" + intRandom);
			setPassPhrase(null);
			builder = null;
			environment = null;
			commandString = null;
			unixCommandString = null;
		}
		return intExitCode;
	}
	
	public String getSigner ()
	{
		return _strSigner;
	}
	
	public IAsymmetricSecurityProvider setSigner (String signer)
	{
		_strSigner = signer;
		
		return this;
	}
	
	public IAsymmetricSecurityProvider setRecipient (String recipient)
	{
		_strRecipient = recipient;
		
		return this;
	}
	
	public String getRecipient ()
	{
		return _strRecipient;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.security.IAsymmetricSecurityProvider#setJobData(com.fundtech.iris.admin.data.ExecutionJobData)
	 */
	@Override
	public void setJobData (ExecutionJobData jobData)
	{
		this.jobData = jobData;
	}
	
}
