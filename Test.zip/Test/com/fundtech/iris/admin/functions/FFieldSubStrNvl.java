package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;


/**
 * TODO This function is to truncate the value.
 * 
 * @author Archana Shirude
 * @version $Id: FFieldSubStrNvl.java,v 1.1 2015/12/09 05:02:45 ramap Exp $
 * @since 1.0.0
 */
public class FFieldSubStrNvl extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FFieldSubStrNvl.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String param1 = null ;
		String param2 = null ;
		
		String fieldVal1 = null ;
		String fieldVal2 = null ;
		
		String data = null;
		String val = null ;
		
		Integer startIndex = 0 ;
		Integer endIndex = null ;
		BatchBand instBatch = null;
		Band dataBand = null;
		String[] paramArray = null;
		String[] fieldArray = null ; 
		
		
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			instBatch = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			logger.trace("Data {}", data);
			paramArray = data.split(",");
			param1 = paramArray[0].trim();
			param2 = paramArray[1].trim();
			
			fieldArray = param1.split("[\\|]+");
			fieldVal1 = getConcateFieldValue(fieldArray, dataBand, instBatch);
			
			fieldArray = param2.split("[\\|]+");
			fieldVal2 = getConcateFieldValue(fieldArray, dataBand, instBatch);
			
			startIndex = Integer.parseInt(paramArray[2].trim());
			
			if(paramArray.length > 3)
			{
				endIndex = Integer.parseInt(paramArray[3].trim());
			}
			
			val  = fieldVal1 ;
			if (null == fieldVal1 || "".equals(fieldVal1))
			{
				val = fieldVal2 ;
			}
			
			if (null != val && startIndex != null)
			{
				if(startIndex > val.length())
				{
//					if(logger.isErrorEnabled())
//					logger.error( "Start index is greater than string length" );
					// I think we no need to any thing.. need to ask Archana Shirude who did this coding 
				}
				else
				{
					if(endIndex == null || endIndex >= val.length())
					{
						endIndex = val.length() ;
					}
					else
					{
						endIndex = startIndex + endIndex ;
						endIndex = endIndex - 1 ;
					}
					val = val.substring(startIndex - 1, endIndex);
				}
				
			}
			
			logger.trace("val {}", val);
		}
		catch (Exception e)
		{
			logger.error("Error while SUBSTRNVL", e);
		}
		
		return val;
	}
	
	private String getConcateFieldValue(String[] fieldArray,Band dataBand,BatchBand instBatch)
	{
		StringBuilder builder = null;
		String fieldValue = null ;
		try
		{
			builder = new StringBuilder();
			for(String fieldName : fieldArray)
			{
				if(-1 != fieldName.indexOf("."))
				{
					fieldValue =  getRefValue(fieldName, dataBand, instBatch);
				}
				else if(" ".equals(fieldName))
				{
					fieldValue = fieldName ;
				}
				else
				{
					fieldValue = fieldName.replace("'", "");
				}
				if (fieldValue == null)
					fieldValue = "";
				builder.append(fieldValue);
			}
		}
		catch (Exception e)
		{
			logger.error("Error while Concatenate", e);
		}
		return builder.toString();
	}
	
}
