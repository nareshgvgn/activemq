/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.functions
 * FILE   : FSetCreditDebitAmount.java
 * CREATED: Jan 7, 2014 12:30:10 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.math.BigDecimal;
import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

/**
 * 
 * <p>
 * This helper function checks the indicator, based on indicator it takes payment amount or debit amount. Default indicator is "P"
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into iris_function_mst (DATA_TYPE, FUNCTION_NAME, FUNCTION_DESC, MAPPING_TYPE, MAPPED_CLASS, VALID_FLAG)
 * values ('DECIMAL', 'SETINSTAMNT', 'Syntax: SETINSTAMNT(Amount Indicator, Payment Amount, Debit Amount)  Description: Based on the given 
 * Amount Indicator value it sets either Payment Amount or Debit Amount as an Instrument Amount', 4, 'com.fundtech.iris.admin.functions.FSetCreditDebitAmount', 'Y');
 * </pre>
 * 
 * </p>
 * 
 * @author Smita Rudrake
 * @version $Id: FSetCreditDebitAmount.java,v 1.2 2014/07/20 04:58:19 ramap Exp $
 */
public class FSetCreditDebitAmount extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FSetCreditDebitAmount.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		String data = null;
		String amntIndicator = null;
		String amount = null;
		BigDecimal instAmnt = null;
		Band instBand = null;
		BatchBand instBatch = null;
		
		try
		{
			instBand = (Band) params.get(IFunction.EXECUTION_BAND);
			instBatch = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			data = (String) params.get(IFunction.FUNCTION_DATA);
			String[] str = data.split(",");
			amntIndicator = getRefValue(str[0].trim(), instBand, instBatch);
			
			if (amntIndicator == null || amntIndicator.isEmpty())
				amntIndicator = "P";
			
			if ("P".equalsIgnoreCase(amntIndicator))
				amount = getRefValue(str[1].trim(), instBand, instBatch);
			
			if ("D".equalsIgnoreCase(amntIndicator))
				amount = getRefValue(str[2].trim(), instBand, instBatch);
			
			if (amount == null)
				instAmnt = new BigDecimal(0);
			else
				instAmnt = new BigDecimal(amount);
		}
		catch (Exception e)
		{
			logger.error("Error while setting Instrument Amount.", e);
		}
		
		return instAmnt.toPlainString();
	}
	
}
