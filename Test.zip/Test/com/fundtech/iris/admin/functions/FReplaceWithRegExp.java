/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.functions
 * FILE   : FReplaceWithRegExp.java
 * CREATED: Sep 11, 2016 1:07:25 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>This method replaces the chars with given char 
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code Example REPLACE( "[^\\d]", "") this example replaces non-numeric values to empty
 * 				  REPLACE("[^0-9]", "") this example replaces non-numeric values to empty
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: FReplaceWithRegExp.java,v 1.1 2016/09/12 07:20:16 ramap Exp $
 */
public class FReplaceWithRegExp  implements IFunction
{
	private Logger logger = LoggerFactory.getLogger(FReplaceWithRegExp.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String data = null;
		String val = null;
		String[] strArray = null;
		String expression = null;
		String replaceChar = "";
		
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			val = (String) params.get(IFunction.FUNCTION_VALUE);
			
			if ( val == null)
				return null;
			if ( data ==  null)
				return val;
			
			strArray = StringUtils.split(data, ",");
			expression  = strArray[0];
			
			if ( strArray.length > 1)
				replaceChar = strArray[1];
			
			val = val.replaceAll(expression, replaceChar);
			
		}
		catch (Exception e)
		{
			logger.error("Error while replacing .", e);
		}
		
		return val;
	}
	
	// This is for testing
	public static void main(String[] args )
	{
		String myStr = "212-684-4446";
		myStr = myStr.replaceAll( "[^\\d]", "" );
		System.out.println(myStr);
	}
	
}
