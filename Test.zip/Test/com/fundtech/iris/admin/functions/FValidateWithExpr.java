package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

/**
 * 
 * <p>
 * This helper function validates the data which is read from file by using given regular expression. This method throws exception if data is not
 * valid.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into iris_function_mst (DATA_TYPE, FUNCTION_NAME, FUNCTION_DESC, MAPPING_TYPE, MAPPED_CLASS, VALID_FLAG)
 * values ('STRING', 'VALIDATEWITHEXPR', 'Syntax: VALIDATEWITHEXPR(Regular Expression) Description: To Validate the data against Regular Expression. 
 * Data will be rejected when it fails to match the Regular Expression.', 2, 'com.fundtech.iris.admin.functions.FValidateWithExpr', 'Y');
 * </pre>
 * 
 * </p>
 * <p>
 * For Email:- <i>^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$</i>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FValidateWithExpr.java,v 1.6 2014/07/20 04:58:19 ramap Exp $
 */
public class FValidateWithExpr extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FValidateWithExpr.class);
	
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		FormatException formatEx = null;
		String fieldValue = null;
		String REGEX = null;
		
		try
		{
			REGEX = (String) params.get(IFunction.FUNCTION_DATA); // This will be regular expression passed as an argument
			fieldValue = (String) params.get(IFunction.FUNCTION_VALUE);
			
			if (fieldValue == null || fieldValue.isEmpty())
				return fieldValue;
			
			if (!fieldValue.trim().matches(REGEX))
			{
				logger.error("Data Is Not Valid against Regular Expression{} ", REGEX);
				formatEx = new FormatException("com.fundtech.iris.admin.functions.FValidateWithExpr", new Object[]
				{ "Data Is Not Valid." }, null);
				logger.error(IRISLogger.getText(formatEx));
				throw formatEx;
			}
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		
		return fieldValue;
	}
	
}
