package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*------------------------------------------------------------------------------
 * PACKAGE: 
 * FILE   : FSubStr.java
 * CREATED: 24-May-2013 12:55:53 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/

/**
 * TODO This function is to truncate the value.
 * 
 * @author Maharshi Chavda
 * @version $Id: FSubStr.java,v 1.3 2014/07/20 04:58:19 ramap Exp $
 * @since 1.0.0
 */
public class FSubStr implements IFunction
{
	private Logger logger = LoggerFactory.getLogger(FSubStr.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String data = null;
		String val = null;
		int startIndex = 0;
		int endIndex = 0;
		String[] index = null;
		
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			val = (String) params.get(IFunction.FUNCTION_VALUE);
			
			index = data.split(",");
			startIndex = Integer.parseInt(index[0]);
			endIndex = Integer.parseInt(index[1]);
			
			if (null != val)
			{
				if (endIndex >= val.length())
					endIndex = val.length();
				
				val = val.substring(startIndex - 1, endIndex);
			}
		}
		catch (Exception e)
		{
			logger.error("Error while substring", e);
		}
		
		return val;
	}
}
