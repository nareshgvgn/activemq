package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

public class FGetBenefIFSCCode extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FGetBenefIFSCCode.class);
	
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		String val = null;
		
		try
		{
			val = (String) params.get(IFunction.FUNCTION_VALUE);
			String[] str = val.split("/");
			val = str[01];
		}
		catch (Exception e)
		{
			logger.error("Error while deriving Beneficiary IFSC Code.", e);
		}
		
		return val;
	}
	
}
