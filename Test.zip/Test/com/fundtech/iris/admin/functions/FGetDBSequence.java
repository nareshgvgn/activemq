/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.functions
 * FILE   : FGetDBSequence.java
 * CREATED: Aug 14, 2013 12:25:25 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: FGetDBSequence.java,v 1.6 2016/01/12 06:48:52 ramap Exp $
 * @since 1.0.0
 */
public class FGetDBSequence implements IFunction
{
	private Logger logger = LoggerFactory.getLogger(FGetDBSequence.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params) throws FormatException
	{
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String dbSequence = null;
		String sql = null;
		String nextVal = null;
		FormatException fExp = null;
		try
		{
			dbSequence = (String) params.get(IFunction.FUNCTION_DATA);
			sql = "SELECT " + dbSequence + ".currval FROM DUAL";
			statement = dbConnection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			if (resultSet.next())
				nextVal = resultSet.getString(1);
		}
		catch (Exception exp)
		{
			logger.error("Error while getting sequence " + dbSequence + ".nextval");
			fExp = new FormatException("com.fundtech.iris.admin.functions.FGetDBSequence", new Object[]
			{ "Data Is Not Valid." }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			HelperUtils.doClose(resultSet);
			HelperUtils.doClose(statement);
		}
		return nextVal;
	}
	
}
