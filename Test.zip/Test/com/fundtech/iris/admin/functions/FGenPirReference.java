package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.StringUtils;

public class FGenPirReference extends IrisAdminPlugin
{
	private final static String appSql = "SELECT GENERIC.GET_DATE(?) FROM DUAL";
	private final static String seqFunction = "SELECT seq_pir_ref_var.nextval FROM DUAL";
	private final static Logger logger = LoggerFactory.getLogger(FGenPirReference.class);
	
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException
	
	{
		String applDate = null;
		ExecutionJobData jobData = null;
		String clientCode = null;
		String sellerCode = null;
		String seqNumber = null;
		String retVal = null;
		try
		{
			jobData = (ExecutionJobData) params.get(IFunction.EXECUTION_DATA);
			clientCode = jobData.getEntityCode();
			sellerCode = jobData.getSellerCode();
			applDate = getAppDate(dbConnection, sellerCode);
			seqNumber = getSeqNumber(dbConnection);
			
			retVal = clientCode + applDate + seqNumber;
			
		}
		catch (Exception e)
		{
			logger.error("Error while getting Application Date", e);
			// DO not throw Exception in Functions.. lets caller decided what he wants to do
		}
		return retVal;
	}
	
	private String getAppDate (Connection dbConnection, String sellerCode) throws Exception
	{
		Date applDate = null;
		PreparedStatement applStmt = null;
		ResultSet applRs = null;
		SimpleDateFormat dateFormat = null;
		String retVal = null;
		try
		{
			applStmt = dbConnection.prepareStatement(appSql);
			applStmt.setString(1, sellerCode);
			applRs = applStmt.executeQuery();
			if (applRs.next())
			{
				applDate = applRs.getDate(1);
				dateFormat = new SimpleDateFormat("ddMM");
				retVal = dateFormat.format(applDate);
			}
			else
			 throw	new FormatException("error.iris.admin.appdate", new Object[]
						{ "Seller:" + sellerCode + "  doesn't have application Data" }, null);
				
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			HelperUtils.doClose(applRs);
			HelperUtils.doClose(applStmt);
		}
		return retVal;
	}
	
	private String getSeqNumber (Connection dbConnection) throws Exception
	{
		String seqNumber = null;
		PreparedStatement seqlStmt = null;
		ResultSet seqRs = null;
		try
		{
			seqlStmt = dbConnection.prepareStatement(seqFunction);
			seqRs = seqlStmt.executeQuery();
			if (seqRs.next())
			{
				seqNumber = seqRs.getString(1);
				seqNumber = StringUtils.padLeft(seqNumber, "0", 5);
			}
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			HelperUtils.doClose(seqRs);
			HelperUtils.doClose(seqlStmt);
		}
		return seqNumber;
	}
}
