/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.functions
 * FILE   : SetSeqNumber.java
 * CREATED: Aug 22, 2013 10:05:38 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: SetSeqNumber.java,v 1.5 2016/10/19 14:10:22 ramap Exp $
 * @since 1.0.0
 */
public class SetSeqNumber extends IrisAdminPlugin
{
	
	private long seqNumber = 1;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String number = null;
		String data = null;
		
		data = (String) params.get(IFunction.FUNCTION_DATA);
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(data) || IrisAdminConstants.CONSTANT_YES.equalsIgnoreCase(data) || "true".equalsIgnoreCase(data))
			seqNumber = 1;
		else
			seqNumber++;
		
		number = "" + seqNumber;
		
		return number;
	}
	
}
