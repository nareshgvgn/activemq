/*----------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.iris.admin.functions
 * FILE     : FGetEffectiveDate.java
 * CREATED  : Apr 05, 2017
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *--------------------------------------------------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>
 * This function returns the concatenated string by using given reference field's value.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into iris_function_mst (DATA_TYPE, FUNCTION_NAME, FUNCTION_DESC, MAPPING_TYPE, MAPPED_CLASS, VALID_FLAG)
 * values ('STRING', 'CONCAT', 'Syntax: CONCAT() Description: To Concatenate the given String Fields.', 4, 'com.fundtech.iris.admin.functions.FGetEffectiveDate', 'Y');
 * </pre>
 * 
 * </p>
 * 
 * @author Maharshi Chavda
 * @version $Id: FGetEffectiveDate.java$
 */
public class FGetEffectiveDate extends IrisAdminPlugin
{
	
	private static Logger logger = LoggerFactory.getLogger(FGetEffectiveDate.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params) throws FormatException
	{
		String functionData = null;
		BatchBand instBatch = null;
		Band dataBand = null;
		String[] fieldNames = null;
		Date actDate = null;
		PreparedStatement applStmt = null;
		ResultSet applRs = null;
		SimpleDateFormat dateFormat = null;
		String retVal = null;
		String categoryCode= null;
		String clientName= null;
		String packageId= null;
		String productCode= null;
		String outDateFormat= null;
		ExecutionJobData jobData = null;
		String clientId = null;
		String sql = "SELECT f_get_effective_date(?,?,?,?,?) FROM DUAL";
		
		try
		{
			functionData = (String) params.get(IFunction.FUNCTION_DATA);
			instBatch = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			jobData = (ExecutionJobData) params.get(IFunction.EXECUTION_DATA);
			clientId = jobData.getEntityCode();
			fieldNames = functionData.split(",");
			
			categoryCode = fieldNames[0];
			clientName = getRefValue(fieldNames[1], dataBand, instBatch);
			packageId = getRefValue(fieldNames[2], dataBand, instBatch);
			productCode = getRefValue(fieldNames[3], dataBand, instBatch);
			outDateFormat = fieldNames[4];

			applStmt = dbConnection.prepareStatement(sql);
			applStmt.setString(1, categoryCode);
			applStmt.setString(2, clientName);
			applStmt.setString(3, packageId);
			applStmt.setString(4, productCode);
			applStmt.setString(5, clientId);
			applRs = applStmt.executeQuery();
			if (applRs.next())
			{
				actDate = applRs.getDate(1);
				dateFormat = new SimpleDateFormat(outDateFormat);
				retVal = dateFormat.format(actDate);
				
			}
		}
		catch (Exception e)
		{
			logger.error("Error while deriving effective date.", e);
		}
		finally
		{
			HelperUtils.doClose(applRs);
			HelperUtils.doClose(applStmt);
		}
		logger.trace("Effective Date :: {}", retVal);
		return retVal;
	}
}
