package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*------------------------------------------------------------------------------
 * PACKAGE: 
 * FILE   : SuffixImpl.java
 * CREATED: 29-May-2013 5:03:04 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/

/**
 * This function is to return string suffixing value to data.
 * 
 * @author Maharshi Chavda
 * @version $Id: FSuffix.java,v 1.4 2014/07/20 04:58:19 ramap Exp $
 * @since 1.0.0
 */
public class FSuffix implements IFunction
{
	private Logger logger = LoggerFactory.getLogger(FSuffix.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String data = null;
		String val = null;
		
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			val = (String) params.get(IFunction.FUNCTION_VALUE);
			if (null != val && null != data)
			{
				data = val.concat(data);
			}
		}
		catch (Exception e)
		{
			logger.error("Error while suffixing.", e);
		}
		
		return data;
	}
}
