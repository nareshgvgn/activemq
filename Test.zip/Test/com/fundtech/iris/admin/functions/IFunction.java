/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.mapping
 * FILE   : IFunction.java
 * CREATED: Mar 3, 2013 11:31:44 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: IFunction.java,v 1.5 2016/12/22 13:42:07 ramap Exp $
 * @since 1.0.0
 */
public interface IFunction
{
	public String FUNCTION_DATA = "DATA";
	public String FUNCTION_FIELD = "FIELD";
	public String FUNCTION_VALUE = "VALUE";
	public String EXECUTION_DATA = "EXECUTION_DATA";
	public String EXECUTION_BAND = "EXECUTION_BAND";
	public String EXECUTION_BATCH = "EXECUTION_BATCH";
	public String EXECUTION_BAND_DEF = "EXECUTION_BAND_DEF";
	
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException;
	
}
