/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.functions
 * FILE   : GCPUserPasswordGenerator.java
 * CREATED: Aug 1, 2016 1:33:50 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.core.security.DefaultPasswordTool;
import com.fundtech.core.util.Pair;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: GCPUserPasswordGenerator.java,v 1.3 2016/08/19 06:37:31 ramap Exp $
 */
public class GCPUserPasswordGenerator extends IrisAdminPlugin
{

	private Logger logger = LoggerFactory.getLogger(GCPUserPasswordGenerator.class.getName());
	
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		String functionData = null;
		Band dataBand = null;
		BatchBand batchBand = null;
		String userId = null;
		ExecutionJobData jobData = null;
		String passBeanName = null;
		String password = null;
		Pair<String> pair = null;
		FormatException fExp = null;
		DefaultPasswordTool tool = null;
		
		try
		{
			functionData = (String) params.get(IFunction.FUNCTION_DATA);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			batchBand = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			jobData = (ExecutionJobData) params.get(IFunction.EXECUTION_DATA);
			userId = getRefValue(functionData, dataBand, batchBand);
			passBeanName = jobData.getFilterParameter(IrisAdminConstants.PASSWORD_GEN_NAME);
			
			if ( StringUtils.isEmpty(passBeanName))
				return password;
			
			tool = (DefaultPasswordTool)ContextManager.getInstance().getBeanObject(passBeanName);
			pair = tool.generatePassword(userId);
			logger.trace("For User :{} default password is: {}", userId, pair.getOld());
			password = pair.getNew();
		}
		catch( Exception exp)
		{
			logger.error("Error while generating password for {}",userId );
			fExp = new FormatException("com.fundtech.iris.admin.functions.generatepassword", new Object[]{ userId }, exp);
			logger.error(IRISLogger.getText(fExp));
		}
		return password;
	}
}
