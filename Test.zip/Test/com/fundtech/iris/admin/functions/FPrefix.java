package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*------------------------------------------------------------------------------
 * PACKAGE: 
 * FILE   : Concat.java
 * CREATED: 24-May-2013 1:36:46 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/

/**
 * TODO This function is to return string prefixing value to data.
 * 
 * @author Maharshi Chavda
 * @version $Id: FPrefix.java,v 1.3 2014/07/20 04:58:19 ramap Exp $
 * @since 1.0.0
 */
public class FPrefix implements IFunction
{
	private Logger logger = LoggerFactory.getLogger(FPrefix.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String data = null;
		String val = null;
		
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			val = (String) params.get(IFunction.FUNCTION_VALUE);
			
			if (null != val && null != data)
			{
				data = data.concat(val);
			}
			
		}
		catch (Exception e)
		{
			logger.error("Error while prefixing.", e);
		}
		
		return data;
	}
}
