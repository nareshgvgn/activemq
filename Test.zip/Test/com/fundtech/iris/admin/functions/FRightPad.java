/*------------------------------------------------------------------------------
 * PACKAGE: 
 * FILE   : FRightPad
 * CREATED: 24-May-2013 2:29:17 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.StringUtils;

/**
 * <p>
 * This helper function does the right padding
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into iris_function_mst (DATA_TYPE, FUNCTION_NAME, FUNCTION_DESC, MAPPING_TYPE, MAPPED_CLASS, VALID_FLAG)
 * values ('STRING', 'RIGHTPADDING', 'Syntax: RIGHTPADDING(FillerCharacter) Description: To pad the given FillerCharacter at the right 
 * of the Field Value', 2, 'com.fundtech.iris.admin.functions.FRightPad', 'Y');
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FRightPad.java,v 1.2 2014/07/20 04:58:19 ramap Exp $
 */
public class FRightPad implements IFunction
{
	private Logger logger = LoggerFactory.getLogger(FRightPad.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String data = null;
		String fldVal = null;
		int length = 0;
		String filler = null;
		String[] str = null;
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			fldVal = (String) params.get(IFunction.FUNCTION_VALUE);
			
			str = data.split(",");
			length = Integer.parseInt(str[0]);
			filler = str[1];
			
			if (filler == null || fldVal == null)
				return fldVal;
			
			fldVal = StringUtils.padRight(fldVal, filler, length);
		}
		catch (Exception e)
		{
			logger.error("Error while padding filler.", e);
		}
		return fldVal;
	}
}
