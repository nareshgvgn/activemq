/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.functions
 * FILE   : FGetSysDate.java
 * CREATED: Jul 9, 2013 6:15:37 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.DateUtils;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FGetSysDate.java,v 1.9 2015/10/19 12:06:08 ramap Exp $
 */
public class FGetSysDate implements IFunction
{
	private static Logger logger = LoggerFactory.getLogger(FGetSysDate.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String sysDate = null;
		MappingField field = null;
		SimpleDateFormat formater = null;
		ExecutionJobData jobData = null;
		try
		{
			field = (MappingField) params.get(IFunction.FUNCTION_FIELD);
			jobData = (ExecutionJobData) params.get(IFunction.EXECUTION_DATA);
			if ("U".equals(jobData.getMapType()))
				formater = new SimpleDateFormat(DateUtils.ISO_DATEFORMAT);
			else
				formater = new SimpleDateFormat(field.getFormat());
			sysDate = formater.format(Calendar.getInstance().getTime());
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			logger.error("Error while converting data for Field:{} and format:{}", field.getFieldName(), field.getFormat());
		}
		finally
		{
			formater = null;
		}
		
		return sysDate;
	}
	
}
