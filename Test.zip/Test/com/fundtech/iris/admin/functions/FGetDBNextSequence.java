/*----------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.iris.admin.functions
 * FILE     : FGetDBNextSequence.java
 * CREATED  : Aug 13, 2013 1:25:03 PM
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *--------------------------------------------------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;

/**
 * This function returns the next value of <code>ORACLE SEQUENCE</code>.
 * 
 * @author Ratnesh.Chourasiya
 * @version $Id: FGetDBNextSequence.java,v 1.5 2016/01/12 06:48:52 ramap Exp $
 */
public class FGetDBNextSequence implements IFunction
{
	private Logger _logger = LoggerFactory.getLogger(FGetDBNextSequence.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String dbSequence = null;
		String sql = null;
		String nextVal = null;
		try
		{
			dbSequence = (String) params.get(IFunction.FUNCTION_DATA);
			sql = "SELECT " + dbSequence + ".nextval FROM DUAL";
			statement = dbConnection.prepareStatement(sql);
			resultSet = statement.executeQuery();
			if (resultSet.next())
				nextVal = resultSet.getString(1);
		}
		catch (Exception ex)
		{
			_logger.error("Error while getting sequence " + dbSequence + ".nextval", ex);
		}
		finally
		{
			HelperUtils.doClose(resultSet);
			HelperUtils.doClose(statement);
		}
		return nextVal;
	}
}
