package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.StringUtils;

/*------------------------------------------------------------------------------
 * PACKAGE: 
 * FILE   : FAbs.java
 * CREATED: 24-May-2013 2:29:17 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/

/**
 * TODO This function is for left padding.
 * 
 * @author Maharshi Chavda
 * @version $Id: FLeftPad.java,v 1.5 2014/07/20 04:58:19 ramap Exp $
 * @since 1.0.0
 */
public class FLeftPad implements IFunction
{
	private Logger logger = LoggerFactory.getLogger(FLeftPad.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String data = null;
		String val = null;
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			val = (String) params.get(IFunction.FUNCTION_VALUE);
			
			String[] str = data.split(",");
			int length = Integer.parseInt(str[0]);
			String filler = str[1];
			
			if (null != val && null != filler)
				val = StringUtils.padLeft(val, filler, length);
		}
		catch (Exception e)
		{
			logger.error("Error while padding filler.", e);
		}
		return val;
	}
}
