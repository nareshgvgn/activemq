/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.mapping
 * FILE   : FApplDate.java
 * CREATED: Mar 10, 2013 1:04:32 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: FApplDate.java,v 1.5 2017/02/27 07:25:46 ramap Exp $
 * @since 1.0.0
 */
public class FApplDate implements IFunction
{
	private final String appSql = "SELECT GENERIC.GET_DATE(?) FROM DUAL";
	private Logger logger = LoggerFactory.getLogger(FApplDate.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.mapping.IFunction#execute(java.sql.Connection, java.lang.Object[])
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		Date applDate = null;
		PreparedStatement applStmt = null;
		ResultSet applRs = null;
		ExecutionJobData jobData = null;
		try
		{
			applStmt = dbConnection.prepareStatement(appSql);
			jobData = (ExecutionJobData) params.get(IFunction.EXECUTION_DATA);
			applStmt.setString(1, jobData.getSellerCode());
			applRs = applStmt.executeQuery();
			applRs.next();
			applDate = applRs.getDate(1);
			
		}
		catch (Exception e)
		{
			logger.error("Error while getting Application Date", e);
			// DO not throw Exception in Functions.. lets caller decided what he wants to do
		}
		finally
		{
			HelperUtils.doClose(applRs);
			HelperUtils.doClose(applStmt);
		}
		return applDate.toString();
	}
	
}
