package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;


/**
 * TODO This function is to truncate the value.
 * 
 * @author Archana Shirude
 * @version $Id: FFieldDecode.java,v 1.2 2015/12/09 05:17:52 ramap Exp $
 * @since 1.0.0
 */
public class FFieldDecode extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FFieldDecode.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String param1 = null ;
		
		String fieldVal1 = null ;
		String fieldVal2 = null ;
		String fieldVal3 = null ;
		
		String data = null;
		String val = null ;
		
		BatchBand instBatch = null;
		Band dataBand = null;
		String[] paramArray = null;
		String[] fieldArray = null ; 
		
		
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			instBatch = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			
			logger.trace("Data {}", data);
			
			paramArray = data.split(",");
			param1 = paramArray[0].trim();
						
			fieldArray = param1.split("[\\|]+");
			fieldVal1 = getConcateFieldValue(fieldArray, dataBand, instBatch);
			
			for(int i=1 ; i < paramArray.length ; i++)
			{
				fieldArray = paramArray[i].trim().split("[\\|]+");
				fieldVal2 = getConcateFieldValue(fieldArray, dataBand, instBatch);
			
				if(paramArray.length > i+1)
				{
					fieldArray = paramArray[i+1].trim().split("[\\|]+");
					fieldVal3 = getConcateFieldValue(fieldArray, dataBand, instBatch);
				}
				
				if(i+1 != paramArray.length)
				{
					if(fieldVal1.equals(fieldVal2))
					{
						val =  fieldVal3;
						break;
					}
					else
					{
						i++;
					}
				}
				else
				{
					val = fieldVal2 ;
				}
			}
			logger.trace("val {}", val);
		}
		catch (Exception e)
		{
			logger.error("Error while NVL", e);
		}
		
		return val;
	}
	
	private String getConcateFieldValue(String[] fieldArray,Band dataBand,BatchBand instBatch)
	{
		StringBuilder builder = null;
		String fieldValue = null ;
		try
		{
			builder = new StringBuilder();
			for(String fieldName : fieldArray)
			{
				if(-1 != fieldName.indexOf("."))
				{
					fieldValue =  getRefValue(fieldName, dataBand, instBatch);
				}
				else if(" ".equals(fieldName))
				{
					fieldValue = fieldName ;
				}
				else
				{
					fieldValue = fieldName.replace("'", "");
				}
				if (fieldValue == null)
					fieldValue = "";
				builder.append(fieldValue);
			}
		}
		catch (Exception e)
		{
			logger.error("Error while substring", e);
		}
		return builder.toString();
	}
}
