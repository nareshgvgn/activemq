/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.mapping
 * FILE   : FGetFilePath.java
 * CREATED: Jun 30, 2013 4:17:55 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.io.File;
import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: FGetFilePath.java,v 1.4 2014/07/20 04:58:19 ramap Exp $
 * @since 1.0.0
 */
public class FGetFilePath implements IFunction
{
	private Logger logger = LoggerFactory.getLogger(FGetFilePath.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.mapping.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String invFileName = null;
		String txnFileName = null;
		ExecutionJobData jobData = null;
		String filePath = null;
		File txnFile = null;
		File file = null;
		
		try
		{
			invFileName = (String) params.get(IFunction.FUNCTION_VALUE);
			if ((invFileName == null) || ("".equals(invFileName.trim())))
				return filePath = "";
			
			invFileName = invFileName.trim();
			jobData = (ExecutionJobData) params.get(IFunction.EXECUTION_DATA);
			txnFileName = jobData.getMediaDetails();
			txnFile = new File(txnFileName);
			filePath = getFilePath(txnFile.getAbsolutePath());
			
			if (!"H2H".equals(jobData.getChannelType()))
			{
				if ((invFileName != null) && (!"".equals(invFileName.trim())))
				{
					file = new File(filePath, invFileName);
					filePath = file.getAbsolutePath();
				}
			}
			else
			{
				if ((invFileName != null) && (!"".equals(invFileName.trim())))
				{
					filePath = jobData.getFilterParameter("InvoiceFilePath");
					file = new File(filePath, invFileName);
					filePath = file.getAbsolutePath();
				}
			}
		}
		catch (Exception e)
		{
			logger.error("Error while checking for file exists", e);
			// DO not throw Exception in Functions.. lets caller decided what he wants to do
		}
		// Attachment sub file field is null�-�the invoice data would be picked from the invoice detail section.
		return filePath;
	}
	
	/**
	 * This method is to read filePath and return it.
	 * 
	 * @param fileName
	 * @return filePath
	 */
	private String getFilePath (String fileName)
	{
		String filePath = null;
		filePath = fileName.substring(0, fileName.lastIndexOf(File.separator));
		return filePath;
	}
	
}
