/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.functions
 * FILE   : FFieldConcatAddenda.java
 * CREATED: Dec 22, 2016 4:55:37 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;

/**
 * <p>This function developed for Jira FTIRIS-86. This function concats the configured fields with fixed fixed with format
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code insert into iris_function_mst (DATA_TYPE, FUNCTION_NAME, FUNCTION_DESC, MAPPING_TYPE, MAPPED_CLASS, VALID_FLAG)
 * values ('STRING', 'CONCATADDENDA', 'Syntax: CONCATADDENDA(Band.Field Name/Constant Value1,Band.Field Name/Constant Value2,....Band.Field Name/Constant Value10) 
 * Description: To Concatenate the given Field values or given constant values in the given sequence.', 4, 'com.fundtech.iris.admin.functions.FFieldConcatAddenda', 'Y');
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: FFieldConcatAddenda.java,v 1.6 2016/12/23 05:10:28 ramap Exp $
 */
public class FFieldConcatAddenda  extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FFieldConcatAddenda.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@SuppressWarnings("resource")
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String fieldVal1 = null ;
		String data = null;
		String val = null ;
		BatchBand instBatch = null;
		Band dataBand = null;
		String[] paramArray = null;
		String refKey = null ; 
		StringBuilder builder = null;
		int firstIndex = -1;
		String fieldRef = null;
		MappingField field = null;
		InterfaceBandDef intBandDef = null;
		try
		{
			builder = new StringBuilder();
			data = (String) params.get(IFunction.FUNCTION_DATA);
			instBatch = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			
			logger.trace("Function Config: {}", data);
			
			paramArray = data.split(",");
			
			for(int i=0 ; i < paramArray.length ; i++)
			{
				refKey = paramArray[i];
				firstIndex = refKey.indexOf(".");
				fieldRef = refKey.substring(firstIndex + 1, refKey.length());
				intBandDef = (InterfaceBandDef)params.get(IFunction.EXECUTION_BAND_DEF);
				field = getMappingField(intBandDef.getMappingFields(), fieldRef);
				fieldVal1 =  getRefValue(refKey, dataBand, instBatch);
				
				if (fieldVal1 == null)
					fieldVal1 = ""; 
				
				fieldVal1 = StringUtils.rightPad(fieldVal1, field.getFieldLength(), " ");
				logger.trace("for filed: {} the value is: {}",fieldRef,fieldVal1);
				builder.append(fieldVal1);
				
			}
			val = builder.toString() ;
		}
		catch (Exception e)
		{
			logger.error("Error while Addenda", e);
		}
		return val;
	}
	
	private MappingField getMappingField(List<MappingField> listMappingFields, String fieldRef)
	{
		MappingField output = null;
		for ( MappingField field : listMappingFields)
		{
			if (fieldRef.trim().equals(field.getFieldName()))
			{
				output = field;
				break;
			}
		}
		
		return output;
		
	}
}
