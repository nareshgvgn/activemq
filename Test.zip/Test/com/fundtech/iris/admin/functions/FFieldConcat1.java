package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;


/**
 * This function is to truncate the value.
 * 
 * @author Archana Shirude
 * @version $Id: FFieldConcat1.java,v 1.2 2016/08/04 05:35:42 ramap Exp $
 * @since 1.0.0
 */
public class FFieldConcat1 extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FFieldConcat.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String fieldVal1 = null ;
		String data = null;
		String val = null ;
		
		BatchBand instBatch = null;
		Band dataBand = null;
		String[] paramArray = null;
		String[] fieldArray = null ; 
		StringBuilder builder = null;
		boolean isFirst = true;
		
		try
		{
			builder = new StringBuilder();
			data = (String) params.get(IFunction.FUNCTION_DATA);
			instBatch = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			logger.trace("Data {}", data);
			paramArray = data.split(",");
			
			for(int i=0 ; i < paramArray.length ; i++)
			{
				fieldArray = paramArray[i].trim().split("[\\|]+");
				fieldVal1 = getConcateFieldValue(fieldArray, dataBand, instBatch);
			
				if (fieldVal1 == null)
					fieldVal1 = ""; 
				if (isFirst)
					builder.append(":");
					else 
					builder.append(",");
					
				isFirst = false;
				builder.append(fieldVal1);
				val = builder.toString() ;
			}
			logger.trace("val {}",val);
		}
		catch (Exception e)
		{
			logger.error("Error while NVL", e);
		}
		
		return val;
	}
	
	private String getConcateFieldValue(String[] fieldArray,Band dataBand,BatchBand instBatch)
	{
		StringBuilder builder = null;
		String fieldValue = null ;
		
		try
		{
			builder = new StringBuilder();
			for(String fieldName : fieldArray)
			{
				if(-1 != fieldName.indexOf("."))
				{
					fieldValue =  getRefValue(fieldName, dataBand, instBatch);
				}
				else if(" ".equals(fieldName))
				{
					fieldValue = fieldName ;
				}
				else
				{
					fieldValue = fieldName.replace("'", "");
				}
				if (fieldValue == null)
					fieldValue = "";
				
					
				builder.append(fieldValue);
			}
		}
		catch (Exception e)
		{
			logger.error("Error while substring", e);
		}
		return builder.toString();
	}
	
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------*
 *  Helper for testinng
 *----------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	public static void main( String[ ] args )
	{
		Map< String, Object > params = new HashMap< String, Object >();
		Connection dbConnection = null;
		params.put( IFunction.FUNCTION_DATA,"'ONE2ONE',' ','ACCTRANCR'" );
		FFieldConcat nvl = new FFieldConcat();
 
		try
		{
			System.out.println( nvl.execute( dbConnection, params ) );
		}
		catch( Exception ex )
		{
			ex.printStackTrace();
		}
	}
}
