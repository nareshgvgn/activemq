package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;



/**
 * TODO This function is to truncate the value.
 * 
 * @author Archana Shirude
 * @version $Id: FFieldSubStr.java,v 1.2 2015/12/09 05:17:52 ramap Exp $
 * @since 1.0.0
 */
public class FFieldSubStr extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FFieldSubStr.class.getName());
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String data = null;
		String field = null ;
		String fieldValue = null ;
		BatchBand instBatch = null;
		Band dataBand = null;
		Integer startIndex = 0;
		Integer endIndex = null;
		String[] index = null;
		String[] fieldIndex = null ; 
		StringBuilder builder = null;
		
		try
		{
			data = (String) params.get(IFunction.FUNCTION_DATA);
			instBatch = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			
			logger.trace( "Function Data :: {}" , data );
			
			index = data.split(",");
			field = index[0].trim();
			startIndex = Integer.parseInt(index[1].trim());
			if(index.length > 2)
			{
				endIndex = Integer.parseInt(index[2].trim());
			}
			
			if(!"".equals(field) && null != field)
			{
				fieldIndex = field.split("[\\|]+");
				builder = new StringBuilder();
				for(String fieldName : fieldIndex)
				{
					if(-1 != fieldName.indexOf("."))
					{
						fieldValue =  getRefValue(fieldName, dataBand, instBatch);
					}
					else if(" ".equals(fieldName))
					{
						fieldValue = fieldName ;
					}
					else
					{
						fieldValue = fieldName.replace("'", "");
					}
					if (fieldValue == null)
						fieldValue = "";
					
					builder.append(fieldValue);
				}
				fieldValue = builder.toString();
				
				if(!"".equals(fieldValue) && startIndex != null)
				{
					if(startIndex > fieldValue.length())
					{
//						if(logger.isErrorEnabled())
//						logger.error( "Start index is greater than string length" );
						// I think we no need to any thing.. need to ask Archana Shirude who did this coding
					}
					else
					{
						if(endIndex == null || endIndex >= fieldValue.length())
						{
							endIndex = fieldValue.length() ;
						}
						else
						{
							endIndex = startIndex + endIndex ;
							endIndex = endIndex - 1 ;
						}
						fieldValue = fieldValue.substring(startIndex - 1, endIndex);
					}
				}
				else
				{
					if(logger.isErrorEnabled())
					logger.error("Parameter 1 and Parameter2 is mandatory");	
				}
			}
			
			logger.trace( "Output :: {}" , fieldValue );
		}
		catch (Exception e)
		{
			logger.error("Error while substring", e);
		}
		
		return fieldValue;
	}
}
