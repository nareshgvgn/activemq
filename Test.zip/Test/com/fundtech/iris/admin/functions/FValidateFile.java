package com.fundtech.iris.admin.functions;

import java.io.File;
import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;

/*------------------------------------------------------------------------------
 * PACKAGE: 
 * FILE   : toLowerCase.java
 * CREATED: 24-May-2013 1:34:25 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/

/**
 * This function is to validate invoice file and returns flag whether to upload invoice information from detail section or invoice from external file
 * or send to reject repair.
 * 
 * @author Maharshi Chavda
 * @version $Id: FValidateFile.java,v 1.6 2015/09/10 10:44:19 ramap Exp $
 * @since 1.0.0
 * 
 */
public class FValidateFile extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(FValidateFile.class.getName());
	private final String SUCCESS = "S";
	private final String REJECT = "R";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params)
	{
		String invFileName = null;
		File file = null;
		String functionData = null;
		Band dataBand = null;
		BatchBand batchBand = null;
		
		try
		{
			functionData = (String) params.get(IFunction.FUNCTION_DATA);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			batchBand = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			invFileName = getRefValue(functionData, dataBand, batchBand);
			
			if (invFileName != null && !"".equals(invFileName.trim()))
			{
				file = new File(invFileName);
				if (file.exists())
					return SUCCESS;
				else
					return REJECT;
			}
			
			return "";
			
		}
		catch (Exception e)
		{
			logger.error("Error while checking for file exists", e);
			// DO not throw Exception in Functions.. lets caller decided what he wants to do
		}
		// Attachment sub file field is null�-�the invoice data would be picked from the invoice detail section.
		return REJECT;
	}
	
}
