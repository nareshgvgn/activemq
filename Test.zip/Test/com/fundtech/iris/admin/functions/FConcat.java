/*----------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.iris.admin.functions
 * FILE     : FConcat.java
 * CREATED  : Aug 23, 2013 1:25:03 PM
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *--------------------------------------------------------------------------------------------------------------------*/
package com.fundtech.iris.admin.functions;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>
 * This function returns the concatenated string by using given reference field's value.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into iris_function_mst (DATA_TYPE, FUNCTION_NAME, FUNCTION_DESC, MAPPING_TYPE, MAPPED_CLASS, VALID_FLAG)
 * values ('STRING', 'CONCAT', 'Syntax: CONCAT() Description: To Concatenate the given String Fields.', 4, 'com.fundtech.iris.admin.functions.FConcat', 'Y');
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FConcat.java,v 1.4 2014/07/20 04:58:19 ramap Exp $
 */
public class FConcat extends IrisAdminPlugin
{
	
	private static Logger logger = LoggerFactory.getLogger(FConcat.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public String execute (Connection dbConnection, Map<String, Object> params) throws FormatException
	{
		BatchBand instBatch = null;
		String finalVal = null;
		String functionData = null;
		String fldVal = null;
		Band dataBand = null;
		String[] fieldNames = null;
		StringBuilder builder = null;
		FormatException fExp = null;
		try
		{
			instBatch = (BatchBand) params.get(IFunction.EXECUTION_BATCH);
			functionData = (String) params.get(IFunction.FUNCTION_DATA);
			dataBand = (Band) params.get(IFunction.EXECUTION_BAND);
			fieldNames = functionData.split(",");
			builder = new StringBuilder();
			for (String name : fieldNames)
			{
				fldVal = getRefValue(name, dataBand, instBatch);
				if (fldVal == null)
					fldVal = "";
				fldVal = fldVal.trim();
				builder.append(fldVal);
			}
			finalVal = builder.toString();
			logger.trace("Concatenated string :: {}", finalVal);
		}
		catch (Exception exp)
		{
			logger.error("Error while concatenating the strings");
			fExp = new FormatException("com.fundtech.iris.admin.functions.FConcat", new Object[]
			{ "Data Is Not Valid." }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			fieldNames = null;
			CleanUpUtils.doClean(builder);
			builder = null;
		}
		return finalVal;
	}
}
