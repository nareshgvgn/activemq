/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : Definitions.java
 * CREATED: Jan 6, 2013 12:41:47 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin;

import java.util.HashMap;
import java.util.Map;

import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.model.ModelDef;

/**
 * This class must be singleton. This class hold the {@link InterfaceDef} data. If any of the process defination changed during the day, @EOD we rest
 * that Interface + process and reloads it when ever particular interface executes.
 * 
 * @author Babu Paluri
 * @version $Id: Definitions.java,v 1.9 2014/09/09 10:11:48 ramap Exp $
 * @since 1.0.0
 */
public class Definitions
{
	private static Definitions definitions = null;
	private Map<String, String> functionLst = new HashMap<String, String>();
	private Map<String, String> routineLst = new HashMap<String, String>();
	private Map<String, ModelDef> modelDefs = new HashMap<String, ModelDef>();
	
	private Definitions()
	{
		
	}
	
	public static synchronized Definitions getInstance ()
	{
		if (definitions == null)
			definitions = new Definitions();
		
		return definitions;
	}
	
	public void addFunction (String name, String clazz)
	{
		functionLst.put(name, clazz);
	}
	
	public String getFunctionClass (String name)
	{
		return functionLst.get(name);
	}
	
	public void setFunctions (Map<String, String> functionLst)
	{
		this.functionLst = functionLst;
	}
	
	public int sizeFunctions ()
	{
		return functionLst.size();
	}
	
	public synchronized void addModelDef (ModelDef definition)
	{
		modelDefs.put(definition.getModelName(), definition);
	}
	
	public synchronized ModelDef getModelDef (String key)
	{
		return modelDefs.get(key);
	}
	
	public synchronized boolean containsModelDef (String key)
	{
		
		return modelDefs.containsKey(key);
	}
	
	/*
	 * TODO based on audit number may be we need to call this method @EOD???
	 */
	public synchronized void removeModelDefinition (String key)
	{
		modelDefs.remove(key);
	}
	
	public void addRoutine (String name, String clazz)
	{
		routineLst.put(name, clazz);
	}
	
	public Map<String, String> getRoutineClasses ()
	{
		return routineLst;
	}
	
	public String getRoutineClass (String name)
	{
		return routineLst.get(name);
	}
	
	public void setRoutines (Map<String, String> routineLst)
	{
		this.routineLst = routineLst;
	}
	
	public int sizeRoutines ()
	{
		return routineLst.size();
	}
}
