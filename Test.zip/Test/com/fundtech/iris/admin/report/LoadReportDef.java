/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.report
 * FILE   : LoadReportDef.java
 * CREATED: Jun 12, 2014 11:13:35 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.LoadingException;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: LoadReportDef.java,v 1.12 2016/07/24 07:19:10 ramap Exp $
 */
public class LoadReportDef
{
	private static Logger logger = LoggerFactory.getLogger(LoadReportDef.class);
	private Connection dbConnection = null;
	private RMJobData jobData = null;
	
	public LoadReportDef(Connection dbConnection, RMJobData jobData)
	{
		this.dbConnection = dbConnection;
		this.jobData = jobData;
	}
	
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @throws LoadingException
	 * </pre></p>
	 */
	public void loadData() throws LoadingException
	{
		String reportType = null;
		LoadingException lExp = null;
		String reportCode = null;
		
		IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.TRACE, logger, "Before Loading defs");
		try
		{
			reportType = jobData.getReportType();
			reportCode = jobData.getSrcId();
			if ( "SOR".equals(reportType) || IrisAdminConstants.SCH_PROFILE.equals(reportType)) // standard oracle report
			{
				loadStandardEngineClass();
				loadStandardReportParmDefs(reportCode);
			}
			else if ( "SOCR".equals(reportType)) // standard oracle custom report
			{
				loadCustomEngineClass();
				loadCustomReportParmDefs();
				reportCode = jobData.getParentSrcName();
				loadStandardReportParmDefs(reportCode);
			}
			else 
			{
				logger.error("Report Type:{} not supporetd right now for report:{}" , reportType, reportCode);
				lExp = new LoadingException("iris.admin.report.notsupported", new Object[] {reportType, reportCode}, null);
				throw lExp;
			}
			
		}
		catch ( LoadingException exp)
		{
			jobData.setStatus("L");
			throw exp;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("L");
			lExp = new LoadingException("iris.admin.report.def", new Object[] {reportType, reportCode}, null);
			throw lExp;
		}
		finally
		{
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.TRACE, logger, "After loading Defs");
		}
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @throws LoadingException
	 * </pre></p>
	 */
	private void loadStandardReportParmDefs(String reportCode) throws LoadingException
	{
		String sql = "select t.parameter_code, t.seq_nmbr, t.data_type,LIST_OF_VALUE_TYPE, COLUMN_NAME_LHS from report_parameter_mst t where t.report_code = ? and "
				+ " (FILTER_FLAG='Y' OR EDITABLE_FLAG='Y')";
		PreparedStatement st = null;
		ResultSet rs = null;
		ReportParameterDef def = null;
		String parmCode = null;
		try
		{
			st = dbConnection.prepareStatement(sql);
			st.setString(1, reportCode);
			rs = st.executeQuery();
			while (rs.next())
			{
				def = new ReportParameterDef();
				def.setDataType(rs.getString("data_type"));
				parmCode = rs.getString("parameter_code");
				def.setParamCode(parmCode);
				def.setReportCode(reportCode);
				def.setSeqNumbr(rs.getInt("seq_nmbr"));
				def.setDisplayType(rs.getString("LIST_OF_VALUE_TYPE"));
				def.setReportColumnName(rs.getString("COLUMN_NAME_LHS"));
				jobData.addReportParamDef( parmCode, def);
			}
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
		}
		finally
		{
			HelperUtils.doClose(rs);
			HelperUtils.doClose(st);
		}
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @throws LoadingException
	 * </pre></p>
	 */
	private void loadStandardEngineClass () throws LoadingException
	{
		String sql = "SELECT T.EXECUTION_CLASS FROM MEDIUM_MST T, Report_Defn_Mst  r WHERE T.FORMAT_TYPE = r.report_engine and r.report_code=?";
		PreparedStatement st = null;
		ResultSet rs = null;
		String clazz = null;
		try
		{
			st = dbConnection.prepareStatement(sql);
			st.clearParameters();
			st.setString(1, jobData.getSrcId());
			rs = st.executeQuery();
			if (rs.next())
			{
				clazz = rs.getString("EXECUTION_CLASS");
				if ( clazz == null)
					clazz = "com.fundtech.iris.admin.execution.OracleReportExecutor";
				jobData.setExecutionClass(clazz);
			}
			
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
		}
		finally
		{
			HelperUtils.doClose(rs);
			HelperUtils.doClose(st);
		}
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @throws LoadingException
	 * </pre></p>
	 */
	private void loadCustomEngineClass () throws LoadingException
	{
		String sql = "SELECT T.EXECUTION_CLASS FROM MEDIUM_MST T WHERE T.FORMAT_TYPE = 'ORACUST'";
		PreparedStatement st = null;
		ResultSet rs = null;
		String clazz = null;
		
		try
		{
			st = dbConnection.prepareStatement(sql);
			rs = st.executeQuery();
			if (rs.next())
			{
				clazz = rs.getString("EXECUTION_CLASS");
				if ( clazz == null)
					clazz = "com.fundtech.iris.admin.execution.OracleCustomReportExecutor";
				jobData.setExecutionClass(clazz);
			}
			
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
		}
		finally
		{
			HelperUtils.doClose(rs);
			HelperUtils.doClose(st);
		}
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @throws LoadingException
	 * </pre></p>
	 */
	private void loadCustomReportParmDefs() throws LoadingException
	{
		String sql = "select t.repreport, t.myrepparameter, t.myrepdefaultvalue from USER_REPORT_PARAMETER_MST t where t.myreprepcode = ? and "
				+ " t.myrepparameter IN ( 'REPCOLS', 'REPORDER')";
		PreparedStatement st = null;
		ResultSet rs = null;
		ReportParameterDef def = null;
		String parmCode = null;
		String reportCode = null;
		String parentReportCode = null;
		try
		{
			st = dbConnection.prepareStatement(sql);
			reportCode = jobData.getSrcId();
			st.setString(1, reportCode);
			rs = st.executeQuery();
			while (rs.next())
			{
				def = new ReportParameterDef();
				def.setColumnJson(rs.getString("myrepdefaultvalue"));
				parmCode = rs.getString("myrepparameter");
				parentReportCode = rs.getString("repreport");
				def.setParamCode(parmCode);
				def.setReportCode(reportCode);
				def.setDataType("JSON");
				jobData.addReportParamDef( parmCode, def);
			}
			jobData.setParentSrcName(parentReportCode);
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
		}
		finally
		{
			HelperUtils.doClose(rs);
			HelperUtils.doClose(st);
		}
	}
	
	
}
