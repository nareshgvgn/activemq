/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.report
 * FILE   : ReportParameterDef.java
 * CREATED: May 11, 2015 9:54:04 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.report;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: ReportParameterDef.java,v 1.4 2015/07/09 09:46:58 ramap Exp $
 */
public class ReportParameterDef
{
	
	private String paramCode = null;
	private String reportCode = null;
	private int seqNumbr = 0;
	private String dataType = null;
	private String displayType = null;
	private String reportColumnName = null;
	private String columnJson = null;
	
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public ReportParameterDef()
	{
		// BABU Auto-generated constructor stub
	}

	/**
	 * @return the paramCode
	 */
	public String getParamCode ()
	{
		return paramCode;
	}

	/**
	 * @param paramCode the paramCode to set
	 */
	public void setParamCode (String paramCode)
	{
		this.paramCode = paramCode;
	}

	/**
	 * @return the reportCode
	 */
	public String getReportCode ()
	{
		return reportCode;
	}

	/**
	 * @param reportCode the reportCode to set
	 */
	public void setReportCode (String reportCode)
	{
		this.reportCode = reportCode;
	}

	/**
	 * @return the seqNumbr
	 */
	public int getSeqNumbr ()
	{
		return seqNumbr;
	}

	/**
	 * @param seqNumbr the seqNumbr to set
	 */
	public void setSeqNumbr (int seqNumbr)
	{
		this.seqNumbr = seqNumbr;
	}

	/**
	 * @return the dataType
	 */
	public String getDataType ()
	{
		return dataType;
	}

	/**
	 * @param dataType the dataType to set
	 */
	public void setDataType (String dataType)
	{
		this.dataType = dataType;
	}

	/**
	 * @return the displayType
	 */
	public String getDisplayType ()
	{
		return displayType;
	}

	/**
	 * @param displayType the displayType to set
	 */
	public void setDisplayType (String displayType)
	{
		this.displayType = displayType;
	}

	/**
	 * @return the reportColumnName
	 */
	public String getReportColumnName ()
	{
		return reportColumnName;
	}

	/**
	 * @param reportColumnName the reportColumnName to set
	 */
	public void setReportColumnName (String reportColumnName)
	{
		this.reportColumnName = reportColumnName;
	}

	/**
	 * @return the columnJson
	 */
	public String getColumnJson ()
	{
		return columnJson;
	}

	/**
	 * @param columnJson the columnJson to set
	 */
	public void setColumnJson (String columnJson)
	{
		this.columnJson = columnJson;
	}

	
	
}
