/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.report.plugins
 * FILE   : SysReportPasswordPlugin.java
 * CREATED: Oct 5, 2016 1:27:53 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.report.plugins;

import java.sql.Connection;
import java.util.Map;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: SysReportPasswordPlugin.java,v 1.1 2016/10/06 07:34:42 ramap Exp $
 */
public class SysReportPasswordPlugin extends IrisAdminPlugin
{
	
	public SysReportPasswordPlugin()
	{
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public String execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		RMJobData jobData = null;
		SecurityProfile secProfile = null;
		String password = null;
		
		jobData = (RMJobData) params.get(IPlugin.EXECUTION_DATA);
		secProfile = jobData.getSecurityProfile();
		if ( secProfile == null)
			return null;
		
		password = secProfile.getPdfPassword();
		
		return password;
	}
	
}
