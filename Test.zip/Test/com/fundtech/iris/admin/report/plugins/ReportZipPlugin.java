/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : ReportZipPlugin.java
 * CREATED: Jun 13, 2014 7:01:39 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.report.plugins;

import java.io.File;
import java.sql.Connection;
import java.util.Map;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.util.FileUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: ReportZipPlugin.java,v 1.4 2016/12/12 10:12:48 ramap Exp $
 */
public class ReportZipPlugin extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(ReportZipPlugin.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		RMJobData jobData = null;
		SecurityProfile secProfile = null;
		String zipType = null;
		File file = null;
		ZipFile zipFile = null;
		ZipParameters parameters = null;
		String orgFile = null;
		String outFileName = null;
		ExecutionException eExp = null;
		String outType = null;
		
		try
		{
			jobData = (RMJobData) params.get(IPlugin.EXECUTION_DATA);
			secProfile = jobData.getSecurityProfile();
			outType = jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE);
			if (secProfile != null)
			{
			
				zipType = secProfile.getZipType();
				if (zipType == null || IrisAdminConstants.CONSTANT_N.equals(zipType))
					return zipType;
				
				orgFile = jobData.getOutFileName();
				file = new File(orgFile);
				outFileName = file.getParent() + File.separator + FileUtils.getBaseName(file.getName()) + ".zip";
				zipFile = new ZipFile(outFileName);
				parameters = new ZipParameters();
				parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
				parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
				if ("P".equals(zipType))
				{
					if ( checkPassword(secProfile.getPdfPassword(), outType))
					{
						parameters.setEncryptFiles(true);
						parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
						parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
						parameters.setPassword(secProfile.getZipPassword());
					}
				}
				zipFile.addFile(file, parameters);
				file.delete();
				jobData.setOutFileName(outFileName);
			}
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE);
		}
		catch (Exception ex)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			eExp = new ExecutionException("error.iris.admin.reort.ReportEmail", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		return null;
	}
	
	private boolean checkPassword(String password, String outType)
	{
		
		if ( password ==  null)
			return true;
		
		if ( "PDF".equals(outType))
			return false;
		
		return true;
	}
	
}
