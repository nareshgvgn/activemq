/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : InterfaceStatusUpdate.java
 * CREATED: Mar 10, 2014 10:35:48 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.report.plugins;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: ReportStatusUpdate.java,v 1.8 2016/06/29 11:05:53 ramap Exp $
 */
public class ReportStatusUpdate extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(ReportStatusUpdate.class);
	private static final String updateSql = "UPDATE IRIS_JOB_QUEUE T SET T.STATUS = ?, T.SYS_END_DATE = SYSDATE , END_DATE = pk_timezone.get_seller_time(?), "
			+ "ERROR_CODE=?, ERROR_MSG=?, MEDIA_DTLS= ? WHERE T.EXECUTION_ID = ?";
	
	public ReportStatusUpdate()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		RMJobData jobData = null;
		String jobStatus = null;
		
		jobData = (RMJobData) params.get(IrisAdminConstants.EXECUTION_DATA);
		jobStatus = jobData.getStatus();
		updateJobStatus(dbConnection, jobData);
		
		/*
		 * E and S are ERROR and Sucess. S status comes after completion of Interface procedure call E Status comes if any error before interface
		 * procedure call
		 */
		
		if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus) || IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE.equals(jobStatus)
				|| IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
			finishJob(dbConnection, jobData);
		
		return null;
	}
	
	private void updateJobStatus (Connection dbConnection, RMJobData jobData) throws ExecutionException
	{
		PreparedStatement updateSt = null;
		int status = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String jobStatus = null;
		String errorCode = "Sucess";
		String errorMsg = "Sucess";
		
		try
		{
			jobStatus = jobData.getStatus();
			if ("E".equals(jobStatus) || "R".equals(jobStatus))
			{
				errorCode = "Error";
				errorMsg = " Error: Please check the report";
			}
			executionId = jobData.getExecutionId();
			
			updateSt = dbConnection.prepareStatement(updateSql);
			updateSt.clearParameters();
			updateSt.setString(1, jobStatus);
			updateSt.setString(2, jobData.getSellerCode());
			updateSt.setString(3, errorCode);
			updateSt.setString(4, errorMsg);
			updateSt.setString(5, jobData.getOutFileName());
			updateSt.setString(6, executionId);
			status = updateSt.executeUpdate();
			
			if (status < 0)
				logger.warn("Job:" + executionId + " record not available for status update");
			else if (logger.isTraceEnabled())
				logger.debug("Job:" + executionId + " Record status updated");
			dbConnection.commit();
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]
			{ errorMsg, updateSql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]
			{ errorMsg, updateSql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(updateSt);
		}
		
	}
	
	private void finishJob (Connection dbConnection, RMJobData jobData) throws ExecutionException
	{
		CallableStatement cStmt = null;
		String sql = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String errorCode = "Sucess";
		String errorMsg = "Sucess";
		String srcType = null;
		String refId = null;
		String status = null;
		
		try
		{
			status =  jobData.getStatus();
			
			if ("E".equals(status) || "R".equals(status))
			{
				errorCode = "Error";
				errorMsg = " Error: Please check the report";
			}
			
			startTime = System.currentTimeMillis();
			sql = "{CALL pkg_iris_admin.finish_iris_job (?, ?, ?, ?,?)}";
			cStmt = dbConnection.prepareCall(sql);
			executionId = jobData.getExecutionId();
			srcType = jobData.getReportType();
			
			logger.trace("Caling pkg_iris_admin.finish_iris_job with Status:{}", status);
			if ( ! IrisAdminConstants.SCH_PROFILE.equals(srcType))
				refId =jobData.getRefId();
			
			cStmt.setString(1, executionId);
			cStmt.setString(2, refId);
			cStmt.setString(3, status);
			cStmt.setString(4, errorCode);
			cStmt.setString(5, errorMsg);
			
			cStmt.executeUpdate();
			dbConnection.commit();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing pkg_iris_admin.finish_iris_job " + " StoredProcedure: " + delta);
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to update job Status:" + status;
			eExp = new ExecutionException("error.iris.admin.job status", new Object[]{ errorMsg, sql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
	}
}
