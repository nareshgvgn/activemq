/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : InvokeChargingPlugin.java
 * CREATED: Jan 19, 2015 3:14:00 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.report.plugins;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * <p>TODO - This helper plugin invokes charging module for charging interface download
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: InvokeChargingPlugin.java,v 1.3 2016/08/12 09:19:09 ramap Exp $
 */
public class InvokeChargingPlugin extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(InvokeChargingPlugin.class);
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public InvokeChargingPlugin()
	{
		
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		RMJobData jobData = null;
		String procCall = "{CALL pkg_iris_admin.p_raise_charge_event(?, ?, ?, ?,?)}";
		CallableStatement cStmt = null;
		ExecutionException eExp = null;
		String executionId = null;
		String sellerCode = null;
		String errorMsg = null;
		String errorCode = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		
		try
		{
			jobData = (RMJobData) params.get(IPlugin.EXECUTION_DATA);
			startTime = System.currentTimeMillis();
			
			cStmt = dbConnection.prepareCall(procCall);
			executionId = jobData.getExecutionId();
			sellerCode = jobData.getSellerCode();
			cStmt.setString(1, sellerCode);
			cStmt.setString(2, "REPEXPORT");
			cStmt.setString(3, executionId);
			cStmt.setString(4, errorCode);
			cStmt.setString(5, errorMsg);
			
			cStmt.executeUpdate();
			dbConnection.commit();
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing pkg_iris_admin.p_raise_charge_event StoredProcedure: {}" , delta);
			
		}
		catch (SQLException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.repchargeStatus", new Object[]	{ errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
		
		return null;
	}
	
}
