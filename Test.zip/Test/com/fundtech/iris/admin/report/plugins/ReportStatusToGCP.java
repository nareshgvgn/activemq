/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : InterfaceStatusToGCP.java
 * CREATED: Feb 5, 2014 1:01:20 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.report.plugins;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.util.FileUtils;

/**
 * <p>
 * This plug in class updated the GCP Status to screens.
 * <h3>Configuration for IRIS</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * 
 * &lt;NodeDefinition id="StatusToGCP" nodeClass="com.fundtech.iris.admin.execution.nodes.InterfacePluginNode"&gt;
 * 		&lt;References&gt;
 * 			&lt;Reference name="uploadType" type="INPUT_TYPE"/&gt;
 * 			&lt;Reference name="uploadType" type="OUTPUT_TYPE"/&gt;
 * 		&lt;/References&gt;
 * 		&lt;Parameter name="HelperClass" value="com.fundtech.iris.admin.plugins.InterfaceStatusToGCP"/&gt;
 * 	&lt;/NodeDefinition&gt;
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: ReportStatusToGCP.java,v 1.13 2016/10/19 14:04:54 ramap Exp $
 */
public class ReportStatusToGCP extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(ReportStatusToGCP.class);
	
	public ReportStatusToGCP()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		RMJobData jobData = null;
		ExecutionException eExp = null;
		String errorMsg = null;
		PreparedStatement pregenPs = null;
		String jobStatus = null;
		String ftpPath = null;
		File outFile = null;
		double bytes = 0;
		double kilobytes = 0;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		String fileName = null;
		String pregenSql = "INSERT INTO IRIS_PRE_GEN_TXN (ENTITY_TYPE,ENTITY_CODE,SRC_TYPE,SRC_NAME,SRC_DESCRIPTION,SCHEDULE_ID,"
				+ " EXECUTION_ID,APP_DATE,CREATED_DATE ,FILE_NAME,FILE_SIZE,del_output,SELLER_CODE,ADDITIONAL_INFO,STATUS,pre_gen_id,CHANNEL_NAME) "
				+ " VALUES (?,?,?,?,?,?,?,generic.get_date(?),SYSDATE ,?,?,?,?,?,?," + " generic.f_generate_sequence_id('IRIS_PREGEN_ID'),?)";
		try
		{
			jobData = (RMJobData) params.get(IPlugin.EXECUTION_DATA);
			jobStatus = jobData.getStatus();
			// If Pre gen flag Y then only insert
			if (  IrisAdminConstants.CONSTANT_N.equals(jobData.getJobParameter(IrisAdminConstants.PRE_GEN_FLAG)))
				return null;
			if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus) || IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
				return null;
			
			fileName = jobData.getOutFileName();
			startTime = System.currentTimeMillis();
			pregenPs = dbConnection.prepareStatement(pregenSql);
			ftpPath = jobData.getFtpPath();
			pregenPs.clearParameters();
			pregenPs.setString(1, jobData.getEntityType());
			pregenPs.setString(2, jobData.getEntityCode());
			pregenPs.setString(3, jobData.getSrcType());
			pregenPs.setString(4, jobData.getSrcId());
			pregenPs.setString(5, jobData.getSrcName()); // src description
			pregenPs.setString(6, jobData.getRefId());
			pregenPs.setString(7, jobData.getExecutionId());
			pregenPs.setString(8, jobData.getSellerCode());// ADD DATE
			// CREATED_DATE is SYSDATE
			
			if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus) || IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
			{
				pregenPs.setString(9, null); // coz its empty file
				pregenPs.setString(13, "Error While generating Report.");
				
			}
			else
			{
				outFile = new File(fileName);
				bytes = outFile.length();
				kilobytes = Math.round(bytes / 1024 * 100.0)/100.0;
				fileName = fileName.replace(ftpPath, "");
				fileName = "." + fileName;
				pregenPs.setString(9, fileName); // coz its empty file
				pregenPs.setString(13, null);
			}
			
			pregenPs.setString(10, kilobytes + "KB");
			pregenPs.setString(11, FileUtils.getExtension(fileName).toUpperCase()); // GET FILE EXTN
			pregenPs.setString(12, jobData.getSellerCode());
			
			pregenPs.setString(14, jobData.getStatus());
			// pre_gen_id used oracle sequence
			if ( jobData.getRefId() ==  null)
				pregenPs.setString(15, "SUB");
			else 
				pregenPs.setString(15, "SCH");
			
			pregenPs.executeUpdate();
			dbConnection.commit();
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			
			logger.debug("Time taken for executing pkg_integrate_gcp.update_gcp_status StoredProcedure: {}" , delta);
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to update job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.updatestatus", new Object[]
			{ errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception ex)
		{
			errorMsg = "Not able to update job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.updatestatus", new Object[]
			{ errorMsg }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(pregenPs);
		}
		return null;
	}
}
