/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : IrisError.java
 * CREATED: Aug 25, 2015 1:04:45 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisError.java,v 1.2 2015/09/01 12:03:40 ramap Exp $
 */
public class IrisError
{
	
	public final static String FILE = "FILE";
	private String bandType = null;
	private String bandName = null;
	private StringBuilder errorDesc = null;
	private long lineNumber = 0;
	private String errorCode = null;
	
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisError()
	{
	}


	/**
	 * @return the bandType
	 */
	public String getBandType ()
	{
		return bandType;
	}


	/**
	 * @param bandType the bandType to set
	 */
	public void setBandType (String bandType)
	{
		this.bandType = bandType;
	}


	/**
	 * @return the fieldName
	 */
	public String getBandName ()
	{
		return bandName;
	}


	/**
	 * @param fieldName the fieldName to set
	 */
	public void setBandName (String bandName)
	{
		this.bandName = bandName;
	}


	/**
	 * @return the errorDesc
	 */
	public String getErrorDesc ()
	{
		return errorDesc.toString();
	}


	/**
	 * @param errorDesc the errorDesc to set
	 */
	public void addErrorDesc (String errorMessage)
	{
		if ( errorDesc == null)
			errorDesc = new StringBuilder();
		else
			errorDesc.append(",");
		errorDesc.append(errorMessage);
		
		
		
	}


	/**
	 * @return the lineNumber
	 */
	public long getLineNumber ()
	{
		return lineNumber;
	}


	/**
	 * @param lineNumber the lineNumber to set
	 */
	public void setLineNumber (long lineNumber)
	{
		this.lineNumber = lineNumber;
	}


	/**
	 * @return the errorCode
	 */
	public String getErrorCode ()
	{
		return errorCode;
	}


	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode (String errorCode)
	{
		this.errorCode = errorCode;
	}
	
}
