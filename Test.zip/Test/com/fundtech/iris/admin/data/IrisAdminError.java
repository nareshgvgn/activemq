/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : IrisAdminError.java
 * CREATED: Oct 23, 2013 11:04:25 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import com.solab.iso8583.IsoMessage;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: IrisAdminError.java,v 1.5 2015/12/23 04:20:00 ramap Exp $
 * @since 1.0.0
 */
public class IrisAdminError
{
	private long lineNumber = 0;
	private String errorType = null;
	private String errorCode = null;
	private String errorMessage = null;
	private String info1 = null;
	private Object errorLine = null;
	
	public IrisAdminError(long lineNumber, String errorType, String errorCode, String errorMessage, String info1, Object errorLine)
	{
		this.lineNumber = lineNumber;
		this.errorType = errorType;
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.info1 = info1;
		this.errorLine = errorLine;
	}
	
	/**
	 * @return the lineNumber
	 */
	public long getLineNumber ()
	{
		return lineNumber;
	}
	
	/**
	 * @param lineNumber
	 *            the lineNumber to set
	 */
	public void setLineNumber (long lineNumber)
	{
		this.lineNumber = lineNumber;
	}
	
	/**
	 * @return the errorType
	 */
	public String getErrorType ()
	{
		return errorType;
	}
	
	/**
	 * @param errorType
	 *            the errorType to set
	 */
	public void setErrorType (String errorType)
	{
		this.errorType = errorType;
	}
	
	/**
	 * @return the errorCode
	 */
	public String getErrorCode ()
	{
		return errorCode;
	}
	
	/**
	 * @param errorCode
	 *            the errorCode to set
	 */
	public void setErrorCode (String errorCode)
	{
		this.errorCode = errorCode;
	}
	
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage ()
	{
		return errorMessage;
	}
	
	/**
	 * @param errorMessage
	 *            the errorMessage to set
	 */
	public void setErrorMessage (String errorMessage)
	{
		this.errorMessage = errorMessage;
	}
	
	/**
	 * @return the info1
	 */
	public String getInfo1 ()
	{
		return info1;
	}
	
	/**
	 * @param info1
	 *            the info1 to set
	 */
	public void setInfo1 (String info1)
	{
		this.info1 = info1;
	}
	
	/**
	 * @return the errorLine
	 */
	public String getErrorLine ()
	{
		if (errorLine == null)
			return null;
				
		if ( errorLine instanceof String)
			return (String) errorLine;
		else if ( errorLine instanceof IsoMessage)
			return ((IsoMessage)errorLine).debugString();
		else 
		return errorLine.toString();
	}
	
	/**
	 * @param errorLine
	 *            the errorLine to set
	 */
	public void setErrorLine (String errorLine)
	{
		this.errorLine = errorLine;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Error: [lineNumber=");
		builder.append(lineNumber);
		builder.append(", ");
		if (errorType != null)
		{
			builder.append("errorType=");
			builder.append(errorType);
			builder.append(", ");
		}
		if (errorCode != null)
		{
			builder.append("errorCode=");
			builder.append(errorCode);
			builder.append(", ");
		}
		if (errorMessage != null)
		{
			builder.append("errorMessage=");
			builder.append(errorMessage);
			builder.append(", ");
		}
		if (info1 != null)
		{
			builder.append("info1=");
			builder.append(info1);
			builder.append(", ");
		}
		if (errorLine != null)
		{
			builder.append("errorLine=");
			builder.append(errorLine);
		}
		builder.append("]");
		return builder.toString();
	}
	
}
