/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : ChildBands.java
 * CREATED: Apr 30, 2013 11:21:06 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ChildBands.java,v 1.2 2014/07/20 04:58:25 ramap Exp $
 * @since 1.0.0
 */
public class ChildBands extends AbstractBand
{
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public ChildBands()
	{
	}
	
}
