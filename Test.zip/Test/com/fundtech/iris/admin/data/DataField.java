/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : DataField.java
 * CREATED: Jun 9, 2014 2:55:26 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: DataField.java,v 1.3 2014/07/28 11:16:38 ramap Exp $
 */
public class DataField
{
	private String dataType = null;
	// 0 : Regular field, 1 : Regular field which is mandatory,2 : Custom field,3 : Custom field which is mandatory
	private int fieldType = 0;
	
	private int fieldLength = 0;
	/**
	 * Mapping Type will have values as 0 : Direct 1 : Referenced 2 : Function 3 : Code Map 4 : Complex 5 : Constant 6 : Running no 7 : Batch Total 8
	 * : Internal default is Direct.
	 */
	private int mappingType = 0;
	private String format = null;
	private int precision = 0;
	
	private String value = null;
	
	/**
	 * @return the dataType
	 */
	public String getDataType ()
	{
		return dataType;
	}
	
	/**
	 * @param dataType
	 *            the dataType to set
	 */
	public void setDataType (String dataType)
	{
		this.dataType = dataType;
	}
	
	/**
	 * @return the fieldType
	 */
	public int getFieldType ()
	{
		return fieldType;
	}
	
	/**
	 * @param fieldType
	 *            the fieldType to set
	 */
	public void setFieldType (int fieldType)
	{
		this.fieldType = fieldType;
	}
	
	/**
	 * @return the fieldLength
	 */
	public int getFieldLength ()
	{
		return fieldLength;
	}
	
	/**
	 * @param fieldLength
	 *            the fieldLength to set
	 */
	public void setFieldLength (int fieldLength)
	{
		this.fieldLength = fieldLength;
	}
	
	/**
	 * @return the mappingType
	 */
	public int getMappingType ()
	{
		return mappingType;
	}
	
	/**
	 * @param mappingType
	 *            the mappingType to set
	 */
	public void setMappingType (int mappingType)
	{
		this.mappingType = mappingType;
	}
	
	/**
	 * @return the format
	 */
	public String getFormat ()
	{
		return format;
	}
	
	/**
	 * @param format
	 *            the format to set
	 */
	public void setFormat (String format)
	{
		this.format = format;
	}
	
	/**
	 * @return the precision
	 */
	public int getPrecision ()
	{
		return precision;
	}
	
	/**
	 * @param precision
	 *            the precision to set
	 */
	public void setPrecision (int precision)
	{
		this.precision = precision;
	}
	
	/**
	 * @return the value
	 */
	public String getValue ()
	{
		return value;
	}
	
	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue (String value)
	{
		this.value = value;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("DataField  Properties: [dataType=");
		builder.append(dataType);
		builder.append(", fieldType=");
		builder.append(fieldType);
		builder.append(", fieldLength=");
		builder.append(fieldLength);
		builder.append(", mappingType=");
		builder.append(mappingType);
		builder.append(", format=");
		builder.append(format);
		builder.append(", precision=");
		builder.append(precision);
		builder.append(", value=");
		builder.append(value);
		builder.append("]");
		return builder.toString();
	}
}
