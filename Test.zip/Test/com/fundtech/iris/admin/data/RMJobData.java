/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : ExecutionJobData.java
 * CREATED: Jun 24, 2013 8:05:44 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.sql.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fundtech.iris.admin.report.ReportParameterDef;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * This class will holds all the data of current job.
 * 
 * @author Babu Paluri
 * @version $Id: RMJobData.java,v 1.8 2016/04/29 09:32:05 ramap Exp $
 * @since 1.0.0
 */
public class RMJobData implements JobData
{
	private String sellerCode = null;
	private String srcName = null;
	private String srcId = null;
	private String parentSrcName = null;
	private String srcType = null;
	private String mapRecordkey = null;
	private String entityCode;
	private String entityType;
	private String status;
	private String executionId;
	private String channelName;
	private String mediaDetails;
	private String refId;
	private String parentExecutionId;
	private String priority;
	private Date entryDate;
	private Date executionDate;
	private Date startDate;
	private Date endDate;
	private String errorCode;
	private String errorMsg;
	private Map<String, String> jobParameters = new HashMap<String, String>();
	private Map<String, String> sysParameters = new HashMap<String, String>();
	private Map<String, String> reportParameters = new LinkedHashMap<String, String>();
	private Map<String, ReportParameterDef> reportParmDefs = new HashMap<String, ReportParameterDef>();
	private String charSet = null;
	private String linSeparator = System.getProperty("line.separator");
	private String ftpPath = null;
	private SecurityProfile securityProfile = null;
	private String paramString = null;
	private String executionClass = null;
	private String dbUser = null;
	private String dbPass = null;
	private String dbUrl = null;
	private String repDdUrl = null;
	private String dbHost = null;
	private String dbPort = null;
	private String dbSid = null;
	private String outFileName = null;
	private String reportType = null;
	private String fileSenderName = null;
	private String reportCodePrefix = null;
	
	public void addReportParameter (String key, String value)
	{
		reportParameters.put(key, value);
	}
	
	public String getReportParameter (String key)
	{
		return reportParameters.get(key);
	}
	
	public void addReportParamDef (String key, ReportParameterDef def)
	{
		reportParmDefs.put(key, def);
	}
	
	public ReportParameterDef getReportParamDef (String key)
	{
		return reportParmDefs.get(key);
	}
	
	public Map<String, ReportParameterDef> getReportParmDefs()
	{
		return reportParmDefs;
	}
	
	public void addJobParameter (String paramName, String paramValue)
	{
		jobParameters.put(paramName, paramValue);
	}
	
	public void setJobParameters (Map<String, String> jobParameters)
	{
		this.jobParameters = jobParameters;
	}
	
	public Map<String, String> getJobParameters ()
	{
		return jobParameters;
	}
	
	public String getJobParameter (String paramName)
	{
		return jobParameters.get(paramName);
	}
	
	public void addSysParameter (String paramName, String paramValue)
	{
		sysParameters.put(paramName, paramValue);
	}
	
	public void setSysParameters (Map<String, String> jobParameters)
	{
		this.sysParameters = jobParameters;
	}
	
	public Map<String, String> getSysParameters ()
	{
		return sysParameters;
	}
	
	public String getSysParameter (String paramName)
	{
		return sysParameters.get(paramName);
	}
	
	/**
	 * @return the executionId
	 */
	public String getExecutionId ()
	{
		return executionId;
	}
	
	/**
	 * @param executionId
	 *            the executionId to set
	 */
	public void setExecutionId (String executionId)
	{
		this.executionId = executionId;
	}
	
	/**
	 * @return the sellerCode
	 */
	public String getSellerCode ()
	{
		return sellerCode;
	}
	
	/**
	 * @param sellerCode
	 *            the sellerCode to set
	 */
	public void setSellerCode (String sellerCode)
	{
		this.sellerCode = sellerCode;
	}
	
	/**
	 * @return the srcName
	 */
	public String getSrcName ()
	{
		return srcName;
	}
	
	/**
	 * @param srcName
	 *            the srcName to set
	 */
	public void setSrcName (String mapName)
	{
		this.srcName = mapName;
	}
	
	/**
	 * @return the srcType
	 */
	public String getSrcType ()
	{
		return srcType;
	}
	
	/**
	 * @param srcType
	 *            the srcType to set
	 */
	public void setSrcType (String interfaceType)
	{
		this.srcType = interfaceType;
	}
	
	/**
	 * @return the entityCode
	 */
	public String getEntityCode ()
	{
		return entityCode;
	}
	
	/**
	 * @param entityCode
	 *            the entityCode to set
	 */
	public void setEntityCode (String entityCode)
	{
		this.entityCode = entityCode;
	}
	
	/**
	 * @return the entityType
	 */
	public String getEntityType ()
	{
		return entityType;
	}
	
	/**
	 * @param entityType
	 *            the entityType to set
	 */
	public void setEntityType (String entityType)
	{
		this.entityType = entityType;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus ()
	{
		return status;
	}
	
	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus (String status)
	{
		this.status = status;
	}
	
	/**
	 * @return the channelName
	 */
	public String getChannelName ()
	{
		return channelName;
	}
	
	/**
	 * @return the mediaDetails
	 */
	public String getMediaDetails ()
	{
		return mediaDetails;
	}
	
	/**
	 * @param mediaDetails
	 *            the mediaDetails to set
	 */
	public void setMediaDetails (String mediaDetails)
	{
		this.mediaDetails = mediaDetails;
	}
	
	/**
	 * @return the refId
	 */
	public String getRefId ()
	{
		return refId;
	}
	
	/**
	 * @param refId
	 *            the refId to set
	 */
	public void setRefId (String refId)
	{
		this.refId = refId;
	}
	
	/**
	 * @return the parentExecutionId
	 */
	public String getParentExecutionId ()
	{
		return parentExecutionId;
	}
	
	/**
	 * @param parentExecutionId
	 *            the parentExecutionId to set
	 */
	public void setParentExecutionId (String parentExecutionId)
	{
		this.parentExecutionId = parentExecutionId;
	}
	
	/**
	 * @return the priority
	 */
	public String getPriority ()
	{
		return priority;
	}
	
	/**
	 * @param priority
	 *            the priority to set
	 */
	public void setPriority (String priority)
	{
		this.priority = priority;
	}
	
	/**
	 * @return the entryDate
	 */
	public Date getEntryDate ()
	{
		return entryDate;
	}
	
	/**
	 * @param entryDate
	 *            the entryDate to set
	 */
	public void setEntryDate (Date entryDate)
	{
		this.entryDate = entryDate;
	}
	
	/**
	 * @return the executionDate
	 */
	public Date getExecutionDate ()
	{
		return executionDate;
	}
	
	/**
	 * @param executionDate
	 *            the executionDate to set
	 */
	public void setExecutionDate (Date executionDate)
	{
		this.executionDate = executionDate;
	}
	
	/**
	 * @return the startDate
	 */
	public Date getStartDate ()
	{
		return startDate;
	}
	
	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate (Date startDate)
	{
		this.startDate = startDate;
	}
	
	/**
	 * @return the endDate
	 */
	public Date getEndDate ()
	{
		return endDate;
	}
	
	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate (Date endDate)
	{
		this.endDate = endDate;
	}
	
	/**
	 * @return the errorCode
	 */
	public String getErrorCode ()
	{
		return errorCode;
	}
	
	/**
	 * @param errorCode
	 *            the errorCode to set
	 */
	public void setErrorCode (String errorCode)
	{
		this.errorCode = errorCode;
	}
	
	//
	// /**
	// * @return the errorMsg
	// */
	// public String getErrorMsg()
	// {
	// return errorMsg;
	// }
	//
	// /**
	// * @param errorMsg the errorMsg to set
	// */
	// public void setErrorMsg(String errorMsg)
	// {
	// this.errorMsg = errorMsg;
	// }
	
	/**
	 * @return the charSet
	 */
	public String getCharSet ()
	{
		return charSet;
	}
	
	/**
	 * @param charSet
	 *            the charSet to set
	 */
	public void setCharSet (String charSet)
	{
		this.charSet = charSet;
	}
	
	public String getLinSeparator ()
	{
		return linSeparator;
	}
	
	public void setLinSeparator (String linSeparator)
	{
		this.linSeparator = linSeparator;
	}
	
	/**
	 * @return the ftpPath
	 */
	public String getFtpPath ()
	{
		return ftpPath;
	}
	
	/**
	 * @param ftpPath
	 *            the ftpPath to set
	 */
	public void setFtpPath (String ftpPath)
	{
		this.ftpPath = ftpPath;
	}
	
	/**
	 * @return the mapRecordkey
	 */
	public String getMapRecordkey ()
	{
		return mapRecordkey;
	}
	
	/**
	 * @param mapRecordkey
	 *            the mapRecordkey to set
	 */
	public void setMapRecordkey (String mapRecordkey)
	{
		this.mapRecordkey = mapRecordkey;
	}
	
	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg ()
	{
		return errorMsg;
	}
	
	/**
	 * @param errorMsg
	 *            the errorMsg to set
	 */
	public void setErrorMsg (String errorMsg)
	{
		this.errorMsg = errorMsg;
	}
	
	/**
	 * @return the reportParams
	 */
	public Map<String, String> getReportParameters ()
	{
		return reportParameters;
	}
	
	/**
	 * @param reportParams
	 *            the reportParams to set
	 */
	public void setReportParameter (Map<String, String> reportParams)
	{
		this.reportParameters = reportParams;
	}
	
	/**
	 * @return the securityProfile
	 */
	public SecurityProfile getSecurityProfile ()
	{
		return securityProfile;
	}
	
	/**
	 * @param securityProfile
	 *            the securityProfile to set
	 */
	public void setSecurityProfile (SecurityProfile securityProfile)
	{
		this.securityProfile = securityProfile;
	}
	
	/**
	 * @param channelName
	 *            the channelName to set
	 */
	public void setChannelName (String channelType)
	{
		this.channelName = channelType;
	}
	
	/**
	 * @return the paramString
	 */
	public String getParamString ()
	{
		return paramString;
	}
	
	/**
	 * @param paramString
	 *            the paramString to set
	 */
	public void setParamString (String paramString)
	{
		this.paramString = paramString;
	}
	
	/**
	 * @return the executionClass
	 */
	public String getExecutionClass ()
	{
		return executionClass;
	}
	
	/**
	 * @param executionClass
	 *            the executionClass to set
	 */
	public void setExecutionClass (String executionClass)
	{
		this.executionClass = executionClass;
	}
	
	/**
	 * @return the dbUser
	 */
	public String getDbUser ()
	{
		return dbUser;
	}
	
	/**
	 * @param dbUser
	 *            the dbUser to set
	 */
	public void setDbUser (String dbUser)
	{
		this.dbUser = dbUser;
	}
	
	/**
	 * @return the dbPass
	 */
	public String getDbPass ()
	{
		return dbPass;
	}
	
	/**
	 * @param dbPass
	 *            the dbPass to set
	 */
	public void setDbPass (String dbPass)
	{
		this.dbPass = dbPass;
	}
	
	/**
	 * @return the dbUrl
	 */
	public String getDbUrl ()
	{
		return dbUrl;
	}
	
	/**
	 * @param dbUrl
	 *            the dbUrl to set
	 */
	public void setDbUrl (String dbUrl)
	{
		this.dbUrl = dbUrl;
	}
	
	/**
	 * @return the repDdUrl
	 */
	public String getRepDdUrl ()
	{
		return repDdUrl;
	}
	
	/**
	 * @param repDdUrl
	 *            the repDdUrl to set
	 */
	public void setRepDdUrl (String repDdUrl)
	{
		this.repDdUrl = repDdUrl;
	}
	
	/**
	 * @return the dbHost
	 */
	public String getDbHost ()
	{
		return dbHost;
	}
	
	/**
	 * @param dbHost
	 *            the dbHost to set
	 */
	public void setDbHost (String dbHost)
	{
		this.dbHost = dbHost;
	}
	
	/**
	 * @return the dbPort
	 */
	public String getDbPort ()
	{
		return dbPort;
	}
	
	/**
	 * @param dbPort
	 *            the dbPort to set
	 */
	public void setDbPort (String dbPort)
	{
		this.dbPort = dbPort;
	}
	
	/**
	 * @return the dbSid
	 */
	public String getDbSid ()
	{
		return dbSid;
	}
	
	/**
	 * @param dbSid
	 *            the dbSid to set
	 */
	public void setDbSid (String dbSid)
	{
		this.dbSid = dbSid;
	}
	
	/**
	 * @return the outFileName
	 */
	public String getOutFileName ()
	{
		return outFileName;
	}
	
	/**
	 * @param outFileName
	 *            the outFileName to set
	 */
	public void setOutFileName (String outFileName)
	{
		this.outFileName = outFileName;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("RMJobData  Properties: [sellerCode=");
		builder.append(sellerCode);
		builder.append(", srcName=");
		builder.append(srcName);
		builder.append(", srcType=");
		builder.append(srcType);
		builder.append(", mapRecordkey=");
		builder.append(mapRecordkey);
		builder.append(", entityCode=");
		builder.append(entityCode);
		builder.append(", entityType=");
		builder.append(entityType);
		builder.append(", status=");
		builder.append(status);
		builder.append(", executionId=");
		builder.append(executionId);
		builder.append(", channelName=");
		builder.append(channelName);
		builder.append(", mediaDetails=");
		builder.append(mediaDetails);
		builder.append(", refId=");
		builder.append(refId);
		builder.append(", parentExecutionId=");
		builder.append(parentExecutionId);
		builder.append(", priority=");
		builder.append(priority);
		builder.append(", entryDate=");
		builder.append(entryDate);
		builder.append(", executionDate=");
		builder.append(executionDate);
		builder.append(", startDate=");
		builder.append(startDate);
		builder.append(", endDate=");
		builder.append(endDate);
		builder.append(", errorCode=");
		builder.append(errorCode);
		builder.append(", errorMsg=");
		builder.append(errorMsg);
		builder.append(", jobParameters=");
		builder.append(jobParameters);
		builder.append(", sysParameters=");
		builder.append(sysParameters);
		builder.append(", charSet=");
		builder.append(charSet);
		builder.append(", linSeparator=");
		builder.append(linSeparator);
		builder.append(", ftpPath=");
		builder.append(ftpPath);
		builder.append(", reportParameters=");
		builder.append(reportParameters);
		builder.append(", securityProfile=");
		builder.append(securityProfile);
		builder.append(", paramString=");
		builder.append(paramString);
		builder.append(", executionClass=");
		builder.append(executionClass);
		builder.append(", dbUser=");
		builder.append(dbUser);
		builder.append(", dbPass=");
		builder.append("******");
		builder.append(", dbUrl=");
		builder.append(dbUrl);
		builder.append(", repDdUrl=");
		builder.append(repDdUrl);
		builder.append(", dbHost=");
		builder.append(dbHost);
		builder.append(", dbPort=");
		builder.append(dbPort);
		builder.append(", dbSid=");
		builder.append(dbSid);
		builder.append(", outFileName=");
		builder.append(outFileName);
		builder.append("]");
		return builder.toString();
	}
	
	/**
	 * @return the reportType
	 */
	public String getReportType ()
	{
		return reportType;
	}
	
	/**
	 * @param reportType
	 *            the reportType to set
	 */
	public void setReportType (String reportType)
	{
		this.reportType = reportType;
	}

	/**
	 * @return the parentSrcName
	 */
	public String getParentSrcName ()
	{
		return parentSrcName;
	}

	/**
	 * @param parentSrcName the parentSrcName to set
	 */
	public void setParentSrcName (String parentSrcName)
	{
		this.parentSrcName = parentSrcName;
	}

	/**
	 * @return the fileSenderName
	 */
	public String getFileSenderName ()
	{
		return fileSenderName;
	}

	/**
	 * @param fileSenderName the fileSenderName to set
	 */
	public void setFileSenderName (String fileSenderName)
	{
		this.fileSenderName = fileSenderName;
	}

	/**
	 * @return the srcId
	 */
	public String getSrcId ()
	{
		return srcId;
	}

	/**
	 * @param srcId the srcId to set
	 */
	public void setSrcId (String srcId)
	{
		this.srcId = srcId;
	}
	
	public void cleanup()
	{
		 sellerCode = null;
		 srcName = null;
		 srcId = null;
		 parentSrcName = null;
		 srcType = null;
		 mapRecordkey = null;
		 entityCode = null;
		 entityType = null;
		 status = null;
		 executionId = null;
		 channelName = null;
		 mediaDetails = null;
		 refId = null;
		 parentExecutionId = null;
		 priority = null;
		 entryDate = null;
		 executionDate = null;
		 startDate = null;
		 endDate = null;
		 errorCode = null;
		 charSet = null;
		 ftpPath = null;
		 securityProfile = null;
		 executionClass = null;
		 dbUser = null;
		 dbPass = null;
		 dbUrl = null;
		 repDdUrl = null;
		 dbHost = null;
		 dbPort = null;
		 dbSid = null;
		 outFileName = null;
		 reportType = null;
		 fileSenderName = null;
		 errorMsg = null;
		 CleanUpUtils.doClean(jobParameters);
		 CleanUpUtils.doClean(sysParameters);
		 CleanUpUtils.doClean(reportParameters);
		 CleanUpUtils.doClean(reportParmDefs);
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param string
	 * </pre></p>
	 */
	public void setReportCodePrefix (String reportCodePrefix)
	{
		this.reportCodePrefix = reportCodePrefix;
		
	}

	/**
	 * @return the reportCodePrefix
	 */
	public String getReportCodePrefix ()
	{
		return reportCodePrefix;
	}
	
}
