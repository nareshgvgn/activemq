/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : ModelAbstractBand.java
 * CREATED: May 6, 2013 10:48:20 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ModelAbstractBand.java,v 1.2 2016/09/21 08:40:28 ramap Exp $
 * @since 1.0.0
 */
public class ModelAbstractBand
{
	protected LinkedHashMap<String, List<ModelBand>> bandsMap = new LinkedHashMap<String, List<ModelBand>>();
	
	public void addBand (ModelBand band)
	{
		List<ModelBand> lstBand = null;
		lstBand = bandsMap.get(band.getBandType());
		if (lstBand != null)
		{
			lstBand.add(band);
		}
		else
		{
			lstBand = new ArrayList<ModelBand>();
			lstBand.add(band);
			bandsMap.put(band.getBandType(), lstBand);
		}
	}
	
	public List<ModelBand> getBands (String key)
	{
		List<ModelBand> lstBand = null;
		lstBand = bandsMap.get(key);
		return lstBand;
	}
	
	public Set<String> getAllBands ()
	{
		return bandsMap.keySet();
	}
}
