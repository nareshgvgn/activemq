/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : AbstractBand.java
 * CREATED: Apr 30, 2013 11:18:34 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: AbstractBand.java,v 1.8 2016/09/21 08:40:28 ramap Exp $
 * @since 1.0.0
 */
public class AbstractBand implements Closeable
{
	protected LinkedHashMap<String, List<Band>> bandsMap = new LinkedHashMap<String, List<Band>>();
	private static Logger logger = LoggerFactory.getLogger(AbstractBand.class);
	
	public void addBand (Band band)
	{
		List<Band> lstBand = null;
		lstBand = bandsMap.get(band.getName());
		if (lstBand != null)
		{
			lstBand.add(band);
		}
		else
		{
			lstBand = new ArrayList<Band>();
			lstBand.add(band);
			bandsMap.put(band.getName(), lstBand);
		}
	}
	
	public List<Band> getBands (String key)
	{
		List<Band> lstBand = null;
		lstBand = bandsMap.get(key);
		return lstBand;
	}
	
	public Set<String> getAllBands ()
	{
		return bandsMap.keySet();
	}
	
	public int size ()
	{
		return bandsMap.size();
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		try
		{
			for (Map.Entry<String, List<Band>> entry : bandsMap.entrySet())
			{
				List<Band> bands = entry.getValue();
				for (Band band : bands)
				{
					CleanUpUtils.doClose(band);
				}
				CleanUpUtils.doClean(bands);
			}
			
		}
		catch ( Exception e)
		{
			logger.error("Error:",e);
			//ignore
		}
		finally
		{
			CleanUpUtils.doClean(bandsMap);
			
		}
		
	}
}
