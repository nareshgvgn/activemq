/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : BatchBand.java
 * CREATED: Dec 4, 2013 5:58:25 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.io.Closeable;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.Element;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: BatchBand.java,v 1.20 2016/10/20 09:08:26 ramap Exp $
 */
public class BatchBand implements Closeable
{
	private List<Band> batchBands = new ArrayList<Band>();
	private Band parentBand = null;
	private String batchName = null;
	private String minMaxKey = null;
	private BatchBand parentBatchBand = null;
	private int sequenceNumber = 0;
	
	public void addBatchBands (Band dataBand)
	{
		dataBand.setParentBand(parentBand);
		batchBands.add(dataBand);
	}
	
	public List<Band> getBatchBands ()
	{
		return batchBands;
	}
	
	public Band getParentBand ()
	{
		return parentBand;
	}
	
	public void setParentBand (Band parentBand)
	{
		this.parentBand = parentBand;
	}
	
	public String getBatchName ()
	{
		return batchName;
	}
	
	public void setBatchName (String bandName)
	{
		this.batchName = bandName;
	}
	
	public String getMinMaxKey ()
	{
		return minMaxKey;
	}
	
	public void setMinMaxKey (String minMaxKey)
	{
		this.minMaxKey = minMaxKey;
	}
	
	public BatchBand getParentBatchBand ()
	{
		return parentBatchBand;
	}
	
	public void setParentBatchBand (BatchBand parentBatchBand)
	{
		this.parentBatchBand = parentBatchBand;
	}
	
	public int getSequenceNumber ()
	{
		return sequenceNumber;
	}
	
	public void setSequenceNumber (int sequenceNumber)
	{
		this.sequenceNumber = sequenceNumber;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param out
	 * @param delimiter
	 * @param qualifier
	 * @param pBandDefs
	 * @param isFirst
	 * @throws ExecutionException
	 * @throws IOException
	 * </pre>
	 * 
	 * </p>
	 */
	public void doWriteText (Writer out, String delimiter, String qualifier, Map<String, InterfaceBandDef> pBandDefs, boolean isFirst)
			throws ExecutionException, IOException
	{
		InterfaceBandDef childDef = null;
		String bandName = null;
		for (Band band : batchBands)
		{
			bandName = band.getName();
			childDef = pBandDefs.get(bandName);
			band.doWriteText(out, delimiter, qualifier, childDef, isFirst);
			isFirst = true;
			out.flush();
		}
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param writerType
	 * @param myRootElement
	 * @param pBandDefs
	 * @param isFirst
	 * @param previousBandIndex
	 * @return
	 * @throws ExecutionException
	 * @throws FormatException
	 * </pre></p>
	 */
	public int doWriteXML (int writerType, Element myRootElement, Map<String, InterfaceBandDef> pBandDefs, boolean isFirst, int previousBandIndex)
			throws ExecutionException, FormatException
	{
		InterfaceBandDef childDef = null;
		String bandName = null;
		Element batchElement = null;
		String bandXpath = null;
		String parentXpath = null;
		Element paraentElement = null;
		int bandIndex = -1;
		
		if (IrisAdminConstants.XML_MULTI_LEVEL == writerType)
		{
			for (Band band : batchBands)
			{
				bandName = band.getName();
				childDef = pBandDefs.get(bandName);
				bandIndex = getBandIndex(bandName, pBandDefs);
				
				if ( bandIndex > -1 && bandIndex == previousBandIndex )
					bandIndex = bandIndex + 1;
				
				parentXpath = childDef.getParentXPath();
				bandXpath = childDef.getBandXPath();
				bandXpath = removeBraces(bandXpath);
				if (parentXpath != null && !parentXpath.equals("") && !parentXpath.equals("."))
				{
					if (isFirst)
					{
						paraentElement = IrisAdminUtils.createBatchFromXPath(myRootElement, parentXpath, bandIndex);
						batchElement = IrisAdminUtils.createBand(paraentElement, bandXpath, bandIndex);
						band.doWriteXML(writerType, batchElement, childDef);
					}
					else
					{
						paraentElement = (Element) myRootElement.selectSingleNode(parentXpath);
						if (paraentElement == null)
							paraentElement = IrisAdminUtils.createBatchFromXPath(myRootElement, parentXpath, bandIndex);
						
						batchElement = IrisAdminUtils.createBand(paraentElement, bandXpath, bandIndex);
						band.doWriteXML(writerType, batchElement, childDef);
					}
				}
				else
				{
					batchElement = IrisAdminUtils.createBand(myRootElement, bandXpath, bandIndex);
					band.doWriteXML(writerType, batchElement, childDef);
				}
				
				
			}
			isFirst = false; // this field is not to create parent again
		}
		
		return bandIndex;
	}
	
	/**
	 * <p> This helper method gets the band index between parent band fields
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param childDef
	 * @return
	 * </pre></p>
	 */
	private int getBandIndex (String bandName, Map<String, InterfaceBandDef> pBandDefs)
	{
		int parenntMaxSeq = -1;
		int currentMinSeq = -1;
		int currentIndex = -1;
		InterfaceBandDef parentDef = null; 
		InterfaceBandDef childDef = null; 
		
		childDef = pBandDefs.get(bandName);
		parentDef = childDef.getParentBandDef() ;
		if ( parentDef != null)
		{
			parenntMaxSeq  = parentDef.getEndsequenceNumber();
			currentMinSeq = childDef.getStartSequenceNumber();
			if ( parenntMaxSeq < currentMinSeq)
				return currentIndex;
			
			currentIndex = checkFieldsIndex(bandName, pBandDefs);
		}
		
		return currentIndex;
	}

	
	/**
	 * <p>This helper method checks band sequence between parent band fields
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param mappingFields
	 * @param currentMinSeq
	 * @return
	 * </pre></p>
	 */
	private int checkFieldsIndex (String bandName, Map<String, InterfaceBandDef> pBandDefs)
	{
		int index = -1;
		int fieldSeq = 0;
		int count = 0;
		List<MappingField> mappingFields = null;
		int currentMinSeq = -1; 
		InterfaceBandDef childDef = null; 
		String previousTag = null;
		String currrenntTag = null;
		String expression = null;
		
		childDef = pBandDefs.get(bandName);
		currentMinSeq = childDef.getStartSequenceNumber();
		mappingFields = childDef.getParentBandDef().getMappingFields();
		
		for ( MappingField field : mappingFields)
		{
			if ( IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType()
					&& IrisAdminConstants.MAPPING_TYPE_NAMESPACE != field.getMappingType())
			{
				expression = field.getRelativeXPath();
				/*
				 * Check if same root element is coming.. else get the root element
				 */
				if ( ! StringUtils.startsWith(expression, "./" + currrenntTag))
					currrenntTag = getTopElementName(field.getRelativeXPath());
				
				fieldSeq = field.getsequenceNmbr();
				if ( currentMinSeq < fieldSeq)
				{
					index = count ;
					break;
				}
				/*
				 * if current tag not matches with previous Tag then only increment the number. else ignore
				 * some times expression may come like ./tag1/tag2. we need to read only tag1. remaing path is nothing but child elements. so that index count will be
				 * proper
				 */
				if ( ! currrenntTag.equals(previousTag))
					count = count + 1;
				previousTag = currrenntTag;
			}
		}
		return index;
	}
	
	/**
	 * <p>This helper method finds Root element from the expression
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param expression
	 * @return
	 * </pre></p>
	 */
	private String getTopElementName(String expression)
	{
		String returnValue = null;
		String[] splitVals = null; 
		
		if ( expression == null)
			return null;
		
		splitVals = StringUtils.split(expression, "/");
		returnValue = splitVals[1];
		return returnValue;
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param writerType
	 * @param document
	 * @param pBandDefs
	 * @param isFirst
	 * @param previousBandIndex
	 * @return integer of band sequence
	 * @throws ExecutionException
	 * @throws FormatException
	 * </pre></p>
	 */
	public int doWriteXMLDoc (int writerType, Document document, Map<String, InterfaceBandDef> pBandDefs, boolean isFirst, int previousBandIndex)
			throws ExecutionException, FormatException
	{
		InterfaceBandDef childDef = null;
		String bandName = null;
		Element batchElement = null;
		String bandXpath = null;
		String parentXpath = null;
		Element paraentElement = null;
		int bandIndex = -1;
		
		if (IrisAdminConstants.XML_MULTI_LEVEL == writerType)
		{
			for (Band band : batchBands)
			{
				bandName = band.getName();
				childDef = pBandDefs.get(bandName);
				bandIndex = getBandIndex(bandName, pBandDefs);
				if ( bandIndex > -1 && bandIndex == previousBandIndex )
					bandIndex = bandIndex + 1;
				parentXpath = childDef.getParentXPath();
				bandXpath = childDef.getBandXPath();
				batchElement = null;
				// bandXpath = removeBraces(bandXpath);
				if (parentXpath != null && !parentXpath.equals("") && !parentXpath.equals("."))
				{
					if (isFirst)
					{
						paraentElement = IrisAdminUtils.createBatchFromXPath(document, parentXpath);
						batchElement = IrisAdminUtils.createBatchFromXPath(batchElement, bandXpath, bandIndex);
						band.doWriteXML(writerType, batchElement, childDef);
						paraentElement.add(batchElement);
					}
					else
					{
						paraentElement = (Element) document.selectSingleNode(parentXpath);
						batchElement = IrisAdminUtils.createBatchFromXPath(batchElement, bandXpath, bandIndex);
						band.doWriteXML(writerType, batchElement, childDef);
						paraentElement.add(batchElement);
					}
				}
				else
				{
					batchElement = IrisAdminUtils.createBand(document, bandXpath);
					band.doWriteXML(writerType, batchElement, childDef);
				}
				isFirst = false;
			}
			isFirst = false;
		}
		
		return bandIndex;
		
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandXpath
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private String removeBraces (String bandXpath)
	{
		if (bandXpath.endsWith("[..]"))
		{
			bandXpath = bandXpath.substring(0, bandXpath.length() - 4);
		}
		if (bandXpath.startsWith("./"))
		{
			bandXpath = bandXpath.replace("./", "");
		}
		return bandXpath;
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		batchName = null;
		minMaxKey = null;
		sequenceNumber = 0;
	}
}
