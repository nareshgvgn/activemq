/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : RootBand.java
 * CREATED: Apr 30, 2013 11:20:07 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: RootBand.java,v 1.6 2015/10/19 12:08:13 ramap Exp $
 * @since 1.0.0
 */
public class RootBand implements Closeable
{
	
	private static Logger logger = LoggerFactory.getLogger(RootBand.class);
	private List<Band> batchBands = new ArrayList<Band>();
	private List<BatchBand> batches = new ArrayList<BatchBand>();
	private String groupSql = null;
	
	/**
	 * @return the groupSql
	 */
	public String getGroupSql ()
	{
		return groupSql;
	}
	
	/**
	 * @param groupSql
	 *            the groupSql to set
	 */
	public void setGroupSql (String groupSql)
	{
		this.groupSql = groupSql;
	}
	
	public void addBatchBands (Band batchBand)
	{
		batchBands.add(batchBand);
	}
	
	public List<Band> getBatchBands ()
	{
		return batchBands;
	}
	
	public void addBatches (BatchBand batchBand)
	{
		batches.add(batchBand);
	}
	
	public List<BatchBand> getBatches ()
	{
		return batches;
	}
	
	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		try
		{
			
			for ( BatchBand batchBand : batches)
			{
				CleanUpUtils.doClose(batchBand);
			}
			
			for ( Band band : batchBands)
			{
				CleanUpUtils.doClose(band);
			}
		}
		catch ( Exception e)
		{
			logger.error("Error:",e);
			//Ignore
		}
		finally
		{
			CleanUpUtils.doClean(batchBands);
			CleanUpUtils.doClean(batches);
			groupSql = null;
		}
		
	}
}
