/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : SecurityProfile.java
 * CREATED: Jun 4, 2014 5:11:15 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: SecurityProfile.java,v 1.4 2016/10/19 14:04:55 ramap Exp $
 */
public class SecurityProfile
{
	private String name = null;
	private boolean integrityCheckRequired = false;
	private String integrityAlgo = null;
	private boolean encryptionRequired = false;
	private String encryptionType = null;
	private String encryptionAlgo = null;
	private int encryptionKeyLength = 0;
	private String encryptionKey = null;
	private boolean siginingRequired = false;
	private String signingType = null;
	private String siginingAlgo = null;
	private boolean notifySucess = false;
	private boolean notifyFailure = false;
	private String channelType = null;
	private String channelIPAddress = null;
	private int channelPort = 21;
	private String channelMode = "BINARY";
	private String channelUser = null;
	private String channelPassword = null;
	private String channelBasePath = null;
	private String channelCertName = null;
	private String emailId = null;
	private String pdfPassword = null;
	private String zipType = null;
	private String zipPassword = null;
	private String signingKey = null;
	
	/**
	 * @return the name
	 */
	public String getName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName (String name)
	{
		this.name = name;
	}
	
	/**
	 * @return the integrityCheckRequired
	 */
	public boolean isIntegrityCheckRequired ()
	{
		return integrityCheckRequired;
	}
	
	/**
	 * @param integrityCheckRequired
	 *            the integrityCheckRequired to set
	 */
	public void setIntegrityCheckRequired (String integrityCheckRequired)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(integrityCheckRequired))
			this.integrityCheckRequired = true;
	}
	
	/**
	 * @return the integrityAlgo
	 */
	public String getIntegrityAlgo ()
	{
		return integrityAlgo;
	}
	
	/**
	 * @param integrityAlgo
	 *            the integrityAlgo to set
	 */
	public void setIntegrityAlgo (String integrityAlgo)
	{
		this.integrityAlgo = integrityAlgo;
	}
	
	/**
	 * @return the encryptionRequired
	 */
	public boolean isEncryptionRequired ()
	{
		return encryptionRequired;
	}
	
	/**
	 * @param encryptionRequired
	 *            the encryptionRequired to set
	 */
	public void setEncryptionRequired (String encryptionRequired)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(encryptionRequired))
			this.encryptionRequired = true;
	}
	
	/**
	 * @return the encryptionType
	 */
	public String getEncryptionType ()
	{
		return encryptionType;
	}
	
	/**
	 * @param encryptionType
	 *            the encryptionType to set
	 */
	public void setEncryptionType (String encryptionType)
	{
		this.encryptionType = encryptionType;
	}
	
	/**
	 * @return the encryptionAlgo
	 */
	public String getEncryptionAlgo ()
	{
		return encryptionAlgo;
	}
	
	/**
	 * @param encryptionAlgo
	 *            the encryptionAlgo to set
	 */
	public void setEncryptionAlgo (String encryptionAlgo)
	{
		this.encryptionAlgo = encryptionAlgo;
	}
	
	/**
	 * @return the encryptionKeyLength
	 */
	public int getEncryptionKeyLength ()
	{
		return encryptionKeyLength;
	}
	
	/**
	 * @param encryptionKeyLength
	 *            the encryptionKeyLength to set
	 */
	public void setEncryptionKeyLength (int encryptionKeyLength)
	{
		this.encryptionKeyLength = encryptionKeyLength;
	}
	
	/**
	 * @return the encryptionKey
	 */
	public String getEncryptionKey ()
	{
		return encryptionKey;
	}
	
	/**
	 * @param encryptionKey
	 *            the encryptionKey to set
	 */
	public void setEncryptionKey (String encryptionKey)
	{
		this.encryptionKey = encryptionKey;
	}
	
	/**
	 * @return the siginingRequired
	 */
	public boolean isSiginingRequired ()
	{
		return siginingRequired;
	}
	
	/**
	 * @param siginingRequired
	 *            the siginingRequired to set
	 */
	public void setSiginingRequired (String siginingRequired)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(siginingRequired))
			this.siginingRequired = true;
	}
	
	/**
	 * @return the signingType
	 */
	public String getSigningType ()
	{
		return signingType;
	}
	
	/**
	 * @param signingType
	 *            the signingType to set
	 */
	public void setSigningType (String signingType)
	{
		this.signingType = signingType;
	}
	
	/**
	 * @return the siginingAlgo
	 */
	public String getSiginingAlgo ()
	{
		return siginingAlgo;
	}
	
	/**
	 * @param siginingAlgo
	 *            the siginingAlgo to set
	 */
	public void setSiginingAlgo (String siginingAlgo)
	{
		this.siginingAlgo = siginingAlgo;
	}
	
	/**
	 * @return the notifySucess
	 */
	public boolean isNotifySucess ()
	{
		return notifySucess;
	}
	
	/**
	 * @param notifySucess
	 *            the notifySucess to set
	 */
	public void setNotifySucess (String notifySucess)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(notifySucess))
			this.notifySucess = true;
	}
	
	/**
	 * @return the notifyFailure
	 */
	public boolean isNotifyFailure ()
	{
		return notifyFailure;
	}
	
	/**
	 * @param notifyFailure
	 *            the notifyFailure to set
	 */
	public void setNotifyFailure (String notifyFailure)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(notifyFailure))
			this.notifyFailure = true;
	}
	
	/**
	 * @return the channelType
	 */
	public String getChannelType ()
	{
		return channelType;
	}
	
	/**
	 * @param channelType
	 *            the channelType to set
	 */
	public void setChannelType (String channelType)
	{
		this.channelType = channelType;
	}
	
	/**
	 * @return the channelIPAddress
	 */
	public String getChannelIPAddress ()
	{
		return channelIPAddress;
	}
	
	/**
	 * @param channelIPAddress
	 *            the channelIPAddress to set
	 */
	public void setChannelIPAddress (String channelIPAddress)
	{
		this.channelIPAddress = channelIPAddress;
	}
	
	/**
	 * @return the channelPort
	 */
	public int getChannelPort ()
	{
		return channelPort;
	}
	
	/**
	 * @param channelPort
	 *            the channelPort to set
	 */
	public void setChannelPort (int channelPort)
	{
		this.channelPort = channelPort;
	}
	
	/**
	 * @return the channelMode
	 */
	public String getChannelMode ()
	{
		return channelMode;
	}
	
	/**
	 * @param channelMode
	 *            the channelMode to set
	 */
	public void setChannelMode (String channelMode)
	{
		this.channelMode = channelMode;
	}
	
	/**
	 * @return the channelUser
	 */
	public String getChannelUser ()
	{
		return channelUser;
	}
	
	/**
	 * @param channelUser
	 *            the channelUser to set
	 */
	public void setChannelUser (String channelUser)
	{
		this.channelUser = channelUser;
	}
	
	/**
	 * @return the channelPassword
	 */
	public String getChannelPassword ()
	{
		return channelPassword;
	}
	
	/**
	 * @param channelPassword
	 *            the channelPassword to set
	 */
	public void setChannelPassword (String channelPassword)
	{
		this.channelPassword = channelPassword;
	}
	
	/**
	 * @return the channelBasePath
	 */
	public String getChannelBasePath ()
	{
		return channelBasePath;
	}
	
	/**
	 * @param channelBasePath
	 *            the channelBasePath to set
	 */
	public void setChannelBasePath (String channelBasePath)
	{
		this.channelBasePath = channelBasePath;
	}
	
	/**
	 * @return the channelCertName
	 */
	public String getChannelCertName ()
	{
		return channelCertName;
	}
	
	/**
	 * @param channelCertName
	 *            the channelCertName to set
	 */
	public void setChannelCertName (String channelCertName)
	{
		this.channelCertName = channelCertName;
	}
	
	/**
	 * @return the emailId
	 */
	public String getEmailId ()
	{
		return emailId;
	}
	
	/**
	 * @param emailId
	 *            the emailId to set
	 */
	public void setEmailId (String emailId)
	{
		this.emailId = emailId;
	}
	
	/**
	 * @return the pdfPassword
	 */
	public String getPdfPassword ()
	{
		return pdfPassword;
	}
	
	/**
	 * @param pdfPassword
	 *            the pdfPassword to set
	 */
	public void setPdfPassword (String pdfPassword)
	{
		this.pdfPassword = pdfPassword;
	}
	
	/**
	 * @return the zipType
	 */
	public String getZipType ()
	{
		return zipType;
	}
	
	/**
	 * @param zipType
	 *            the zipType to set
	 */
	public void setZipType (String zipType)
	{
		this.zipType = zipType;
	}
	
	/**
	 * @return the zipPassword
	 */
	public String getZipPassword ()
	{
		return zipPassword;
	}
	
	/**
	 * @param zipPassword
	 *            the zipPassword to set
	 */
	public void setZipPassword (String zipPassword)
	{
		this.zipPassword = zipPassword;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = null;
		String outVal = null;
		
		builder = new StringBuilder();
		builder.append("SecurityProfile Properties: [");
		if (name != null)
		{
			builder.append("name=");
			builder.append(name);
			builder.append(", ");
		}
		builder.append("integrityCheckRequired=");
		builder.append(integrityCheckRequired);
		builder.append(", ");
		if (integrityAlgo != null)
		{
			builder.append("integrityAlgo=");
			builder.append(integrityAlgo);
			builder.append(", ");
		}
		builder.append("encryptionRequired=");
		builder.append(encryptionRequired);
		builder.append(", ");
		if (encryptionType != null)
		{
			builder.append("encryptionType=");
			builder.append(encryptionType);
			builder.append(", ");
		}
		if (encryptionAlgo != null)
		{
			builder.append("encryptionAlgo=");
			builder.append(encryptionAlgo);
			builder.append(", ");
		}
		builder.append("encryptionKeyLength=");
		builder.append(encryptionKeyLength);
		builder.append(", ");
		if (encryptionKey != null)
		{
			builder.append("encryptionKey=");
			builder.append(encryptionKey);
			builder.append(", ");
		}
		builder.append("siginingRequired=");
		builder.append(siginingRequired);
		builder.append(", ");
		if (signingType != null)
		{
			builder.append("signingType=");
			builder.append(signingType);
			builder.append(", ");
		}
		if (siginingAlgo != null)
		{
			builder.append("siginingAlgo=");
			builder.append(siginingAlgo);
			builder.append(", ");
		}
		builder.append("notifySucess=");
		builder.append(notifySucess);
		builder.append(", notifyFailure=");
		builder.append(notifyFailure);
		builder.append(", ");
		if (channelType != null)
		{
			builder.append("channelType=");
			builder.append(channelType);
			builder.append(", ");
		}
		if (channelIPAddress != null)
		{
			builder.append("channelIPAddress=");
			builder.append(channelIPAddress);
			builder.append(", ");
		}
		builder.append("channelPort=");
		builder.append(channelPort);
		builder.append(", ");
		if (channelMode != null)
		{
			builder.append("channelMode=");
			builder.append(channelMode);
			builder.append(", ");
		}
		if (channelUser != null)
		{
			builder.append("channelUser=");
			builder.append(channelUser);
			builder.append(", ");
		}
		if (channelBasePath != null)
		{
			builder.append("channelBasePath=");
			builder.append(channelBasePath);
			builder.append(", ");
		}
		if (channelCertName != null)
		{
			builder.append("channelCertName=");
			builder.append(channelCertName);
			builder.append(", ");
		}
		if (emailId != null)
		{
			builder.append("emailId=");
			builder.append(emailId);
			builder.append(", ");
		}
		if (zipType != null)
		{
			builder.append("zipType=");
			builder.append(zipType);
			builder.append(", ");
		}
		if (zipPassword != null)
		{
			builder.append("zipPassword=");
			builder.append(zipPassword);
		}
		builder.append("]");
		
		outVal = builder.toString();
		CleanUpUtils.doClean(builder);
		builder = null;
		return outVal;
	}

	/**
	 * @return the signingKey
	 */
	public String getSigningKey ()
	{
		return signingKey;
	}

	/**
	 * @param signingKey the signingKey to set
	 */
	public void setSigningKey (String signingKey)
	{
		this.signingKey = signingKey;
	}
}
