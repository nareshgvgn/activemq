/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : InterfaceMap.java
 * CREATED: Jul 1, 2013 9:45:38 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceMap.java,v 1.5 2014/07/20 04:58:25 ramap Exp $
 * @since 1.0.0
 */
public class InterfaceMap
{
	private String name = null;
	private String type = null;
	private String modeuleCode = null;
	private String interfaceDefRecordKey = null;
	private InterfaceDef interfaceDef = null;
	private String secProfileRecordKey = null;
	private SecurityProfile securityProfile = null;
	
	/**
	 * @return the name
	 */
	public String getName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName (String name)
	{
		this.name = name;
	}
	
	/**
	 * @return the type
	 */
	public String getType ()
	{
		return type;
	}
	
	/**
	 * @param type
	 *            the type to set
	 */
	public void setType (String type)
	{
		this.type = type;
	}
	
	/**
	 * @return the modeuleCode
	 */
	public String getModeuleCode ()
	{
		return modeuleCode;
	}
	
	/**
	 * @param modeuleCode
	 *            the modeuleCode to set
	 */
	public void setModeuleCode (String modeuleCode)
	{
		this.modeuleCode = modeuleCode;
	}
	
	/**
	 * @return the interfaceDef
	 */
	public InterfaceDef getInterfaceDefinition ()
	{
		return interfaceDef;
	}
	
	/**
	 * @param interfaceDef
	 *            the interfaceDef to set
	 */
	public void setInterfaceDefinition (InterfaceDef interfaceDef)
	{
		this.interfaceDef = interfaceDef;
	}
	
	/**
	 * @return the securityProfile
	 */
	public SecurityProfile getSecurityProfile ()
	{
		return securityProfile;
	}
	
	/**
	 * @param securityProfile
	 *            the securityProfile to set
	 */
	public void setSecurityProfile (SecurityProfile securityProfile)
	{
		this.securityProfile = securityProfile;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = null;
		String outVal = null;
		
		builder = new StringBuilder();
		builder.append("InterfaceMap  Properties: [");
		if (name != null)
		{
			builder.append("name=");
			builder.append(name);
			builder.append(", ");
		}
		if (type != null)
		{
			builder.append("type=");
			builder.append(type);
			builder.append(", ");
		}
		if (modeuleCode != null)
		{
			builder.append("modeuleCode=");
			builder.append(modeuleCode);
			builder.append(", ");
		}
		if (interfaceDef != null)
		{
			builder.append("interfaceDef=");
			builder.append(interfaceDef);
			builder.append(", ");
		}
		if (securityProfile != null)
		{
			builder.append("securityProfile=");
			builder.append(securityProfile);
		}
		builder.append("]");
		outVal = builder.toString();
		CleanUpUtils.doClean(builder);
		builder = null;
		return outVal;
	}
	
	/**
	 * @return the interfaceDefRecordKey
	 */
	public String getInterfaceDefRecordKey ()
	{
		return interfaceDefRecordKey;
	}
	
	/**
	 * @param interfaceDefRecordKey
	 *            the interfaceDefRecordKey to set
	 */
	public void setInterfaceDefRecordKey (String interfaceDefRecordKey)
	{
		this.interfaceDefRecordKey = interfaceDefRecordKey;
	}
	
	/**
	 * @return the secProfileRecordKey
	 */
	public String getSecProfileRecordKey ()
	{
		return secProfileRecordKey;
	}
	
	/**
	 * @param secProfileRecordKey
	 *            the secProfileRecordKey to set
	 */
	public void setSecProfileRecordKey (String secProfileRecordKey)
	{
		this.secProfileRecordKey = secProfileRecordKey;
	}
	
}
