/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : ExecutionJobData.java
 * CREATED: Jun 24, 2013 8:05:44 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * This class will holds all the data of current job.
 * 
 * @author Babu Paluri
 * @version $Id: ExecutionJobData.java,v 1.21 2016/12/08 11:25:42 ramap Exp $
 * @since 1.0.0
 */
public class ExecutionJobData implements JobData
{
	private String sellerCode = null;
	private String mapName = null;
	private String mapType = null;
	private String mapRecordkey = null;
	private String entityCode;
	private String entityType;
	private String status;
	private String executionId;
	private String responseExecutionId = null;
	private String channelType;
	private String srcSubType = null;
	private String mediaDetails = null;
	private String orgMediaDetails = null;
	private String refId;
	private String parentExecutionId;
	private String priority;
	private Date entryDate;
	private Date executionDate;
	private Date startDate;
	private Date endDate;
	private String errorCode;
	private String errorMsg;
	private Map<String, String> filterParameters = new HashMap<String, String>();
	private InterfaceMap interfaceMap = null;
	private String charSet = null;
	private String linSeparator = System.getProperty("line.separator");
	private boolean splitFile = false;
	private List<String> splitFileList = new ArrayList<String>();
	private boolean accumulateErros = false;
	private List<IrisAdminError> errors = new ArrayList<IrisAdminError>();
	private Queue<IrisError> monitorErrors = new LinkedList<IrisError>();
	private String formatterType = null;
	private boolean noData = false;
	private Map<String, String> parms = new HashMap<String, String>();
	private String ftpPath = null;
	private InterfaceDef interfaceDef = null;
	private String mediumType = IrisAdminConstants.MEDIA_FILE;
	private String messageData = null;
	private Object dataObject = null;
	private Object irisDataObject = null;
	private boolean isReUpload = false;
	private String whereCondition = null;
	
	
	public void addSplitFile (String fileWithPath)
	{
		splitFileList.add(fileWithPath);
	}
	
	public List<String> getSplitFileList ()
	{
		return splitFileList;
	}
	
	public void setSplitFile (List<String> listFiles)
	{
		splitFileList = listFiles;
	}
	
	/**
	 * @return the interfaceMap
	 */
	public InterfaceMap getInterfaceMap ()
	{
		return interfaceMap;
	}
	
	/**
	 * @param interfaceMap
	 *            the interfaceMap to set
	 */
	public void setInterfaceMap (InterfaceMap interfaceMap)
	{
		this.interfaceMap = interfaceMap;
	}
	
	/**
	 * @param paramName
	 * @param paramValue
	 */
	public void addFilterParemeter (String paramName, String paramValue)
	{
		filterParameters.put(paramName, paramValue);
	}
	
	public void setFilterParameters (Map<String, String> filterParameters)
	{
		this.filterParameters = filterParameters;
	}
	
	public Map<String, String> getFilterParameters ()
	{
		return filterParameters;
	}
	
	public String getFilterParameter (String paramName)
	{
		return filterParameters.get(paramName);
	}
	
	/**
	 * @return the executionId
	 */
	public String getExecutionId ()
	{
		return executionId;
	}
	
	/**
	 * @param executionId
	 *            the executionId to set
	 */
	public void setExecutionId (String executionId)
	{
		this.executionId = executionId;
	}
	
	/**
	 * @return the sellerCode
	 */
	public String getSellerCode ()
	{
		return sellerCode;
	}
	
	/**
	 * @param sellerCode
	 *            the sellerCode to set
	 */
	public void setSellerCode (String sellerCode)
	{
		this.sellerCode = sellerCode;
	}
	
	/**
	 * @return the mapName
	 */
	public String getMapName ()
	{
		return mapName;
	}
	
	/**
	 * @param mapName
	 *            the mapName to set
	 */
	public void setMapName (String mapName)
	{
		this.mapName = mapName;
	}
	
	/**
	 * @return the mapType
	 */
	public String getMapType ()
	{
		return mapType;
	}
	
	/**
	 * @param mapType
	 *            the mapType to set
	 */
	public void setMapType (String interfaceType)
	{
		this.mapType = interfaceType;
	}
	
	/**
	 * @return the entityCode
	 */
	public String getEntityCode ()
	{
		return entityCode;
	}
	
	/**
	 * @param entityCode
	 *            the entityCode to set
	 */
	public void setEntityCode (String entityCode)
	{
		this.entityCode = entityCode;
	}
	
	/**
	 * @return the entityType
	 */
	public String getEntityType ()
	{
		return entityType;
	}
	
	/**
	 * @param entityType
	 *            the entityType to set
	 */
	public void setEntityType (String entityType)
	{
		this.entityType = entityType;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus ()
	{
		return status;
	}
	
	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus (String status)
	{
		this.status = status;
	}
	
	/**
	 * @return the channelType
	 */
	public String getChannelType ()
	{
		return channelType;
	}
	
	/**
	 * @param channelType
	 *            the channelType to set
	 */
	public void setChannelName (String module)
	{
		this.channelType = module;
	}
	
	/**
	 * @return the mediaDetails
	 */
	public String getMediaDetails ()
	{
		return mediaDetails;
	}
	
	/**
	 * @param mediaDetails
	 *            the mediaDetails to set
	 */
	public void setMediaDetails (String mediaDetails)
	{
		this.mediaDetails = mediaDetails;
	}
	
	/**
	 * @return the refId
	 */
	public String getRefId ()
	{
		return refId;
	}
	
	/**
	 * @param refId
	 *            the refId to set
	 */
	public void setRefId (String refId)
	{
		this.refId = refId;
	}
	
	/**
	 * @return the parentExecutionId
	 */
	public String getParentExecutionId ()
	{
		return parentExecutionId;
	}
	
	/**
	 * @param parentExecutionId
	 *            the parentExecutionId to set
	 */
	public void setParentExecutionId (String parentExecutionId)
	{
		this.parentExecutionId = parentExecutionId;
	}
	
	/**
	 * @return the priority
	 */
	public String getPriority ()
	{
		return priority;
	}
	
	/**
	 * @param priority
	 *            the priority to set
	 */
	public void setPriority (String priority)
	{
		this.priority = priority;
	}
	
	/**
	 * @return the entryDate
	 */
	public Date getEntryDate ()
	{
		return entryDate;
	}
	
	/**
	 * @param entryDate
	 *            the entryDate to set
	 */
	public void setEntryDate (Date entryDate)
	{
		this.entryDate = entryDate;
	}
	
	/**
	 * @return the executionDate
	 */
	public Date getExecutionDate ()
	{
		return executionDate;
	}
	
	/**
	 * @param executionDate
	 *            the executionDate to set
	 */
	public void setExecutionDate (Date executionDate)
	{
		this.executionDate = executionDate;
	}
	
	/**
	 * @return the startDate
	 */
	public Date getStartDate ()
	{
		return startDate;
	}
	
	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate (Date startDate)
	{
		this.startDate = startDate;
	}
	
	/**
	 * @return the endDate
	 */
	public Date getEndDate ()
	{
		return endDate;
	}
	
	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate (Date endDate)
	{
		this.endDate = endDate;
	}
	
	/**
	 * @return the errorCode
	 */
	public String getErrorCode ()
	{
		return errorCode;
	}
	
	/**
	 * @param errorCode
	 *            the errorCode to set
	 */
	public void setErrorCode (String errorCode)
	{
		this.errorCode = errorCode;
	}
	
	/**
	 * @return the charSet
	 */
	public String getCharSet ()
	{
		return charSet;
	}
	
	/**
	 * @param charSet
	 *            the charSet to set
	 */
	public void setCharSet (String charSet)
	{
		this.charSet = charSet;
	}
	
	/**
	 * @return the splitFile
	 */
	public boolean isSplitFile ()
	{
		return splitFile;
	}
	
	/**
	 * @param splitFile
	 *            the splitFile to set
	 */
	public void setSplitFile (boolean splitFile)
	{
		this.splitFile = splitFile;
	}
	
	public String getLinSeparator ()
	{
		return linSeparator;
	}
	
	public void setLinSeparator (String linSeparator)
	{
		this.linSeparator = linSeparator;
	}
	
	public boolean isAccumulateErros ()
	{
		return accumulateErros;
	}
	
	public void setAccumulateErros (boolean accumulateErros)
	{
		this.accumulateErros = accumulateErros;
	}
	
	public List<IrisAdminError> getErrors ()
	{
		return errors;
	}
	
	public void addError (IrisAdminError error)
	{
		errors.add(error);
	}
	
	
	public Queue<IrisError> getIrisErrors ()
	{
		return monitorErrors;
	}
	
	public void addIrisError (IrisError irisError)
	{
		monitorErrors.add(irisError);
	}
	
	
	
	public String getFormatterType ()
	{
		return formatterType;
	}
	
	public void setFormatterType (String formatterType)
	{
		this.formatterType = formatterType;
	}
	
	/**
	 * @return the ftpPath
	 */
	public String getFtpPath ()
	{
		return ftpPath;
	}
	
	/**
	 * @param ftpPath
	 *            the ftpPath to set
	 */
	public void setFtpPath (String ftpPath)
	{
		this.ftpPath = ftpPath;
	}
	
	/**
	 * @return the noData
	 */
	public boolean isNoData ()
	{
		return noData;
	}
	
	/**
	 * @param noData
	 *            the noData to set
	 */
	public void setNoData (boolean noData)
	{
		this.noData = noData;
	}
	
	/**
	 * @return the parms
	 */
	public String getParm (String key)
	{
		return parms.get(key);
	}
	
	/**
	 * @param parms
	 *            the parms to set
	 */
	public void addParms (String key, String value)
	{
		this.parms.put(key, value);
	}
	
	/**
	 * @return the mapRecordkey
	 */
	public String getMapRecordkey ()
	{
		return mapRecordkey;
	}
	
	/**
	 * @param mapRecordkey
	 *            the mapRecordkey to set
	 */
	public void setMapRecordkey (String mapRecordkey)
	{
		this.mapRecordkey = mapRecordkey;
	}
	
	/**
	 * @return the interfaceDef
	 */
	public InterfaceDef getInterfaceDef ()
	{
		return interfaceDef;
	}
	
	/**
	 * @param interfaceDef
	 *            the interfaceDef to set
	 */
	public void setInterfaceDef (InterfaceDef interfaceDef)
	{
		this.interfaceDef = interfaceDef;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("ExecutionJobData  Properties: [sellerCode=");
		builder.append(sellerCode);
		builder.append(", mapName=");
		builder.append(mapName);
		builder.append(", mapType=");
		builder.append(mapType);
		builder.append(", mapRecordkey=");
		builder.append(mapRecordkey);
		builder.append(", entityCode=");
		builder.append(entityCode);
		builder.append(", entityType=");
		builder.append(entityType);
		builder.append(", status=");
		builder.append(status);
		builder.append(", executionId=");
		builder.append(executionId);
		builder.append(", channelType=");
		builder.append(channelType);
		builder.append(", mediaDetails=");
		builder.append(mediaDetails);
		builder.append(", refId=");
		builder.append(refId);
		builder.append(", parentExecutionId=");
		builder.append(parentExecutionId);
		builder.append(", priority=");
		builder.append(priority);
		builder.append(", entryDate=");
		builder.append(entryDate);
		builder.append(", executionDate=");
		builder.append(executionDate);
		builder.append(", startDate=");
		builder.append(startDate);
		builder.append(", endDate=");
		builder.append(endDate);
		builder.append(", errorCode=");
		builder.append(errorCode);
		builder.append(", errorMsg=");
		builder.append(errorMsg);
		builder.append(", filterParameters=");
		builder.append(filterParameters);
		builder.append(", interfaceMap=");
		builder.append(interfaceMap);
		builder.append(", charSet=");
		builder.append(charSet);
		builder.append(", linSeparator=");
		builder.append(linSeparator);
		builder.append(", splitFile=");
		builder.append(splitFile);
		builder.append(", splitFileList=");
		builder.append(splitFileList);
		builder.append(", accumulateErros=");
		builder.append(accumulateErros);
		builder.append(", errors=");
		builder.append(errors);
		builder.append(", formatterType=");
		builder.append(formatterType);
		builder.append(", noData=");
		builder.append(noData);
		builder.append(", parms=");
		builder.append(parms);
		builder.append(", ftpPath=");
		builder.append(ftpPath);
		builder.append(", interfaceDef=");
		builder.append(interfaceDef);
		builder.append("]");
		return builder.toString();
	}
	
	/**
	 * @return the mediumType
	 */
	public String getMediumType ()
	{
		return mediumType;
	}
	
	/**
	 * @param mediumType
	 *            the mediumType to set
	 */
	public void setMediumType (String mediaType)
	{
		this.mediumType = mediaType;
	}
	
	/**
	 * @return the messageData
	 */
	public String getMessageData ()
	{
		return messageData;
	}
	
	/**
	 * @param messageData
	 *            the messageData to set
	 */
	public void setMessageData (String messageData)
	{
		this.messageData = messageData;
	}

	/**
	 * @return the dataObject
	 */
	public Object getDataObject ()
	{
		return dataObject;
	}

	/**
	 * @param dataObject the dataObject to set
	 */
	public void setDataObject (Object dataObject)
	{
		this.dataObject = dataObject;
	}
	
	public void cleanup()
	{
		sellerCode = null;
		 mapName = null;
		mapType = null;
		mapRecordkey = null;
		entityCode = null;;
		entityType = null;;
		status = null;;
		executionId = null;;
		channelType = null;;
		mediaDetails = null;;
		refId = null;;
		parentExecutionId = null;;
		priority = null;;
		entryDate = null;;
		executionDate = null;;
		 startDate = null;;
		endDate = null;;
		errorCode = null;;
		errorMsg = null;;
		ftpPath = null;
		messageData = null;
		dataObject = null;
		charSet = null;
		formatterType = null;
		linSeparator = null;
		CleanUpUtils.doClean(splitFileList);
		CleanUpUtils.doClean(errors);
		CleanUpUtils.doClean(parms);
	}

	/**
	 * @return the srcSubType
	 */
	public String getSrcSubType ()
	{
		return srcSubType;
	}

	/**
	 * @param srcSubType the srcSubType to set
	 */
	public void setSrcSubType (String srcSubType)
	{
		this.srcSubType = srcSubType;
	}

	/**
	 * @return the isReUpload
	 */
	public boolean isReUpload ()
	{
		return isReUpload;
	}

	/**
	 * @param isReUpload the isReUpload to set
	 */
	public void setReUpload (boolean isReUpload)
	{
		this.isReUpload = isReUpload;
	}

	/**
	 * @return the orgMediaDetails
	 */
	public String getOrgMediaDetails ()
	{
		return orgMediaDetails;
	}

	/**
	 * @param orgMediaDetails the orgMediaDetails to set
	 */
	public void setOrgMediaDetails (String orgMediaDetails)
	{
		this.orgMediaDetails = orgMediaDetails;
	}

	/**
	 * @return the irisDataObject
	 */
	public Object getIrisDataObject ()
	{
		return irisDataObject;
	}

	/**
	 * @param irisDataObject the irisDataObject to set
	 */
	public void setIrisDataObject (Object irisDataObject)
	{
		this.irisDataObject = irisDataObject;
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param executionId2
	 * </pre></p>
	 */
	public void setRespExecutionId (String responseExecutionId)
	{
		this.responseExecutionId = responseExecutionId;
		
	}
	
	public String getRespExecutionId()
	{
		return responseExecutionId;
	}

	/**
	 * @return the whereCondition
	 */
	public String getWhereCondition ()
	{
		return whereCondition;
	}

	/**
	 * @param whereCondition the whereCondition to set
	 */
	public void setWhereCondition (String whereCondition)
	{
		this.whereCondition = whereCondition;
	}
	
}
