/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : ModelBand.java
 * CREATED: May 6, 2013 10:46:27 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ModelBand.java,v 1.1 2014/07/25 05:57:43 ramap Exp $
 * @since 1.0.0
 */
public class ModelBand implements Cloneable
{
	private String name = null;
	private String id = null;
	private String bandPath = null;
	private String bandType = null;
	private String currentSessionId = null;
	private long parentNo = 0;
	private long myNumber = 0;
	private String processBandName = null;
	private ModelChildBands childBands = new ModelChildBands();
	private Map<String, String> fieldsList = new HashMap<String, String>();
	private Map<String, String> fieldColumns = new HashMap<String, String>();
	private List<ModelBand> dataRow = new ArrayList<ModelBand>();;
	private ModelBand parentBand = null;
	
	public List<ModelBand> getRows ()
	{
		return dataRow;
	}
	
	public void addRow (ModelBand band)
	{
		dataRow.add(band);
	}
	
	public String getFieldValue (String fldName)
	{
		String fldValue = null;
		
		fldValue = fieldsList.get(fldName);
		return fldValue;
	}
	
	public void setFieldValue (String fldName, String fldValue)
	{
		fieldsList.put(fldName, fldValue);
	}
	
	public Map<String, String> getFieldRow ()
	{
		return this.fieldsList;
	}
	
	public void setFieldColumns (String fldName, String fldColumnsName)
	{
		fieldColumns.put(fldName, fldColumnsName);
	}
	
	public Map<String, String> getFieldColumns ()
	{
		return this.fieldColumns;
	}
	
	public String getFieldColumn (String fldName)
	{
		String fldColumn = null;
		
		fldColumn = fieldColumns.get(fldName);
		return fldColumn;
	}
	
	/**
	 * @return the bandPath
	 */
	public String getBandPath ()
	{
		return bandPath;
	}
	
	/**
	 * @param bandPath
	 *            the bandPath to set
	 */
	public void setBandPath (String bandPath)
	{
		this.bandPath = bandPath;
	}
	
	public void addFields (Map<String, String> fieldsMap)
	{
		this.fieldsList = fieldsMap;
	}
	
	public void addChildBand (ModelBand band)
	{
		childBands.addBand(band);
	}
	
	public List<ModelBand> getChildBands (String key)
	{
		List<ModelBand> lstBand = null;
		lstBand = childBands.getBands(key);
		return lstBand;
	}
	
	public Set<String> getAllBands ()
	{
		return childBands.getAllBands();
	}
	
	/**
	 * @return the name
	 */
	public String getName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName (String name)
	{
		this.name = name;
	}
	
	/**
	 * @return the id
	 */
	public String getId ()
	{
		return id;
	}
	
	/**
	 * @param id
	 *            the id to set
	 */
	public void setId (String id)
	{
		this.id = id;
	}
	
	/**
	 * @return the bandType
	 */
	public String getBandType ()
	{
		return bandType;
	}
	
	/**
	 * @param bandType
	 *            the bandType to set
	 */
	public void setBandType (String bandType)
	{
		this.bandType = bandType;
	}
	
	/**
	 * @return the parentBand
	 */
	public ModelBand getParentBand ()
	{
		return parentBand;
	}
	
	/**
	 * @param parentBand
	 *            the parentBand to set
	 */
	public void setParentBand (ModelBand parentBand)
	{
		this.parentBand = parentBand;
	}
	
	/**
	 * @return the currentSessionId
	 */
	public String getCurrentSessionId ()
	{
		return currentSessionId;
	}
	
	/**
	 * @param currentSessionId
	 *            the currentSessionId to set
	 */
	public void setCurrentSessionId (String currentSessionId)
	{
		this.currentSessionId = currentSessionId;
	}
	
	/**
	 * @return the parentNo
	 */
	public long getParentNo ()
	{
		return parentNo;
	}
	
	/**
	 * @param parentNo
	 *            the parentNo to set
	 */
	public void setParentNo (long parentNo)
	{
		this.parentNo = parentNo;
	}
	
	/**
	 * @return the myNumber
	 */
	public long getMyNumber ()
	{
		return myNumber;
	}
	
	/**
	 * @param myNumber
	 *            the myNumber to set
	 */
	public void setMyNumber (long myNumber)
	{
		this.myNumber = myNumber;
	}
	
	public Object clone () throws CloneNotSupportedException
	{
		ModelBand modelBand = new ModelBand();
		modelBand.name = this.name;
		modelBand.fieldsList = new HashMap<String, String>(fieldsList);
		modelBand.id = this.id;
		modelBand.bandPath = this.bandPath;
		modelBand.bandType = this.bandType;
		modelBand.currentSessionId = this.currentSessionId;
		modelBand.parentNo = this.parentNo;
		modelBand.myNumber = this.myNumber;
		modelBand.processBandName = this.processBandName;
		// interfaceBand.childBands = this.childBands;
		// interfaceBand.fieldColumns = new HashMap<String, String>(fieldColumns);
		// interfaceBand.dataRow = new ArrayList<ModelBand>(dataRow);;
		// interfaceBand.parentBand = this.parentBand;
		
		return modelBand;
	}
	
	/**
	 * @return the processBandName
	 */
	public String getProcessBandName ()
	{
		return processBandName;
	}
	
	/**
	 * @param processBandName
	 *            the processBandName to set
	 */
	public void setProcessBandName (String processBandName)
	{
		this.processBandName = processBandName;
	}
}
