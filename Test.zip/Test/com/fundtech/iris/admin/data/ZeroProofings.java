/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : ZeroProofings.java
 * CREATED: Jun 29, 2013 3:13:03 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.util.HashMap;
import java.util.Map;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ZeroProofings.java,v 1.4 2016/04/07 05:34:44 ramap Exp $
 * @since 1.0.0
 */
public class ZeroProofings
{
	private Map<String, ZeroProofing> zeroProofings = new HashMap<String, ZeroProofing>();
	
	public void addSourceValue (String sourceKey, double sourceValue)
	{
		ZeroProofing zeroProofing = null;
		zeroProofing = zeroProofings.get(sourceKey);
		zeroProofing.addSourceValue(sourceValue);
	}
	
	public boolean contains (String sourceKey)
	{
		return zeroProofings.containsKey(sourceKey);
	}
	
	public void setPrimeValue (String sourceKey, double primeValue)
	{
		ZeroProofing zeroProofing = null;
		zeroProofing = zeroProofings.get(sourceKey);
		zeroProofing.setPrimeValue(primeValue);
	}
	
	public void setZeroProofing (ZeroProofing zeroProofing)
	{
		zeroProofings.put(zeroProofing.getSourceFieldName(), zeroProofing);
	}
	
	public ZeroProofing getZeroProofing (String sourceKey)
	{
		ZeroProofing zeroProofing = null;
		zeroProofing = zeroProofings.get(sourceKey);
		return zeroProofing;
	}
	
	/**
	 * @return the zeroProofings
	 */
	public Map<String, ZeroProofing> getZeroProofings ()
	{
		return zeroProofings;
	}
}
