/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : Band.java
 * CREATED: Mar 1, 2013 11:30:19 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.io.Closeable;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: Band.java,v 1.29 2017/01/30 04:50:14 ramap Exp $
 * @since 1.0.0
 */
public class Band implements Closeable
{
	private static Logger logger = LoggerFactory.getLogger(Band.class);
	
	private String name = null;
	private String id = null;
	private String bandPath = null;
	private String bandType = null;
	private ChildBands childBands = new ChildBands();
	private Map<String, DataField> fieldsList = new HashMap<String, DataField>();
	private Band parentBand = null;
	private String lineSeparator = null;
	private String minMaxKey = null;
	private int sequenceNumber = 0;
	private List<BatchBand> childBatches = new ArrayList<BatchBand>();
	
	/**
	 * @return the minMaxKey
	 */
	public String getMinMaxKey ()
	{
		return minMaxKey;
	}
	
	/**
	 * @param minMaxKey
	 *            the minMaxKey to set
	 */
	public void setMinMaxKey (String minMaxKey)
	{
		this.minMaxKey = minMaxKey;
	}
	
	public String getFieldValue (String fldName)
	{
		String fldValue = null;
		DataField field = null;
		
		if (fieldsList.containsKey(fldName))
		{
			field = fieldsList.get(fldName);
			fldValue = field.getValue();
		}
		// else its a custom field
		
		return fldValue;
	}
	
	public DataField getDataField (String name)
	{
		DataField field = null;
		field = fieldsList.get(name);
		
		return field;
	}
	
	public void setFieldValue (String fldName, DataField dataField)
	{
		fieldsList.put(fldName, dataField);
	}
	
	public Map<String, DataField> getFieldRow ()
	{
		return this.fieldsList;
	}
	
	/**
	 * @return the bandPath
	 */
	public String getBandPath ()
	{
		return bandPath;
	}
	
	/**
	 * @param bandPath
	 *            the bandPath to set
	 */
	public void setBandPath (String bandPath)
	{
		this.bandPath = bandPath;
	}
	
	public void addFields (Map<String, DataField> fieldsMap)
	{
		this.fieldsList = fieldsMap;
	}
	
	public void addChildBand (Band band)
	{
		childBands.addBand(band);
	}
	
	public List<Band> getChildBands (String key)
	{
		List<Band> lstBand = null;
		lstBand = childBands.getBands(key);
		return lstBand;
	}
	
	public Set<String> getAllBands ()
	{
		return childBands.getAllBands();
	}
	
	/**
	 * @return the name
	 */
	public String getName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName (String name)
	{
		this.name = name;
	}
	
	/**
	 * @return the id
	 */
	public String getId ()
	{
		return id;
	}
	
	/**
	 * @param id
	 *            the id to set
	 */
	public void setId (String id)
	{
		this.id = id;
	}
	
	/**
	 * @return the bandType
	 */
	public String getBandType ()
	{
		return bandType;
	}
	
	/**
	 * @param bandType
	 *            the bandType to set
	 */
	public void setBandType (String bandType)
	{
		this.bandType = bandType;
	}
	
	/**
	 * @return the parentBand
	 */
	public Band getParentBand ()
	{
		return parentBand;
	}
	
	/**
	 * @param parentBand
	 *            the parentBand to set
	 */
	public void setParentBand (Band parentBand)
	{
		this.parentBand = parentBand;
	}
	
	/**
	 * 
	 * <p>
	 * This helper method writes band data in to given stream
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param out
	 * @param delimiter
	 * @param qualifier
	 * @param bandDef
	 * @param isFirst
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	public void doWriteText (Writer out, String delimiter, String qualifier, InterfaceBandDef bandDef, boolean isFirst) throws ExecutionException
	{
		String fldVal = null;
		ExecutionException eExp = null;
		List<MappingField> listFields = null;
		Map<String, InterfaceBandDef> pBandDefs = null;
		boolean isPatrentSeq = false;
		StringBuilder lineData = null;
		String finalString = null;
		DataField dataField = null;
		String bandDelimiter = null;
		String bandQualifier = null;
		
		try
		{
			listFields = bandDef.getMappingFields();
			isPatrentSeq = findSequence();
			bandDelimiter = bandDef.getDelimiter();
			bandQualifier = bandDef.getQualifier();
			
			if (isPatrentSeq)
			{
				if (!fieldsList.isEmpty())
				{
					lineData = new StringBuilder();
//					lineData.append(lineSeparator);
					for (MappingField field : listFields)
					{
						if (IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType())
						{
							if (logger.isTraceEnabled())
								logger.trace("BandName:{}, FieldName:{} ", bandDef.getBandName(), field.getFieldName());
							dataField = fieldsList.get(field.getFieldName());
							fldVal = dataField.getValue();
							if (bandDelimiter != null)
							{
								if (field.getsequenceNmbr() != 1)
									fldVal = bandDelimiter + fldVal;
							}
							lineData.append(fldVal);
						}
					}
					finalString = lineData.toString();
					finalString = finalString.trim();
					if (finalString.length() < 1 && !bandDef.isMandatory())
					{
						if (logger.isTraceEnabled())
							logger.error("Band:" + bandDef.getBandName() + " is empty and abd is not mandagtory, so not writing in file");
					}
					else
					{
						if (null != this.getId())
							lineData.insert(0, (this.getId()));
						else if ( bandDelimiter != null)
							lineData = new StringBuilder( StringUtils.removeStart(lineData.toString(), bandDelimiter));
						
						if (isFirst)
							lineData.insert(0, lineSeparator);
						isFirst = true;
						out.write(lineData.toString());
						out.flush();
					}
				}
				
				CleanUpUtils.doClean(fieldsList);
			}
			pBandDefs = bandDef.getChildDefinitions().getBandDefinitions();
			for (BatchBand cBand : childBatches)
			{
				cBand.doWriteText(out, delimiter, qualifier, pBandDefs, isFirst);
				out.flush();
				isFirst = true;
			}
			if (!fieldsList.isEmpty())
			{
				lineData = new StringBuilder();
				for (MappingField field : listFields)
				{
					if (IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType())
					{
						if (logger.isTraceEnabled())
							logger.trace("BandName:" + bandDef.getBandName() + " FieldName:" + field.getFieldName());
						dataField = fieldsList.get(field.getFieldName());
						fldVal = dataField.getValue();
						if (bandDelimiter != null)
						{
							if (fldVal.contains(bandDelimiter) && bandQualifier != null)
								fldVal = bandQualifier + fldVal + bandQualifier;
							
							if (field.getsequenceNmbr() != 1)
								fldVal = bandDelimiter + fldVal;
						}
						lineData.append(fldVal);
					}
				}
				/*
				 * Check if data is empty and band is non mandatory do not write empty line in file.
				 */
				finalString = lineData.toString();
				finalString = finalString.trim();
				finalString = finalString.replaceAll("0", "");
				if (finalString.length() < 1 && !bandDef.isMandatory())
				{
					if (logger.isTraceEnabled())
						logger.error("Band:" + bandDef.getBandName() + " is empty and abd is not mandagtory, so not writing in file");
				}
				else
				{
					if (null != this.getId())
						lineData.insert(0, (this.getId()));
					else if ( bandDelimiter != null)
						lineData = new StringBuilder( StringUtils.removeStart(lineData.toString(), bandDelimiter));
						
					
					if ((!isFirst) || (isFirst && ! isPatrentSeq))
						lineData.insert(0, lineSeparator);
					
					isFirst = true;
					out.write(lineData.toString());
					out.flush();
				}
				
				CleanUpUtils.doClean(fieldsList);
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (IOException exp)
		{
			logger.error("Error while writing " + getName());
			eExp = new ExecutionException("error.iris.admin.writefile", new Object[]
			{ getName(), fieldsList }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			logger.error("Error while writing " + getName());
			eExp = new ExecutionException("error.iris.admin.writefile", new Object[]
			{ getName(), fieldsList }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(lineData);
			finalString = null;
		}
	}
	
	public void doWriteXML (int writerType, Element batchElement, InterfaceBandDef bandDef) throws ExecutionException
	{
		String fldVal = null;
		ExecutionException eExp = null;
		List<MappingField> listFields = null;
		Map<String, InterfaceBandDef> pBandDefs = null;
		Element currentElement = null;
		String expression = null;
		boolean isFirst = true;
		DataField dataField = null;
		int bandIndex = -1;
		
		try
		{
			listFields = bandDef.getMappingFields();
			if (!fieldsList.isEmpty())
			{
				for (MappingField field : listFields)
				{
					/*
					 * If field is not internal and name space then execute. Ie. for all other fields including attributes
					 */
					if (IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType()
							&& IrisAdminConstants.MAPPING_TYPE_NAMESPACE != field.getMappingType())
					{
						if (logger.isTraceEnabled())
							logger.trace("BandName:" + bandDef.getBandName() + " FieldName:" + field.getFieldName());
						
						dataField = fieldsList.get(field.getFieldName());
						fldVal = dataField.getValue();
						expression = field.getRelativeXPath();
						if (!expression.contains("@"))
						{
							currentElement = IrisAdminUtils.createBatchFromXPath(batchElement, expression , -1);
							currentElement.setText(fldVal);
						}
						else
							currentElement = IrisAdminUtils.createElementsFromXPath(batchElement, expression, fldVal, -1);
					}
				}
			}
			CleanUpUtils.doClean(fieldsList);
			pBandDefs = bandDef.getChildDefinitions().getBandDefinitions();
			for (BatchBand cBand : childBatches)
			{
				bandIndex = cBand.doWriteXML(writerType, batchElement, pBandDefs, isFirst, bandIndex);
				isFirst = false; // this field is not to create parent again
			}
		}
		catch (UnsupportedOperationException exp)
		{
			logger.error("Error while writing " + getName());
			eExp = new ExecutionException("error.iris.admin.writefile", new Object[]{ getName(), fieldsList }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IllegalArgumentException exp)
		{
			logger.error("Error while writing " + getName());
			eExp = new ExecutionException("error.iris.admin.writefile", new Object[]{ getName(), fieldsList }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (FormatException exp)
		{
			logger.error("Error while writing " + getName());
			eExp = new ExecutionException("error.iris.admin.writefile", new Object[]{ getName(), fieldsList }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			logger.error("Error while writing " + getName());
			eExp = new ExecutionException("error.iris.admin.writefile", new Object[]{ getName(), fieldsList }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
	}
	
	/**
	 * TODO
	 * 
	 * @return
	 */
	private boolean findSequence ()
	{
		boolean returnVal = true;
		for (BatchBand cBand : childBatches)
		{
			if (cBand.getSequenceNumber() < sequenceNumber)
			{
				returnVal = false;
				break;
				
			}
		}
		return returnVal;
	}
	
	/**
	 * @return the lineSeparator
	 */
	public String getLineSeparator ()
	{
		return lineSeparator;
	}
	
	/**
	 * @param lineSeparator
	 *            the lineSeparator to set
	 */
	public void setLineSeparator (String lineSeparator)
	{
		this.lineSeparator = lineSeparator;
	}
	
	
	public int getSequenceNumber ()
	{
		return sequenceNumber;
	}
	
	public void setSequenceNumber (int sequenceNumber)
	{
		this.sequenceNumber = sequenceNumber;
	}
	
	public List<BatchBand> getChildBatches ()
	{
		return childBatches;
	}
	
	public void addChildBatche (BatchBand batchBand)
	{
		childBatches.add(batchBand);
	}
	
	public int getChildBandsSize ()
	{
		return childBands.size();
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		name = null;
		id = null;
		bandPath = null;
		bandType = null;
		CleanUpUtils.doClose(childBands);
		CleanUpUtils.doClean(fieldsList);
		
		lineSeparator = null;
		minMaxKey = null;
		for (BatchBand batchBand :  childBatches)
		{
			CleanUpUtils.doClose(batchBand);
		}
		CleanUpUtils.doClean(childBatches);
	}

	/**
	 * @return the hasChilds
	 */
	public boolean hasChilds ()
	{
		if ( getChildBandsSize() > 0)
			return true;
		else
			return false;
	}
	
}
