/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : ModelChildBands.java
 * CREATED: May 6, 2013 10:48:00 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ModelChildBands.java,v 1.1 2014/07/25 05:57:43 ramap Exp $
 * @since 1.0.0
 */
public class ModelChildBands extends ModelAbstractBand
{
	
}
