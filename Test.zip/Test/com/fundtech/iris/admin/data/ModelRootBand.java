/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.data
 * FILE   : ModelRootBand.java
 * CREATED: May 10, 2013 2:35:07 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ModelRootBand.java,v 1.4 2015/10/19 12:08:13 ramap Exp $
 * @since 1.0.0
 */
public class ModelRootBand implements Closeable
{
	List<ModelBand> batchBands = new ArrayList<ModelBand>();
	
	public void addBatchBands (ModelBand batchBand)
	{
		batchBands.add(batchBand);
	}
	
	public List<ModelBand> getBatchBands ()
	{
		return batchBands;
	}
	
	public void cleanup()
	{
		CleanUpUtils.doClean(batchBands);
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		// BABU Auto-generated method stub
		
	}

}
