/*----------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.iris.admin.data
 * FILE     : DataZeroProofing.java
 * CREATED  : Jun 29, 2013 2:42:51 PM
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *--------------------------------------------------------------------------------------------------------------------*/
package com.fundtech.iris.admin.data;

/**
 * This class
 * 
 * @author Rohini Ghadge
 * @version $Id: ZeroProofing.java,v 1.3 2014/07/20 04:58:24 ramap Exp $
 */
public class ZeroProofing
{
	private String type = null;
	private int seqNumber = 0;
	private String primeBandName = null;
	private String primeFieldName = null;
	private String sourceBandName = null;
	private String sourceFieldName = null;
	private double primeValue = 0;
	private double sourceValue = 0;
	
	/**
	 * @return the type
	 */
	public String getType ()
	{
		return type;
	}
	
	/**
	 * @param type
	 *            the type to set
	 */
	public void setType (String type)
	{
		this.type = type;
	}
	
	/**
	 * @return the seqNumber
	 */
	public int getSeqNumber ()
	{
		return seqNumber;
	}
	
	/**
	 * @param seqNumber
	 *            the seqNumber to set
	 */
	public void setSeqNumber (int seqNumber)
	{
		this.seqNumber = seqNumber;
	}
	
	/**
	 * @return the primeBandName
	 */
	public String getPrimeBandName ()
	{
		return primeBandName;
	}
	
	/**
	 * @param primeBandName
	 *            the primeBandName to set
	 */
	public void setPrimeBandName (String primeBandName)
	{
		this.primeBandName = primeBandName;
	}
	
	/**
	 * @return the primeFieldName
	 */
	public String getPrimeFieldName ()
	{
		return primeFieldName;
	}
	
	/**
	 * @param primeFieldName
	 *            the primeFieldName to set
	 */
	public void setPrimeFieldName (String primeFieldName)
	{
		this.primeFieldName = primeFieldName;
	}
	
	/**
	 * @return the sourceBandName
	 */
	public String getSourceBandName ()
	{
		return sourceBandName;
	}
	
	/**
	 * @param sourceBandName
	 *            the sourceBandName to set
	 */
	public void setSourceBandName (String sourceBandName)
	{
		this.sourceBandName = sourceBandName;
	}
	
	/**
	 * @return the sourceFieldName
	 */
	public String getSourceFieldName ()
	{
		return sourceFieldName;
	}
	
	/**
	 * @param sourceFieldName
	 *            the sourceFieldName to set
	 */
	public void setSourceFieldName (String sourceFieldName)
	{
		this.sourceFieldName = sourceFieldName;
	}
	
	/**
	 * @return the primeValue
	 */
	public double getPrimeValue ()
	{
		return primeValue;
	}
	
	/**
	 * @param primeValue
	 *            the primeValue to set
	 */
	public void setPrimeValue (double primeValue)
	{
		this.primeValue = primeValue;
	}
	
	/**
	 * @return the sourceValue
	 */
	public double getSourceValue ()
	{
		return sourceValue;
	}
	
	/**
	 * @param sourceValue
	 *            the sourceValue to set
	 */
	public void setSourceValue (double sourceValue)
	{
		this.sourceValue = sourceValue;
	}
	
	public void addSourceValue (double sourceValue)
	{
		this.sourceValue = this.sourceValue + sourceValue;
	}
	
	public void countSourceValue ()
	{
		this.sourceValue = this.sourceValue + 1;
	}
	
	public boolean checkProof ()
	{
		/*
		 * we can't compare with equal or == coz double may go for rounding
		 */
		if (Math.abs(primeValue - sourceValue) < .0000001)
			return true;
		
		return false;
	}
}
