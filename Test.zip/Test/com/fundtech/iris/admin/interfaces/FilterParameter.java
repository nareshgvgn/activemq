/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : FilterParameter.java
 * CREATED: Jan 18, 2013 3:13:52 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: FilterParameter.java,v 1.2 2014/07/20 04:58:17 ramap Exp $
 * @since 1.0.0
 */
public class FilterParameter
{
	private String name = null;
	private String dataType = null;
	private String format = null;
	private int sequenceNbr = 0;
	private String defaultValue = null;
	private String derivationType = null;
	private String derivationLogic1 = null;
	private String derivationLogic2 = null;
	
	/**
	 * @return the name
	 */
	public String getName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName (String name)
	{
		this.name = name;
	}
	
	/**
	 * @return the dataType
	 */
	public String getDataType ()
	{
		return dataType;
	}
	
	/**
	 * @param dataType
	 *            the dataType to set
	 */
	public void setDataType (String dataType)
	{
		this.dataType = dataType;
	}
	
	/**
	 * @return the format
	 */
	public String getFormat ()
	{
		return format;
	}
	
	/**
	 * @param format
	 *            the format to set
	 */
	public void setFormat (String format)
	{
		this.format = format;
	}
	
	/**
	 * @return the sequenceNbr
	 */
	public int getSequenceNbr ()
	{
		return sequenceNbr;
	}
	
	/**
	 * @param sequenceNbr
	 *            the sequenceNbr to set
	 */
	public void setSequenceNbr (int sequenceNbr)
	{
		this.sequenceNbr = sequenceNbr;
	}
	
	/**
	 * @return the defaultValue
	 */
	public String getDefaultValue ()
	{
		return defaultValue;
	}
	
	/**
	 * @param defaultValue
	 *            the defaultValue to set
	 */
	public void setDefaultValue (String defaultValue)
	{
		this.defaultValue = defaultValue;
	}
	
	/**
	 * @return the derivationType
	 */
	public String getDerivationType ()
	{
		return derivationType;
	}
	
	/**
	 * @param derivationType
	 *            the derivationType to set
	 */
	public void setDerivationType (String derivationType)
	{
		this.derivationType = derivationType;
	}
	
	/**
	 * @return the derivationLogic1
	 */
	public String getDerivationLogic1 ()
	{
		return derivationLogic1;
	}
	
	/**
	 * @param derivationLogic1
	 *            the derivationLogic1 to set
	 */
	public void setDerivationLogic1 (String derivationLogic1)
	{
		this.derivationLogic1 = derivationLogic1;
	}
	
	/**
	 * @return the derivationLogic2
	 */
	public String getDerivationLogic2 ()
	{
		return derivationLogic2;
	}
	
	/**
	 * @param derivationLogic2
	 *            the derivationLogic2 to set
	 */
	public void setDerivationLogic2 (String derivationLogic2)
	{
		this.derivationLogic2 = derivationLogic2;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Filter Parameters Properties: [name=");
		builder.append(name);
		builder.append(", dataType=");
		builder.append(dataType);
		builder.append(", format=");
		builder.append(format);
		builder.append(", sequenceNbr=");
		builder.append(sequenceNbr);
		builder.append(", defaultValue=");
		builder.append(defaultValue);
		builder.append(", derivationType=");
		builder.append(derivationType);
		builder.append(", derivationLogic1=");
		builder.append(derivationLogic1);
		builder.append(", derivationLogic2=");
		builder.append(derivationLogic2);
		builder.append("]");
		return builder.toString();
	}
}
