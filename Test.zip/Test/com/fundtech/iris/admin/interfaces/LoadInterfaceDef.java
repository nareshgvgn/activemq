/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : LoadInterfaceDef.java
 * CREATED: Feb 5, 2013 10:33:19 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.Definitions;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.model.LoadModelDef;
import com.fundtech.iris.admin.model.ModelDef;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: LoadInterfaceDef.java,v 1.12 2016/12/08 11:25:41 ramap Exp $
 * @since 1.0.0
 */
public class LoadInterfaceDef
{
	
	private static Logger logger = LoggerFactory.getLogger(LoadInterfaceDef.class.getName());
	private Connection dbConnection = null;
	private String interfaceRecordKey = null;
	private ExecutionJobData jobData = null;
	
	private static final String zpSQL = "SELECT * FROM IRIS_INT_ZF_DTL WHERE PARENT_RECORD_KEY_NMBR= ?";
	private static  final String processSQL = "SELECT * FROM IRIS_INT_MST WHERE RECORD_KEY_NMBR= ?";
	private static final  String formatterSQL = "SELECT FORMATTER_CLASS, EXECUTION_CLASS, FORMAT_TYPE, LINE_SEPARATOR FROM MEDIUM_MST T WHERE T.MODEL_TYPE =? "
			+ " AND T.MEDIUM_TYPE = ? AND T.MEDIUM_NAME = ?";
	private static  final String routineSql = "SELECT *  FROM IRIS_INT_INPUT_PARAM WHERE  PARENT_RECORD_KEY_NMBR =?  ORDER BY ROUTINE_TYPE, SEQUENCE_NMBR";
	
	private static  final String splitSql = "SELECT * FROM IRIS_INT_SPLIT_PARAM WHERE  PARENT_RECORD_KEY_NMBR = ?";
	private static  final String fileGenSql = "SELECT T.MAPPED_CLASS, T.ROUTINE_TYPE FROM IRIS_ROUTINE_MST T WHERE (T.ROUTINE_NAME = ? AND T.ROUTINE_TYPE = 'FILENAME_GEN_ROUTINE')"
			+ " OR (T.ROUTINE_NAME = ? AND T.ROUTINE_TYPE = 'EMPTY_FILENAME_GEN_ROUTINE')";
	
	private static  final String filterSQL = "SELECT *  FROM IRIS_INT_FILTER_PARAM  WHERE PARENT_RECORD_KEY_NMBR = ?  ORDER BY SEQUENCE_NMBR";
	private static final String funcSQL ="SELECT * FROM IRIS_FUNCTION_MST";
			
	public LoadInterfaceDef(Connection dbConnection, ExecutionJobData jobData, String interfaceRecordKey)
	{
		this.dbConnection = dbConnection;
		this.interfaceRecordKey = interfaceRecordKey;
		this.jobData = jobData;
	}
	
	public InterfaceDef getinterfaceDef () throws LoadingException
	{
		Definitions definitions = null;
		InterfaceDef interfaceDef = null;
		ModelDef modelDef = null;
		LoadingException loadExp = null;
		Map<String, String> fundctions = null;
		Map<String, String> routines = null;
		String modelName = null;
		
		try
		{
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.TRACE, logger, "Before Loading defs");
			interfaceDef = loadInterfaceDef();
			loadZeroProofing(interfaceDef);
			
			definitions = Definitions.getInstance();
			if (definitions.sizeFunctions() < 1)
			{
				fundctions = loadFunctions();
				definitions.setFunctions(fundctions);
			}
			if (definitions.sizeRoutines() < 1)
			{
				routines = loadRoutines();
				definitions.setRoutines(routines);
				
			}
			modelName = interfaceDef.getModelName();
			
			if (definitions.containsModelDef(modelName))
				modelDef = definitions.getModelDef(modelName);
			else
			{
				modelDef = loadModelDef(modelName);
				definitions.addModelDef(modelDef);
			}
			interfaceDef.setDefinitionType(modelDef.getModelType());
			interfaceDef.setModelDef(modelDef);
			
		}
		catch (LoadingException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			loadExp = new LoadingException("error.irisdb.interface", new Object[] {}, exp);
			logger.error(IRISLogger.getText(loadExp));
			throw loadExp;
		}
		finally
		{
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.TRACE, logger, "After loading Defs");
		}
		return interfaceDef;
	}
	
	/**
	 * 
	 * @param _connection
	 * @return
	 */
	private void loadZeroProofing (InterfaceDef interfaceDef) throws LoadingException
	{
		ZeroProofingDef zeroProofingDef = null;
		PreparedStatement zpStmt = null;
		ResultSet zpRs = null;
		LoadingException intExp = null;
		
		try
		{
			// zeroProofingDef = new ZeroProofingDef();
			zpStmt = dbConnection.prepareStatement(zpSQL);
			zpStmt.clearParameters();
			zpStmt.setString(1, interfaceRecordKey);
			zpRs = zpStmt.executeQuery();
			while (zpRs.next())
			{
				zeroProofingDef = new ZeroProofingDef();
				
				zeroProofingDef.setType(zpRs.getString("ZF_TYPE").trim());
				zeroProofingDef.setSeqNumber(zpRs.getInt("SEQUENCE_NMBR"));
				zeroProofingDef.setPrimeBandName(zpRs.getString("PRIME_BAND_NAME"));
				zeroProofingDef.setPrimeFieldName(zpRs.getString("PRIME_FIELD_NAME"));
				zeroProofingDef.setSourceBandName(zpRs.getString("SOURCE_BAND_NAME"));
				if (zpRs.getString("ZF_TYPE").trim().equals("S"))
					zeroProofingDef.setSourceFieldName(zpRs.getString("SOURCE_FIELD_NAME"));
				else
					zeroProofingDef.setSourceFieldName(zpRs.getString("SOURCE_BAND_NAME"));
				interfaceDef.addZeroProofing(zeroProofingDef);
			}
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ zpSQL }, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ zpSQL }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(zpRs);
			HelperUtils.doClose(zpStmt);
		}
		
	}
	
	/**
	 * @param _connection
	 * @return
	 * @throws LoadingException
	 */
	private Map<String, String> loadRoutines () throws LoadingException
	{
		PreparedStatement rtnStmt = null;
		String rtnSQL = null;
		ResultSet rtnRs = null;
		LoadingException intExp = null;
		Map<String, String> routines = new HashMap<String, String>();
		rtnSQL = "SELECT * FROM IRIS_ROUTINE_MST";
		try
		{
			rtnStmt = dbConnection.prepareStatement(rtnSQL);
			rtnRs = rtnStmt.executeQuery();
			while (rtnRs.next())
			{
				routines.put(rtnRs.getString("ROUTINE_NAME"), rtnRs.getString("MAPPED_CLASS"));
			}
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ rtnSQL }, sqlExp);
			IRISLogger.getText(intExp);
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ rtnSQL }, exp);
			IRISLogger.getText(intExp);
			throw intExp;
		}
		finally
		{
			rtnSQL = null;
			HelperUtils.doClose(rtnRs);
			HelperUtils.doClose(rtnStmt);
		}
		return routines;
	}
	
	/**
	 * TODO
	 * 
	 * @param dbConnection
	 * @param interfaceCode
	 * @return
	 */
	private ModelDef loadModelDef (String modelName) throws LoadingException
	{
		LoadModelDef loader = null;
		ModelDef defination = null;
		
		loader = new LoadModelDef();
		defination = loader.loadDefinition(dbConnection, modelName);
		return defination;
	}
	
	/**
	 * TODO
	 * 
	 * @param definitions
	 */
	private Map<String, String> loadFunctions () throws LoadingException
	{
		PreparedStatement funcStmt = null;
		ResultSet funcRs = null;
		LoadingException intExp = null;
		Map<String, String> fundctions = new HashMap<String, String>();
		
		try
		{
			funcStmt = dbConnection.prepareStatement(funcSQL);
			funcRs = funcStmt.executeQuery();
			while (funcRs.next())
			{
				fundctions.put(funcRs.getString("FUNCTION_NAME"), funcRs.getString("MAPPED_CLASS"));
			}
		}
		
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ funcSQL }, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ funcSQL }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(funcRs);
			HelperUtils.doClose(funcStmt);
		}
		return fundctions;
	}
	
	/**
	 * TODO
	 * 
	 * @param interfaceCode
	 * @param processCode
	 * @return
	 */
	private InterfaceDef loadInterfaceDef () throws LoadingException
	{
		PreparedStatement processStmt = null;
		PreparedStatement formatterStmt = null;
		String strSql = null;
		ResultSet processRs = null;
		ResultSet formatterRs = null;
		InterfaceDef interfaceDef = null;
		InterfaceBandsDef bands = null;
		LoadBandDef loadBands = null;
		LoadingException intExp = null;
		String formatterClass = null;
		Map<String, FilterParameter> runTimeParameters = null;
		List<SplitParameter> splitParms = null;
		Map<String, List<RoutineParameter>> routinesParms = null;
		String mapType  = null;
		
		try
		{
			strSql = processSQL;
			processStmt = dbConnection.prepareStatement(strSql);
			processStmt.clearParameters();
			processStmt.setString(1, interfaceRecordKey);
			processRs = processStmt.executeQuery();
			
			// This sql should bring only one row or 0 rows
			if (processRs.next())
				interfaceDef = setInterfaceDefination(processRs);
			else
			// if 0 rows we need to terminate the execution
			{
				intExp = new LoadingException("error.irisdb.interface.nodata", new Object[]
				{ strSql }, null);
				IRISLogger.getText(intExp);
				throw intExp;
			}
			HelperUtils.doClose(processRs);
			HelperUtils.doClose(processStmt);
			interfaceDef.setDefinitionType(jobData.getMapType());
			strSql = formatterSQL;
			formatterStmt = dbConnection.prepareStatement(strSql);
			formatterStmt.clearParameters();
			if ( "SCH_SEGMENTED".equals(jobData.getMapType()) )
				mapType = "D";
			else
				mapType = jobData.getMapType();
				
			formatterStmt.setString(1, mapType);
			formatterStmt.setString(2, interfaceDef.getMediumType());
			formatterStmt.setString(3, interfaceDef.getMediumName());
			formatterRs = formatterStmt.executeQuery();
			if (formatterRs.next())
			{
				
				formatterClass = formatterRs.getString("FORMATTER_CLASS");
				interfaceDef.setFormatterClass(formatterClass);
				interfaceDef.setExecutionClass(formatterRs.getString("EXECUTION_CLASS"));
				interfaceDef.setFormatterType(formatterRs.getString("FORMAT_TYPE"));
				interfaceDef.setReaderLineSeparator(formatterRs.getString("LINE_SEPARATOR"));
				
			}
			else
			// if 0 rows we need to terminate the execution
			{
				intExp = new LoadingException("error.irisdb.interface.nodata", new Object[]	{ strSql }, null);
				logger.error(IRISLogger.getText(intExp));
				throw intExp;
			}
			
			if (interfaceDef.isGenFileNameRequired())
			{
				addFileNameGenClass(interfaceDef);
			}
			
			HelperUtils.doClose(formatterRs);
			HelperUtils.doClose(formatterStmt);
			
			loadBands = new LoadBandDef(interfaceRecordKey, interfaceDef);
			bands = loadBands.loadBandDefination(dbConnection);
			interfaceDef.setBandsDefinition(bands);
			runTimeParameters = loadFilterParms();
			interfaceDef.setRunTimeParms(runTimeParameters);
			if (interfaceDef.isSplitRequired())
			{
				splitParms = loadSplitParameters();
				interfaceDef.setSplitParameters(splitParms);
			}
			
			routinesParms = loadRoutinesParms();
			interfaceDef.setRoutines(routinesParms);
		}
		catch (LoadingException intexp)
		{
			jobData.setStatus("L");
			throw intexp;
		}
		catch (SQLException sqlExp)
		{
			jobData.setStatus("L");
			intExp = new LoadingException("error.irisdb.interface", new Object[]	{ strSql }, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("L");
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ strSql }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			strSql = null;
			HelperUtils.doClose(processRs);
			HelperUtils.doClose(processStmt);
			HelperUtils.doClose(formatterRs);
			HelperUtils.doClose(formatterStmt);
		}
		
		return interfaceDef;
	}
	
	/**
	 * 
	 * TODO
	 * 
	 * @return
	 * @throws LoadingException
	 */
	private Map<String, List<RoutineParameter>> loadRoutinesParms () throws LoadingException
	{
		Map<String, List<RoutineParameter>> routinesParms = null;
		List<RoutineParameter> parameters = null;
		PreparedStatement routineStmt = null;
		ResultSet routineRs = null;
		LoadingException intExp = null;
		RoutineParameter routinesParm = null;
		String currRoutineType = null;
		
		routinesParms = new HashMap<String, List<RoutineParameter>>();
		try
		{
			routineStmt = dbConnection.prepareStatement(routineSql);
			routineStmt.clearParameters();
			routineStmt.setString(1, interfaceRecordKey);
			routineRs = routineStmt.executeQuery();
			while (routineRs.next())
			{
				currRoutineType = routineRs.getString("ROUTINE_TYPE");
				if (routinesParms.containsKey(currRoutineType))
					parameters = routinesParms.get(currRoutineType);
				else
				{
					parameters = new ArrayList<RoutineParameter>();
					routinesParms.put(currRoutineType, parameters);
				}
				
				routinesParm = new RoutineParameter();
				routinesParm.setBandRef(routineRs.getString("BAND_NAME"));
				routinesParm.setFieldRef(routineRs.getString("FIELD_NAME"));
				routinesParm.setName(routineRs.getString("PARAMETER_NAME"));
				routinesParm.setSequence(routineRs.getInt("SEQUENCE_NMBR"));
				routinesParm.setParameterType(routineRs.getString("PARAMETER_TYPE"));
				parameters.add(routinesParm);
			}
		}
		catch (SQLException exp)
		{
			jobData.setStatus("L");
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ routineSql }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(routineRs);
			HelperUtils.doClose(routineStmt);
		}
		
		return routinesParms;
	}
	
	/**
	 * TODO
	 * 
	 * @return splitParameters
	 */
	private List<SplitParameter> loadSplitParameters () throws LoadingException
	{
		List<SplitParameter> splitParameters = null;
		PreparedStatement splitStmt = null;
		ResultSet splitRs = null;
		LoadingException intExp = null;
		SplitParameter splitParm = null;
		
		try
		{
			splitParameters = new ArrayList<SplitParameter>();
			splitStmt = dbConnection.prepareStatement(splitSql);
			splitStmt.clearParameters();
			splitStmt.setString(1, interfaceRecordKey);
			splitRs = splitStmt.executeQuery();
			
			while (splitRs.next())
			{
				splitParm = new SplitParameter();
				splitParm.setSeqNumber(splitRs.getInt("SEQUENCE_NMBR"));
				splitParm.setBandName(splitRs.getString("BAND_NAME"));
				splitParm.setFieldName(splitRs.getString("FIELD_NAME"));
				splitParameters.add(splitParm);
			}
		}
		catch (SQLException exp)
		{
			jobData.setStatus("L");
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ splitSql }, exp);
			IRISLogger.getText(intExp);
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(splitRs);
			HelperUtils.doClose(splitStmt);
		}
		
		return splitParameters;
	}
	
	/**
	 * TODO
	 * 
	 * @param dbConnection
	 * @param interfaceDefinition
	 */
	private void addFileNameGenClass (InterfaceDef def) throws Exception
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String type = null;
		LoadingException intExp = null;
		
		try
		{
			stmt = dbConnection.prepareStatement(fileGenSql);
			stmt.clearParameters();
			stmt.setString(1, def.getFileNamegenRoutine());
			stmt.setString(2, def.getEmptyFileGenRoutine());
			rs = stmt.executeQuery();
			
			while (rs.next())
			{
				type = rs.getString("ROUTINE_TYPE");
				if (IrisAdminConstants.FILENAME_GEN_ROUTINE.equals(type))
					def.setFileNameClass(rs.getString("MAPPED_CLASS"));
				else if (IrisAdminConstants.EMPTY_FILENAME_GEN_ROUTINE.equals(type))
					def.setEmptyFileNameClass(rs.getString("MAPPED_CLASS"));
			}
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ fileGenSql }, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ fileGenSql }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(rs);
			HelperUtils.doClose(stmt);
		}
		
	}
	
	/**
	 * This helper method loads the runtime ( filter) parameters for the given process and attaches to the process
	 * 
	 * @param dbConnection
	 * @param interfaceCode
	 * @param processCode
	 * @return
	 */
	private Map<String, FilterParameter> loadFilterParms () throws LoadingException
	{
		Map<String, FilterParameter> runTimeParameters = null;
		PreparedStatement filterStmt = null;
		ResultSet filterRs = null;
		FilterParameter filterParameter = null;
		LoadingException intExp = null;
		String paramName = null;
		
		runTimeParameters = new HashMap<String, FilterParameter>();
		try
		{
			filterStmt = dbConnection.prepareStatement(filterSQL);
			filterStmt.clearParameters();
			filterStmt.setString(1, interfaceRecordKey);
			filterRs = filterStmt.executeQuery();
			while (filterRs.next())
			{
				filterParameter = new FilterParameter();
				filterParameter.setDataType(filterRs.getString("PARAM_DATA_TYPE"));
				paramName = filterRs.getString("PARAMETER_NAME");
				filterParameter.setName(paramName);
				filterParameter.setDefaultValue(filterRs.getString("DEFAULT_VALUE"));
				filterParameter.setDerivationLogic1(filterRs.getString("DERIVATION_LOGIC1"));
				filterParameter.setDerivationLogic2(filterRs.getString("DERIVATION_LOGIC2"));
				filterParameter.setFormat(filterRs.getString("PARAM_FORMAT"));
				filterParameter.setSequenceNbr(filterRs.getInt("SEQUENCE_NMBR"));
				runTimeParameters.put(paramName, filterParameter);
				
			}
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[] { filterSQL }, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ filterSQL }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(filterRs);
			HelperUtils.doClose(filterStmt);
		}
		return runTimeParameters;
	}
	
	private InterfaceDef setInterfaceDefination (ResultSet rs) throws SQLException
	{
		InterfaceDef interfaceDef = null;
		String delimiter = null;
		
		interfaceDef = new InterfaceDef();
		interfaceDef.setModelName(rs.getString("MODEL_NAME"));
		interfaceDef.setInterfaceName(rs.getString("INTERFACE_NAME"));
		interfaceDef.setInterfaceDesc(rs.getString("INTERFACE_DESC"));
		interfaceDef.setEntityType(rs.getString("ENTITY_TYPE"));
		interfaceDef.setEntityCode(rs.getString("ENTITY_CODE"));
		interfaceDef.setMediumType(rs.getString("MEDIUM_TYPE").trim());
		interfaceDef.setMediumName(rs.getString("MEDIUM_NAME"));
		delimiter = rs.getString("DELIMITER");
		delimiter = getDelimiter(delimiter);
		interfaceDef.setDelimiter(delimiter);
		interfaceDef.setQualifier(rs.getString("QUALIFIER"));
		interfaceDef.setPreProcessingRoutine(rs.getString("PRE_PROCESSING_ROUTINE"));
		interfaceDef.setPostProcessingRoutine(rs.getString("POST_PROCESSING_ROUTINE"));
		interfaceDef.setPostUpdationRoutine(rs.getString("POST_UPDATION_ROUTINE"));
		interfaceDef.setReverseUpdateFlag(rs.getString("REVERSE_UPDATE_FLAG"));
		interfaceDef.setReverseUpdateRoutine(rs.getString("REVERSE_UPDATE_ROUTINE"));
		interfaceDef.setFileNameGenFlag(rs.getString("FILENAME_GEN_FLAG"));
		interfaceDef.setFileNamegenRoutine(rs.getString("FILENAME_GEN_ROUTINE"));
		interfaceDef.setEmptyFileGenFlag(rs.getString("EMPTY_FILENAME_GEN_FLAG"));
		interfaceDef.setEmptyFileGenRoutine(rs.getString("EMPTY_FILENAME_GEN_ROUTINE"));
		interfaceDef.setWhereCondition1(rs.getString("WHERE_CONDITION1"));
		interfaceDef.setWhereCondition2(rs.getString("WHERE_CONDITION2"));
		interfaceDef.setFileSplitFlag(rs.getString("FILE_SPLIT_FLAG"));
		interfaceDef.setSampleFileType(rs.getString("SAMPLE_FILE_TYPE"));
		interfaceDef.setSampleFileContent(rs.getString("SAMPLE_FILE_CONTENT_TYPE"));
		interfaceDef.setSellerCode(rs.getString("SELLER_CODE"));
		interfaceDef.setLineOffsetFlag(rs.getString("LINE_OFFSET_START_FLAG"));
		interfaceDef.setLineOffsetPosition(rs.getInt("LINE_OFFSET_VALUE"));
		interfaceDef.addParsendCondition(rs.getString("parsed_condition1"));
		interfaceDef.addParsendCondition(rs.getString("parsed_condition2"));
		return interfaceDef;
	}
	
	private String getDelimiter (String delimiter)
	{
		
		if ("CRLF".equals(delimiter))
			return "\r\n";
		else if ("LF".equals(delimiter))
			return "\n";
		else
			return delimiter;
		
	}
	
}
