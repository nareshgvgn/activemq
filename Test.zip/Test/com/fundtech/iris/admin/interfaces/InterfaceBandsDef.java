/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : InterfaceBandsDef.java
 * CREATED: Jan 6, 2013 10:53:31 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceBandsDef.java,v 1.2 2014/07/20 04:58:18 ramap Exp $
 * @since 1.0.0
 */
public class InterfaceBandsDef
{
	private Map<String, InterfaceBandDef> interfaceBandDefs = new LinkedHashMap<String, InterfaceBandDef>();
	
	/**
	 * Add Band Definition to list of definitions
	 * 
	 * @param interfaceBandDef
	 */
	public void addBandDefination (InterfaceBandDef interfaceBandDef)
	{
		interfaceBandDefs.put(interfaceBandDef.getBandName(), interfaceBandDef);
	}
	
	/**
	 * @return the interfaceBandDefs
	 */
	public Map<String, InterfaceBandDef> getBandDefinitions ()
	{
		return interfaceBandDefs;
	}
	
	/**
	 * @param interfaceBandDefs
	 *            the interfaceBandDefs to set
	 */
	public void setBandDefinitions (Map<String, InterfaceBandDef> interfaceBandDefs)
	{
		this.interfaceBandDefs = interfaceBandDefs;
	}
	
	public boolean containsBandDefinition (String key)
	{
		return interfaceBandDefs.containsKey(key);
	}
	
	public InterfaceBandDef getBandDefinition (String key)
	{
		return interfaceBandDefs.get(key);
	}
}
