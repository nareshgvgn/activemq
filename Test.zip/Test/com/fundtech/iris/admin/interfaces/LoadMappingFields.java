/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : LoadMappingFields.java
 * CREATED: Feb 6, 2013 11:48:15 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.CodeMap;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.NameSpaceElements;
import com.fundtech.iris.admin.exceptions.LoadingException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: LoadMappingFields.java,v 1.15 2016/10/19 14:04:54 ramap Exp $
 * @since 1.0.0
 */
public class LoadMappingFields
{
	private long totalBandLength = 0;
	private int bandIdPosition = 0;
	private int bandIdLength = 0;
	private static final Logger logger = LoggerFactory.getLogger(LoadMappingFields.class);
	private String interfaceType = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 * 
	 * @param processCode
	 * @param interfaceCode
	 */
	public LoadMappingFields(String interfaceType)
	{
		this.interfaceType = interfaceType;
	}
	
	/**
	 * TODO
	 * 
	 * @param bandName
	 * @param fieldsStmt
	 * @return
	 */
	public List<MappingField> loadFields (String bandRecordKey, String bandName, PreparedStatement fieldsStmt, PreparedStatement codeMapStmt)
			throws LoadingException
	{
		List<MappingField> mappingFields = null;
		ResultSet fieldsRs = null;
		MappingField currentField = null;
		ResultSet codeMapRs = null;
		CodeMap codeMap = null;
		String inputValue = null;
		String outputValue = null;
		String codeMapId = null;
		MappingField previousField = null;
		LoadingException intExp = null;
		String defaultVal = null;
		String restVal = null;
		
		mappingFields = new ArrayList<MappingField>();
		try
		{
			fieldsStmt.clearParameters();
			fieldsStmt.setString(1, bandRecordKey);
			fieldsStmt.setString(2, bandName);
			fieldsRs = fieldsStmt.executeQuery();
			while (fieldsRs.next())
			{
				currentField = setFields(fieldsRs, previousField);
				if (IrisAdminConstants.MAPPING_TYPE_CODEMAP == currentField.getMappingType() || IrisAdminConstants.MAPPING_TYPE_REFCODEMAP == currentField.getMappingType() )
				{
					codeMap = new CodeMap();
					codeMapStmt.clearParameters();
					codeMapId = currentField.getCodeMapRef();
					codeMapStmt.setString(1, codeMapId);
					codeMapRs = codeMapStmt.executeQuery();
					codeMap.setCodeMapId(codeMapId);
					while (codeMapRs.next())
					{
						defaultVal = codeMapRs.getString("default_value");
						restVal = codeMapRs.getString("others_value");
						inputValue = codeMapRs.getString("INPUT_VALUE");
						outputValue = codeMapRs.getString("OUTPUT_VALUE");
						codeMap.setCodeMap(inputValue, outputValue);
					}
					HelperUtils.doClose(codeMapRs);
					codeMap.setDefaultVal(defaultVal);
					codeMap.setRestVal(restVal);
					currentField.attachCodeMap(codeMap);
				}
				// currentField.setPreviousField(previousField);
				mappingFields.add(currentField);
				previousField = currentField;
			}
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.mappingfields", new Object[] {}, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(codeMapRs);
			HelperUtils.doClose(fieldsRs);
		}
		return mappingFields;
	}
	
	/**
	 * TODO
	 * 
	 * @param fieldsRs
	 * @return
	 */
	private MappingField setFields (ResultSet fieldsRs, MappingField previousField) throws SQLException
	{
		MappingField currentField = null;
		int fieldLength = 0;
		int seqNumber = 0;
		int startPosition = 0;
		int endPosition = 0;
		String restrictToSize = null;
		
		currentField = new MappingField();
		
		// Data describing the field
		currentField.setBandType(fieldsRs.getString("BAND_TYPE"));
		currentField.setBandName(fieldsRs.getString("BAND_NAME"));
		currentField.setFieldName(fieldsRs.getString("MODEL_FIELD_NAME")); // Column name has to change to FIELD_NAME
		currentField.setDataType(fieldsRs.getString("MODEL_FIELD_DATA_TYPE")); // Column name has to change to FIELD_DATA_TYPE
		fieldLength = fieldsRs.getInt("FIELD_LENGTH");
		restrictToSize = fieldsRs.getString("restrict_to_size");
		if ( IrisAdminConstants.CONSTANT_Y.equals(restrictToSize))
			currentField.setRestrictToSize(true);
		
		currentField.setFieldLength(fieldLength);
		currentField.setRemarks(fieldsRs.getString("FIELD_REMARKS"));
		currentField.setModelFieldLength(fieldsRs.getInt("MODEL_FIELD_LENGTH"));
		currentField.setFieldType(fieldsRs.getInt("FIELD_TYPE"));
		currentField.setMandatory(fieldsRs.getString("MANDATORY"));
		currentField.setFormat(fieldsRs.getString("FIELD_FORMAT"));
		currentField.setAlignment(fieldsRs.getString("FIELD_ALIGNMENT"));
		currentField.setPrecision(fieldsRs.getInt("DECIMAL_VALUE"));
		currentField.setFiller(fieldsRs.getString("FILLER"));
		currentField.setDefaultValue(fieldsRs.getString("DEFAULT_VALUE"));
		currentField.setconstantValue(fieldsRs.getString("CONSTANT_VALUE"));
		currentField.setMappingType(fieldsRs.getInt("MAPPING_TYPE"));
		// SEQUENCE_NMBR could be 0(null) if not reading from file ie. it could be Ref field or Cont Val ..etc
		seqNumber = fieldsRs.getInt("SEQUENCE_NMBR");
		currentField.setsequenceNmbr(seqNumber);
		
		// Details of Field Mapping
		currentField.setBandRef(fieldsRs.getString("REF_BAND_NAME")); // Reference Mapping Band
		currentField.setFieldRef(fieldsRs.getString("REF_FIELD")); // Reference Mapping Field
		currentField.setCodeMapRef(fieldsRs.getString("REF_CODE_MAP")); // Code Map Mapping
		currentField.setBatchRunningNoName(fieldsRs.getString("RESET_BAND_NAME")); // Running Sequence Number Mapping
		currentField.setDerivationLogic1(fieldsRs.getString("DERIVATION_LOGIC1")); // Function Mapping
		currentField.setDerivationLogic2(fieldsRs.getString("DERIVATION_LOGIC2"));
		currentField.setResetBandName(fieldsRs.getString("RESET_BAND_NAME"));
		currentField.setBatchTotalType(fieldsRs.getString("BATCH_TOTAL_TYPE")); // Batch Total Mapping for Download
		
		currentField.setAbsoluteXPath1(fieldsRs.getString("ABSOLUTE_XPATH1"));
		currentField.setAbsoluteXPath2(fieldsRs.getString("ABSOLUTE_XPATH2"));
		currentField.setRelativeXPath(fieldsRs.getString("RELATIVE_XPATH"));
		// Download details
		currentField.setorderBy(fieldsRs.getString("ORDER_BY"));
		currentField.setorderSequenceNmbr(fieldsRs.getInt("ORDER_SEQUENCE_NMBR"));
		// Check what Smita written
		
		startPosition = getStartPosition(previousField, seqNumber);
		endPosition = startPosition + fieldLength;
		currentField.setStartPosition(startPosition);
		currentField.setEndPosition(endPosition);
		if ( IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(interfaceType))
			currentField.setExecutionOrder(getUploadFieldOrder(currentField));
		return currentField;
	}
	
	

	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param currentField
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private int getUploadFieldOrder (MappingField field)
	{
		int retVal = 100;
		
		if (IrisAdminConstants.MAPPING_TYPE_DIRECT == field.getMappingType())
			retVal = 1;
		else if (IrisAdminConstants.MAPPING_TYPE_DYNAMIC == field.getMappingType())
			retVal = 1;
		else if (IrisAdminConstants.MAPPING_TYPE_NAMESPACE == field.getMappingType())
			retVal = 1;
		else if (IrisAdminConstants.MAPPING_TYPE_FILTER == field.getMappingType())
			retVal = 4;
		else if (IrisAdminConstants.MAPPING_TYPE_CODEMAP == field.getMappingType())
			retVal = 8;
		else if (IrisAdminConstants.MAPPING_TYPE_CONSTANT == field.getMappingType())
			retVal = 12;
		else if (IrisAdminConstants.MAPPING_TYPE_RUNNING_NO == field.getMappingType())
			retVal = 16;
		else if (IrisAdminConstants.MAPPING_TYPE_INTERNAL == field.getMappingType())
			retVal = 20;
		else if (IrisAdminConstants.MAPPING_TYPE_FUNCTION == field.getMappingType())
			retVal = 28;
		
		else if (IrisAdminConstants.MAPPING_TYPE_REFERENCED == field.getMappingType())
			retVal = 40;
		else if (IrisAdminConstants.MAPPING_TYPE_COMPLEX == field.getMappingType())
			retVal = 44;
		else if (IrisAdminConstants.MAPPING_TYPE_ROUTINE == field.getMappingType())
			retVal = 48;
		else if (IrisAdminConstants.MAPPING_TYPE_REFCODEMAP == field.getMappingType())
			retVal = 52;
		else if (IrisAdminConstants.MAPPING_TYPE_ISNULLCODEMAP == field.getMappingType())
			retVal = 1;
		else if (IrisAdminConstants.MAPPING_TYPE_IGNORE == field.getMappingType())//Ignore 
			retVal = 60;
		
		return retVal;
	}
	
	/**
	 * TODO
	 * 
	 * @param previousField
	 * @param seqNumber
	 * @return
	 */
	private int getStartPosition (MappingField previousField, int currentSeqNbr)
	{
		int previousEndPosition = 0;
		int previousSqNbr = 0;
		int startPosition = 0;
		
		if (previousField != null)
		{
			previousEndPosition = previousField.getEndPosition();
			previousSqNbr = previousField.getsequenceNmbr();
		}
		if (previousSqNbr < bandIdPosition && bandIdPosition < currentSeqNbr)
		{
			startPosition = previousEndPosition + bandIdLength;
		}
		else
			startPosition = previousEndPosition;
		
		return startPosition;
	}
	
	/**
	 * @return the totalBandLength
	 */
	public long getTotalBandLength ()
	{
		return totalBandLength;
	}
	
	/**
	 * @param totalBandLength
	 *            the totalBandLength to set
	 */
	public void setTotalBandLength (long totalBandLength)
	{
		this.totalBandLength = totalBandLength;
	}
	
	/**
	 * @return the bandIdPosition
	 */
	public int getBandIdPosition ()
	{
		return bandIdPosition;
	}
	
	/**
	 * @param bandIdPosition
	 *            the bandIdPosition to set
	 */
	public void setBandIdPosition (int bandIdPosition)
	{
		this.bandIdPosition = bandIdPosition;
	}
	
	/**
	 * @return the bandIdLength
	 */
	public int getBandIdLength ()
	{
		return bandIdLength;
	}
	
	/**
	 * @param bandIdLength
	 *            the bandIdLength to set
	 */
	public void setBandIdLength (int bandIdLength)
	{
		this.bandIdLength = bandIdLength;
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandRecordkey
	 * @param bandName
	 * @param nameSpaceStmt
	 * @param nameSpaceMap
	 * </pre></p>
	 */
	public List<NameSpaceElements> loadNameSpacesFields (String bandRecordKey, String bandName, PreparedStatement nameSpaceStmt) throws LoadingException
	{
		ResultSet nameSpaceRs = null;
		List<NameSpaceElements> nameSpaceList = null;
		NameSpaceElements nameSpace = null;
		String absXpath1 = null;
		String[] tokens = null;
		LoadingException intExp = null;
		try
		{
			
			nameSpaceStmt.clearParameters();
			nameSpaceStmt.setString(1, bandRecordKey);
			nameSpaceStmt.setString(2, bandName);
			nameSpaceRs = nameSpaceStmt.executeQuery();
			nameSpaceList = new ArrayList<NameSpaceElements>();
			while (nameSpaceRs.next())
			{
				nameSpace = new NameSpaceElements();
				nameSpace.setBandName(nameSpaceRs.getString("BAND_NAME"));
				nameSpace.setNameSpaceURI(nameSpaceRs.getString("CONSTANT_VALUE"));
				absXpath1 = nameSpaceRs.getString("ABSOLUTE_XPATH1");
				nameSpace.setAbsoluteXPath1(absXpath1);
				tokens = absXpath1.split(":");
				nameSpace.setNameSpace(tokens[0]);
				if ( tokens.length > 1)
					nameSpace.setPrefix(tokens[1]);
				nameSpace.setAbsoluteXPath2(nameSpaceRs.getString("ABSOLUTE_XPATH2"));
				nameSpace.setRelativeXPath(nameSpaceRs.getString("RELATIVE_XPATH"));
				nameSpaceList.add(nameSpace);
			}
			
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.nameSpacesFields", new Object[] {}, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch ( Exception exp)
		{
			intExp = new LoadingException("error.irisdb.nameSpacesFields", new Object[] {}, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(nameSpaceRs);
		}
		return nameSpaceList;
		
	}

}
