/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : ZeroProofingDef.java
 * CREATED: Jun 27, 2013 11:31:42 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ZeroProofingDef.java,v 1.2 2014/07/20 04:58:17 ramap Exp $
 * @since 1.0.0
 */
public class ZeroProofingDef
{
	private String type = null;
	private int seqNumber = 0;
	private String primeBandName = null;
	private String primeFieldName = null;
	private String sourceBandName = null;
	private String sourceFieldName = null;
	
	/**
	 * @return the type
	 */
	public String getType ()
	{
		return type;
	}
	
	/**
	 * @param type
	 *            the type to set
	 */
	public void setType (String type)
	{
		this.type = type;
	}
	
	/**
	 * @return the seqNumber
	 */
	public int getSeqNumber ()
	{
		return seqNumber;
	}
	
	/**
	 * @param seqNumber
	 *            the seqNumber to set
	 */
	public void setSeqNumber (int seqNumber)
	{
		this.seqNumber = seqNumber;
	}
	
	/**
	 * @return the primeBandName
	 */
	public String getPrimeBandName ()
	{
		return primeBandName;
	}
	
	/**
	 * @param primeBandName
	 *            the primeBandName to set
	 */
	public void setPrimeBandName (String primeBandName)
	{
		this.primeBandName = primeBandName;
	}
	
	/**
	 * @return the primeFieldName
	 */
	public String getPrimeFieldName ()
	{
		return primeFieldName;
	}
	
	/**
	 * @param primeFieldName
	 *            the primeFieldName to set
	 */
	public void setPrimeFieldName (String primeFieldName)
	{
		this.primeFieldName = primeFieldName;
	}
	
	/**
	 * @return the sourceBandName
	 */
	public String getSourceBandName ()
	{
		return sourceBandName;
	}
	
	/**
	 * @param sourceBandName
	 *            the sourceBandName to set
	 */
	public void setSourceBandName (String sourceBandName)
	{
		this.sourceBandName = sourceBandName;
	}
	
	/**
	 * @return the sourceFieldName
	 */
	public String getSourceFieldName ()
	{
		return sourceFieldName;
	}
	
	/**
	 * @param sourceFieldName
	 *            the sourceFieldName to set
	 */
	public void setSourceFieldName (String sourceFieldName)
	{
		this.sourceFieldName = sourceFieldName;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Zero Proofing Properties: [type=");
		builder.append(type);
		builder.append(", seqNumber=");
		builder.append(seqNumber);
		builder.append(", primeBandName=");
		builder.append(primeBandName);
		builder.append(", primeFieldName=");
		builder.append(primeFieldName);
		builder.append(", sourceBandName=");
		builder.append(sourceBandName);
		builder.append(", sourceFieldName=");
		builder.append(sourceFieldName);
		builder.append("]");
		return builder.toString();
	}
	
}
