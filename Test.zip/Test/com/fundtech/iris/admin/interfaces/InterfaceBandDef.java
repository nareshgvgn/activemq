/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : InterfaceBandDef.java
 * CREATED: Jan 6, 2013 10:56:32 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

import java.util.ArrayList;
import java.util.List;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;

/**
 * This is a POJO class which hold the Band Definition
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceBandDef.java,v 1.6 2016/10/19 14:04:55 ramap Exp $
 * @since 1.0.0
 */
public class InterfaceBandDef
{
	/**
	 * Interface Band Type, which is pre-loaded at interface definition
	 */
	private String bandType = null;
	
	/**
	 * Band Id
	 */
	private String bandId = null;
	
	/**
	 * Band Name
	 */
	private String BandName = null;
	
	/**
	 * X Path1 of XML/XSD, which indicates repetitiveness
	 */
	private String absoluteXPath1 = null;
	
	/**
	 * X Path2 of XML/XSD, which indicates repetitiveness
	 */
	private String absoluteXPath2 = null;
	
	private String bandXPath = null;
	private String parentXPath = null;
	private String relativeXPath = null;
	
	/**
	 * Band is mandatory or not for the process. if Interface level band is mandatory, then Process level it must be mandatory
	 */
	private boolean mandatory = false;
	
	private InterfaceBandsDef childDefinitions = new InterfaceBandsDef();
	
	/**
	 * Parent Band Name
	 */
	private String parentBandName = null;
	
	private InterfaceBandDef parentBandDef = null;
	
	// TODO This list must be in order, may be we can use apache Order List?????
	private List<MappingField> mappingFields = new ArrayList<MappingField>();
	
	private int bandIdPosition = 0;
	
	private int bandIdLength = 0;
	
	private int bandLevel = 0;
	
	// This bandPath is for internal while retrieving data
	private String bandPath = null;
	
	private int sequenceNumber = 0;
	
//	private int maxSequenceNumber = 0;
	
	private String formatterClass = null;
	private String formatterLineSepartor = null;
	private String dataStoreName = null;
	private String delimiter = null;
	private String qualifier = null;
	
	private int startSequenceNumber = 0;
	private int endsequenceNumber = 0;
	
	private String whereCondition = null;
	private String updateQuery = null;
	
	
	/**
	 * @return the bandPath
	 */
	public String getBandPath ()
	{
		return bandPath;
	}
	
	/**
	 * @param bandPath
	 *            the bandPath to set
	 */
	public void setBandPath (String bandPath)
	{
		this.bandPath = bandPath;
	}
	
	/**
	 * @return the bandIdPosition
	 */
	public int getBandIdPosition ()
	{
		return bandIdPosition;
	}
	
	/**
	 * @param bandPosition
	 *            the bandIdPosition to set
	 */
	public void setBandIdPosition (int bandIdPosition)
	{
		this.bandIdPosition = bandIdPosition;
	}
	
	/**
	 * @return the bandIdLength
	 */
	public int getBandIdLength ()
	{
		return bandIdLength;
	}
	
	/**
	 * @param bandLength
	 *            the bandIdLength to set
	 */
	public void setBandIdLength (int bandIdLength)
	{
		this.bandIdLength = bandIdLength;
	}
	
	/**
	 * @return the bandLevel
	 */
	public int getBandLevel ()
	{
		return bandLevel;
	}
	
	/**
	 * @param bandLevel
	 *            the bandLevel to set
	 */
	public void setBandLevel (int bandLevel)
	{
		this.bandLevel = bandLevel;
	}
	
	/**
	 * @return the bandType
	 */
	public String getBandType ()
	{
		return bandType;
	}
	
	/**
	 * @param bandType
	 *            the bandType to set
	 */
	public void setBandType (String bandType)
	{
		this.bandType = bandType;
	}
	
	/**
	 * @return the bandId
	 */
	public String getBandId ()
	{
		return bandId;
	}
	
	/**
	 * @param bandId
	 *            the bandId to set
	 */
	public void setBandId (String bandId)
	{
		this.bandId = bandId;
	}
	
	/**
	 * @return the bandName
	 */
	public String getBandName ()
	{
		return BandName;
	}
	
	/**
	 * @param bandName
	 *            the bandName to set
	 */
	public void setBandName (String bandName)
	{
		BandName = bandName;
	}
	
	/**
	 * @return the absXPath1
	 */
	public String getAbsoluteXPath1 ()
	{
		return absoluteXPath1;
	}
	
	/**
	 * @param absXPath1
	 *            the absXPath1 to set
	 */
	public void setAbsoluteXPath1 (String bandXPath1)
	{
		this.absoluteXPath1 = bandXPath1;
	}
	
	/**
	 * @return the bandXPath2
	 */
	public String getAbsoluteXPath2 ()
	{
		return absoluteXPath2;
	}
	
	/**
	 * @param bandXPath2
	 *            the bandXPath2 to set
	 */
	public void setAbsoluteXPath2 (String bandXPath2)
	{
		this.absoluteXPath2 = bandXPath2;
	}
	
	/**
	 * @return the mandatory
	 */
	public boolean isMandatory ()
	{
		return mandatory;
	}
	
	/**
	 * @param mandatory
	 *            the mandatory to set
	 */
	public void setMandatory (String mandatory)
	{
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(mandatory))
			this.mandatory = true;
		else
			this.mandatory = false;
		
	}
	
	/**
	 * @return the parentBand
	 */
	public InterfaceBandsDef getChildDefinitions ()
	{
		return childDefinitions;
	}
	
	/**
	 * @param parentBand
	 *            the parentBand to set
	 */
	public void addChildBand (InterfaceBandDef childBand)
	{
		childDefinitions.addBandDefination(childBand);
	}
	
	/**
	 * @return the parentBandName
	 */
	public String getParentBandName ()
	{
		return parentBandName;
	}
	
	/**
	 * @param parentBandName
	 *            the parentBandName to set
	 */
	public void setParentBandName (String parentBandName)
	{
		this.parentBandName = parentBandName;
	}
	
	/**
	 * @return the mappingFields
	 */
	public List<MappingField> getMappingFields ()
	{
		return mappingFields;
	}
	
	/**
	 * @param mappingFields
	 *            the mappingFields to set
	 */
	public void setMappingFields (List<MappingField> mappingFields)
	{
		this.mappingFields = mappingFields;
	}
	
	/**
	 * @param mappingField
	 */
	public void addMappingField (MappingField mappingField)
	{
		mappingFields.add(mappingField);
	}
	
	public boolean isChildBand (String bandId)
	{
		for (InterfaceBandDef band : childDefinitions.getBandDefinitions().values())
		{
			if (band.getBandId().equals(bandId))
				return true;
		}
		return false;
	}
	
	public InterfaceBandDef getChildBand (String bandId)
	{
		for (InterfaceBandDef band : childDefinitions.getBandDefinitions().values())
		{
			if (band.getBandId().equals(bandId))
				return band;
		}
		return null;
	}
	
	public String getRelativeXPath ()
	{
		return relativeXPath;
	}
	
	public void setRelativeXPath (String relativeXPath)
	{
		this.relativeXPath = relativeXPath;
	}
	
	public int getSequenceNumber ()
	{
		return sequenceNumber;
	}
	
	public void setSequenceNumber (int sequenceNumber)
	{
		this.sequenceNumber = sequenceNumber;
	}
	
//	public int getMaxSequenceNumber ()
//	{
//		return maxSequenceNumber;
//	}
//	
//	public void setMaxSequenceNumber (int maxSequenceNumber)
//	{
//		this.maxSequenceNumber = maxSequenceNumber;
//	}
	
	public String getBandXPath ()
	{
		return bandXPath;
	}
	
	public void setBandXPath (String bandXPath)
	{
		this.bandXPath = bandXPath;
	}
	
	public String getParentXPath ()
	{
		return parentXPath;
	}
	
	public void setParentXPath (String parentXPath)
	{
		this.parentXPath = parentXPath;
	}
	
	/**
	 * @return the formatterClass
	 */
	public String getFormatterClass ()
	{
		return formatterClass;
	}
	
	/**
	 * @param formatterClass
	 *            the formatterClass to set
	 */
	public void setFormatterClass (String formatterClass)
	{
		this.formatterClass = formatterClass;
	}
	
	/**
	 * @return the dataStoreName
	 */
	public String getMediumName ()
	{
		return dataStoreName;
	}
	
	/**
	 * @param dataStoreName
	 *            the dataStoreName to set
	 */
	public void setMediumName (String dataStoreName)
	{
		this.dataStoreName = dataStoreName;
	}
	
	/**
	 * @return the delimiter
	 */
	public String getDelimiter ()
	{
		return delimiter;
	}
	
	/**
	 * @param delimiter
	 *            the delimiter to set
	 */
	public void setDelimiter (String delimiter)
	{
		this.delimiter = delimiter;
	}
	
	/**
	 * @return the qualifier
	 */
	public String getQualifier ()
	{
		return qualifier;
	}
	
	/**
	 * @param qualifier
	 *            the qualifier to set
	 */
	public void setQualifier (String qualifier)
	{
		this.qualifier = qualifier;
	}
	
	/**
	 * @return the formatterLineSepartor
	 */
	public String getFormatterLineSepartor ()
	{
		if (formatterLineSepartor == null)
			formatterLineSepartor = System.getProperty("line.separator");
		
		return formatterLineSepartor;
	}
	
	/**
	 * @param formatterLineSepartor
	 *            the formatterLineSepartor to set
	 */
	public void setFormatterLineSepartor (String formatterLineSepartor)
	{
		this.formatterLineSepartor = formatterLineSepartor;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Band Def Properties: [bandType=");
		builder.append(bandType);
		builder.append(", bandId=");
		builder.append(bandId);
		builder.append(", BandName=");
		builder.append(BandName);
		builder.append(", absoluteXPath1=");
		builder.append(absoluteXPath1);
		builder.append(", absoluteXPath2=");
		builder.append(absoluteXPath2);
		builder.append(", bandXPath=");
		builder.append(bandXPath);
		builder.append(", parentXPath=");
		builder.append(parentXPath);
		builder.append(", relativeXPath=");
		builder.append(relativeXPath);
		builder.append(", mandatory=");
		builder.append(mandatory);
		builder.append(", childDefinitions=");
		builder.append(childDefinitions);
		builder.append(", parentBandName=");
		builder.append(parentBandName);
		builder.append(", mappingFields=");
		builder.append(mappingFields);
		builder.append(", bandIdPosition=");
		builder.append(bandIdPosition);
		builder.append(", bandIdLength=");
		builder.append(bandIdLength);
		builder.append(", bandLevel=");
		builder.append(bandLevel);
		builder.append(", bandPath=");
		builder.append(bandPath);
		builder.append(", sequenceNumber=");
		builder.append(sequenceNumber);
//		builder.append(", maxSequenceNumber=");
//		builder.append(maxSequenceNumber);
		builder.append(", formatterClass=");
		builder.append(formatterClass);
		builder.append(", formatterLineSepartor=");
		builder.append(formatterLineSepartor);
		builder.append(", dataStoreName=");
		builder.append(dataStoreName);
		builder.append(", delimiter=");
		builder.append(delimiter);
		builder.append(", qualifier=");
		builder.append(qualifier);
		builder.append("]");
		return builder.toString();
	}
	
	/**
	 * @return the parentBandDef
	 */
	public InterfaceBandDef getParentBandDef ()
	{
		return parentBandDef;
	}
	
	/**
	 * @param parentBandDef
	 *            the parentBandDef to set
	 */
	public void setParentBandDef (InterfaceBandDef parentBandDef)
	{
		this.parentBandDef = parentBandDef;
	}

	/**
	 * @return the startSequenceNumber
	 */
	public int getStartSequenceNumber ()
	{
		return startSequenceNumber;
	}

	/**
	 * @param startSequenceNumber the startSequenceNumber to set
	 */
	public void setStartSequenceNumber (int startSequenceNumber)
	{
		this.startSequenceNumber = startSequenceNumber;
	}

	/**
	 * @return the endsequenceNumber
	 */
	public int getEndsequenceNumber ()
	{
		return endsequenceNumber;
	}

	/**
	 * @param endsequenceNumber the endsequenceNumber to set
	 */
	public void setEndsequenceNumber (int endsequenceNumber)
	{
		this.endsequenceNumber = endsequenceNumber;
	}

	/**
	 * @return the whereCondition
	 */
	public String getWhereCondition ()
	{
		return whereCondition;
	}

	/**
	 * @param whereCondition the whereCondition to set
	 */
	public void setWhereCondition (String whereCondition)
	{
		this.whereCondition = whereCondition;
	}

	/**
	 * @return the updateQuery
	 */
	public String getUpdateQuery ()
	{
		return updateQuery;
	}

	/**
	 * @param updateQuery the updateQuery to set
	 */
	public void setUpdateQuery (String updateQuery)
	{
		this.updateQuery = updateQuery;
	}
	
}
