/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : SplitParameter.java
 * CREATED: Oct 11, 2013 3:18:17 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: SplitParameter.java,v 1.2 2014/07/20 04:58:17 ramap Exp $
 * @since 1.0.0
 */
public class SplitParameter
{
	private String bandName = null;
	private String fieldName = null;
	private int seqNumber = 0;
	
	public String getBandName ()
	{
		return bandName;
	}
	
	public void setBandName (String bandName)
	{
		this.bandName = bandName;
	}
	
	public String getFieldName ()
	{
		return fieldName;
	}
	
	public void setFieldName (String fieldName)
	{
		this.fieldName = fieldName;
	}
	
	public int getSeqNumber ()
	{
		return seqNumber;
	}
	
	public void setSeqNumber (int seqNumber)
	{
		this.seqNumber = seqNumber;
	}
	
}
