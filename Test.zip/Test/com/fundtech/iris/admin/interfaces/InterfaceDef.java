/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : InterfaceDef.java
 * CREATED: Jan 6, 2013 10:14:36 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.NameSpaceElements;
import com.fundtech.iris.admin.model.ModelDef;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceDef.java,v 1.7 2016/12/08 11:25:40 ramap Exp $
 * @since 1.0.0
 */
public class InterfaceDef
{
	private String modelName = null;
	private String interfaceName = null;
	private String interfaceDesc = null;
	private String entityType = null;
	private String entityCode = null;
	private String mediumType = null;
	private String mediumName = null;
	private String formatterType = null;
	private String delimiter = null;
	private String qualifier = null;
	private String preProcessingRoutine = null;
	private String postProcessingRoutine = null;
	private String postUpdationRoutine = null;
	private boolean reverseUpdateFlag = false;
	private String reverseUpdateRoutine = null;
	private boolean genFileNameRequired = false;
	private String fileNamegenRoutine = null;
	private String fileNameClass = null;
	private boolean emptyFileRequired = false;
	private String emptyFileGenRoutine = null;
	private String emptyFileNameClass = null;
	private String whereCondition1 = null;
	private String whereCondition2 = null;
	private boolean splitRequired = false;
	private Object sampleFile = null;
	private String sampleFileContent = null;
	private String sampleFileType = null;
	private String sellerCode = null;
	private String formatterClass = null;
	private String executionClass = null;
	private String readerLineSeparator = null;
	private String definitionType = null;
	private String parsendCondition = null;
	private Map<String, FilterParameter> runTimeParameters = null;
	private InterfaceBandsDef interfaceBandsDef = null;
	private Map<String, List<RoutineParameter>> routines = new HashMap<String, List<RoutineParameter>>();
	private Map<String, ZeroProofingDef> zeroProofings = new HashMap<String, ZeroProofingDef>();
	private Map<String, String> zeroProofingPair = new HashMap<String, String>();
	private List<SplitParameter> splitParameters = new ArrayList<SplitParameter>();
	private ModelDef mosdelDef = null;
	private String lineOffsetFlag = null;
	private int lineOffsetPosition = 0;
	
	private Map<String,List<NameSpaceElements>> nameSpaceElements = new LinkedHashMap<String, List<NameSpaceElements>>();
	
	public void addZeroProofing (ZeroProofingDef zeroProofingDef)
	{
		String key = null;
		
		key = zeroProofingDef.getSourceFieldName();
		zeroProofings.put(key, zeroProofingDef);
		zeroProofingPair.put(zeroProofingDef.getPrimeFieldName(), zeroProofingDef.getSourceFieldName());
	}
	
	public boolean containsZeroProofing (String key)
	{
		return zeroProofings.containsKey(key);
	}
	
	public ZeroProofingDef getZeroProofing (String key)
	{
		return zeroProofings.get(key);
	}
	
	public String getZeroProofingSourceKey (String prikeKey)
	{
		return zeroProofingPair.get(prikeKey);
	}
	
	public boolean containsProofingPrimeKey (String prikeKey)
	{
		return zeroProofingPair.containsKey(prikeKey);
	}
	
	/**
	 * @return the modelName
	 */
	public String getModelName ()
	{
		return modelName;
	}
	
	/**
	 * @param modelName
	 *            the modelName to set
	 */
	public void setModelName (String modelName)
	{
		this.modelName = modelName;
	}
	
	/**
	 * @return the interfaceName
	 */
	public String getInterfaceName ()
	{
		return interfaceName;
	}
	
	/**
	 * @param interfaceName
	 *            the interfaceName to set
	 */
	public void setInterfaceName (String processCode)
	{
		this.interfaceName = processCode;
	}
	
	/**
	 * @return the entityType
	 */
	public String getEntityType ()
	{
		return entityType;
	}
	
	/**
	 * @param entityType
	 *            the entityType to set
	 */
	public void setEntityType (String entityType)
	{
		this.entityType = entityType;
	}
	
	/**
	 * @return the entityCode
	 */
	public String getEntityCode ()
	{
		return entityCode;
	}
	
	/**
	 * @param entityCode
	 *            the entityCode to set
	 */
	public void setEntityCode (String entityCode)
	{
		this.entityCode = entityCode;
	}
	
	/**
	 * @return the mediumType
	 */
	public String getMediumType ()
	{
		return mediumType;
	}
	
	/**
	 * @param mediumType
	 *            the mediumType to set
	 */
	public void setMediumType (String dataStoreType)
	{
		this.mediumType = dataStoreType;
	}
	
	/**
	 * @return the mediumName
	 */
	public String getMediumName ()
	{
		return mediumName;
	}
	
	/**
	 * @param mediumName
	 *            the mediumName to set
	 */
	public void setMediumName (String dataStoreName)
	{
		this.mediumName = dataStoreName;
	}
	
	/**
	 * @return the delimiter
	 */
	public String getDelimiter ()
	{
		return delimiter;
	}
	
	/**
	 * @param delimiter
	 *            the delimiter to set
	 */
	public void setDelimiter (String delimiter)
	{
		this.delimiter = delimiter;
	}
	
	/**
	 * @return the qualifier
	 */
	public String getQualifier ()
	{
		return qualifier;
	}
	
	/**
	 * @param qualifier
	 *            the qualifier to set
	 */
	public void setQualifier (String qualifier)
	{
		this.qualifier = qualifier;
	}
	
	/**
	 * @return the preProcessingRoutine
	 */
	public String getPreProcessingRoutine ()
	{
		return preProcessingRoutine;
	}
	
	/**
	 * @param preProcessingRoutine
	 *            the preProcessingRoutine to set
	 */
	public void setPreProcessingRoutine (String preProcessingRoutine)
	{
		this.preProcessingRoutine = preProcessingRoutine;
	}
	
	/**
	 * @return the postProcessingRoutine
	 */
	public String getPostProcessingRoutine ()
	{
		return postProcessingRoutine;
	}
	
	/**
	 * @param postProcessingRoutine
	 *            the postProcessingRoutine to set
	 */
	public void setPostProcessingRoutine (String postProcessingRoutine)
	{
		this.postProcessingRoutine = postProcessingRoutine;
	}
	
	/**
	 * @return the postUpdationRoutine
	 */
	public String getPostUpdationRoutine ()
	{
		return postUpdationRoutine;
	}
	
	/**
	 * @param postUpdationRoutine
	 *            the postUpdationRoutine to set
	 */
	public void setPostUpdationRoutine (String postUpdationRoutine)
	{
		this.postUpdationRoutine = postUpdationRoutine;
	}
	
	/**
	 * @return the reverseUpdateFlag
	 */
	public boolean isReverseUpdateFlag ()
	{
		return reverseUpdateFlag;
	}
	
	/**
	 * @param reverseUpdateFlag
	 *            the reverseUpdateFlag to set
	 */
	public void setReverseUpdateFlag (String reverseUpdateFlag)
	{
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(reverseUpdateFlag))
			this.reverseUpdateFlag = true;
		else
			this.reverseUpdateFlag = false;
	}
	
	/**
	 * @return the reverseUpdateRoutine
	 */
	public String getReverseUpdateRoutine ()
	{
		return reverseUpdateRoutine;
	}
	
	/**
	 * @param reverseUpdateRoutine
	 *            the reverseUpdateRoutine to set
	 */
	public void setReverseUpdateRoutine (String reverseUpdateRoutine)
	{
		this.reverseUpdateRoutine = reverseUpdateRoutine;
	}
	
	/**
	 * @return the genFileNameRequired
	 */
	public boolean isGenFileNameRequired ()
	{
		return genFileNameRequired;
	}
	
	/**
	 * @param genFileNameRequired
	 *            the genFileNameRequired to set
	 */
	public void setFileNameGenFlag (String fileNamegenFlag)
	{
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(fileNamegenFlag))
			this.genFileNameRequired = true;
		else
			this.genFileNameRequired = false;
	}
	
	/**
	 * @return the fileNamegenRoutine
	 */
	public String getFileNamegenRoutine ()
	{
		return fileNamegenRoutine;
	}
	
	/**
	 * @param fileNamegenRoutine
	 *            the fileNamegenRoutine to set
	 */
	public void setFileNamegenRoutine (String fileNamegenRoutine)
	{
		this.fileNamegenRoutine = fileNamegenRoutine;
	}
	
	/**
	 * @return the emptyFileRequired
	 */
	public boolean isEmptyFileRequired ()
	{
		return emptyFileRequired;
	}
	
	/**
	 * @param emptyFileRequired
	 *            the emptyFileRequired to set
	 */
	public void setEmptyFileGenFlag (String emptyFileGenFlag)
	{
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(emptyFileGenFlag))
			this.emptyFileRequired = true;
		else
			this.emptyFileRequired = false;
	}
	
	/**
	 * @return the emptyFileGenRoutine
	 */
	public String getEmptyFileGenRoutine ()
	{
		return emptyFileGenRoutine;
	}
	
	/**
	 * @param emptyFileGenRoutine
	 *            the emptyFileGenRoutine to set
	 */
	public void setEmptyFileGenRoutine (String emptyFileGenRoutine)
	{
		this.emptyFileGenRoutine = emptyFileGenRoutine;
	}
	
	/**
	 * @return the whereCondition1
	 */
	public String getWhereCondition1 ()
	{
		return whereCondition1;
	}
	
	/**
	 * @param whereCondition1
	 *            the whereCondition1 to set
	 */
	public void setWhereCondition1 (String whereCondition1)
	{
		this.whereCondition1 = whereCondition1;
	}
	
	/**
	 * @return the whereCondition2
	 */
	public String getWhereCondition2 ()
	{
		return whereCondition2;
	}
	
	/**
	 * @param whereCondition2
	 *            the whereCondition2 to set
	 */
	public void setWhereCondition2 (String whereCondition2)
	{
		this.whereCondition2 = whereCondition2;
	}
	
	/**
	 * @return the splitRequired
	 */
	public boolean isSplitRequired ()
	{
		return splitRequired;
	}
	
	/**
	 * @param fileSplit
	 *            the fileSplit to set
	 */
	public void setFileSplitFlag (String fileSplitFlag)
	{
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(fileSplitFlag))
			this.splitRequired = true;
		else
			this.splitRequired = false;
	}
	
	/**
	 * @return the parametersMap
	 */
	public Map<String, FilterParameter> getRunTimeParms ()
	{
		return runTimeParameters;
	}
	
	/**
	 * @param parametersMap
	 *            the parametersMap to set
	 */
	public void setRunTimeParms (Map<String, FilterParameter> parametersMap)
	{
		this.runTimeParameters = parametersMap;
	}
	
	/**
	 * @return the interfaceBandsDef
	 */
	public InterfaceBandsDef getBandsDefinition ()
	{
		return interfaceBandsDef;
	}
	
	/**
	 * @param interfaceBandsDef
	 *            the interfaceBandsDef to set
	 */
	public void setBandsDefinition (InterfaceBandsDef interfaceBandsDef)
	{
		this.interfaceBandsDef = interfaceBandsDef;
	}
	
	/**
	 * @param sellerCode
	 *            Seller of respective Process Definition
	 */
	public void setSellerCode (String sellerCode)
	{
		this.sellerCode = sellerCode;
	}
	
	/**
	 * @return Seller of respective Process Definition
	 */
	public String getSellerCode ()
	{
		return sellerCode;
	}
	
	/**
	 * @param sampleFile
	 *            Object of Sample XML/XSD File
	 */
	public void setSampleFile (Object sampleFile)
	{
		this.sampleFile = sampleFile;
	}
	
	/**
	 * @return Object of Sample XML/XSD File
	 */
	public Object getSampleFile ()
	{
		return sampleFile;
	}
	
	/**
	 * @param sampleFileContent
	 *            File Content Type
	 */
	public void setSampleFileContent (String sampleFileContent)
	{
		this.sampleFileContent = sampleFileContent;
	}
	
	/**
	 * @return File Content Type
	 */
	public String getSampleFileContent ()
	{
		return sampleFileContent;
	}
	
	/**
	 * @param sampleFileType
	 *            XML / XSD S
	 */
	public void setSampleFileType (String sampleFileType)
	{
		this.sampleFileType = sampleFileType;
	}
	
	/**
	 * @return File Type as XML / XSD
	 */
	public String getSampleFileType ()
	{
		return sampleFileType;
	}
	
	/**
	 * @return the formatterClass
	 */
	public String getFormatterClass ()
	{
		return formatterClass;
	}
	
	/**
	 * @param formatterClass
	 *            the formatterClass to set
	 */
	public void setFormatterClass (String formatterClass)
	{
		this.formatterClass = formatterClass;
	}
	
	/**
	 * @return the routines
	 */
	public Map<String, List<RoutineParameter>> getRoutines ()
	{
		return routines;
	}
	
	public List<RoutineParameter> getRoutineParameters (String routineType)
	{
		// Need to write actual code
		
		if (IrisAdminConstants.PRE_PROCESSING_ROUTINE.equals(routineType))
		{
			
		}
		return routines.get(routineType);
	}
	
	/**
	 * @param routines
	 *            the routines to set
	 */
	public void setRoutines (Map<String, List<RoutineParameter>> routines)
	{
		this.routines = routines;
	}
	
	public void addRoutine (String routineType, List<RoutineParameter> routineParms)
	
	{
		this.routines.put(routineType, routineParms);
	}
	
	/**
	 * @return the definitionType
	 */
	public String getDefinitionType ()
	{
		return definitionType;
	}
	
	/**
	 * @param definitionType
	 *            the definitionType to set
	 */
	public void setDefinitionType (String definitionType)
	{
		this.definitionType = definitionType;
	}
	
	/**
	 * @return the fileNameClass
	 */
	public String getFileNameClass ()
	{
		return fileNameClass;
	}
	
	/**
	 * @param fileNameClass
	 *            the fileNameClass to set
	 */
	public void setFileNameClass (String fileNameClass)
	{
		this.fileNameClass = fileNameClass;
	}
	
	public String getExecutionClass ()
	{
		return executionClass;
	}
	
	public void setExecutionClass (String executionClass)
	{
		this.executionClass = executionClass;
	}
	
	public boolean addSplitParameter (SplitParameter splitParameter)
	{
		return splitParameters.add(splitParameter);
	}
	
	public List<SplitParameter> getSplitParameters ()
	{
		return splitParameters;
	}
	
	public void setSplitParameters (List<SplitParameter> splitParameters)
	{
		this.splitParameters = splitParameters;
	}
	
	public String getEmptyFileNameClass ()
	{
		return emptyFileNameClass;
	}
	
	public void setEmptyFileNameClass (String emptyFileNameClass)
	{
		this.emptyFileNameClass = emptyFileNameClass;
	}
	
	public ModelDef getMosdelDef ()
	{
		return mosdelDef;
	}
	
	public void setModelDef (ModelDef interfaceDef)
	{
		this.mosdelDef = interfaceDef;
	}
	
	public String getFormatterType ()
	{
		return formatterType;
	}
	
	public void setFormatterType (String formatterType)
	{
		this.formatterType = formatterType;
	}
	
	/**
	 * @return the readerLineSeparator
	 */
	public String getReaderLineSeparator ()
	{
		return readerLineSeparator;
	}
	
	/**
	 * @param readerLineSeparator
	 *            the readerLineSeparator to set
	 */
	public void setReaderLineSeparator (String separator)
	{
		if (null == separator)
			separator = "\n";
		this.readerLineSeparator = separator;
	}

	/**
	 * @return the nameSpaceElements
	 */
	public Map<String, List<NameSpaceElements>> getNameSpaceElements ()
	{
		return nameSpaceElements;
	}

	/**
	 * @param nameSpaceElements the nameSpaceElements to set
	 */
	public void setNameSpaceElements (Map<String, List<NameSpaceElements>> nameSpaceElements)
	{
		this.nameSpaceElements = nameSpaceElements;
	}

	/**
	 * @return the interfaceDesc
	 */
	public String getInterfaceDesc ()
	{
		return interfaceDesc;
	}

	/**
	 * @param interfaceDesc the interfaceDesc to set
	 */
	public void setInterfaceDesc (String interfaceDesc)
	{
		this.interfaceDesc = interfaceDesc;
	}

	/**
	 * @return the lineOffsetFlag
	 */
	public String getLineOffsetFlag ()
	{
		return lineOffsetFlag;
	}

	/**
	 * @param lineOffsetFlag the lineOffsetFlag to set
	 */
	public void setLineOffsetFlag (String lineOffsetFlag)
	{
		this.lineOffsetFlag = lineOffsetFlag;
	}

	/**
	 * @return the lineOffsetPosition
	 */
	public int getLineOffsetPosition ()
	{
		return lineOffsetPosition;
	}

	/**
	 * @param lineOffsetPosition the lineOffsetPosition to set
	 */
	public void setLineOffsetPosition (int lineOffsetPosition)
	{
		
		this.lineOffsetPosition = lineOffsetPosition;
	}

	/**
	 * @return the parsendCondition
	 */
	public String getParsendCondition ()
	{
		return parsendCondition;
	}

	/**
	 * @param parsendCondition the parsendCondition to set
	 */
	public void addParsendCondition (String parsendCondition)
	{
		if ( parsendCondition != null)
		{
			if (this.parsendCondition == null)
				this.parsendCondition = parsendCondition;
			else
				this.parsendCondition += parsendCondition;
		}
	}
	
}
