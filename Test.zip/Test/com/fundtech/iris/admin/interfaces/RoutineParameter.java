/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : RoutineParameter.java
 * CREATED: Mar 14, 2013 12:39:53 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: RoutineParameter.java,v 1.2 2014/07/20 04:58:17 ramap Exp $
 * @since 1.0.0
 */
public class RoutineParameter
{
	private String bandRef = null;
	private String fieldRef = null;
	private int sequence = Integer.MIN_VALUE;
	private String parameterType = null; /* I for Interface F for filter parameter */
	private String name = null;
	
	/**
	 * @return the name
	 */
	public String getName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName (String name)
	{
		this.name = name;
	}
	
	/**
	 * @return the bandRef
	 */
	public String getBandRef ()
	{
		return bandRef;
	}
	
	/**
	 * @param bandRef
	 *            the bandRef to set
	 */
	public void setBandRef (String bandRef)
	{
		this.bandRef = bandRef;
	}
	
	/**
	 * @return the fieldRef
	 */
	public String getFieldRef ()
	{
		return fieldRef;
	}
	
	/**
	 * @param fieldRef
	 *            the fieldRef to set
	 */
	public void setFieldRef (String fieldRef)
	{
		this.fieldRef = fieldRef;
	}
	
	/**
	 * @return the sequence
	 */
	public int getSequence ()
	{
		return sequence;
	}
	
	/**
	 * @param sequence
	 *            the sequence to set
	 */
	public void setSequence (int sequence)
	{
		this.sequence = sequence;
	}
	
	/**
	 * @return the type
	 */
	public String getParameterType ()
	{
		return parameterType;
	}
	
	/**
	 * @param type
	 *            the type to set
	 */
	public void setParameterType (String type)
	{
		this.parameterType = type;
	}
	
}
