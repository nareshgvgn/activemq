/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : LoadBandDef.java
 * CREATED: Feb 6, 2013 9:45:11 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.NameSpaceElements;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.FieldComparator;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: LoadBandDef.java,v 1.19 2016/09/15 06:57:05 ramap Exp $
 * @since 1.0.0
 */
public class LoadBandDef
{
	private static Logger logger = LoggerFactory.getLogger(LoadBandDef.class.getName());
	private String interfaceRecordKey = null;
	private InterfaceDef interfaceDef = null;
	
	private static final String minMaxSql = "SELECT MAX(M.SEQUENCE_NMBR) as MAXSEQNUMBER , min(m.sequence_nmbr) AS MINSEQNUMBER FROM iris_int_mapping_dtl M WHERE M.PARENT_RECORD_KEY_NMBR =? "
			+ "AND M.BAND_NAME =? and m.mapping_type <> 11";
	private static final String fieldSql = "SELECT * FROM IRIS_INT_MAPPING_DTL WHERE PARENT_RECORD_KEY_NMBR =? AND BAND_NAME =? and MAPPING_TYPE <> 11 ORDER BY SEQUENCE_NMBR, MAPPING_TYPE";
	private static final String nameSpaceSql = "SELECT * FROM IRIS_INT_MAPPING_DTL WHERE PARENT_RECORD_KEY_NMBR =? AND BAND_NAME =? and MAPPING_TYPE = 11 ORDER BY SEQUENCE_NMBR, MAPPING_TYPE";
	private static final String bandSql = "SELECT * FROM IRIS_INT_BAND_DTL WHERE PARENT_RECORD_KEY_NMBR = ? ORDER BY SEQUENCE_NMBR, BAND_LEVEL, PARENT_BAND_NAME";
	private static final String codeMapSQL = "select m.default_value, m.others_value, d.input_value, d.output_value from iris_codemap_mst m, iris_codemap_dtl d  "
			+ " WHERE m.record_key_nmbr = d.parent_record_key_nmbr AND M.VALID_FLAG = 'Y' AND M.record_key_nmbr = ?";
	
	private static final String formatterSQL = "SELECT FORMATTER_CLASS, EXECUTION_CLASS, FORMAT_TYPE, LINE_SEPARATOR FROM MEDIUM_MST T WHERE T.MODEL_TYPE = ? AND T.MEDIUM_TYPE = ? AND T.MEDIUM_NAME = ?";
	
	
	public LoadBandDef(String interfaceRecordKey, InterfaceDef interfaceDef)
	{
		this.interfaceDef = interfaceDef;
		this.interfaceRecordKey = interfaceRecordKey;
	}
	
	public InterfaceBandsDef loadBandDefination (Connection connection) throws LoadingException
	{
		InterfaceBandDef bandDef = null;
		InterfaceBandsDef bands = null;
		LoadingException intExp = null;
		String strSql = null;
		PreparedStatement bandStmt = null;
		ResultSet bandRs = null;
		List<MappingField> mappingFields = null;
		LoadMappingFields loadMappingFields = null;
		PreparedStatement codeMapStmt = null;
		InterfaceBandDef tempDefinition = null;
		FieldComparator comparator = null;
		String bandRecordkey = null;
		Map<String,List<NameSpaceElements>> nameSpaceMap = new LinkedHashMap<String, List<NameSpaceElements>>();
		List<NameSpaceElements> nameSpaceList = null;
		PreparedStatement minMaxSt = null;
		PreparedStatement fieldsStmt = null;
		PreparedStatement nameSpaceStmt = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		String currentParentName = null;
		InterfaceBandDef parentBandDef = null;
		List<String> parents = null;
		String bandName = null;
		
		try
		{
			bandStmt = connection.prepareStatement(bandSql);
			bandStmt.clearParameters();
			bandStmt.setString(1, interfaceRecordKey);
			bandRs = bandStmt.executeQuery();
			fieldsStmt = connection.prepareStatement(fieldSql);
			
			if (IrisAdminConstants.FORMAT_TYPE_XML.equals(interfaceDef.getFormatterType()))
			{
				nameSpaceStmt = connection.prepareStatement(nameSpaceSql);
				minMaxSt = connection.prepareStatement(minMaxSql);
			}
			codeMapStmt = connection.prepareStatement(codeMapSQL);
			bands = new InterfaceBandsDef();
			loadMappingFields = new LoadMappingFields(interfaceDef.getDefinitionType());
			bandDefs = new HashMap<String, InterfaceBandDef>();
			parents = new ArrayList<String>();
			// Result set may have multiple rows too
			while (bandRs.next())
			{
				bandRecordkey = bandRs.getString("RECORD_KEY_NMBR");
				bandDef = setBandDefinition(bandRs);
				setBandFormatters(bandDef, connection);
				loadMappingFields.setBandIdLength(bandDef.getBandIdLength());
				loadMappingFields.setBandIdPosition(bandDef.getBandIdPosition());
				mappingFields = loadMappingFields.loadFields(bandRecordkey, bandDef.getBandName(), fieldsStmt, codeMapStmt);
				
				//do this only if its XML. Otherwise its useless to create
				if (IrisAdminConstants.FORMAT_TYPE_XML.equals(interfaceDef.getFormatterType()))
				{
					nameSpaceList = loadMappingFields.loadNameSpacesFields(bandRecordkey, bandDef.getBandName(), nameSpaceStmt);
					nameSpaceMap.put( bandDef.getBandName(), nameSpaceList);
					getMinMaxSequenceNumbers(connection, minMaxSt, bandDef, bandRecordkey);
				}
				
				// If definition type is upload, re-arrange sequence of execution.
				if (IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(interfaceDef.getDefinitionType()))
				{
					comparator = new FieldComparator();
					Collections.sort(mappingFields, comparator);
				}
				bandDef.setMappingFields(mappingFields);
				currentParentName = bandDef.getParentBandName();
				bandName = bandDef.getBandName();
				if (currentParentName == null)
				{
					/*
					 * bellow created empty band fetch it if created. move child of empty band to newly created band.
					 */
					parentBandDef = bandDefs.get(bandName);
					if (parentBandDef != null)
					{
						moveBands(parentBandDef, bandDef);
					}
					bandDef.setBandPath(bandName);
					parents.add(bandDef.getBandName());
					bandDefs.put(bandName, bandDef);
				}
				else if (bandDefs.containsKey(bandName))
				{
					tempDefinition = bandDefs.get(bandName);
					moveBands(tempDefinition, bandDef);
					parentBandDef = bandDefs.get(currentParentName);
					bandDef.setBandPath(parentBandDef.getBandPath() + "." + bandName);
					bandDef.setParentBandDef(parentBandDef);
					parentBandDef.addChildBand(bandDef);
					bandDefs.put(bandName, bandDef);
				}
				else
				{
					parentBandDef = bandDefs.get(currentParentName);
					/*
					 * if the parent band def is null means parent band is trailer band and it has to come later and not at the begining. Right now it
					 * may occur in download only. If it occurs in upload needs to see how to handle So create empty parent band and attach child for
					 * that. Later when parent band comes create proper band and move childs to it
					 */
					if (parentBandDef == null)
					{
						parentBandDef = createEmptyBandDef(currentParentName);
						bandDefs.put(currentParentName, parentBandDef);
					}
					bandDef.setBandPath(parentBandDef.getBandPath() + "." + bandName);
					bandDef.setParentBandDef(parentBandDef);
					parentBandDef.addChildBand(bandDef);
					bandDefs.put(bandName, bandDef);
				}
			}
			for (String s : parents)
			{
				InterfaceBandDef tempBandDef = bandDefs.get(s);
				
				resolveReferences(tempBandDef, bandDefs);
				bands.addBandDefination(tempBandDef);
				
			}
			interfaceDef.setNameSpaceElements(nameSpaceMap);
			loadRoutineDetails(connection, bandDefs);
		}
		catch ( LoadingException exp)
		{
			throw exp;
		}
		catch (SQLException sqlExp)
		{
			
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ strSql }, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ strSql }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		
		finally
		{
			CleanUpUtils.doClean(bandDefs);
			CleanUpUtils.doClean(parents);
			parents = null;
			currentParentName = null;
			bandName = null;
			strSql = null;
			HelperUtils.doClose(codeMapStmt);
			HelperUtils.doClose(fieldsStmt);
			HelperUtils.doClose(bandRs);
			HelperUtils.doClose(bandStmt);
			HelperUtils.doClose(nameSpaceStmt);
			HelperUtils.doClose(minMaxSt);
		}
		return bands;
	}
	
	/**
	 * 
	 * <p>
	 * This Helper method gets the Band level formatters data
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandDef
	 * @param connection
	 * @throws LoadingException
	 * </pre>
	 * 
	 * </p>
	 */
	private void setBandFormatters (InterfaceBandDef bandDef, Connection connection) throws LoadingException
	{
		PreparedStatement formatterStmt = null;
		LoadingException intExp = null;
		ResultSet formatterRs = null;
		String formatterClass = null;
		
		try
		{
			if (bandDef.getMediumName() == null)
			{
				bandDef.setMediumName(interfaceDef.getMediumName());
				bandDef.setFormatterClass(interfaceDef.getFormatterClass());
				bandDef.setDelimiter(interfaceDef.getDelimiter());
				bandDef.setQualifier(interfaceDef.getQualifier());
				bandDef.setFormatterLineSepartor(interfaceDef.getReaderLineSeparator());
				
				return;
			}
			
			if (bandDef.getMediumName().equals(interfaceDef.getMediumName()))
			{
				bandDef.setFormatterClass(interfaceDef.getFormatterClass());
				bandDef.setFormatterLineSepartor(interfaceDef.getReaderLineSeparator());
				return;
			}
			
			formatterStmt = connection.prepareStatement(formatterSQL);
			formatterStmt.clearParameters();
			formatterStmt.setString(1, interfaceDef.getDefinitionType());
			formatterStmt.setString(2, interfaceDef.getMediumType());
			formatterStmt.setString(3, bandDef.getMediumName());
			formatterRs = formatterStmt.executeQuery();
			if (formatterRs.next())
			{
				
				formatterClass = formatterRs.getString("FORMATTER_CLASS");
				bandDef.setFormatterClass(formatterClass);
				bandDef.setFormatterLineSepartor(formatterRs.getString("LINE_SEPARATOR"));
				
			}
			else
			// if 0 rows we need to terminate the execution
			{
				intExp = new LoadingException("error.irisdb.interface.nodata", new Object[]	{ formatterSQL }, null);
				logger.error(IRISLogger.getText(intExp));
				throw intExp;
			}
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ formatterSQL, bandDef.getMediumName() }, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]{ formatterSQL, bandDef.getMediumName() }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(formatterRs);
			HelperUtils.doClose(formatterStmt);
		}
	}
	
	/**
	 * This method
	 * 
	 * @param bandDef
	 * @param bandDefs
	 * @return
	 */
	private void resolveReferences (InterfaceBandDef bandDef, Map<String, InterfaceBandDef> bandDefs)
	{
		String bandRef = null;
		String bandRefPath = null;
		Map<String, InterfaceBandDef> childDefs = null;
		for (MappingField field : bandDef.getMappingFields())
		{
			if (IrisAdminConstants.MAPPING_TYPE_REFERENCED == field.getMappingType())
			{
				bandRef = field.getBandRef();
				bandRefPath = bandDefs.get(bandRef).getBandPath();
				// bandRefPath = bandRefPath + "." + fieldRef;
				field.setBandRefPath(bandRefPath);
			}
			// TODO we need to do for Complex also here only
		}
		childDefs = bandDef.getChildDefinitions().getBandDefinitions();
		
		for (InterfaceBandDef childDef : childDefs.values())
		{
			resolveReferences(childDef, bandDefs);
		}
	}
	
	/**
	 * TODO
	 * 
	 * @param bandRs
	 * @return
	 */
	private InterfaceBandDef setBandDefinition (ResultSet bandRs) throws SQLException
	{
		InterfaceBandDef bandDef = null;
		String relativeXPath = null;
		String absXpath = null;
		String delimiter = null;
		
		bandDef = new InterfaceBandDef();
		bandDef.setBandName(bandRs.getString("BAND_NAME"));
		bandDef.setBandIdPosition(bandRs.getInt("BAND_ID_POSITION"));
		bandDef.setBandIdLength(bandRs.getInt("BAND_ID_LENGTH"));
		bandDef.setBandId(bandRs.getString("BAND_ID"));
		bandDef.setBandType(bandRs.getString("BAND_TYPE"));
		bandDef.setBandLevel(bandRs.getInt("BAND_LEVEL"));
		bandDef.setParentBandName(bandRs.getString("PARENT_BAND_NAME"));
		bandDef.setMandatory(bandRs.getString("MANDATORY"));
		bandDef.setWhereCondition(bandRs.getString("WHERE_CONDITION"));
		bandDef.setUpdateQuery(bandRs.getString("UPDATE_QUERY"));
		bandDef.setSequenceNumber(bandRs.getInt("SEQUENCE_NMBR"));
		absXpath = bandRs.getString("ABSOLUTE_XPATH1");
		bandDef.setAbsoluteXPath1(absXpath);
		bandDef.setAbsoluteXPath2(bandRs.getString("ABSOLUTE_XPATH2"));
		relativeXPath = bandRs.getString("RELATIVE_XPATH");
		
		if (relativeXPath == null)
			relativeXPath = absXpath;
		if (relativeXPath != null)
			setPaths(relativeXPath, bandDef);
		
		bandDef.setMediumName(bandRs.getString("MEDIUM_NAME"));
		delimiter = bandRs.getString("DELIMITER");
		delimiter = getDelimiter(delimiter);
		bandDef.setDelimiter(delimiter);
		bandDef.setQualifier(bandRs.getString("QUALIFIER"));
		
		return bandDef;
	}
	
	private String getDelimiter (String delimiter)
	{
		
		if ("CRLF".equals(delimiter))
			return "\r\n";
		else if ("LF".equals(delimiter))
			return "\n";
		else
			return delimiter;
		
	}
	
	/**
	 * <p>
	 * This helper method puts parentXpath and bandXpath fopr XML only.
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param relativeXPath
	 * @param interfaceBandDef
	 * </pre>
	 * 
	 * </p>
	 */
	private void setPaths (String relativeXPath, InterfaceBandDef interfaceBandDef)
	{
		String parentXPath = null;
		String bandXPath = null;

		/*
		 * if parent xpath derives as "." the remove / at the beginning for field else add "." at the beginning for andXpath so that xpath will be
		 * intact.
		 */
		if (IrisAdminConstants.FORMAT_TYPE_XML.equals(interfaceDef.getFormatterType()))
		{
			parentXPath = relativeXPath.substring(0, relativeXPath.lastIndexOf("/"));
			if (parentXPath != null && (".".equals(parentXPath) || "".equals(parentXPath)))
			{
				bandXPath = relativeXPath.substring(relativeXPath.lastIndexOf("/") + 1, relativeXPath.length());
			}
			else
			{
				bandXPath = relativeXPath.substring(relativeXPath.lastIndexOf("/"), relativeXPath.length());
				bandXPath = "." + bandXPath;
			}
			
		}
		interfaceBandDef.setParentXPath(parentXPath);
		interfaceBandDef.setBandXPath(bandXPath);
		interfaceBandDef.setRelativeXPath(relativeXPath);
		
	}
	
	private InterfaceBandDef createEmptyBandDef (String bandName)
	{
		InterfaceBandDef interfaceBandDef = null;
		
		interfaceBandDef = new InterfaceBandDef();
		interfaceBandDef.setBandName(bandName);
		interfaceBandDef.setBandPath(bandName);
		return interfaceBandDef;
	}
	
	/**
	 * TODO
	 * 
	 * @param dbConnection
	 * @param interfaceCode
	 * @param processCode
	 * @return
	 */
	private void loadRoutineDetails (Connection dbConnection, Map<String, InterfaceBandDef> bandDefs) throws LoadingException
	{
		PreparedStatement routineStmt = null;
		ResultSet routinetRs = null;
		String strSql = null;
		LoadingException intExp = null;
		List<RoutineParameter> parameterFields = null;
		
		strSql = "SELECT * FROM IRIS_INT_INPUT_PARAM T WHERE  INTERFACE_NAME = ? AND ROUTINE_TYPE = ? and PARENT_RECORD_KEY_NMBR = ? ORDER BY SEQUENCE_NMBR";
		try
		{
			
			routineStmt = dbConnection.prepareStatement(strSql);
			
			if (interfaceDef.getFileNamegenRoutine() != null)
			{
				parameterFields = getFileNameGenRoutine(bandDefs, routineStmt, IrisAdminConstants.FILENAME_GEN_ROUTINE);
				interfaceDef.addRoutine(IrisAdminConstants.FILENAME_GEN_ROUTINE, parameterFields);
			}
			
			if (interfaceDef.getPreProcessingRoutine() != null)
			{
				parameterFields = getFileNameGenRoutine(bandDefs, routineStmt, IrisAdminConstants.PRE_PROCESSING_ROUTINE);
				interfaceDef.addRoutine(IrisAdminConstants.PRE_PROCESSING_ROUTINE, parameterFields);
			}
			
			if (interfaceDef.getPostProcessingRoutine() != null)
			{
				parameterFields = getFileNameGenRoutine(bandDefs, routineStmt, IrisAdminConstants.POST_PROCESSING_ROUTINE);
				interfaceDef.addRoutine(IrisAdminConstants.POST_PROCESSING_ROUTINE, parameterFields);
			}
			
			if (interfaceDef.getPostUpdationRoutine() != null)
			{
				parameterFields = getFileNameGenRoutine(bandDefs, routineStmt, IrisAdminConstants.POST_UPDATION_ROUTINE);
				interfaceDef.addRoutine(IrisAdminConstants.POST_UPDATION_ROUTINE, parameterFields);
			}
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ strSql }, sqlExp);
			IRISLogger.getText(intExp);
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.interface", new Object[]
			{ strSql }, exp);
			IRISLogger.getText(intExp);
			throw intExp;
		}
		finally
		{
			strSql = null;
			HelperUtils.doClose(routinetRs);
			HelperUtils.doClose(routineStmt);
		}
	}
	
	private List<RoutineParameter> getFileNameGenRoutine (Map<String, InterfaceBandDef> bandDefs, PreparedStatement routineStmt, String routineType)
			throws Exception
	{
		ResultSet routinetRs = null;
		List<RoutineParameter> parameterFields = null;
		RoutineParameter routineParm = null;
		
		try
		{
			parameterFields = new ArrayList<RoutineParameter>();
			routineStmt.clearParameters();
			routineStmt.setString(1, interfaceDef.getInterfaceName());
			routineStmt.setString(2, routineType);
			routineStmt.setString(3, interfaceRecordKey);
			routinetRs = routineStmt.executeQuery();
			while (routinetRs.next())
			{
				routineParm = new RoutineParameter();
				routineParm.setName(routinetRs.getString("PARAMETER_NAME"));
				routineParm.setBandRef(routinetRs.getString("BAND_NAME"));
				routineParm.setFieldRef(routinetRs.getString("FIELD_NAME"));
				routineParm.setSequence(routinetRs.getInt("SEQUENCE_NMBR"));
				routineParm.setParameterType(routinetRs.getString("PARAMETER_TYPE"));
				parameterFields.add(routineParm);
			}
			
			return parameterFields;
		}
		finally
		{
			HelperUtils.doClose(routinetRs);
		}
		
	}
	
	private void moveBands (InterfaceBandDef fromBand, InterfaceBandDef toBand)
	{
		Map<String, InterfaceBandDef> pBandDefs = null;
		pBandDefs = fromBand.getChildDefinitions().getBandDefinitions();
		for (InterfaceBandDef pBandDef : pBandDefs.values())
		{
			pBandDef.setParentBandDef(toBand);
			toBand.addChildBand(pBandDef);
		}
		CleanUpUtils.doClean(pBandDefs);
	}
	
	private void getMinMaxSequenceNumbers(Connection dbConnection, PreparedStatement minMaxSt,InterfaceBandDef bandDef, String bandKey) throws SQLException
	{
		String bandName = null;
		ResultSet minMaxRs = null;
		
		try
		{
			bandName = bandDef.getBandName();
			minMaxSt.clearParameters();
			minMaxSt.setString(1, bandKey);
			minMaxSt.setString(2, bandName);
			minMaxRs = minMaxSt.executeQuery();
			if ( minMaxRs.next())
			{
				bandDef.setStartSequenceNumber(minMaxRs.getInt("MINSEQNUMBER"));
				bandDef.setEndsequenceNumber(minMaxRs.getInt("MAXSEQNUMBER"));
			}
		}
		finally
		{
			HelperUtils.doClose(minMaxRs);
		}
	}
}
