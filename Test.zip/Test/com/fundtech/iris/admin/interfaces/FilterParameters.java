/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : FilterParameters.java
 * CREATED: Jan 18, 2013 3:19:10 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.interfaces;

import java.util.HashMap;
import java.util.Map;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: FilterParameters.java,v 1.2 2014/07/20 04:58:17 ramap Exp $
 * @since 1.0.0
 */
public class FilterParameters
{
	private Map<String, FilterParameter> filterParameters = new HashMap<String, FilterParameter>();
	
	@SuppressWarnings("unused")
	private void addParameter (String key, FilterParameter filterParameter)
	{
		filterParameters.put(key, filterParameter);
	}
	
	@SuppressWarnings("unused")
	private FilterParameter getParameter (String key)
	{
		return filterParameters.get(key);
	}
	
	/**
	 * @return the filterParameters
	 */
	public Map<String, FilterParameter> getFilterParameters ()
	{
		return filterParameters;
	}
	
	/**
	 * @param filterParameters
	 *            the filterParameters to set
	 */
	public void setFilterParameters (Map<String, FilterParameter> filterParameters)
	{
		this.filterParameters = filterParameters;
	}
}
