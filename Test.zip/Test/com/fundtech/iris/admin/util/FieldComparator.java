/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : FieldComparator.java
 * CREATED: May 31, 2014 12:16:30 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.io.Serializable;
import java.util.Comparator;

import com.fundtech.iris.admin.MappingField;

/**
 * <p>
 * This Comparator checks field mapping type and makes in order.
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FieldComparator.java,v 1.3 2014/09/09 10:40:46 ramap Exp $
 */
public class FieldComparator implements Comparator<MappingField>, Serializable
{
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	public int compare (MappingField one, MappingField two)
	{
		int flag = 0;
		int order1 = one.getExecutionOrder();
		int order2 = two.getExecutionOrder();
		
		flag = order1 < order2 ? -1 : order1 == order2 ? 0 : 1;
		return flag;
	}
	
}
