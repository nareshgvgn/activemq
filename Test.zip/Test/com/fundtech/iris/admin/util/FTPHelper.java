package com.fundtech.iris.admin.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.SocketException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.net.ProtocolCommandEvent;
import org.apache.commons.net.ProtocolCommandListener;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPHTTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPSClient;
import org.apache.commons.net.io.CopyStreamEvent;
import org.apache.commons.net.io.CopyStreamListener;
import org.apache.commons.net.util.TrustManagerUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * 
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FTPHelper.java,v 1.7 2017/02/27 13:19:03 ramap Exp $
 */
public class FTPHelper
{
	private static Logger logger = LoggerFactory.getLogger(FTPHelper.class);
	private String remoteHost = null;
	private int remotePort = 0;
	private String proxyHost = null;
	private String proxyPort = null;
	private String proxyUser = null;
	private String proxyPass = null;
	private String ftpUser = null;
	private String ftpPassword = null;
	private static Boolean passiveMode = Boolean.TRUE;
	private long keepAliveTimeout = -1;
	private int controlKeepAliveReplyTimeout = -1;
	private final static String DEFAULT_PROTOCOL = "FTP";
	private String protocol = DEFAULT_PROTOCOL;
	private boolean validateCertificate = false;
	private KeyStore trustManager = null;
	private String channelType = null;
	
	public FTPHelper(String remoteHost, int remotePort, String ftpUser, String ftpPassword, String channelType)
	{
		if (StringUtils.isEmpty(remoteHost))
			throw new RuntimeException("Remote host not configured.");
		
		if (remotePort == 0)
			throw new RuntimeException("Remote Port not configured");
		
		if (StringUtils.isEmpty(ftpUser))
			throw new RuntimeException("FTP User not configured");
		
		if (StringUtils.isEmpty(ftpPassword))
			throw new RuntimeException("FTP Password not configured");
		
		this.remoteHost = remoteHost;
		this.remotePort = remotePort;
		this.ftpUser = ftpUser;
		this.ftpPassword = ftpPassword;
		this.channelType = channelType;
	}
	
	/**
	 * <p>
	 * This
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param proxyHost
	 * @param proxyPort
	 * @param proxyUser
	 * @param proxyPassword
	 * </pre>
	 * 
	 * </p>
	 */
	public void setProxyDetails (String proxyHost, String proxyPort, String proxyUser, String proxyPassword)
	{
		this.proxyHost = proxyHost;
		this.proxyPort = proxyPort;
		this.proxyUser = proxyUser;
		this.proxyPass = proxyPassword;
	}
	
	public void uploadFile (String fileName, String remoteDestDir) throws IOException, GeneralSecurityException, Exception
	{
		List<String> listOfFiles = null;
		
		listOfFiles = new ArrayList<String>();
		listOfFiles.add(fileName);
		uploadFiles(listOfFiles, remoteDestDir);
		
	}
	
	public void uploadFiles (List<String> listOfFiles, String remoteDestDir) throws IOException, GeneralSecurityException, Exception
	{
		FTPClient ftp = null;
		ChannelSftp channelSftp = null;
		
		try
		{
			if (null != channelType && "SFTP".equals(channelType))
			{
				channelSftp = sftpConnect(remoteHost, remotePort, ftpUser, ftpPassword);
				uploadFilesSFTP(listOfFiles, remoteDestDir, channelSftp);
			}
			else if (!"SSH".equals(channelType))
			{
				ftp = ftpConnect(remoteHost, remotePort, ftpUser, ftpPassword);
				uploadFiles(listOfFiles, remoteDestDir, ftp);
			}
		}
		finally
		{
			ftpDisconnect(ftp);
			sftpDisconnect(channelSftp);
		}
		
	}
	
	public List<String> downloadFiles (String localDir, String remoteDir, Boolean deleteSrcFile, String destDir) throws IOException,
			GeneralSecurityException
	{
		FTPClient ftp = null;
		List<String> downloadedFiles = null;
		
		try
		{
			if (!"SSH".equals(channelType))
			{
				ftp = ftpConnect(remoteHost, remotePort, ftpUser, ftpPassword);
				downloadedFiles = downloadFiles(localDir, remoteDir, deleteSrcFile, destDir, ftp);
			}
			else
			{
				
			}
			
		}
		finally
		{
			ftpDisconnect(ftp);
		}
		
		return downloadedFiles;
		
	}
	
	private List<String> downloadFiles (String localDir, String remoteDir, Boolean deleteSrcFile, String destDir, FTPClient ftp) throws IOException,
			GeneralSecurityException
	{
		FTPFile[] ftpFiles = null;
		List<String> downloadedFiles = null;
		File localFile = null;
		boolean dwld = false;
		FileOutputStream fos = null;
		File localFileDir = null;
		
		try
		{
			
			localFileDir = new File(localDir);
			if (!localFileDir.exists())
			{
				if (!localFileDir.mkdirs())
				{
					logger.error("Unable to create the local folder({}) where file needs to be download. Unable to continue.", localDir);
					return new ArrayList<String>();
				}
			}
			
			/*
			 * Verify in advance whether remoteDestinationDirectoryPath is accessible or not. change working directory can verify whether it is exists
			 * or not. It can not perform permission check.
			 */
			if (!StringUtils.isEmpty(destDir))
			{
				if (!ftp.changeWorkingDirectory(destDir))
				{
					logger.error("Unable to access the destination folder where file need to be moved after download. Unable to continue.");
					return new ArrayList<String>();
				}
			}
			
			if (StringUtils.isEmpty(remoteDir))
				remoteDir = ".";
			
			if (!ftp.changeWorkingDirectory(remoteDir))
			{
				logger.error("Failed to change directory on remote server." + " Not correct if configured directory does not exists."
						+ " If continued can download some other files. Returning without downloding files.");
				return new ArrayList<String>();
			}
			
			ftpFiles = ftp.listFiles();
			downloadedFiles = new ArrayList<String>();
			for (int i = 0; i < ftpFiles.length; i++)
			{
				FTPFile file = ftpFiles[i];
				if (file.isDirectory())
				{
					logger.trace("Its a Direcotory, so ignoring{}", file.getName());
					continue;
				}
				
				if (logger.isDebugEnabled())
					logger.debug("File Name = " + file.getName() + " ; File Size = " + file.getSize());
				/*
				 * Copying/Downloading the file from a remote location to the local system
				 */
				localFile = new File(localDir + File.separator + file.getName());
				fos = new FileOutputStream(localFile);
				ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
				dwld = ftp.retrieveFile(file.getName(), fos);
				if (logger.isDebugEnabled())
					logger.debug("File Download status..." + dwld + " Name:" + file.getName());
				fos.close();
				
				if (deleteSrcFile && !StringUtils.isEmpty(destDir))
				{
					if (logger.isInfoEnabled())
						logger.info("Moving file on remote server from : " + file.getName() + " to : " + destDir + file.getName());
					if (!ftp.rename(file.getName(), destDir + file.getName()))
					{
						logger.error("Failed to move file on remote server. This can lead to duplicate file processing. Ignoring this file to download.");
						localFile.delete();
					}
					else
					{
						downloadedFiles.add(file.getName());
					}
				}
				else if (deleteSrcFile)
					ftp.deleteFile(file.getName());
				else
					downloadedFiles.add(file.getName());
			}
		}
		catch (IOException io)
		{
			throw io;
		}
		
		return downloadedFiles;
	}
	
	private void uploadFiles (List<String> listOfFiles, String remoteDestDir, FTPClient ftp) throws IOException, GeneralSecurityException
	{
		File currFile = null;
		boolean iscontinue = true;
		
		try
		{
			ftp.changeWorkingDirectory(remoteDestDir);
			for (String fileName : listOfFiles)
			{
				currFile = new File(fileName);
				logger.trace("File Picked up for uploading :{}" , fileName);
				
				if (!currFile.exists())
				{
					logger.error("No such source file:" + currFile);
					iscontinue = false;
				}
				else if (!currFile.isFile())
				{
					logger.error("Can't copy directory:" + currFile);
					iscontinue = false;
				}
				else if (!currFile.canRead())
				{
					logger.error("Source file is unreadable:" + currFile);
					iscontinue = false;
				}
				if ( iscontinue)
					moveFile(currFile, ftp);
			}
		}
		finally
		{
			
		}
		
	}// upload Files FTP
	
	private void uploadFilesSFTP(List<String> listOfFiles, String remoteDestDir, ChannelSftp channelSftp) throws Exception
	{
		File currFile = null;
		boolean iscontinue = true;
		
		try
		{
			if (!StringUtils.isEmpty(remoteDestDir))
				channelSftp.cd(remoteDestDir);
			for (String fileName : listOfFiles)
			{
				currFile = new File(fileName);
				logger.trace("File Picked up for uploading :{}" , fileName);
				
				if (!currFile.exists())
				{
					logger.error("No such source file:" + currFile);
					iscontinue = false;
				}
				else if (!currFile.isFile())
				{
					logger.error("Can't copy directory:" + currFile);
					iscontinue = false;
				}
				else if (!currFile.canRead())
				{
					logger.error("Source file is unreadable:" + currFile);
					iscontinue = false;
				}
				if ( iscontinue)
					channelSftp.put(new FileInputStream(currFile), currFile.getName());
			}
		}
		finally
		{
			
		}
		
	}// upload Files SFTP
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param currFile
	 * @param ftp
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @throws IOException
	 */
	private void moveFile (File currFile, FTPClient ftp) throws IOException
	{
		FileInputStream inStream = null;
		
		try
		{
			inStream = new FileInputStream(currFile);
			ftp.storeFile(currFile.getName(), inStream);
			
			if (logger.isDebugEnabled())
				logger.debug("File:" + currFile.getName() + " copied !!!");
		}
		finally
		{
			HelperUtils.doClose(inStream);
		}
	}
	
	private FTPClient ftpConnect (String remoteHost, int remotePort, String ftpUser, String ftpPassword) throws SocketException, IOException,GeneralSecurityException
	{
		int reply = -1;
		FTPClient ftp = null;
		FTPSClient ftps = null;
		
		try
		{
			if (DEFAULT_PROTOCOL.equals(protocol))
			{
				if (proxyHost != null)
					ftp = new FTPHTTPClient(proxyHost, Integer.parseInt(proxyPort), proxyUser, proxyPass);
				else
					ftp = new FTPClient();
			}
			
			else
			{
				ftps = new FTPSClient();
				
				if (!validateCertificate)
					ftps.setTrustManager(TrustManagerUtils.getAcceptAllTrustManager());
				else
				{
					if (trustManager == null)
						ftps.setTrustManager(TrustManagerUtils.getValidateServerCertificateTrustManager());
					else
						ftps.setTrustManager(TrustManagerUtils.getDefaultTrustManager(trustManager));
					
				}
				ftp = ftps;
			}
			
			if (keepAliveTimeout >= 0)
			{
				ftp.setControlKeepAliveTimeout(keepAliveTimeout);
			}
			if (controlKeepAliveReplyTimeout >= 0)
			{
				ftp.setControlKeepAliveReplyTimeout(controlKeepAliveReplyTimeout);
			}
			ftp.addProtocolCommandListener(new MyLogger(false));
			ftp.connect(remoteHost, remotePort);
			reply = ftp.getReplyCode();
			
			if (!FTPReply.isPositiveCompletion(reply))
			{
				logger.debug("Reply from FTP {}", reply);
				ftp.disconnect();
				logger.error("FTP server refused connection.");
				throw new SocketException("FTP server refused connection.");
			}
			
			if (passiveMode.booleanValue())
				ftp.enterLocalPassiveMode();
			
			if (!ftp.login(ftpUser, ftpPassword))
			{
				if (logger.isDebugEnabled())
					logger.debug("FTP Reply is :" + ftp.getReplyString());
				ftp.logout();
				throw new SocketException("Not able to connect FTP with credentials");
			}
			
			ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
		}
		catch ( SocketException exp)
		{
			throw exp;
		}
		catch ( IOException exp)
		{
			throw exp;
		}
		catch( GeneralSecurityException exp)
		{
			throw exp;
		}
		
		return ftp;
	}
	
	private ChannelSftp sftpConnect (String remoteHost, int remotePort, String ftpUser, String ftpPassword) throws JSchException
	{
		ChannelSftp sftp = null;
		Session session = null;
		JSch jsch = null;
		Channel channel = null;
		Hashtable<String, String> opts = null;
		
		try
		{
			jsch = new JSch();
			opts = new Hashtable<String, String>();
			opts.put("StrictHostKeyChecking", "no");
			jsch = new JSch();
			JSch.setConfig(opts);
			session = jsch.getSession(ftpUser, remoteHost, remotePort);
			session.setPassword(ftpPassword);
			session.connect();
			channel = session.openChannel("sftp");
			channel.connect();
			sftp = (ChannelSftp) channel;
			return sftp;
		}
		finally
        {
        	if (session != null) session = null;
        	if (jsch != null) jsch = null;
        }
	}
	
	private void sftpDisconnect(ChannelSftp channelSftp)
	{
		if (null == channelSftp) return;

		try
		{
			if (channelSftp.isConnected())
			{
				channelSftp.disconnect();
				channelSftp.getSession().disconnect();
			}
		}
		catch (Exception ex)
		{
			logger.error("Unexpected error has occurred while closing sftp connection!", ex);
		}
	}
	
	private void ftpDisconnect (FTPClient ftp)
	{
		try
		{
			if (ftp == null)
				return;
			
			ftp.noop(); // check that control connection is working OK
			ftp.logout();
			ftp.disconnect();
		}
		catch (IOException io)
		{
			logger.error("Could not disconnect Remote Connection:\n", io);
		}
	}
	
	/**
	 * @param keepAliveTimeout
	 *            the keepAliveTimeout to set
	 */
	public void setKeepAliveTimeout (long keepAliveTimeout)
	{
		this.keepAliveTimeout = keepAliveTimeout;
	}
	
	/**
	 * @param controlKeepAliveReplyTimeout
	 *            the controlKeepAliveReplyTimeout to set
	 */
	public void setControlKeepAliveReplyTimeout (int controlKeepAliveReplyTimeout)
	{
		this.controlKeepAliveReplyTimeout = controlKeepAliveReplyTimeout;
	}
	
	/**
	 * @param protocol
	 *            the protocol to set
	 */
	public void setProtocol (String protocol)
	{
		this.protocol = protocol;
	}
	
	/**
	 * @param trustmgr
	 *            the trustmgr to set
	 * @throws KeyStoreException
	 * @throws IOException
	 * @throws CertificateException
	 * @throws NoSuchAlgorithmException
	 */
	public void setTrustManager (String keyStoreFile, String password) throws KeyStoreException, NoSuchAlgorithmException, CertificateException,
			IOException
	{
		FileInputStream fIn = null;
		
		try
		{
			fIn = new FileInputStream(keyStoreFile);
			trustManager = KeyStore.getInstance("JKS");
			trustManager.load(fIn, password.toCharArray());
		}
		finally
		{
			HelperUtils.doClose(fIn);
		}
	}
	
	private CopyStreamListener createListener ()
	{
		return new CopyStreamListener()
		{
			private long megsTotal = 0;
			
			// @Override
			public void bytesTransferred (CopyStreamEvent event)
			{
				bytesTransferred(event.getTotalBytesTransferred(), event.getBytesTransferred(), event.getStreamSize());
			}
			
			// @Override
			public void bytesTransferred (long totalBytesTransferred, int bytesTransferred, long streamSize)
			{
				long megs = totalBytesTransferred / 1000000;
//				for (long l = megsTotal; l < megs; l++)
//				{
//					System.err.print("#");
//				}
				megsTotal = megs;
			}
		};
	}
	
	private static class MyLogger implements ProtocolCommandListener
	{
		private boolean showCredentials = false;
		private String cmd = null;
		
		public MyLogger(boolean showCredentials)
		{
			this.showCredentials = showCredentials;
		}
		
		public void protocolCommandSent (ProtocolCommandEvent event)
		{
			cmd = event.getCommand();
			
			if (("PASS".equalsIgnoreCase(cmd) || "USER".equalsIgnoreCase(cmd)) && !showCredentials)
				logger.debug("{}:{}", cmd, "*******");
			else
				logger.debug(event.getMessage().trim());
		}
		
		public void protocolReplyReceived (ProtocolCommandEvent event)
		{
			cmd = event.getCommand();
			cmd = event.getCommand();
			logger.debug(cmd);
			logger.debug(event.getMessage().trim());
		}
		
	}
}
