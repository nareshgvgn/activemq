/*------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.core.util
 * FILE     : StringUtils.java
 * CREATED  : Mar 4, 2009 4:23:44 PM
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * String utilities.
 * 
 * @author Prasad P. Khandekar
 * @verion $Id: StringUtils.java,v 1.2 2014/07/20 04:58:25 ramap Exp $
 * @since 1.0
 */
public abstract class StringUtils
{
	private static final Log _log = LogFactory.getLog(StringUtils.class.getName());
	
	/**
	 * Right pad a given string 'n' times with the padChar.
	 * 
	 * @param src
	 *            the string to be padded
	 * @param padChar
	 *            The padding character
	 * @param len
	 *            the length of output.
	 * @return the right padded string if final length is greater than source and source string is not null. Returns null if source string is null.
	 *         Returns source string as is if desired length is less than the source string.
	 */
	public static final String padRight (String src, String padChar, int len)
	{
		int idx = 0;
		StringBuilder sb = null;
		
		if (null == src)
		{
			if (_log.isWarnEnabled())
				_log.warn("Can rightPad null string!");
			return null;
		}
		if (len < src.length())
			return src;
		sb = new StringBuilder(len);
		sb.append(src);
		for (idx = src.length(); idx < len; idx++)
			sb.append(padChar);
		return sb.toString();
	}
	
	/**
	 * Left pad a given string 'n' times with the padChar.
	 * 
	 * @param src
	 *            the string to be padded
	 * @param padChar
	 *            The padding character
	 * @param len
	 *            the length of output.
	 * @return the left padded string if final length is greater than source and source string is not null. Returns null if source string is null.
	 *         Returns source string as is if desired length is less than the source string.
	 */
	public static final String padLeft (String src, String padChar, int len)
	{
		int idx = 0;
		StringBuilder sb = null;
		
		if (null == src)
		{
			if (_log.isWarnEnabled())
				_log.warn("Can leftPad null string!");
			return null;
		}
		if (len < src.length())
			return src;
		sb = new StringBuilder(len);
		for (idx = 0; idx < (len - src.length()); idx++)
			sb.append(padChar);
		sb.append(src);
		return sb.toString();
	}
	
	/**
	 * Helper method to convert a Character to String
	 * 
	 * @param chrIn
	 *            the character to be converted
	 * @return The String representation of Character, null if input is null.
	 */
	public static final String charToStr (Character chrIn)
	{
		if (null == chrIn)
		{
			if (_log.isWarnEnabled())
				_log.warn("Can not convert null Character to string!");
			return null;
		}
		return String.valueOf(chrIn.charValue());
	}
	
	/**
	 * Helper method to convert a String to Character
	 * 
	 * @param strIn
	 *            the string to be converted
	 * @return The first character in String, null if the input string is empty or null.
	 */
	public static final Character strToChar (String strIn)
	{
		if (null == strIn)
		{
			if (_log.isWarnEnabled())
				_log.warn("Can not convert null string to Character!");
			return null;
		}
		if (strIn.length() == 0)
			return null;
		return strIn.charAt(0);
	}
	
	/**
	 * Helper method to convert a Number to String
	 * 
	 * @param numIn
	 *            the number to be converted
	 * @return The string representation of number, null if the input is null.
	 */
	public static final String numberToString (Number numIn)
	{
		return (null == numIn ? null : numIn.toString());
	}
	
	/**
	 * Helper method to capitalize the first character of the given string and return the resultant string.
	 * 
	 * @param strIn
	 *            The string to be capitalized.
	 * @return The capitalized string, null if input is null or empty.
	 */
	public static final String capitalize (String strIn)
	{
		int strLen = -1;
		if (strIn == null || (strLen = strIn.length()) == 0)
			return strIn;
		return new StringBuffer(strLen).append(Character.toTitleCase(strIn.charAt(0))).append(strIn.substring(1)).toString();
	}
	
	/**
	 * Helper method to determine whether the supplied string is a zero length string or not. The null is also considered as zero length string.
	 * 
	 * @param strIn
	 *            The string to be checked.
	 * @return true if the supplied string is null or has zero length, false otherwise.
	 */
	public static final boolean isEmpty (String strIn)
	{
		return (null == strIn || strLength(strIn, true) == 0);
	}
	
	/**
	 * A null safe helper method to obtain the length of the input string.
	 * 
	 * @param strIn
	 *            The string whose length is to be obtained.
	 * @return 0 if input string is <code>null</code>, <code>String.length()</code> otherwise.
	 */
	public static final int strLength (String strIn)
	{
		return strLength(strIn, false);
	}
	
	/**
	 * A null safe helper method to obtain the length of the input string.
	 * 
	 * @param strIn
	 *            The string whose length is to be obtained.
	 * @param blnTrim
	 *            A flag to determine whether
	 * @return 0 if input string is <code>null</code>, <code>String.length()</code> otherwise.
	 */
	public static final int strLength (String strIn, boolean blnTrim)
	{
		return (null == strIn ? 0 : (blnTrim ? strIn.trim().length() : strIn.length()));
	}
	
	/**
	 * Helper method to check whether the length of supplied string falls between the specified limits.
	 * 
	 * @param strIn
	 *            The string whose length is to be checked.
	 * @param min
	 *            The minimum length
	 * @param max
	 *            The maximum length
	 * @return true if string length is in the specified limits, false othwerwise
	 */
	public static final boolean isLengthBetween (String strIn, int min, int max)
	{
		int len = -1;
		if (min == 0 && isEmpty(strIn))
			return true;
		len = strLength(strIn, true);
		return (len >= min && len <= max);
	}
}
