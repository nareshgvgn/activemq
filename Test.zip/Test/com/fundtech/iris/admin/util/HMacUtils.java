package com.fundtech.iris.admin.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import com.fundtech.iris.admin.security.DigestUtility;
import com.fundtech.iris.admin.security.Hmac;

/**
 * This is helper class which calculate the HASH/HMAC values.
 * 
 * @author Ratnesh Chourasiya
 * @created on : Jul 26, 2011 12:40:43 PM
 * @version $Id: HMacUtils.java,v 1.5 2014/09/09 10:39:46 ramap Exp $ : HMacUtils.java
 */
public class HMacUtils
{
	private final static String CHARSET = "UTF-8";
	private String certificatePath = null;
	private String hmacPassword = null;
	private String hmacAlias = null;
	private String hmacKeyalg = null;
	private String hashAlg = null;
	private String providerClass = null;
	private String providerName = null;
	
	/**
	 * @param certificatePath
	 * @param hmacPassword
	 * @param hmacAlias
	 * @param hmacKeyalg
	 * @param hashKey
	 */
	public HMacUtils(String certificatePath, String hmacPassword, String hmacAlias, String hmacKeyalg, String hashAlg, String providerClass,
			String providerName)
	{
		super();
		this.certificatePath = certificatePath;
		this.hmacPassword = hmacPassword;
		this.hmacAlias = hmacAlias;
		this.hmacKeyalg = hmacKeyalg;
		this.hashAlg = hashAlg;
		this.providerClass = providerClass;
		this.providerName = providerName;
		
	}
	
	// public String getHmacString(String value) throws Exception
	public String getHmacString (String value) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException,
			IOException, NoSuchProviderException, InvalidKeyException
	
	{
		Hmac hmacUtil = new Hmac();
		return Hmac.toHexString(hmacUtil.getDigest(value.toString().getBytes(CHARSET), hmacKeyalg,
				hmacUtil.getKeySpec(certificatePath, hmacPassword, hmacAlias, hmacKeyalg, providerClass, providerName)));
		
	}
	
	public String getHashString (String value) throws NoSuchAlgorithmException, UnsupportedEncodingException
	
	{
		DigestUtility digestUtil = new DigestUtility();
		return digestUtil.toHexString(digestUtil.getDigest(value.toString().getBytes(CHARSET), hashAlg));
	}
	
	public static void main (String[] args) throws UnrecoverableKeyException, InvalidKeyException, KeyStoreException, NoSuchAlgorithmException,
			CertificateException, NoSuchProviderException, IOException
	{
		
		// HMacUtils hMacUtils = new HMacUtils("/home/chaitanya/mykeystore.jks",
		// "123456", "anztest", "HmacSHA256",
		// "SHA-256", null, null);
		// System.out.println(hMacUtils.getHmacString("Chaitanya"));
	}
}
