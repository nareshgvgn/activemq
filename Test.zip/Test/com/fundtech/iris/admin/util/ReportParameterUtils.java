/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : ReportParameterUtils.java
 * CREATED: Jun 6, 2015 12:18:45 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DurationFieldType;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.report.ReportParameterDef;

/**
 * <p>TODO - The description and purpose of this class goes here
 * </p>
 * <p>
 * <h3>References</h3>
 * 	<table BORDER="30" CELLPADDING="10" CELLSPACING="3" BORDERCOLOR="000000">
	<tbody>
		<tr height="20">
			<td height="20" style="height:20px;width:253px;"><u><span style="color:#FF0000;"><em><strong>Operator</strong></em></span></u></td>
			<td style="width:231px;"><u><span style="color:#FF0000;"><em><strong>Data</strong></em></span></u></td>
			<td style="width:317px;"><u><span style="color:#FF0000;"><em><strong>Example:-</strong></em></span></u></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${BT}</em></td>
			<td><em>DATA1,DATA2</em></td>
			<td><em>${BT}|DATA1,DATA2</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${EQ}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${EQ}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${STARTWITH}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${STARTWITH}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${ENDWITH}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${ENDWITH}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${CONTAINS}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${CONTAINS}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${AS_OF_DATE}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${AS_OF_DATE}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LQ}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${LQ}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LT}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${LT}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${GQ}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${GQ}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${GT}</em></td>
			<td><em>DATA1</em></td>
			<td><em>${GT}|DATA1</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${TODAY}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${TODAY}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${YESTERDAY}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${YESTERDAY}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${THIS_WEEK}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${THIS_WEEK}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LAST_WEEK}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${LAST_WEEK}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LAST_WEEK_TODAY}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${LAST_WEEK_TODAY}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LAST_MONTH}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${LAST_MONTH}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${THIS_MONTH}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${THIS_MONTH}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LAST_MONTH_TODAY}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${LAST_MONTH_TODAY}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${THIS_QUARTER}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${THIS_QUARTER}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LAST_QUATER}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${LAST_QUATER}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LAST_QUATER_TODAY}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${LAST_QUATER_TODAY}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${THIS_YEAR}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${THIS_YEAR}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LAST_YEAR}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${LAST_YEAR}</em></td>
		</tr>
		<tr height="20">
			<td height="20" style="height:20px;"><em>${LAST_YEAR_TODAY}</em></td>
			<td><em>Nothing</em></td>
			<td><em>${LAST_YEAR_TODAY}</em></td>
		</tr>
	</tbody>
</table>

 * </p>
 * @author Babu Paluri
 * @version $Id: ReportParameterUtils.java,v 1.5 2016/12/08 11:23:37 ramap Exp $
 */
public class ReportParameterUtils
{
	
	
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	private ReportParameterUtils()
	{
	}
	
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param parmCode
	 * @param jobData
	 * @param parmDef
	 * @return
	 * </pre></p>
	 */
	public static String getNumberValueString (String parmCode, RMJobData jobData, ReportParameterDef parmDef)
	{
		String returnStr = null;
		String parmOperator = null;
		StringBuilder builder = null;
		int count = 0;
		String inputValue = null;
		String[] splitData = null;
		Map<String, String> reportParms = null;
		
	
		reportParms = jobData.getReportParameters();
		inputValue = reportParms.get(parmCode);
		if ( inputValue ==  null)
			return null;
		splitData = StringUtils.splitPreserveAllTokens(inputValue, "|");
		parmOperator = splitData[0];
		
		
		 if ( IrisAdminConstants.EQUAL.equals(parmOperator) &&  "LM".equals(parmDef.getDisplayType() ))
		{
			
			builder = new StringBuilder();
			builder.append("IN|");
			String[] values = getValues(splitData[1]);
			for ( String s : values)
			{
				if ( count != 0)
					builder.append("," + s );
				else
					builder.append( s );
			}
			returnStr = builder.toString();
			CleanUpUtils.doClean(builder);	
		}
		else if ( "LM".equals(parmDef.getDisplayType() ))
		{
			
			
			if ( "(ALL)".equals(parmOperator ))
				return "=|%";
				
			builder = new StringBuilder();
			builder.append("IN|");
			String[] values = getValues(parmOperator);
			for ( String s : values)
			{
				if ( count != 0)
					builder.append("," + s );
				else
					builder.append(s);
				count++;
			}
			returnStr = builder.toString();
			CleanUpUtils.doClean(builder);	
		}
		else
		{
			
			returnStr = "=|" + parmOperator;
			
		}
		return returnStr;
	}


	public static String getDecimalValueString(String parmCode, RMJobData jobData,ReportParameterDef parmDef)
	{
		String returnStr = null;
		String parmOperator = null;
		String inputValue = null;
		String[] splitData = null;
		String[] splitData1 = null;
		Map<String, String> reportParms = null;
		
		reportParms = jobData.getReportParameters();
		inputValue = reportParms.get(parmCode);
		if ( inputValue ==  null)
			return null;
		splitData = StringUtils.splitPreserveAllTokens(inputValue, "|");
		parmOperator = splitData[0];
		
		try
		{
			if ( IrisAdminConstants.BETWEEN.equals(parmOperator))
			{
				splitData1 = StringUtils.splitPreserveAllTokens(splitData[1], ",");
				returnStr = "BETWEEN|" + splitData1[0] + "," + splitData1[1] ;
			}
			else if ( IrisAdminConstants.EQUAL.equals(parmOperator) || IrisAdminConstants.AS_OF_DATE.equals(parmOperator))
				returnStr = "=|" + splitData[1] ;
			else if ( IrisAdminConstants.NOT_EQUAL.equals(parmOperator) )
				returnStr = "<>|" + splitData[1] ;
			else if ( IrisAdminConstants.LESSTHAN_EQUAL.equals(parmOperator))
				returnStr = "<=|" + splitData[1] ;
			else if ( IrisAdminConstants.LESSTHAN.equals(parmOperator))
				returnStr = "<|" + splitData[1] ;
			else if ( IrisAdminConstants.GRATERTHAN_EQUAL.equals(parmOperator))
				returnStr = ">=|" + splitData[1] ;
			else if ( IrisAdminConstants.GRATERTHAN.equals(parmOperator))
				returnStr = ">|" + splitData[1] ;
		}
		finally
		{
			parmOperator = null;
			inputValue = null;
			splitData = null;
			splitData1 = null;
		}
		
		return returnStr;
	}
	public static String getTextValueString(String parmCode, RMJobData jobData, ReportParameterDef parmDef)
	{
		String returnStr = null;
		String parmOperator = null;
		StringBuilder builder = null;
		int count = 0;
		Map<String, String> reportParms = null;
		String inputValue = null;
		String[] splitData = null;
		
	
		reportParms = jobData.getReportParameters();
		inputValue = reportParms.get(parmCode);
		if ( inputValue == null)
			return null;
		
		splitData = StringUtils.splitPreserveAllTokens(inputValue, "|");
		parmOperator = splitData[0];
		if ( "(ALL)".equals(splitData[0] ))
			return null;
		
		try
		{
			
			if ( IrisAdminConstants.START_WITH.equals(parmOperator))
				
				returnStr = "LIKE|'" + splitData[1] + "%'" ;
			else if ( IrisAdminConstants.END_WITH.equals(parmOperator))
				
				returnStr = "LIKE|'%" + splitData[1] + "'" ;
			else if ( IrisAdminConstants.CONTAINS_WITH.equals(parmOperator))
				
				returnStr = "LIKE|'%" + splitData[1] + "%'" ;
			else if ( IrisAdminConstants.EQUAL.equals(parmOperator) &&  "LM".equals(parmDef.getDisplayType() ))
			{
				builder = new StringBuilder();
				builder.append("IN|");
				String[] values = getValues(splitData[1]);
				for ( String s : values)
				{
					if ( count != 0)
						builder.append(",'" + s + "'");
					else
						builder.append("'" + s + "'");
				}
				returnStr = builder.toString();
				CleanUpUtils.doClean(builder);	
			}
			else if ( "LM".equals(parmDef.getDisplayType() ))
			{
				builder = new StringBuilder();
				builder.append("IN|");
				String[] values = getValues(splitData[0]);
				for ( String s : values)
				{
					if ( count != 0)
						builder.append(",'" + s + "'");
					else
						builder.append("'" + s + "'");
					count++;
				}
				returnStr = builder.toString();
				CleanUpUtils.doClean(builder);	
			}
			else
			{
				if ("USER".equalsIgnoreCase(parmCode) || "SELLER".equalsIgnoreCase(parmCode) || "CORPORATION".equalsIgnoreCase(parmCode) || "CLIENT".equalsIgnoreCase(parmCode))
				{
					returnStr = splitData[0];
					return returnStr;
				}
				returnStr = "=|'" + splitData[0] +"'";
			}
		}
		finally
		{
			parmOperator = null;
			builder = null;
			count = 0;
			inputValue = null;
			splitData = null;
		}
		return returnStr;
	}
	
	private static String[] getValues(String value)
	{
		String[] values = null;
		
		values = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(value,",");
		
		return values;
	}
	
	public static String getDateValueString(String parmCode,RMJobData jobData, ReportParameterDef parmDef) 
	{
		String returnStr = null;
		String parmOperator = null;
		Map<String, String> reportParms = null;
		String inputValue = null;
		String[] splitData = null;
		String[] splitData1 = null;
		String paramVal = null;
		DateTime appDate = null;
		DateTime startDate = null;
		DateTime endDate = null;
		int year = 0;
		int month = 0;
		
		reportParms = jobData.getReportParameters();
		inputValue = reportParms.get(parmCode);
		if ( inputValue ==  null)
			return null;
		
		splitData = StringUtils.splitPreserveAllTokens(inputValue, "|");
		parmOperator = splitData[0];
		try
		{
			if (IrisAdminConstants. BETWEEN.equals(parmOperator))
			{
				splitData1 = StringUtils.splitPreserveAllTokens(splitData[1], ",");
				returnStr = "BETWEEN|" + splitData1[0] + "," + splitData1[1] ;
			}
			else if ( IrisAdminConstants.EQUAL.equals(parmOperator) || IrisAdminConstants.AS_OF_DATE.equals(parmOperator))
				returnStr = "=|" + splitData[1] ;
			else if ( IrisAdminConstants.NOT_EQUAL.equals(parmOperator) )
				returnStr = "<>|" + splitData[1] ;
			else if ( IrisAdminConstants.LESSTHAN_EQUAL.equals(parmOperator))
				returnStr = "<=|" + splitData[1] ;
			else if ( IrisAdminConstants.LESSTHAN.equals(parmOperator))
				returnStr = "<|" + splitData[1] ;
			else if ( IrisAdminConstants.GRATERTHAN_EQUAL.equals(parmOperator))
				returnStr = ">=|" + splitData[1];
			else if ( IrisAdminConstants.GRATERTHAN.equals(parmOperator))
				returnStr = ">|" + splitData[1];
			else if ( IrisAdminConstants.AS_OF_DATE.equals(parmOperator))
				returnStr = "=|" + splitData[1];
			else if ( IrisAdminConstants.TODAY.equals(parmOperator))
			{
				paramVal = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE)).toString("dd/MM/yyyy");
				returnStr = "=|" + paramVal;
			}
			else if ( IrisAdminConstants.YESTERDAY.equals(parmOperator))
			{
				paramVal = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_PREV_APP_DATE)).toString("dd/MM/yyyy");
				returnStr = "=|" + paramVal;
			}
			else if ( IrisAdminConstants.LAST_WEEK.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				DateTime dt2 = appDate.withFieldAdded(DurationFieldType.weeks(), -1);
				startDate = dt2.withDayOfWeek(1);
				endDate = dt2.withDayOfWeek(7);
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + endDate.toString("dd/MM/yyyy");
			}
			else if ( IrisAdminConstants.LAST_WEEK_TODAY.equals(parmOperator))
			{
				
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				DateTime dt2 = appDate.withFieldAdded(DurationFieldType.weeks(), -1);
				startDate = dt2.withDayOfWeek(1);
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + appDate.toString("dd/MM/yyyy") ;
			}
			else if ( IrisAdminConstants.THIS_WEEK.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				startDate = appDate.withDayOfWeek(1);
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + appDate.toString("dd/MM/yyyy");
			}
			else if ( IrisAdminConstants.LAST_MONTH.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear();
				month = appDate.getMonthOfYear() - 1;
				if ( month < 1)
				{
					year = year - 1;
					month = 12;
				}
				startDate = appDate.withDate(year, month, 1);
				endDate = startDate.dayOfMonth().withMaximumValue();
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + endDate.toString("dd/MM/yyyy");
			}
			
			else if ( IrisAdminConstants.THIS_MONTH.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear();
				month = appDate.getMonthOfYear();
				startDate = appDate.withDate(year, month, 1);
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + appDate.toString("dd/MM/yyyy") ;
			}
			else if ( IrisAdminConstants.LAST_MONTH_TODAY.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear();
				month = appDate.getMonthOfYear() - 1;
				
				if ( month < 1)
				{
					year = year - 1;
					month = 12;
				}
				startDate = appDate.withDate(year, month, 1);
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + appDate.toString("dd/MM/yyyy") ;
			}
			else if ( IrisAdminConstants.LAST_QUATER.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				
				if ( appDate.getMonthOfYear() <= 3)
				{
					year = appDate.getYear() - 1;
					startDate = appDate.withDate(year, 10, 1);
					endDate = appDate.withDate(year , 12, 31);
				}
				else
				{
					startDate = quarterStartFor(appDate);
					endDate = quarterEndFor(appDate);
				}
				
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + endDate.toString("dd/MM/yyyy");
			}
			else if ( IrisAdminConstants.THIS_QUARTER.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				startDate = quarterStartFor(appDate);
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + appDate.toString("dd/MM/yyyy");
			}
			else if ( IrisAdminConstants.LAST_YEAR_TODAY.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				
				year = appDate.getYear() - 1;
				startDate = appDate.withDate(year, 1, 1);
				
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + appDate.toString("dd/MM/yyyy") ;
			}
			else if ( IrisAdminConstants.LAST_YEAR.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear() - 1;
				startDate = appDate.withDate(year, 1, 1);
				endDate = appDate.withDate(year, 12, 31);
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + endDate.toString("dd/MM/yyyy");
			}
			else if ( IrisAdminConstants.THIS_YEAR.equals(parmOperator))
			{
				appDate = getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear();
				startDate = appDate.withDate(year, 1, 1);
				returnStr = "BETWEEN|" + startDate.toString("dd/MM/yyyy") + "," + appDate.toString("dd/MM/yyyy");
			}
		}
		finally
		{
			parmOperator = null;
			inputValue = null;
			splitData = null;
			splitData1 = null;
			paramVal = null;
			appDate = null;
			startDate = null;
			endDate = null;
			year = 0;
			month = 0;
		}
		return returnStr;
	}
	
	private static DateTime quarterStartFor(DateTime date) 
	{
        return date.withDayOfMonth(1).withMonthOfYear((((date.getMonthOfYear() - 1) / 3) * 3) + 1);
    }

    private  static DateTime quarterEndFor(DateTime date)
    {
        return quarterStartFor(date).plusMonths(3).minusDays(1);
    }
    
    private static DateTime getDate (String value) throws UnsupportedOperationException, IllegalArgumentException
	{
		DateTime date = null;
		DateTimeFormatter fmt = null;
		try
		{
			if (value.trim().length() > 10)
			{
				fmt = DateTimeFormat.forPattern("dd/MM/yyyy HH:mm:ss");
			}
			else
			{
				fmt = DateTimeFormat.forPattern("dd/MM/yyyy");
			}
			date = fmt.parseDateTime(value);
		}
		finally
		{
			fmt = null;
		}
		return date;
	}
    
	
}
