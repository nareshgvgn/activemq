package com.fundtech.iris.admin.util;

import java.io.File;
import java.io.RandomAccessFile;

/**
 * 
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ReverseFileReader.java,v 1.2 2014/07/20 04:58:25 ramap Exp $
 * @since 1.0.0
 */
public class ReverseFileReader
{
	private RandomAccessFile randomfile = null;
	private long position = -1;
	
	public ReverseFileReader(File inputFile) throws Exception
	{
		String thisLine = null;
		Exception exp = null;
		
		if (!inputFile.exists())
		{
			exp = new Exception("File Not found:" + inputFile.getAbsolutePath());
			throw exp;
		}
		
		// Open up a random access file
		this.randomfile = new RandomAccessFile(inputFile, "r");
		
		// Set our seek position to the end of the file
		this.position = this.randomfile.length();
		
		// Seek to the end of the file
		this.randomfile.seek(this.position);
		
		// Move our pointer to the first valid position at the end of the file.
		thisLine = this.randomfile.readLine();
		while (thisLine == null)
		{
			this.position--;
			this.randomfile.seek(this.position);
			thisLine = this.randomfile.readLine();
			this.randomfile.seek(this.position);
		}
	}
	
	public ReverseFileReader(String filename) throws Exception
	{
		this(new File(filename));
	}
	
	public void closeFileReader () throws Exception
	{
		if (this.randomfile != null)
		{
			this.randomfile.close();
		}
	}
	
	// Read one line from the current position towards the beginning
	public String readLine () throws Exception
	{
		int thisCode;
		char thisChar;
		String finalLine = "";
		
		// If our position is less than zero already, we are at the beginning
		// with nothing to return.
		if (this.position < 0)
			return null;
		
		for (;;)
		{
			// we've reached the beginning of the file
			if (this.position < 0)
				break;
			
			// Seek to the current position
			this.randomfile.seek(this.position);
			
			// Read the data at this position
			thisCode = this.randomfile.readByte();
			thisChar = (char) thisCode;
			
			// If this is a line break or carrige return, stop looking
			if (thisCode == 13 || thisCode == 10)
			{
				// See if the previous character is also a line break character.
				// this accounts for crlf combinations
				this.randomfile.seek(this.position - 1);
				int nextCode = this.randomfile.readByte();
				// If we found another linebreak character, ignore it
				if ((thisCode == 10 && nextCode == 13) || (thisCode == 13 && nextCode == 10))
					this.position = this.position - 1;
				// Move the pointer for the next readline
				this.position--;
				break;
			}
			else
				// This is a valid character append to the string
				finalLine = thisChar + finalLine;
			
			// Move to the next char
			this.position--;
		}
		// return the line
		return finalLine;
	}
	
	public long getCurrentOffset ()
	{
		return position;
	}
}
