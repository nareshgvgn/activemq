/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : OracleType.java
 * CREATED: Jul 2, 2014 2:45:50 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

import oracle.jdbc.OracleTypes;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: OracleType.java,v 1.2 2014/07/20 04:58:25 ramap Exp $
 */
public class OracleType implements SQLData
{
	
	public static final String _SQL_NAME = "KEY_VALUE_PAIR";
	public static final int _SQL_TYPECODE = OracleTypes.STRUCT;
	private String key = null;
	private String value = null;
	private String type = null;
	
	public OracleType(String key, String value, String type)
	{
		this.key = key;
		this.value = value;
		this.type = type;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.sql.SQLData#getSQLTypeName()
	 */
	@Override
	public String getSQLTypeName () throws SQLException
	{
		return OracleType._SQL_NAME;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.sql.SQLData#readSQL(java.sql.SQLInput, java.lang.String)
	 */
	@Override
	public void readSQL (SQLInput stream, String typeName) throws SQLException
	{
		this.key = stream.readString();
		this.value = stream.readString();
		this.type = stream.readString();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.sql.SQLData#writeSQL(java.sql.SQLOutput)
	 */
	@Override
	public void writeSQL (SQLOutput stream) throws SQLException
	{
		stream.writeString(this.key);
		stream.writeString(this.value);
		stream.writeString(this.type);
	}
}