/*------------------------------------------------------------------------------
 * PACKAGE: com.cashtech.iris.util
 * FILE   : HelperUtils.java
 * CREATED: May 16, 2006 2:36:03 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.io.Closeable;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.jms.JMSException;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.Context;
import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Property;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.logging.IrisMarkers;

import oracle.jdbc.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 * A class containing frequently required utility methods 
 * @author Prasad P. Khandekar
 * @version $Id: HelperUtils.java,v 1.3 2015/10/19 12:01:44 ramap Exp $
 * @since 1.0.0
 */
public final class HelperUtils
{
    public static final String lineSeparator = System.getProperty("line.separator");
    
	private static final Logger _logger = LoggerFactory.getLogger(HelperUtils.class);

    private static final Map<String, Integer> DATA_TYPES = new HashMap<String, Integer>();
    static
    {
        DATA_TYPES.put("STRING", Integer.valueOf("0"));
        DATA_TYPES.put("LONG", Integer.valueOf("1"));
        DATA_TYPES.put("INTEGER", Integer.valueOf("2"));
        DATA_TYPES.put("UTILDATE", Integer.valueOf("3"));
        DATA_TYPES.put("DATE", Integer.valueOf("3"));
        DATA_TYPES.put("TIMESTAMP", Integer.valueOf("4"));
        DATA_TYPES.put("BOOLEAN", Integer.valueOf("5"));
        DATA_TYPES.put("BIGDECIMAL", Integer.valueOf("6"));
        DATA_TYPES.put("CHARACTER", Integer.valueOf("7"));
        DATA_TYPES.put("BYTE", Integer.valueOf("8"));
        DATA_TYPES.put("SQLDATE", Integer.valueOf("9"));
        DATA_TYPES.put("DOUBLE", Integer.valueOf("10"));
        DATA_TYPES.put("FLOAT", Integer.valueOf("11"));
        DATA_TYPES.put("BIGINTEGER", Integer.valueOf("12"));
        DATA_TYPES.put("SHORT", Integer.valueOf("13"));
        DATA_TYPES.put("CURRENCY", Integer.valueOf("14"));
        DATA_TYPES.put("OBJECT", Integer.valueOf("15"));
    }

    /**
     * A helper method to Close the specified stream and releases any system 
     * resources associated with it. 
     * @see Closeable
     * @param toClose The stream to be closed.
     */
    public static void doClose(Closeable toClose)
    {
        if (null == toClose) return;

        try
        {
            toClose.close();
        }
        catch (IOException exIgnore)
        {
            _logger.warn("Unable to close closable!", exIgnore);
        }
        toClose = null;
    }

    /**
     * Helper method to close the server socket and free the underlying resources.
     * @param sock The server socket to be closed.
     */
    public static void doClose(ServerSocket sock)
    {
        if (null == sock) return;

        try
        {
            if (!sock.isClosed())
                sock.close();
        }
        catch (IOException ioEx)
        {
            _logger.warn("Error occured while closing server socket!", ioEx);
        }
        sock = null;
    }

    /**
     * Helper method to close the server socket and free the underlying resources.
     * @param sock The server socket to be closed.
     */
    public static void doClose(Socket sock)
    {
        if (null == sock) return;

        try
        {
            if (!sock.isClosed())
                sock.close();
        }
        catch (IOException ioEx)
        {
            _logger.warn("Error occured while closing server socket!", ioEx);
        }
        sock = null;
    }

    /**
     * A helper method to close the database connection and release any resources
     * associated with it.
     * @param toClose The database connection reference
     */
    public static void doClose(Connection toClose)
    {
        if (null == toClose) return;

        try
        {
            if (!toClose.isClosed())
                toClose.close();
        }
        catch (SQLException exIgnore)
        {
        	_logger.error("Error:",exIgnore);
        }
        toClose =  null;
    }

    /**
     * A helper method to close the database statement and release any resources
     * associated with it.
     * @param toClose The database statement reference
     */
    public static void doClose(Statement toClose)
    {
        if (null == toClose) return;

        try
        {
            toClose.close();
        }
        catch (SQLException exIgnore)
        {
        	_logger.error("Error:",exIgnore);
        }
        toClose = null;
    }

    /**
     * A helper method to close the resultset and release any resources
     * associated with it.
     * @param toClose The resultset reference
     */
    public static void doClose(ResultSet toClose)
    {
        if (null == toClose) return;

        try
        {
            toClose.close();
        }
        catch (SQLException exIgnore)
        {
        	_logger.error("Error:",exIgnore);
        }
        toClose = null;
    }
    
    /**
     * A helper method to close the resultset and release any resources
     * associated with it.
     * @param toClose The resultset reference
     */
    public static void doClose(Scanner toClose)
    {
        if (null == toClose) return;

        try
        {
            toClose.close();
        }
        catch (Exception exIgnore)
        {
            _logger.warn("Unable to close closable!", exIgnore);
        }
        toClose = null;
    }

    /**
     * A helper method to retrieve the named data objects from given data object.
     * @param in the input do from which child do's are to be extracted.
     * @param name the name of the do to be extracted.
     * @return A list containing the references to named sdo instances.
     * @throws InappropriatePathTypeException 
     */
    public static List<Object> getNamedSDOs(DataObject in, String name) 
        throws InappropriatePathTypeException
    {
        int index = 0;
        int cntr = 0;
        List<Object> lstRet = null;
        List<Object> lstTmp = null;
        List props = null;
        Type inType = null;
        Object value = null;
        Property prop = null;
        String tokName = null;
        String[] toks = null;
        String path = null;
        int start = -1;
    	int end = -1;
    	int lstIndex = -1;
    	String token = null;
    	String indexVal = null;
        
        if (null == name) return null;

        try
        {
            lstRet = new ArrayList<Object>();
            inType = in.getType();
            path = name;
            toks = path.split("\\\\");
            tokName = toks[0];
            if ( toks.length > 1)
            {
            	token = tokName;
            	start = token.indexOf("[");
    	        end = token.indexOf("]", start + 1);
    	        if (start + 1 < end)
    	        	indexVal = token.substring(start + 1, end);
    	        lstIndex = toInteger(indexVal, -1);

    	        token = token.substring(0, start);
            	if (token.equals(inType.getName()))
            		name = path.substring(tokName.length() + 1);
            }
            
            if (name.equalsIgnoreCase(inType.getName()))
            {
                // the input do and the requested do are the same hence add it to
                // the list being returned.
                lstRet.add(in);
            }
            else
            {
                // we need to traverse through all the properties
                props = inType.getProperties();
                for (index = 0; index < props.size(); index++)
                {
                    prop = (Property) props.get(index);
                    // Since we are interested in a do we will skip the properties
                    // having primitive data type.
                    if (!isPrimitive(prop.getTypeName()))
                    {
                        value = in.getValue(prop.getName());
                        if (value instanceof List)
                        {
                            for (cntr = 0; cntr < ((List) value).size(); cntr++)
                            {
                                lstTmp = getNamedSDOs((DataObject) ((List) value).get(cntr), 
                                                        name);
                                lstRet.addAll(lstTmp);
                            }
                        }
                        else if (value instanceof DataObject)
                        {
                            lstTmp = getNamedSDOs((DataObject) value, name);
                            lstRet.addAll(lstTmp);
                        }
                        lstTmp = null;
                    }
                    prop = null;
                } // props for loop
                props = null;
            }
        }
        finally
        {
            if (lstTmp != null) lstTmp = null;
            if (prop != null) prop = null;
            if (props != null) props = null;
            if (inType != null) inType = null;
            if (value != null) value = null;
        }
        return lstRet;
    }

    /**
     * Helper method to determine whether the specified typename is a primitive
     * data type name or not. Following data types are assumed to be primitive
     * <ol>
     *  <li>BigDecimal</li>
     *  <li>BigInteger</li>
     *  <li>Boolean</li>
     *  <li>Byte</li>
     *  <li>Character</li>
     *  <li>Date</li>
     *  <li>Double</li>
     *  <li>Float</li>
     *  <li>Integer</li>
     *  <li>Long</li>
     *  <li>Object</li>
     *  <li>Short</li>
     *  <li>String</li>
     *  <li>SQLDate</li>
     *  <li>Timestamp</li>
     * </ol>
     * @param typeName The name to be checked.
     * @return true if typename is a primitive data type, false otherwise.
     */
    public static boolean isPrimitive(String typeName)
    {
        int lastPos = -1;
        boolean blnPrimitive = false;
        String dataType = null;

        if (null == typeName)
        {
            _logger.warn("Null type name was passed, returning true");
            return true;
        }

        dataType = typeName.toUpperCase();
        lastPos = dataType.lastIndexOf(".");
        if (lastPos != -1)
            dataType = dataType.substring(lastPos + 1);

        blnPrimitive = DATA_TYPES.containsKey(dataType);

        if (_logger.isTraceEnabled(IrisMarkers.TRACE))
			_logger.trace(IrisMarkers.TRACE, "Type [" + typeName + "] is " +
                            (blnPrimitive ? "a " : "not a ") +
                            "primitive type!");
        return blnPrimitive;
    }

	/**
	 * This method returns the unicode representation of the given String 'str'
	 * e.g. if we user provided a value ilke '\u0045\u0013\u0010\u0004\u0003' the
	 * JAXB parser converts it into string and we need to parese it to get exact
	 * unicode representation
	 * 
	 * @param str representating unicode string
	 * @return actual unicode representation of the string if it contains '\\u'
	 * in the string, null otherwise
	 */
	public static String getUnicodeValue(String str)
	{
		int pos = -1;
		int next = -1;
		String temp = null;

        if (null == str) return null;

		pos = str.indexOf("\\u");
        if (pos == -1) return str;

		while (pos != -1)
		{
			if (null == temp) temp = "";

			next = str.indexOf("\\u", pos + 1);
			if (next < 0)
				temp += (char) Integer.parseInt(str.substring(pos + 2, 
						str.length()));
			else
				temp += (char) Integer.parseInt(str.substring(pos + 2, next));
			pos = next;
		}
		return temp;
	}

    /**
     * A Helper method to return the data types index
     * @param dataType The data type name
     * @return the integer identifier associated with that data type
     */
    public static int getDataTypeIndex(String dataType)
    {
    	int pos = -1;

        if (null == dataType) return -1;
        dataType = dataType.toUpperCase();
        pos = dataType.lastIndexOf(".");
        if (pos >= 0) dataType = dataType.substring(pos + 1);
        if (DATA_TYPES.containsKey(dataType))
            return ((Integer) DATA_TYPES.get(dataType)).intValue();

        return -1;
    }

    /**
     * A helper method to cleanup JMS Session
     * @param session
     */
    public static void doClose(Session session)
    {
        if (null == session) return;

        try
        {
            session.close();
        }
        catch (JMSException jmsEx)
        {
            _logger.warn("Unable to close JMS session!", jmsEx);
        }
        session = null;
    }

    /**
     * A helper method to load a class and check whether it exists or not.
     * @param clsName The full class name
     * @return true if named class exists, false otherwise
     */
    public static boolean isClassAvailable(String clsName)
    {
        Class clazz = null;

        try
        {
            clazz = Class.forName(clsName);
            return (clazz != null);
        }
        catch (ClassNotFoundException exIgnore)
        {
        	_logger.error("Error:",exIgnore);
        }
        return false;
    }
    
    /**
     * Counts the char(given) repeated in a given string 
     * @param str The string in which the number of occurrences of 'c' are to be
     * found.
     * @param c The character to whose number of occurrences are sought.
     * @return The count
     */
    public static int countChar(String str, char c)
    {
        int index = 0;
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++)
        {
            if (chars[i] == c)
                index++;
        }
        return index;
    }
    
    public static synchronized String paddingString(String stringTobePadded,
			int numberOfChartoLook, char charTobePaddedWith,
			boolean ispaddingLeft)
	{
    	StringBuilder str = new StringBuilder(stringTobePadded);
		int strLength = str.length();
		if (numberOfChartoLook > 0 && numberOfChartoLook > strLength)
		{
			for (int i = 0; i <= numberOfChartoLook; i++)
			{
				if (ispaddingLeft)
				{
					if (i < numberOfChartoLook - strLength)
					{
						str.insert(0, charTobePaddedWith);
					}
				}
				else
				{
					if (i > strLength)
					{
						str.append(charTobePaddedWith);
					}
				}
			}
		}
		return str.toString();
	}
    
    public static String replaceWithRecordSeparator(String value,String regex)
    {
    	if( value == null)
    	{
    		return null;
    	}
    	value = value.replaceAll(regex, lineSeparator);
    	return value;
    }

    private static int toInteger (String value, int defaultVal)
	{
		int realvalue = 0;
		try
		{
			realvalue = Integer.parseInt(value);
			return realvalue;
		}
		catch (Exception ex)
		{
			_logger.warn("Unable to convert String [" + value + "] to integer!", ex);
		}
		return defaultVal;
	}
	
    
	private static long toLong (String value, long defaultVal)
	{
		long realvalue = 0;
		try
		{
			realvalue = Long.parseLong(value);
			return realvalue;
		}
		catch (Exception ex)
		{
			_logger.warn("Unable to convert String [" + value + "] to long!", ex);
		}
		return defaultVal;
	}
	
	/**
	 * Helper method to create the new named Context
	 * 
	 * @return reference to newly created {@linkplain Context}
	 * @throws Exception
	 */
	public static Context createContext () throws Exception
	{
		
		Context context = null;
		ContextManager contextManager = null;
		
		// Create the context
		contextManager = ContextManager.getInstance();
		context = contextManager.getSimpleContext();
		return context;
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param con
	 * @param sqlType
	 * @param typeName
	 * @param _arrValues
	 * @return
	 * @throws SQLException
	 * </pre></p>
	 */
	public static ARRAY createTypeValue (OracleConnection con, int sqlType, String typeName, Object _arrValues) throws SQLException
	{
		ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(typeName, con);
		
		ARRAY array = new ARRAY(arrayDescriptor, con, _arrValues);
		return array;
	}
    
}
