/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : DBToDBUtils.java
 * CREATED: Feb 9, 2016 9:52:12 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Map;

import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: DBToDBUtils.java,v 1.3 2016/02/09 07:12:59 ramap Exp $
 */
public final class DBToDBUtils
{
	
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandDef
	 * @param jobData
	 * @param hostDbConnection
	 * </pre></p>
	 */
	public static void callHostUpdate (InterfaceBandDef bandDef, ExecutionJobData jobData, Connection hostDbConnection) 
	{
		CallableStatement procStmt = null;
		String procCall = null;
		OracleType[] types = null;
		OracleType  oracleType = null;
		Map<String, String> filters = null;
		int index = 0;
		ARRAY array = null;
		OracleConnection oraConnection = null;
		
		procCall = bandDef.getUpdateQuery();
		if ( procCall == null)
			return ;
		
		try
		{
			oraConnection = IrisAdminUtils.getOracleConnection(hostDbConnection);
			filters = jobData.getFilterParameters();
			procCall = "{CALL " + procCall + "(?,?,?,?,?)}";
			
			if ( filters.size() > 0)
			{
				types = new OracleType[jobData.getFilterParameters().size()];
				for (Map.Entry<String, String> entry : filters.entrySet())
				{
					oracleType = new OracleType(entry.getKey(), entry.getValue(), "RUNTIME");
					types[index] = oracleType;
					index ++;
				}
			}
			else
			{
				types = new OracleType[1];
				oracleType = new OracleType(null, null, null);
				types[0] = oracleType;
			}
			array =  HelperUtils.createTypeValue(oraConnection, OracleTypes.ARRAY, "NT_KEY_VALUE_PAIR", types);
			procStmt = oraConnection.prepareCall(procCall);
			procStmt.setString(1, jobData.getExecutionId());
			procStmt.setString(2, jobData.getMapName());
			procStmt.setString(3, jobData.getStatus());
			procStmt.setString(4, null);
			procStmt.setObject(5, array, OracleTypes.ARRAY);
			procStmt.executeUpdate();
			oraConnection.commit();
		}
		catch ( Exception exp)
		{
			exp.printStackTrace();
		}
		finally
		{
			CleanUpUtils.doClean(procStmt);
		}
		
		
	}
	
	
}
