/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : XlsxSheetToDO.java
 * CREATED: Jul 6, 2016 1:01:22 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.MapDataObject;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: XlsxSheetToDO.java,v 1.1 2016/08/04 05:35:42 ramap Exp $
 */
public class XlsxSheetToDO  implements SheetContentsHandler
{
	private Logger logger = LoggerFactory.getLogger(XlsxSheetToDO.class);
	private int currentRow = -1;
	private int currentCol = -1;
	private int startRow = 0;
	private int endRow = -1;
	private int startCell = 1;
	private int endCell = -1;
	private int isHeader = -1;
	private Map<Integer, String> headers = new HashMap<Integer, String>();
    private boolean isRowStarted = false;
    private String typeName = null;
    private DataObject dataDo = null;
    private List<DataObject> doList = null;
	
	public XlsxSheetToDO(String typeName, List<DataObject> doList)
	{
		this.typeName = typeName;
		this.doList = doList;
	}
	
	public void startRow (int rowNum)
	{
		logger.trace("Row Number: {} is executing ", rowNum);
		
		if ( startRow == rowNum)
			isHeader = 0;
		
		isRowStarted = true;
		currentRow = rowNum;
		currentCol = -1;
	}
	
	public void endRow (int rowNum)
	{
		if ( startRow == rowNum)
			isHeader = 1;
	}
	
	public void cell (String cellReference, String formattedValue, XSSFComment comment)
	{
		CellReference refCell = null;
		String elementName = null;
		
		// gracefully handle missing CellRef here in a similar way as XSSFCell does
		if (cellReference == null)
		{
			cellReference = new CellAddress(currentRow, currentCol).formatAsString();
		}
		refCell = new CellReference(cellReference);
		int thisCol = refCell.getCol();
		
		if ( thisCol >= startCell && startRow <= refCell.getRow())
		{
			if ( isRowStarted && isHeader == 1) //  this condition will lot allow to create empty root
			{
				dataDo = new MapDataObject(typeName);
				doList.add(dataDo);
				isRowStarted = false;
			}
			
			if (isHeader == 0)
			{
				formattedValue = removeSplChas(formattedValue);
				headers.put(thisCol, formattedValue);
			}
			else if ( isHeader == 1)
			{
				elementName = headers.get(thisCol);
				logger.trace("Processing {}  with value:{}" ,elementName, formattedValue);
				try
				{
					dataDo.setValue(elementName, formattedValue);
				}
				catch (InappropriatePathTypeException e)
				{
					// BABU Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		currentCol = thisCol;
	}
	
	
	private String removeSplChas (String sheetName)
	{
		String output = null;
		
		output = sheetName.replaceAll( "[^a-zA-Z0-9]", "");
		
		return output;
	}


	/* (non-Javadoc)
	 * @see org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler#headerFooter(java.lang.String, boolean, java.lang.String)
	 */
	@Override
	public void headerFooter (String text, boolean isHeader, String tagName)
	{
		// BABU Auto-generated method stub
		
	}
	
	
	/**
	 * @return the startRow
	 */
	public int getStartRow ()
	{
		return startRow;
	}

	/**
	 * @param startRow the startRow to set
	 */
	public void setStartRow (int startRow)
	{
		this.startRow = startRow;
	}

	/**
	 * @return the endRow
	 */
	public int getEndRow ()
	{
		return endRow;
	}

	/**
	 * @param endRow the endRow to set
	 */
	public void setEndRow (int endRow)
	{
		this.endRow = endRow;
	}

	/**
	 * @return the startCell
	 */
	public int getStartCell ()
	{
		return startCell;
	}

	/**
	 * @param startCell the startCell to set
	 */
	public void setStartCell (int startCell)
	{
		this.startCell = startCell;
	}

	/**
	 * @return the endCell
	 */
	public int getEndCell ()
	{
		return endCell;
	}

	/**
	 * @param endCell the endCell to set
	 */
	public void setEndCell (int endCell)
	{
		this.endCell = endCell;
	}
}
