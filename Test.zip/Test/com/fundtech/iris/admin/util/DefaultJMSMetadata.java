/*------------------------------------------------------------------------------
 * PACKAGE: com.cashtech.iris.core.processor.activators.jms
 * FILE   : DefaultJMSMetadata.java
 * CREATED: Aug 11, 2011 11:10:25 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.TextMessage;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: DefaultJMSMetadata.java,v 1.4 2014/09/09 10:41:07 ramap Exp $
 * @since 1.0.0
 */
public class DefaultJMSMetadata
{
	public static final String JMS_MESSAGE_ID = "JMSMessageID";
	public static final String JMS_CO_RELATION_ID = "JMSCoRelationID";
	public static final String JMS_DESTINATION = "JMSDestination";
	public static final String JMS_REPLY_TO = "JMSReplyTo";
	public static final String JMS_IBM_MSG_TYPE = "JMS_IBM_MsgType";
	
	public static Map<String, Object> getMessageHeaders (TextMessage jmsMessage) throws JMSException
	{
		String key = null;
		Map<String, Object> customHeaders = null;
		
		customHeaders = new HashMap<String, Object>();
		customHeaders.put(JMS_MESSAGE_ID, jmsMessage.getJMSMessageID());
		customHeaders.put(JMS_CO_RELATION_ID, jmsMessage.getJMSCorrelationID());
		customHeaders.put(JMS_DESTINATION, jmsMessage.getJMSDestination());
		customHeaders.put(JMS_REPLY_TO, jmsMessage.getJMSReplyTo());
		customHeaders.put(JMS_CO_RELATION_ID, jmsMessage.getJMSCorrelationID());
		@SuppressWarnings("unchecked")
		Enumeration<String> enu = jmsMessage.getPropertyNames();
		while (enu.hasMoreElements())
		{
			key = enu.nextElement();
			customHeaders.put(key, jmsMessage.getObjectProperty(key));
		}
		
		return customHeaders;
	}
	
	public static Map<String, Object> getMessageHeaders (BytesMessage jmsMessage) throws JMSException
	{
		String key = null;
		Map<String, Object> customHeaders = null;
		
		customHeaders = new HashMap<String, Object>();
		customHeaders.put(JMS_MESSAGE_ID, jmsMessage.getJMSMessageID());
		customHeaders.put(JMS_CO_RELATION_ID, jmsMessage.getJMSCorrelationID());
		customHeaders.put(JMS_DESTINATION, jmsMessage.getJMSDestination());
		customHeaders.put(JMS_REPLY_TO, jmsMessage.getJMSReplyTo());
		customHeaders.put(JMS_CO_RELATION_ID, jmsMessage.getJMSCorrelationID());
		Enumeration<String> enu = jmsMessage.getPropertyNames();
		while (enu.hasMoreElements())
		{
			key = enu.nextElement();
			customHeaders.put(key, jmsMessage.getObjectProperty(key));
		}
		
		return customHeaders;
	}
	
	public void setMessageHeaders (TextMessage jmsMessage, Map<String, Object> customHeaders) throws JMSException
	{
		
		String key = null;
		Object valueObj = null;
		
		for (Map.Entry<String, Object> entry : customHeaders.entrySet())
		{
			key = entry.getKey();
			valueObj = entry.getValue();
			if (key.equals(JMS_MESSAGE_ID))
				jmsMessage.setJMSCorrelationID((String) valueObj);
			else if (key.equals(JMS_CO_RELATION_ID))
			{
				// need to thik what to do with this
			}
			else if (key.equals(JMS_REPLY_TO))
			{
				// Need to think what to do
			}
			else if (key.equals(JMS_DESTINATION))
			{
				// Need to think what to do
			}
			else if (key.equals(JMS_IBM_MSG_TYPE))
				jmsMessage.setIntProperty(key, 2);
			else
				// Rest Static Values will be passed here, for example MQMD MsgType need to pass
				// Set JMS_IBM_MsgType as key and relavent Value as static in ProcessDef
				jmsMessage.setObjectProperty(key, valueObj);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.util.JMSMetadataHelper#setMessageHeaders(javax.jms.BytesMessage, java.util.Map,
	 * com.cashtech.iris.patterns.sdo.DataObject)
	 */
	public void setMessageHeaders (BytesMessage jmsMessage, Map<String, Object> customHeaders) throws JMSException
	{
		String key = null;
		Object valueObj = null;
		
		for (Map.Entry<String, Object> entry : customHeaders.entrySet())
		{
			key = entry.getKey();
			valueObj = entry.getValue();
			if (key.equals(JMS_MESSAGE_ID))
				jmsMessage.setJMSCorrelationID((String) valueObj);
			else if (key.equals(JMS_CO_RELATION_ID))
			{
				// need to thik what to do with this
			}
			else if (key.equals(JMS_REPLY_TO))
			{
				// Need to think what to do
			}
			else if (key.equals(JMS_DESTINATION))
			{
				// Need to think what to do
			}
			else if (key.equals(JMS_IBM_MSG_TYPE))
				jmsMessage.setIntProperty(key, 2);
			else
				// Rest Static Values will be passed here, for example MQMD MsgType need to pass
				// Set JMS_IBM_MsgType as key and relavent Value as static in ProcessDef
				jmsMessage.setObjectProperty(key, valueObj);
		}
	}
	
}
