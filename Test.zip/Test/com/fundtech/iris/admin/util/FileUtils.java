/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : FileUtils.java
 * CREATED: Mar 12, 2014 9:50:38 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. See the NOTICE file distributed with this work
 * for additional information regarding copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations
 * under the License.
 */
package com.fundtech.iris.admin.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;

/**
 * <p>
 * This helper class taken from apache io FileUtils.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FileUtils.java,v 1.4 2016/04/28 07:06:27 ramap Exp $
 */
public class FileUtils
{
	
	/**
	 * Gets the base name, minus the full path and extension, from a full filename.
	 * <p>
	 * This method will handle a file in either Unix or Windows format. The text after the last forward or backslash and before the last dot is
	 * returned.
	 * 
	 * <pre>
	 * a/b/c.txt --> c
	 * a.txt     --> a
	 * a/b/c     --> c
	 * a/b/c/    --> ""
	 * </pre>
	 * <p>
	 * The output will be the same irrespective of the machine that the code is running on.
	 * 
	 * @param filename
	 *            the filename to query, null returns null
	 * @return the name of the file without the path, or an empty string if none exists
	 */
	public static String getBaseName (String filename)
	{
		return removeExtension(getName(filename));
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Removes the extension from a filename.
	 * <p>
	 * This method returns the textual part of the filename before the last dot. There must be no directory separator after the dot.
	 * 
	 * <pre>
	 * foo.txt    --> foo
	 * a\b\c.jpg  --> a\b\c
	 * a\b\c      --> a\b\c
	 * a.b\c      --> a.b\c
	 * </pre>
	 * <p>
	 * The output will be the same irrespective of the machine that the code is running on.
	 * 
	 * @param filename
	 *            the filename to query, null returns null
	 * @return the filename minus the extension
	 */
	public static String removeExtension (String filename)
	{
		if (filename == null)
		{
			return null;
		}
		int index = indexOfExtension(filename);
		if (index == -1)
		{
			return filename;
		}
		else
		{
			return filename.substring(0, index);
		}
	}
	
	/**
	 * Gets the extension of a filename.
	 * <p>
	 * This method returns the textual part of the filename after the last dot. There must be no directory separator after the dot.
	 * 
	 * <pre>
	 * foo.txt      --> "txt"
	 * a/b/c.jpg    --> "jpg"
	 * a/b.txt/c    --> ""
	 * a/b/c        --> ""
	 * </pre>
	 * <p>
	 * The output will be the same irrespective of the machine that the code is running on.
	 * 
	 * @param filename
	 *            the filename to retrieve the extension of.
	 * @return the extension of the file or an empty string if none exists or {@code null} if the filename is {@code null}.
	 */
	public static String getExtension (String filename)
	{
		if (filename == null)
		{
			return null;
		}
		int index = indexOfExtension(filename);
		if (index == -1)
		{
			return "";
		}
		else
		{
			return filename.substring(index + 1);
		}
	}
	
	/**
	 * Returns the index of the last extension separator character, which is a dot.
	 * <p>
	 * This method also checks that there is no directory separator after the last dot. To do this it uses {@link #indexOfLastSeparator(String)} which
	 * will handle a file in either Unix or Windows format.
	 * <p>
	 * The output will be the same irrespective of the machine that the code is running on.
	 * 
	 * @param filename
	 *            the filename to find the last path separator in, null returns -1
	 * @return the index of the last separator character, or -1 if there is no such character
	 */
	public static int indexOfExtension (String filename)
	{
		if (filename == null)
		{
			return -1;
		}
		int extensionPos = filename.lastIndexOf(".");
		int lastSeparator = indexOfLastSeparator(filename);
		return lastSeparator > extensionPos ? -1 : extensionPos;
	}
	
	/**
	 * Returns the index of the last directory separator character.
	 * <p>
	 * This method will handle a file in either Unix or Windows format. The position of the last forward or backslash is returned.
	 * <p>
	 * The output will be the same irrespective of the machine that the code is running on.
	 * 
	 * @param filename
	 *            the filename to find the last path separator in, null returns -1
	 * @return the index of the last separator character, or -1 if there is no such character
	 */
	public static int indexOfLastSeparator (String filename)
	{
		if (filename == null)
		{
			return -1;
		}
		int lastUnixPos = filename.lastIndexOf("/");
		int lastWindowsPos = filename.lastIndexOf("\\");
		return Math.max(lastUnixPos, lastWindowsPos);
	}
	
	/**
	 * Gets the name minus the path from a full filename.
	 * <p>
	 * This method will handle a file in either Unix or Windows format. The text after the last forward or backslash is returned.
	 * 
	 * <pre>
	 * a/b/c.txt --> c.txt
	 * a.txt     --> a.txt
	 * a/b/c     --> c
	 * a/b/c/    --> ""
	 * </pre>
	 * <p>
	 * The output will be the same irrespective of the machine that the code is running on.
	 * 
	 * @param filename
	 *            the filename to query, null returns null
	 * @return the name of the file without the path, or an empty string if none exists
	 */
	public static String getName (String filename)
	{
		if (filename == null)
		{
			return null;
		}
		int index = indexOfLastSeparator(filename);
		return filename.substring(index + 1);
	}
	
	public static void main (String[] args)
	{
		String s = "babu.txt";
		System.out.println(FileUtils.getBaseName(s));
		s = "babu";
		System.out.println(FileUtils.getBaseName(s));
		s = "babu.txt.pdf";
		System.out.println(FileUtils.getBaseName(s));
		s = "C:/download/babu.txt";
		System.out.println(FileUtils.getBaseName(s));
		s = "C:/download/";
		System.out.println(FileUtils.getBaseName(s));
	}
	
	private void appendToFile(final InputStream in, final File f) throws IOException 
	{
        IOUtils.copy(in, outStream(f));
    }

    private void appendToFile(final String in, final File f)  throws IOException
    {
        appendToFile(IOUtils.toInputStream(in), f);
    }

    private OutputStream outStream(final File f) throws IOException 
    {
        return new BufferedOutputStream(new FileOutputStream(f, true));
    }
    
    private InputStream inStream(final File f) throws FileNotFoundException
    {
    	return new FileInputStream(f);
    }
    
    private void appendToFile( final File needtoCopy , final File toAppedFile) throws FileNotFoundException,  IOException
    {
    	appendToFile(inStream(needtoCopy), toAppedFile);
    }

}
