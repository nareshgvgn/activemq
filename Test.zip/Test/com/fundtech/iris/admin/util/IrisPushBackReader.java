/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : IrisPushBackReader.java
 * CREATED: Feb 3, 2014 10:44:32 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Scanner;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IrisPushBackReader.java,v 1.2 2014/07/20 04:58:25 ramap Exp $
 */
public class IrisPushBackReader
{
	
	private Scanner scanner = null;
	private String lastLine = null;
	
	public IrisPushBackReader(InputStream stream)
	{
		scanner = new Scanner(stream);
	}
	
	public IrisPushBackReader(File file) throws FileNotFoundException
	{
		scanner = new Scanner(file);
	}
	
	public void useDelimiter (String pattern)
	{
		scanner.useDelimiter(pattern);
	}
	
	public boolean hasNext ()
	{
		if (lastLine != null)
			return true;
		else
			return scanner.hasNext();
	}
	
	public String next ()
	{
		String line = null;
		
		if (lastLine != null)
			line = lastLine;
		
		line = scanner.next();
		
		return line;
	}
	
	public boolean hasNextLine ()
	{
		if (lastLine != null)
			return true;
		else
			return scanner.hasNextLine();
	}
	
	public String nextLine ()
	{
		String line = null;
		
		if (lastLine != null)
			line = lastLine;
		
		line = scanner.nextLine();
		
		return line;
	}
	
	public void pushBack (String line)
	{
		lastLine = line;
	}
	
}
