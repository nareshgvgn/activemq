/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : CodeMapDataExtractor.java
 * CREATED: Jul 4, 2016 7:34:15 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.util.SAXHelper;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.MapDataObject;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: CodeMapDataExtractor.java,v 1.1 2016/08/04 05:35:42 ramap Exp $
 */
public class CodeMapDataExtractor extends DataExtractor
{
	private Logger logger = LoggerFactory.getLogger(CodeMapDataExtractor.class);
	public static  String XLS_FILE_NAME = "XLS_FILE_NAME";
	private int startRow = 0;
	private int endRow = -1;
	private int startCell = 0;
	private int endCell = -1;
	private int startSheet = 0;
	private int endSheet = -1;
	private String retunType = "CodeMapList";
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public CodeMapDataExtractor()
	{
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.util.DataExtractor#extract(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object extract (Connection dbConnection, Map<String, Object> parms)
	{
		DataObject outDo = null;
		File xlsxFile = null;
		ExecutionJobData jobData = null;
		
		try
		{
			jobData = (ExecutionJobData)parms.get(IPlugin.EXECUTION_DATA);
			xlsxFile = new File(jobData.getMediaDetails());
			System.out.println("File Received as :" +  xlsxFile.getAbsolutePath());
			outDo = processXls(xlsxFile);
		}
		catch (InappropriatePathTypeException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (SAXException e)
		{
			e.printStackTrace();
		}
		catch (OpenXML4JException e)
		{
			e.printStackTrace();
		}
		return outDo;
	}
	
	/**
	 * Parses and shows the content of one sheet using the specified styles and shared-strings tables.
	 * @param styles
	 * @param strings
	 * @param sheetInputStream
	 * @throws SAXException 
	 * @throws IOException 
	 */
	private void processSheet (StylesTable styles, ReadOnlySharedStringsTable strings, SheetContentsHandler sheetHandler, InputStream sheetInputStream) 
				throws SAXException, IOException
	{
		DataFormatter formatter = null;
		InputSource sheetSource = null;
		XMLReader sheetParser = null;
		ContentHandler handler = null;
		
		formatter = new DataFormatter();
		sheetSource = new InputSource(sheetInputStream);
		try
		{
			sheetParser = SAXHelper.newXMLReader();
			handler = new XSSFSheetXMLHandler(styles, null, strings, sheetHandler, formatter, false);
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
		}
		catch (ParserConfigurationException e)
		{
			throw new RuntimeException("SAX parser appears to be broken - " + e.getMessage());
		}
	}
	
	private DataObject processXls (File xlsxFile) throws IOException, SAXException, OpenXML4JException, InappropriatePathTypeException 
	{
		String sheetName = null;
		String orgSheetName = null;
		ReadOnlySharedStringsTable strings = null;
		XSSFReader xssfReader = null;
		StylesTable styles = null;
		XSSFReader.SheetIterator iter = null;
		InputStream stream = null;
		OPCPackage xlsxPackage = null;
		XlsxSheetToDO xlsxSheetToDO = null;
		long startTime = System.currentTimeMillis();
		List<DataObject> doList = null;
		DataObject outDo = null;
		
		try
		{
			xlsxPackage = OPCPackage.open(xlsxFile, PackageAccess.READ);
			strings = new ReadOnlySharedStringsTable(xlsxPackage);
			xssfReader = new XSSFReader(xlsxPackage);
			styles = xssfReader.getStylesTable();
			iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
			while (iter.hasNext())
			{
				stream = iter.next();
				orgSheetName = iter.getSheetName();
				logger.trace("Conversion {}",  orgSheetName);
				sheetName = removeSplChas(orgSheetName);
				outDo = new MapDataObject(retunType);
				doList = new ArrayList<DataObject>();
				xlsxSheetToDO = new XlsxSheetToDO( sheetName, doList);
				xlsxSheetToDO.setStartRow(startRow);
				xlsxSheetToDO.setEndRow(endRow);
				xlsxSheetToDO.setStartCell(startCell);
				xlsxSheetToDO.setEndCell(endCell);
				
				processSheet(styles, strings, xlsxSheetToDO, stream);
				stream.close();
				System.out.println(doList);
				outDo.setValue(sheetName, doList);
				logger.trace("Conversion took {} secounds  for Sheet:{}" , (int) ((System.currentTimeMillis() - startTime) / 1000),  orgSheetName);
			}
			
			logger.debug(" WorkBook Conversion took {} secounds " , (int) ((System.currentTimeMillis() - startTime) / 1000) );
			return outDo;
		}
		finally
		{
			if ( xlsxPackage != null)
				xlsxPackage.close();
		}
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param sheetName
	 * @return
	 * </pre></p>
	 */
	private String removeSplChas (String sheetName)
	{
		String output = null;
		
		output = sheetName.replaceAll( "[^a-zA-Z0-9]", "");
		
		return output;
	}
	
	/**
	 * @return the startRow
	 */
	public int getStartRow ()
	{
		return startRow;
	}

	/**
	 * @param startRow the startRow to set
	 */
	public void setStartRow (int startRow)
	{
		this.startRow = startRow;
	}

	/**
	 * @return the endRow
	 */
	public int getEndRow ()
	{
		return endRow;
	}

	/**
	 * @param endRow the endRow to set
	 */
	public void setEndRow (int endRow)
	{
		this.endRow = endRow;
	}

	/**
	 * @return the startCell
	 */
	public int getStartCell ()
	{
		return startCell;
	}

	/**
	 * @param startCell the startCell to set
	 */
	public void setStartCell (int startCell)
	{
		this.startCell = startCell;
	}

	/**
	 * @return the endCell
	 */
	public int getEndCell ()
	{
		return endCell;
	}

	/**
	 * @param endCell the endCell to set
	 */
	public void setEndCell (int endCell)
	{
		this.endCell = endCell;
	}

	/**
	 * @return the startSheet
	 */
	public int getStartSheet ()
	{
		return startSheet;
	}

	/**
	 * @param startSheet the startSheet to set
	 */
	public void setStartSheet (int startSheet)
	{
		this.startSheet = startSheet;
	}

	/**
	 * @return the endSheet
	 */
	public int getEndSheet ()
	{
		return endSheet;
	}

	/**
	 * @param endSheet the endSheet to set
	 */
	public void setEndSheet (int endSheet)
	{
		this.endSheet = endSheet;
	}
	
}
