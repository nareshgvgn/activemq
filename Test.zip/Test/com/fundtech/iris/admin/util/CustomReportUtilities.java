/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : CustomReportUtilities.java
 * CREATED: Jul 5, 2015 5:25:23 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.jdom2.Document;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.XMLOutputter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: CustomReportUtilities.java,v 1.3 2015/11/03 04:25:06 ramap Exp $
 */
public final class CustomReportUtilities
{
	private static Logger logger = LoggerFactory.getLogger(CustomReportUtilities.class);
	
	public static String prepareSortColumnParameter(String parentReportCode, String reportCode, String colOrderjsonStr, Map<String, String> paramColumns ) 
	{
		StringBuilder sb = null;
		String result = null;
		JSONObject colJsonNew = null;
		JSONObject selectJson = null;
		JSONArray jarray = null;
		try 
		{
			sb = new StringBuilder();
			
			if (!StringUtils.isEmpty(colOrderjsonStr)) 
			{
				selectJson = JSONObject.fromObject(colOrderjsonStr);
				
				jarray = (JSONArray) selectJson.get("lstBoxdata");
				if (jarray != null) 
				{
					colJsonNew = JSONObject.fromObject(jarray.getString(1));
				} 
				else 
				{
					colJsonNew = selectJson;
				}
			}
			
			if (colJsonNew != null && !(colJsonNew.isEmpty())) 
			{
				Object[] seqidset = colJsonNew.keySet().toArray();
				for (Object column : seqidset) {
					if (column.toString().contains("DESC")) 
					{
						String columnValue = column.toString().replaceAll(
								"DESC", "");
						columnValue = columnValue.trim();
						if (null != paramColumns.get(columnValue)) 
						{
							sb.append(paramColumns.get(columnValue));
							sb.append(" DESC,");
						}
					} 
					else if (column.toString().contains("ASC")) 
					{
						String columnValue = column.toString().replaceAll(
								"ASC", "");
						columnValue = columnValue.trim();
						columnValue = columnValue.toUpperCase();
						if (null != paramColumns.get(columnValue)) 
						{
							sb.append(paramColumns.get(columnValue));
							sb.append(" ASC,");
						}
					}
				}
				if (sb.charAt(sb.length() - 1) == ',') {
					result = sb.substring(0, sb.length() - 1);
				}
			}
			return result;
		} 
		catch (Exception e) 
		{
			logger.error("Exception occur while Evaluting Sort Params", e);
		}
		return null;
	}
	
	public static Document prepareCustomReportXML(JSONObject coljson, String strXMLTemplateName) throws Exception
    {
		  
	    InputStream inputStream = null;
    	SAXBuilder builder = new SAXBuilder();
    	Document doc = null;
    	File outFile = null;
    	try
	    {
	    	inputStream = new FileInputStream(strXMLTemplateName);
			doc = (Document) builder.build(inputStream);
			
			if(coljson != null && !(coljson.isEmpty()))
			{
				
				HashMap<String,Object> changeMap = new HashMap<String,Object>();
				Object[] seqidset = coljson.keySet().toArray();		
				
				//String selectableFramePath = XMLParserUtils.getElementPath(doc,"/report/layout/section[@name='main']/body","R_SELECTABLE");
				
				String mainFramePath = "/report/layout/section[@name='main']/body/frame[@name='M_1']";

				
				
				// Identify group level
				String path=mainFramePath+"/repeatingFrame[@name='R_1']";

				int glevel = XMLParserUtils.getReportGroupLevel(doc,path);

				String groupLevelPath = "";
				for(int cnt=0;cnt<glevel;cnt++){
					groupLevelPath += "/repeatingFrame[@name='R_"+(cnt+1)+"']";
				}
				
				// initialize mData path
				String mDataPath = mainFramePath+groupLevelPath+"/frame[@name='M_Data']";
				
				// Identify if Form or Tabluar
				String layoutType = XMLParserUtils.getLayoutType(mDataPath,doc);
				
			// ************************************
			 if (layoutType.equals("T")){ 
				 
				//String mDataField1GeoPath = mDataPath+"/field[@name='F_101']/geometryInfo";
				String mDataGeoPath = mDataPath+"/geometryInfo";

			// check for header frame
				boolean found = false;
				String repPath = "";
				String labelPath = "/frame[@name='M_Headers']";
				String mHeadPath = "";
				for(int cnt=0;cnt<glevel;cnt++){
					path = mainFramePath+repPath+labelPath;
					found = XMLParserUtils.isValidPath(path,doc);
					if(found){
						mHeadPath = path;
						break;
					}else{
						repPath+="/repeatingFrame[@name='R_"+(cnt+1)+"']";
					}
				}
				//String mHeadtext1GeoPath = mHeadPath+"/text[@name='B_101']/geometryInfo";
				
				
				//Tabular
				double yfactordoub = 0.16000;
				HashMap<String,Object> changeMaplbl = new HashMap<String,Object>();	
				// get original widths
				String elementName="field";
				JSONObject elementWidths = XMLParserUtils.getElementsAttValJson(mDataPath,doc,elementName,"width");
				// get initial x
			    String attributeName="x";
				//String x = XMLParserUtils.readValue(mDataField1GeoPath,doc,attributeName);
				//double xdoub=Double.parseDouble(x);
				// get total width of frame
			    attributeName="width";
				String width = XMLParserUtils.readValue(mDataGeoPath,doc,attributeName);
				double totwidthdoub=Double.parseDouble(width);
// Fixed Type2	- Added : get initial frame x
				String frameX = XMLParserUtils.readValue(mDataGeoPath,doc,"x");
				double xFramedoub=Double.parseDouble(frameX);
				
				//String x = XMLParserUtils.readValue(mDataField1GeoPath,doc,attributeName);
				//double xdoub=Double.parseDouble(x);
				double xdoub=xFramedoub + 0.514;
				double intFldSpcFormFrame = xdoub - xFramedoub;
// Fixed Type2  - End
				// get initial y of data
			    attributeName="y";
				String y = XMLParserUtils.readValue(mDataGeoPath,doc,attributeName);//
				double ydoub=Double.parseDouble(y)+0.019;//
				// get initial y of label
			    attributeName="y";
				String ylbl = XMLParserUtils.readValue(mHeadPath+"/geometryInfo",doc,attributeName);//
				double ydoublbl =Double.parseDouble(ylbl)+0.034;//
				// calculate sumwidth of all required columns
				double sumwidthdoub = 0.00;	
				for(int cnt=0;cnt<seqidset.length;cnt++){
					String key = "F_"+seqidset[cnt].toString();
				    String twidth =elementWidths.getString(key);
					sumwidthdoub+=Double.parseDouble(twidth);
				}
				// calculate required width for all required columns
				
// Fixed Type2  - Modified
				//double occupiedWidth = sumwidthdoub+(0.08*(seqidset.length-1))+xdoub;
				double occupiedWidth = sumwidthdoub+(0.08*(seqidset.length-1))+intFldSpcFormFrame;   
// Fixed Type2  - End
				
				// calculate the new width of column and modify the Json
				if(occupiedWidth<totwidthdoub){
					double addwidth = (totwidthdoub-occupiedWidth-0.08)/seqidset.length;
					for(int cnt=0;cnt<seqidset.length;cnt++){
						String key = "F_"+seqidset[cnt].toString();
						String fwidth =elementWidths.getString(key);
					    double newwidthdoub = addwidth+Double.parseDouble(fwidth);
					    String newwidth = String.valueOf(newwidthdoub);
					    elementWidths.element(key, newwidth);
					}				
				}
				// calculate new x,y for required columns and form Hashmap for both the data and labels
				
// Fixed Type2	- Added : calculate and track the consumed width
				double consumedWidth = intFldSpcFormFrame; 
// Fixed Type2  - End
				
				double curwidh = 0.00;			
				for(int cnt=0;cnt<seqidset.length;cnt++){
					xdoub += curwidh;
					String key = "F_"+seqidset[cnt].toString();
					String keylbl = "B_"+seqidset[cnt].toString();
					String fwidth =elementWidths.getString(key);
				    double elemwidth = Double.parseDouble(fwidth);
// Fixed Type2 - Added/Modified : To check if last element append extra width
				    if((cnt+1)==seqidset.length)
				    	curwidh = elemwidth;
				    else
				    	curwidh = elemwidth +0.08;
					consumedWidth += curwidh; 
					if(consumedWidth > totwidthdoub){   
// Fixed Type2 - End
						xdoub = 0.12292; // take initial value + .1 
						ydoub += yfactordoub;
						ydoublbl += yfactordoub;
					}
					JSONObject elemAttr = new JSONObject();
					elemAttr.accumulate("x", String.valueOf(xdoub));
					elemAttr.accumulate("y", String.valueOf(ydoub));
					elemAttr.accumulate("width", String.valueOf(elemwidth));
					
					JSONObject elemAttrlbl = new JSONObject();
					elemAttrlbl.accumulate("x", String.valueOf(xdoub));
					elemAttrlbl.accumulate("y", String.valueOf(ydoublbl));
					elemAttrlbl.accumulate("width", String.valueOf(elemwidth));
					
					changeMap.put(key, elemAttr);
					changeMaplbl.put(keylbl, elemAttrlbl);
				}
				// Call the util for actual xml modification with changed data geometry values
				XMLParserUtils.rearrangeAttributes(mDataPath,doc,changeMap,"field");
				// Call the util for actual xml modification with changed label geometry values			
				XMLParserUtils.rearrangeAttributes(mHeadPath,doc,changeMaplbl,"text");	
			 }else if(layoutType.equals("F")){
				if(!XMLParserUtils.isValidPath(mDataPath,doc))
					 mDataPath = mainFramePath+groupLevelPath;
				String mDataFrame1GeoPath = mDataPath+"/geometryInfo";
				// Form-Like
		
				// get initial y 
				String initY = XMLParserUtils.readValue(mDataFrame1GeoPath,doc,"y");
				double initYdoub=Double.parseDouble(initY);
				initYdoub = initYdoub + 0.005;
				// get initial height
				//String initHght = XMLParserUtils.readValue(mDataFrame1GeoPath,doc,"height");
				String initHght = "0.17650";
				double initHghtdoub=Double.parseDouble(initHght);
				// get original heights

//				JSONObject elementHeights = XMLParserUtils.getElementsAttValJson(mDataPath,doc,elementName,"height");

				// initialize first element y
				double currY = initYdoub;
				// loop thru required elements and desin the change map
				for(int cnt=0;cnt<seqidset.length;cnt++){
					String key = "M_"+seqidset[cnt].toString();
					JSONObject elemAttr = new JSONObject();
					elemAttr.accumulate("y", String.valueOf(currY));
					changeMap.put(key, elemAttr);
					currY = currY + 0.002 + initHghtdoub;
				}
				// Call the util for actual xml modification with changed data geometry values
				XMLParserUtils.rearrangeAttributesFL(mDataPath,doc,changeMap,"frame");
				
			 }
			}
				
	        if (logger.isDebugEnabled())
	        {
	            logger.debug("Dynamic Report XML is updated!");
	        }
	       
	    	return doc;  
	    }
//    	catch(JDOMException jdom)
//    	{
//			throw new Exception("Failed to update Report XML");
//    	}
    	finally
    	{
    		if(doc == null)
    			throw new Exception("Failed to update Report XML");
    		CleanUpUtils.doClose(inputStream);
    		inputStream = null;
    		doc = null;
    		//dynamicReportFields.clear();
    	}
    }

	
	
}
