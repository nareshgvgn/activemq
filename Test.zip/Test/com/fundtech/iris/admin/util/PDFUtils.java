/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : PDFUtils.java
 * CREATED: Apr 19, 2016 3:29:11 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.util.Date;
import java.util.List;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.util.Matrix;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: PDFUtils.java,v 1.4 2016/06/09 08:41:46 ramap Exp $
 */
public class PDFUtils
{
	
	 /**
     * The scaling factor for font units to PDF units
     */
    private static final int FONTSCALE = 1000;
    
    /**
     * The default font
     */
    private static final PDType1Font DEFAULT_FONT = PDType1Font.COURIER;
    
    private static final PDRectangle DEFAULT_COORDINATES = new PDRectangle(-10,50,1224,792);
    
    private static final PDRectangle DEFAULT_LANDSCAPE_COORDINATES = new PDRectangle(-10,50,1224,792);

    /**
     * The default font size
     */
    private static final int DEFAULT_FONT_SIZE = 12;
    
    /**
     * The line height as a factor of the font size
     */
    private static final float LINE_HEIGHT_FACTOR = 1.5f;

    private int fontSize = DEFAULT_FONT_SIZE;
    private PDFont font = DEFAULT_FONT;
    
    private PDRectangle coordinates = DEFAULT_COORDINATES;
    private boolean isLandscape = false;
    

	
    /**
     * Create a PDF document with some text.
     *
     * @param text The stream of text data.
     *
     * @return The document with the text in it.
     *
     * @throws IOException If there is an error writing the data.
     */
    public PDDocument createPDFFromText( Reader text ) throws IOException
    {
        PDDocument doc = new PDDocument();
        createPDFFromText(doc, text);
        return doc;
    }
    
    /**
     * Create a PDF document with some text.
     *
     * @param text The stream of text data.
     *
     * @throws IOException If there is an error writing the data.
     */
    public void createPDFFromText( PDDocument doc, Reader text ) throws IOException
    {
        try
        {

            final int margin = 0;
           
            //calculate font height and increase by a factor.
            /*
             * Commented original line
             * height = height * fontSize * LINE_HEIGHT_FACTOR ;
             *  float height = font.getBoundingBox().getHeight() / FONTSCALE;
             */
            float height = 0;
            height =  fontSize * LINE_HEIGHT_FACTOR ;
            BufferedReader data = new BufferedReader( text );
            String nextLine = null;
            PDPage page = new PDPage();
            if ( isLandscape)
            	 page.setRotation(90);
           
            page.setMediaBox(coordinates);
            PDPageContentStream contentStream = null;
            float y = -1;
            float maxStringLength = page.getMediaBox().getWidth();

            // There is a special case of creating a PDF document from an empty string.
            boolean textIsEmpty = true;
            while( (nextLine = data.readLine()) != null )
            {

                // The input text is nonEmpty. New pages will be created and added
                // to the PDF document as they are needed, depending on the length of
                // the text.
                textIsEmpty = false;

                String[] lineWords = nextLine.split( " " );
                int lineIndex = 0;
                while( lineIndex < lineWords.length )
                {
                    StringBuilder nextLineToDraw = new StringBuilder();
                    float lengthIfUsingNextWord = 0;
                    do
                    {
                        nextLineToDraw.append( lineWords[lineIndex] );
                        nextLineToDraw.append( " " );
                        lineIndex++;
                        if( lineIndex < lineWords.length )
                        {
                            String lineWithNextWord = nextLineToDraw.toString() + lineWords[lineIndex];
                            lengthIfUsingNextWord =
                                (font.getStringWidth( lineWithNextWord )/FONTSCALE) * fontSize;
                        }
                    }
                    while( lineIndex < lineWords.length && lengthIfUsingNextWord < maxStringLength );
                    if( y < margin )
                    {
                        // We have crossed the end-of-page boundary and need to extend the
                        // document by another page.
                        page = new PDPage();
                        if ( isLandscape)
                        	page.setRotation(90);
                        page.setMediaBox(coordinates);
                        doc.addPage( page );
                        if( contentStream != null )
                        {
                            contentStream.endText();
                            contentStream.close();
                        }
                        contentStream = new PDPageContentStream(doc, page);
                        if ( isLandscape)
                        {
                        	float pageWidth = coordinates.getWidth();
                        	contentStream.transform(new Matrix(0, 1, -1, 0, pageWidth, 0));
                        }
                        contentStream.setFont( font, fontSize );
                        contentStream.beginText();
                        /*
                         * Orginal code commented 
                         * y = page.getMediaBox().getHeight() - margin + height;
                         */
                        y = page.getMediaBox().getHeight();
                        contentStream.newLineAtOffset(margin, y);
                    }

                    if( contentStream == null )
                    {
                        throw new IOException( "Error:Expected non-null content stream." );
                    }
                    contentStream.newLineAtOffset(0, -height);
                    y -= height;
                    contentStream.showText(nextLineToDraw.toString());
                }
            }
            // If the input text was the empty string, then the above while loop will have short-circuited
            // and we will not have added any PDPages to the document.
            // So in order to make the resultant PDF document readable by Adobe Reader etc, we'll add an empty page.
            if (textIsEmpty)
            {
                doc.addPage(page);
            }
            if( contentStream != null )
            {
                contentStream.endText();
                contentStream.close();
            }
        }
        catch( IOException io )
        {
            if( doc != null )
            {
                doc.close();
            }
            throw io;
        }
    }
	
	public void mergePDF(List<String> fileList, String outputFile)
	{
		Date startTime = null;
		String tempFileName = null;
		File tempFile = null;
		PDDocument desPDDoc = null;
		PDFMergerUtility pdfMerger = null;
		boolean hasCloneFirstDoc = false;
		PDDocument doc = null;
		File file = null;
		final String dir = System.getProperty("user.dir");
		
		tempFileName = (new Date()).getTime() + "_temp";
		tempFile = new File(dir +"/" + tempFileName);
		
		// proceed to merge
		
		startTime = new Date();
		pdfMerger = new PDFMergerUtility();
		try
		{
			for (String fileName : fileList)
			{
				if(fileName.contains(".txt"))
				{
					fileName = fileName.replace(".txt", ".pdf");
				}
				file = new File(fileName);
				
				try
				{
					if (hasCloneFirstDoc)
					{
						doc = PDDocument.load(file);
						pdfMerger.appendDocument(desPDDoc, doc);
					}
					else
					{
						desPDDoc = PDDocument.load(file, MemoryUsageSetting.setupTempFileOnly());
						hasCloneFirstDoc = true;
					}
				}
				catch (IOException ioe)
				{
					System.out.println("Invalid PDF detected: " + file.getName());
					ioe.printStackTrace();
				}
				finally
				{
					if (doc != null)
					{
						doc.close();
					}
				}
			}
			
			desPDDoc.save(outputFile);
			Date endTime = new Date();
			long timeTakenInSec = endTime.getTime() - startTime.getTime();
			System.out.println("Time taken: " + (timeTakenInSec / 1000) + " secs " + (timeTakenInSec % 1000) + " ms");
		}
		catch (IOException e)
		{
			e.printStackTrace(); // will encounter issues if it is more than 850 pdfs!!
		}
		finally
		{
			try
			{
				if (desPDDoc != null)
				{
					desPDDoc.close();
				}
			}
			catch (IOException ioe)
			{
				ioe.printStackTrace();
			}
			tempFile.delete();
		}

	}
	
	
	/**
     * @return Returns the font.
     */
    public PDFont getFont()
    {
        return font;
    }
    /**
     * @param aFont The font to set.
     */
    public void setFont(PDFont aFont)
    {
        this.font = aFont;
    }
    /**
     * @return Returns the fontSize.
     */
    public int getFontSize()
    {
        return fontSize;
    }
    /**
     * @param aFontSize The fontSize to set.
     */
    public void setFontSize(int aFontSize)
    {
        this.fontSize = aFontSize;
    }
    
    public void setCoordinates(float x, float y, float width, float height)
    {
    	coordinates = new PDRectangle(x, y, width, height);
    }

	/**
	 * @param isLandscape the isLandscape to set
	 */
	public void setLandscape (boolean isLandscape)
	{
		this.isLandscape = isLandscape;
		if ( isLandscape)
			coordinates = new PDRectangle(50,-10,1224,792);
	}
}
