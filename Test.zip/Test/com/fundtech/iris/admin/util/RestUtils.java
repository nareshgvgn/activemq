/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : RestUtils.java
 * CREATED: Jan 3, 2017 10:18:17 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import org.springframework.http.HttpStatus;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: RestUtils.java,v 1.1 2017/01/30 04:50:14 ramap Exp $
 */
public class RestUtils
{
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public RestUtils()
	{
		// BABU Auto-generated constructor stub
	}
	
	public static boolean isError(HttpStatus status) 
	{
        HttpStatus.Series series = status.series();
        return (HttpStatus.Series.CLIENT_ERROR.equals(series)
                || HttpStatus.Series.SERVER_ERROR.equals(series));
    }
	
}
