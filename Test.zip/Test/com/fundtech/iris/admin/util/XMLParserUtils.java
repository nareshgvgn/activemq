/*----------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.common.utils
 * FILE     : XMLParserUtils.java
 * CREATED  : June 22, 2010 8:22:50 AM
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *--------------------------------------------------------------------------------------------------------------------*/

package com.fundtech.iris.admin.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.CDATA;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.json.JSONObject;
 
public class XMLParserUtils 
{
	private static Logger logger = LoggerFactory.getLogger(XMLParserUtils.class);
	/**
	 * This method will replace value in CDATA block with new value for given xpath 
	 * @param strxPath
	 * @param doc
	 * @param newValue
	 * @throws JDOMException
	 */
	public static void updateCdataValue(String strxPath, Document doc, String newValue) throws JDOMException
	{
		XPathExpression xPath = XPathFactory.instance().compile(strxPath, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
	    CDATA cdata=new CDATA(newValue);
	    if(null != element)
	    {
	    	element.setContent(cdata);
	    }
		
	}

	/**
	 * This method will remove a single node from XML document with entered XPATH.
	 * @param strxPath
	 * @param doc
	 * @throws JDOMException
	 */
	public static void removeSingleNode(String strxPath, Document doc) throws JDOMException
	{
		XPathExpression xPath = XPathFactory.instance().compile(strxPath, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		if(null != element)
		{
		    Element parent = element.getParentElement();
		    parent.removeContent(element);
		}
		
	}
	
	/**
	 * This method will update attribute values for an attribute name in provided xpath
	 * @param strxPath
	 * @param doc
	 * @param attributeName
	 * @param newValue
	 * @throws JDOMException
	 */
	public static void updateAttribute(String strxPath, Document doc, String attributeName, String newValue) throws JDOMException
	{
		XPathExpression xPath = XPathFactory.instance().compile(strxPath, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
	    Attribute attribute = element.getAttribute(attributeName);
	    attribute.setValue(newValue);
	}

	/**
	 * This method will update multiple attributes in an XPATH node
	 * @param strxPath
	 * @param doc
	 * @param attributeNames
	 * @param newValues
	 * @throws JDOMException
	 */
	public static void updateAttributes(String strxPath, Document doc, String[] attributeNames, String[] newValues) throws JDOMException
	{
		XPathExpression xPath = XPathFactory.instance().compile(strxPath, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
	    if(attributeNames.length == newValues.length)
	    {
	    	for(int attrIndex = 0; attrIndex < attributeNames.length ; attrIndex++)
	    	{
	    	    Attribute attribute = element.getAttribute(attributeNames[attrIndex]);
	    	    attribute.setValue(newValues[attrIndex]);
	    		
	    	}
	    }
	}
	
	/**
	 * This method will read  attributes from an Xml node
	 * @param strxPath
	 * @param doc
	 * @param attName
	 */	
	public static String readValue(String strxPath, Document doc, String attName){
		XPathExpression xPath = XPathFactory.instance().compile(strxPath, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		Attribute attribute = element.getAttribute(attName);
		return attribute.getValue();
	}
	
	/**
	 * This method will read Element Attribute values from Xml.
	 * @param stpath
	 * @param doc
	 * @param elementName
	 * @param attributeName
	 */
	public static JSONObject getElementsAttValJson(String stpath,Document doc,String elementName,String attributeName){
		JSONObject elementAttValues = new JSONObject();
		
		XPathExpression xPath = XPathFactory.instance().compile(stpath, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		List<Element> eleList = element.getChildren();
		for(int cnt=0;cnt<eleList.size();cnt++){
			Element cElement = eleList.get(cnt);
			if(cElement.getName().equals(elementName)){
				String id = cElement.getAttribute("name").getValue();
				String width = cElement.getChild("geometryInfo").getAttributeValue(attributeName);
				elementAttValues.accumulate(id, width);
			}
		}
		//elementWidths.toString();
		return elementAttValues;
	}

	/**
	 * This method will rearrange Attributes in Xml.
	 * @param path
	 * @param doc
	 * @param changeMap
	 * @param elementName
	 */
	public static void rearrangeAttributes(String path, Document doc, HashMap<String, Object> changeMap, String elementName) {
		XPathExpression xPath = XPathFactory.instance().compile(path, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		List<Element> eleList = element.getChildren();
		ArrayList<String> nrElements = new ArrayList<String>();
		for(int cnt=0;cnt<eleList.size();cnt++){
			Element cElement = eleList.get(cnt);
			if(cElement.getName().equals(elementName)){
				String id = cElement.getAttribute("name").getValue();
				if(changeMap.containsKey(id)){
					JSONObject attJson = (JSONObject)changeMap.get(id);
						cElement.getChild("geometryInfo").setAttribute("x", (String)attJson.get("x"));
						cElement.getChild("geometryInfo").setAttribute("y", (String)attJson.get("y"));
						cElement.getChild("geometryInfo").setAttribute("width", (String)attJson.get("width"));						
				}else{
					nrElements.add(id);
				}
			}
		}
		for(int cnt=0;cnt<nrElements.size();cnt++){
			String removepath = path+"/"+elementName+"[@name='"+nrElements.get(cnt)+"']";
			try{
				removeSingleNode(removepath,doc);
			}
			catch(Exception e){
				logger.error("Error:",e);
			}
		}
	}

	/**
	 * This method will get Layout Type from Xml.
	 * @param path
	 * @param doc
	 */
	public static String getLayoutType(String path, Document doc) {
		XPathExpression xPath = XPathFactory.instance().compile(path, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		if(element == null)
			return "F";
		else{
			List<Element> eleList = element.getChildren();
			String type="F";
			for(int cnt=0;cnt<eleList.size();cnt++){
				Element cElement = eleList.get(cnt);
				if(cElement.getName().equals("field")){
					type="T";
					break;
				}
			}
			return type;
		}
	}

	/**
	 * This method will get Report Group Level from Xml.
	 * @param doc
	 * @param path
	 */
	public static int getReportGroupLevel(Document doc,String path) {
		XPathExpression xPath = XPathFactory.instance().compile(path, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		int rglevel =1;
		boolean foundNext;
		List<Element> eleList = element.getChildren();
		do{
			int cntr = eleList.size();
			foundNext = false;
			for(int cnt=0;cnt<cntr;cnt++){
				Element cElement = eleList.get(cnt);
				if(cElement.getName().equals("repeatingFrame")){
					String id = cElement.getAttribute("name").getValue();
					if(id.equals("R_"+(rglevel+1))){
						rglevel++;
						eleList = cElement.getChildren();
						foundNext = true;
						cnt = cntr;
					}
				}
			}
		}while(foundNext);
		return rglevel;
	}

	/**
	 * This method will get Report Group Level from Xml.
	 * @param doc
	 * @param path
	 */
	public static String getElementPath(Document doc,String path,String elementName) {
		String foundElementPath = null;
		String elementPath = path;
		
		XPathExpression xPath = XPathFactory.instance().compile(path, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		boolean foundElement;
		List<Element> eleList = element.getChildren();
		
		if(path.contains(elementName)){
			foundElement = true;
			foundElementPath = path;
		}
		else{
			foundElementPath = null;
			foundElement = false;
		}

		while(!foundElement){
			int cntr = eleList.size();
			for(int cnt=0;cnt<cntr;cnt++){
				Element cElement = eleList.get(cnt);
				if(cElement.getName().equals("repeatingFrame") || cElement.getName().equals("frame")){
					String id = cElement.getAttribute("name").getValue();
					if(id.equals("R_SELECTABLE")){
						cnt = cntr;
						foundElementPath = path+"/"+cElement.getName()+"[@name='"+id+"']";
					}else{
						foundElementPath = getElementPath(doc,path+"/"+cElement.getName()+"[@name='"+id+"']",elementName);
					}
						
				}else{
					foundElement = true;
				}
				
			}
		};
		
		return foundElementPath;
	}
	
	/**
	 * This method will check Valid Path from Xml.
	 * @param path
	 * @param doc
	 */
	public static boolean isValidPath(String path, Document doc) {
		XPathExpression xPath = XPathFactory.instance().compile(path, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		boolean isValid;
		if(element==null){
			isValid = false;
		}else{
			isValid = true;
		}
		return isValid;
	}
	
	/**
	 * This method will rearrange AttributesFL from Xml.
	 * @param path
	 * @param doc
	 * @param changeMap
	 * @param doc
	 */
	public static void rearrangeAttributesFL(String path, Document doc, HashMap<String, Object> changeMap, String elementName) {
		XPathExpression xPath = XPathFactory.instance().compile(path, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		List<Element> eleList = element.getChildren();
		ArrayList<String> nrElements = new ArrayList<String>();
		for(int cnt=0;cnt<eleList.size();cnt++){
			Element cElement = eleList.get(cnt);
			if(cElement.getName().equals(elementName)){
				String id = cElement.getAttribute("name").getValue();
				if(changeMap.containsKey(id)){
					JSONObject attJson = (JSONObject)changeMap.get(id);
					cElement.getChild("geometryInfo").setAttribute("y", (String)attJson.get("y"));
					List<Element> childElements = cElement.getChildren();	
					for(int cntr=0;cntr<childElements.size();cntr++){
						Element currElement = childElements.get(cntr);
						if(currElement.getName().equals("field")||currElement.getName().equals("text")){
							double newYd = Double.parseDouble((String)attJson.get("y"))+0.018;
							String newY = String.valueOf(newYd);
							currElement.getChild("geometryInfo").setAttribute("y", newY);
						}
					}
				}else{
					nrElements.add(id);
				}
			}
		}
		for(int cnt=0;cnt<nrElements.size();cnt++){
			String removepath = path+"/"+elementName+"[@name='"+nrElements.get(cnt)+"']";
			try{
				removeSingleNode(removepath,doc);
			}
			catch(Exception e){logger.error("Error:",e);}
		}
	}
	
	public static void rearrangeDelimitedAttributes(String path, Document doc, JSONObject changeMap, String elementName) {
		XPathExpression xPath = XPathFactory.instance().compile(path, Filters.element());
		Element element = (Element) xPath.evaluateFirst(doc);
		List<Element> eleList = element.getChildren();
		ArrayList<String> nrElements = new ArrayList<String>();
		for(int cnt=0;cnt<eleList.size();cnt++){
			Element cElement = eleList.get(cnt);
			if(cElement.getName().equals(elementName)){
				String id = cElement.getAttribute("name").getValue();
				String tempKey = id.replaceAll("CF_", "");
				if(!changeMap.containsKey(tempKey)){
					//JSONObject attJson = (JSONObject)changeMap.get(id);
						//Attribute newatr = new Attribute("excludeFromXmlOutput", "yes");
						//Content cntnt = new Content();
						cElement.getChild("xmlSettings").setAttribute("excludeFromXmlOutput", "yes");
						//cElement.getChild("geometryInfo").setAttribute("y", (String)attJson.get("y"));
						//cElement.getChild("geometryInfo").setAttribute("width", (String)attJson.get("width"));						
				}
			}
		}
	}	
}