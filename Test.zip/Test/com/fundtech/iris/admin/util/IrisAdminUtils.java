/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : IrisAdminUtils.java
 * CREATED: Oct 25, 2013 12:32:45 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.tree.DefaultElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

import net.sf.log4jdbc.ConnectionSpy;
import oracle.jdbc.OracleConnection;

/**
 * 
 * <p>
 * This class is an helper class
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IrisAdminUtils.java,v 1.32 2016/10/19 14:04:55 ramap Exp $
 */

public abstract class IrisAdminUtils extends StringUtils
{
	private static Logger logger = LoggerFactory.getLogger(IrisAdminUtils.class);
	private static final String updateSql = "UPDATE IRIS_JOB_QUEUE T SET T.STATUS = ?, T.SYS_END_DATE = SYSDATE , END_DATE = pk_timezone.get_seller_time(?), "
			+ "ERROR_CODE=?, ERROR_MSG=?, MEDIA_DTLS= ? WHERE T.EXECUTION_ID = ?";
	
	public static enum Level 
	{
        TRACE, DEBUG, INFO, WARN, ERROR
    }
	private static Map<String, Boolean> _mapModifiedProcesses = new ConcurrentHashMap<String, Boolean>();
	
	private static int mb = 1024*1024;
	
	public static final IrisAdminError createError (String errCode, String errMsg, String info1, Object errLine)
	{
		IrisAdminError error = null;
		
		error = createError(0, errCode, errMsg, info1, errLine);
		return error;
	}
	
	public static final IrisAdminError createInterError (String errCode, String errMsg, String info1, String errLine)
	{
		IrisAdminError error = null;
		
		error = createInterError(0, errCode, errMsg, info1, errLine);
		return error;
	}
	
	public static final IrisAdminError createError (long lineNumber, String errCode, String errMsg, String info1, Object errLine)
	{
		IrisAdminError error = null;
		
		error = new IrisAdminError(lineNumber, IrisAdminConstants.ERR_TYPE_ERROR, errCode, errMsg, info1, errLine);
		return error;
	}
	
	public final static IrisError createIrisError (String bandType, String bandName, String errorMessage)
	{
		IrisError irisError = null;
		
		irisError = new IrisError();
		irisError.setBandType(bandType);
		irisError.setBandName(bandName);
		irisError.setLineNumber(0);
		irisError.addErrorDesc(errorMessage);
		
		return irisError;
	}
	public static final IrisAdminError createInterError (long lineNumber, String errCode, String errMsg, String info1, String errLine)
	{
		IrisAdminError error = null;
		
		error = new IrisAdminError(lineNumber, IrisAdminConstants.ERR_TYPE_INTER, errCode, errMsg, info1, errLine);
		return error;
	}
	
	public static boolean getProcessStatus (String key)
	{
		if (_mapModifiedProcesses.get(key) == null)
			return false;
		else
			return _mapModifiedProcesses.get(key);
	}
	
	public static void updateProcessStatus (String key, boolean status)
	{
		_mapModifiedProcesses.put(key, status);
	}
	
	/**
	 * <p>
	 * This helper method gets the reference value from batch band
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field 
	 * @param dataBand 
	 * @param batchBand
	 * @return
	 * @throws FormatException
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	public static String getRefValue (MappingField field, Band dataBand, BatchBand batchBand) throws FormatException, ExecutionException
	{
		String fldVal = null;
		String bandRef = null;
		String fieldRef = null;
		String bandName = null;
		String childBandName = null;
		boolean exists = false;
		BatchBand parentBatchBand = null;
		BatchBand grandParentBatchBand = null;
		
		bandRef = field.getBandRef();
		fieldRef = field.getFieldRef();
		bandName = dataBand.getName();
		while (!exists)
		{
			if (!bandName.equals(bandRef))
			{
				if (batchBand == null)
				{
					exists = true;
					fldVal = getRefValue(field, dataBand);
					break;
				}
				for (Band childBand : batchBand.getBatchBands())
				{
					childBandName = childBand.getName();
					if (childBandName.equals(bandRef))
					{
						fldVal = getRefValue(field, childBand, batchBand);
						exists = true;
						break;
					}
				}
				if (!exists)
				{
					parentBatchBand = batchBand.getParentBatchBand();
					if (parentBatchBand == null)
						exists = true;
					for (Band childBand : parentBatchBand.getBatchBands())
					{
						childBandName = childBand.getName();
						if (childBandName.equals(bandRef))
						{
							fldVal = getRefValue(field, childBand, parentBatchBand);
							exists = true;
							break;
						}
					}
				}
				if (!exists)
				{
					grandParentBatchBand = parentBatchBand.getParentBatchBand();
					if (grandParentBatchBand == null)
						exists = true;
					for (Band grandParentBand : grandParentBatchBand.getBatchBands())
					{
						childBandName = grandParentBand.getName();
						if (childBandName.equals(bandRef))
						{
							fldVal = getRefValue(field, grandParentBand, grandParentBatchBand);
							exists = true;
							break;
						}
					}
				}
			}
			else
			{
				fldVal = dataBand.getFieldValue(fieldRef);
				exists = true;
			}
		}
		return fldVal;
	}
	
	/**
	 * This helper methods gets the reference value of own parent bands or same band which ever is referenced
	 * 
	 * @param field
	 * @param dataBand
	 * @return
	 */
	private static String getRefValue (MappingField field, Band dataBand) throws FormatException
	{
		String bandRef = null;
		String fieldRef = null;
		boolean exists = false;
		Band parentBand = null;
		String fldVal = null;
		FormatException fExp = null;
		
		try
		{
			bandRef = field.getBandRef();
			fieldRef = field.getFieldRef();
			
			while (!exists)
			{
				if (dataBand.getName().equals(bandRef))
				{
					fldVal = dataBand.getFieldValue(fieldRef);
					exists = true;
				}
				else
				{
					parentBand = dataBand.getParentBand();
					
					if (parentBand == null)
						exists = true;
					else
					{
						fldVal = getRefValue(field, parentBand);
						exists = true;
					}
				}
			}
		}
		catch (Exception exp)
		{
			logger.error("Error While assigning Ref Value");
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ "Field Val:" + fldVal, "Band Ref:" + bandRef, "Field Ref:" + fieldRef }, exp);
			throw fExp;
		}
		
		return fldVal;
	}
	
	/**
	 * 
	 * <p>
	 * This helper method creates the attribute for given xpath expression from given element
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param batchElement - {@link Element}
	 * @param expression - XPath expression
	 * @param value value of the attribute
	 * @return {@link Element}
	 * @throws UnsupportedOperationException
	 * @throws IllegalArgumentException
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public static Element createElementsFromXPath (Element batchElement, String expression, String value, int index) throws UnsupportedOperationException,
			IllegalArgumentException, FormatException
	{
		StringBuilder currentPath = null;
		Pattern xpathParserPattern = null;
		Matcher matcher = null;
		String currentXPath = null;
		String elementName = null;
		String filterName = null;
		String attributeName = null;
		StringBuilder builder = null;
		String relativePath = null;
		Element newNode = null;
		Element element = null;
		Element previousElement = null;
		String REGEX = "\\.?/+([\\.\\w]+)(\\[@([\\.\\w]+)\\:?([\\.\\w]+)?\\]+)?(\\[[0-9]+\\])?";
		// \\.?/+([\\w]+)(\\[@([\\w]+)\\:?([\\w]+)?\\]+)?    -- old one
		
		try
		{
			currentPath = new StringBuilder();
			xpathParserPattern = Pattern.compile(REGEX);
			matcher = xpathParserPattern.matcher(expression);
			
			while (matcher.find())
			{
				currentXPath = matcher.group(0);
				elementName = matcher.group(1);
				attributeName = matcher.group(3);
				filterName = matcher.group(4);
				newNode = null;
				if (attributeName != null)
				{
					if (builder == null)
						currentXPath = elementName;
					else if (builder.codePointAt(0) == '.')
						currentXPath = "/" + elementName;
					else
						currentXPath = "./" + elementName;
				}
				
				builder = currentPath.append(currentXPath);
				relativePath = builder.toString();
				
				if (batchElement != null)
				{
					 if (attributeName != null && batchElement.getName().equals(relativePath))
					{
						// for present band itself we are adding name space
						newNode = (Element) batchElement;
					}
					else
						newNode = (Element) batchElement.selectSingleNode(relativePath);
				}
				
				if (newNode == null)
				{
					if (elementName != null)
					{
						element = null;
						if (previousElement != null)
							element = createBand(previousElement,elementName,index);
						else if (batchElement != null)
							element = createBand(batchElement,elementName, index);
						else
							element = new DefaultElement(elementName);
						if (filterName != null)
						{
							element.addAttribute(filterName, value);
						}
						
						newNode = element;
					}
					else
					{
						throw new UnsupportedOperationException("The given xPath is not supported " + relativePath);
					}
					
					index = -1;
				}
				else
				{
					if (attributeName != null)
					{
						newNode.addAttribute(attributeName, value);
						attributeName = null;
						filterName = null;
					}
				}
				previousElement = newNode;
				
			}
			
			return previousElement;
		}
		catch (UnsupportedOperationException exp)
		{
			throw exp;
		}
		catch (IllegalArgumentException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			throw new FormatException("error.iris.admin.xpath", new Object[]
			{ expression }, exp);
		}
		finally
		{
			CleanUpUtils.doClean(currentPath);
			currentPath = null;
			xpathParserPattern = null;
			matcher = null;
			matcher = null;
			currentXPath = null;
			elementName = null;
			filterName = null;
			attributeName = null;
			builder = null;
			relativePath = null;
			newNode = null;
			element = null;
		}
	}
	
	public static Element createBand (Document document, String expression)
	{
		Element element = null;
		
		element = document.addElement(expression);
		return element;
	}
	
	public static Element createBand (Element parentElement, String expression,int index)
	{
		Element element = null;
		
		if ( index > -1)
		{
			element = new  DefaultElement(expression);
			parentElement.elements().add(index, element);	
		}
		else
			element = parentElement.addElement(expression);
		
		return element;
	}
	
	/**
	 * 
	 * <p>
	 * This helper method creates the attribute for given xpath expression from given element
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param batchElement - {@link Element}
	 * @param expression - XPath expression
	 * @return {@link Element}
	 * @throws UnsupportedOperationException
	 * @throws IllegalArgumentException
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public static Element createBatchFromXPath (Element batchElement, String expression, int index) throws UnsupportedOperationException,
			IllegalArgumentException, FormatException
	{
		return createElementsFromXPath(batchElement, expression, null, index);
	}
	
	/**
	 * 
	 * <p>
	 * This helper method creates the attribute for given xpath expression from given element
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param document - {@link Document}
	 * @param expression - XPath expression
	 * @return {@link Element}
	 * @throws UnsupportedOperationException
	 * @throws IllegalArgumentException
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public static Element createBatchFromXPath (Document document, String expression) throws UnsupportedOperationException, IllegalArgumentException,
			FormatException
	{
		StringBuilder currentPath = null;
		Pattern xpathParserPattern = null;
		Matcher matcher = null;
		String currentXPath = null;
		String elementName = null;
		String filterName = null;
		String filterValue = null;
		String attributeName = null;
		StringBuilder builder = null;
		String relativePath = null;
		Node newNode = null;
		Element element = null;
		Element currentNode = null;
		// "\.?/+([\w]+)(\[@([\w]+)='([^']*)'\])?|/@([\w]+)" //REGEX should be like this.
		String REGEX = "/+([\\.\\w]+)(\\[@([\\.\\w]+)='([^']*)'\\])?|/@([\\.\\w]+)";
		
		try
		{
			currentPath = new StringBuilder();
			xpathParserPattern = Pattern.compile(REGEX);
			matcher = xpathParserPattern.matcher(expression);
			if (!document.content().isEmpty())
				currentNode = document.getRootElement();
			
			while (matcher.find())
			{
				currentXPath = matcher.group(0);
				elementName = matcher.group(1);
				filterName = matcher.group(3);
				filterValue = matcher.group(4);
				attributeName = matcher.group(5);
				
				builder = currentPath.append(currentXPath);
				relativePath = builder.toString();
				if (!document.content().isEmpty())
					newNode = document.selectSingleNode(relativePath);
				if (newNode == null)
				{
					if (attributeName != null)
					{
						currentNode.addAttribute(attributeName, "");
						newNode = document.selectSingleNode(relativePath);
					}
					else if (elementName != null)
					{
						
						
						if (currentNode != null)
							element = currentNode.addElement(elementName);
						else
							element = document.addElement(elementName);
						
						if (filterName != null)
							element.addAttribute(filterName, filterValue);
						
						newNode = element;
					}
					else
						throw new UnsupportedOperationException("The given xPath is not supported " + relativePath);
				}
				currentNode = (Element) newNode;
			}
			if (document.selectSingleNode(expression) == null)
			{
				logger.error("Document XPath:" + document.getUniquePath() + "  Given Expression:" + expression);
				throw new IllegalArgumentException("The given xPath cannot be created " + expression);
			}
			return currentNode;
		}
		catch (UnsupportedOperationException exp)
		{
			throw exp;
		}
		catch (IllegalArgumentException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			throw new FormatException("error.iris.admin.xpath", new Object[]
			{ expression }, exp);
		}
		finally
		{
			CleanUpUtils.doClean(currentPath);
			currentPath = null;
			xpathParserPattern = null;
			matcher = null;
			matcher = null;
			currentXPath = null;
			elementName = null;
			filterName = null;
			filterValue = null;
			attributeName = null;
			builder = null;
			relativePath = null;
			newNode = null;
			element = null;
		}
	}
	
	public static void logMemoryDetails(Level level, Logger logger, String text)
	{
		String logMsg = null;
		long totalMemory = 0;
		long freeMemory = 0;
		long maxMemory = 0;
		
		Runtime runtime = Runtime.getRuntime();
		logMsg = "{} #####  Used Memory: {} MB, Free Memory:{} MB,  Total Memory(Heap Size):{} MB,  Max Memory:{} MB  ####";
		totalMemory = runtime.totalMemory();
		freeMemory = runtime.freeMemory();
		maxMemory  =  runtime.maxMemory();
		
		switch (level) {
            case TRACE:
            {
            	logger.trace(logMsg , text, (totalMemory - freeMemory) / mb, freeMemory / mb, totalMemory / mb, maxMemory / mb);
        		break;
            }
            case DEBUG:
            {
            	logger.debug("{} #####  Used Memory: {} MB, Free Memory:{} MB,  Total Memory(Heap Size):{} MB,  Max Memory:{} MB  ####" , text, 
            			(totalMemory - freeMemory) / mb, freeMemory / mb, totalMemory / mb, maxMemory / mb);
        		break;
            }
            case INFO:
            {
            	logger.info("{} #####  Used Memory: {} MB, Free Memory:{} MB,  Total Memory(Heap Size):{} MB,  Max Memory:{} MB  ####" , text, 
            			(totalMemory - freeMemory) / mb, freeMemory / mb, totalMemory / mb, maxMemory / mb);
        		break;
            }
            case WARN:
            {
            	logger.warn("{} #####  Used Memory: {} MB, Free Memory:{} MB,  Total Memory(Heap Size):{} MB,  Max Memory:{} MB  ####" , text, 
            			(totalMemory - freeMemory) / mb, freeMemory / mb, totalMemory / mb, maxMemory / mb);
        		break;
            }
            case ERROR:
            {
            	logger.error("#####  Used Memory: {} MB, Free Memory:{} MB,  Total Memory(Heap Size):{} MB,  Max Memory:{} MB  ####" ,
            			(totalMemory - freeMemory) / mb, freeMemory / mb, totalMemory / mb, maxMemory / mb);
        		break;
            }
		}
	}
	
	public static String getCorrectLocale( String wrongLocale)
	{
		String correctLocale  = null;
		String[] splitLocale = null;
		String language = null;
		
		if ( wrongLocale == null)
			return "en_US";
		
		splitLocale = StringUtils.splitPreserveAllTokens(wrongLocale, "_");
		if ( splitLocale.length < 2)
			return "en_US";
		
		language = splitLocale[0];
		correctLocale = language.toLowerCase() + "_" + splitLocale[1].toUpperCase();
		return correctLocale;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbResourceName
	 * @param applicationContext
	 * @return
	 * </pre></p>
	 */
	public static ConnectionProvider getDBProvider ( String dbResourceName, ApplicationContext applicationContext)
	{
		ConnectionProvider dbProvider = null;
		try
		{
				if (dbResourceName != null)
					dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
				else
					dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
							ResourceTypeEnum.IRIS_DATABASE);
		}
		catch (Exception e)
		{
			logger.error("DB Error:", e);
		}
		return dbProvider;
	}
	
	public static void cleanup (ConnectionProvider dbProvider, Connection dbConnection)
	{
		try
		{
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
			dbProvider = null;
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
	}
	
	
	public static void finishProcess(String status, String errorCode, String errorMsg, ExecutionJobData jobData, String dbResourceName,
			ApplicationContext applicationContext, boolean isSchedule)
	{
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		ExecutionException eExp = null;
		CallableStatement cStmt = null;
		String sql = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		String refId = null;
		String executionId = null;
		
		try
		{
			if ( "C".equals(status))
			{
				if ( errorCode == null)
					errorCode = "Sucess";
				if ( errorMsg == null)
					errorMsg = "Sucess";
			}
			else if (IrisAdminConstants.CONSTANT_N.equals(status))
			{
				status = "C";
				if ( errorCode == null)
					errorCode = "Sucess";
				if ( errorMsg == null)
					errorMsg = "No Data Found";
			}
			else
			{
				if ( errorCode == null)
					errorCode = "ERROR";
				if ( errorMsg == null)
					errorMsg = "Execution Error";
			}
			startTime = System.currentTimeMillis();
			dbProvider = getDBProvider(dbResourceName, applicationContext);
			dbConnection = dbProvider.getConnection();
			updateJobStatus(dbConnection, status, errorCode, errorMsg, jobData);
			sql = "{CALL pkg_iris_admin.finish_iris_job (?, ?, ?, ?,?)}";
			cStmt = dbConnection.prepareCall(sql);
			executionId = jobData.getExecutionId();
			if ( isSchedule)
				refId = jobData.getRefId();
			cStmt.setString(1, executionId);
			cStmt.setString(2, refId);
			cStmt.setString(3, status);
			cStmt.setString(4, errorCode);
			cStmt.setString(5, errorMsg);
			
			cStmt.executeUpdate();
			dbConnection.commit();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			logger.debug("Time taken for executing pkg_iris_admin.finish_iris_job StoredProcedure: {}" , delta);
		}
		catch (Exception exp)
		{
			//do not thorw exception
			logger.error("Ignoring this exceition:{}" , exp.getMessage());	eExp = new ExecutionException("", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
		}
		finally
		{
			CleanUpUtils.doClean(cStmt);
			CleanUpUtils.doClean(dbProvider, dbConnection);
		}
		
	}
	
	private static void updateJobStatus (Connection dbConnection , String status, String errorCode, String errorMsg, ExecutionJobData jobData) throws ExecutionException
	{
		PreparedStatement updateSt = null;
		ExecutionException eExp = null;
		String executionId = null;
		int updateCount = 0;
		
		try
		{
			executionId = jobData.getExecutionId();
			updateSt = dbConnection.prepareStatement(updateSql);
			updateSt.clearParameters();
			updateSt.setString(1, status);
			updateSt.setString(2, jobData.getSellerCode());
			updateSt.setString(3, errorCode);
			updateSt.setString(4, errorMsg);
			updateSt.setString(5, jobData.getMediaDetails());
			updateSt.setString(6, executionId);
			updateCount = updateSt.executeUpdate();
			
			if (updateCount < 0)
				logger.warn("Job:" + executionId + " record not available for status update");
			else if (logger.isTraceEnabled())
				logger.debug("Job:" + executionId + " Record status updated");
			dbConnection.commit();
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.statusupdate", new Object[]	{ "ExecutionId:" + executionId, "JobStatus:" + status, updateSql }, exp);
			IRISLogger.getText(eExp);
			throw eExp;
		}
		catch (Exception exp)
		{
			eExp = new ExecutionException("error.iris.admin.statusupdate", new Object[]	{ "ExecutionId:" + executionId, "JobStatus:" + status, updateSql }, exp);
			IRISLogger.getText(eExp);
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(updateSt);
		}
	}
	
	public static OracleConnection getOracleConnection(Connection connection) throws SQLException 
	{
	    OracleConnection oconn = null;
	    try 
	    {
	    	
	        if (connection.isWrapperFor(oracle.jdbc.OracleConnection.class)) 
	        {
	            oconn = (OracleConnection) connection.unwrap(oracle.jdbc.OracleConnection.class);
	        }
	        else  if (connection.isWrapperFor(ConnectionSpy.class)) 
	        {
	        	ConnectionSpy spy = connection.unwrap(ConnectionSpy.class);
	            oconn = (OracleConnection) spy.unwrap(oracle.jdbc.OracleConnection.class);
	        }
	    } 
	    catch (SQLException e) 
	    {
	        throw e;
	    }
	    return oconn;
	}
	
	
	public static  ExecutionJobData createErrorJOb(ResultSet oldJbosRs) throws SQLException
	{
		ExecutionJobData jobData = null;
		String srcType = null;
		String srcSubType = null;
		
		jobData = new ExecutionJobData();
		jobData.setEntityCode(oldJbosRs.getString("ENTITY_CODE"));
		srcType = oldJbosRs.getString("SRC_TYPE");
		srcSubType = oldJbosRs.getString("src_sub_type");
		
		if ( IrisAdminConstants.DEFINITION_TYPE_RE_UPLOAD.equals(srcType))
		{
			srcType = IrisAdminConstants.DEFINITION_TYPE_UPLOAD;
			jobData.setReUpload(true);
		}
		jobData.setMapType(srcType);
		jobData.setSrcSubType(srcSubType);
		jobData.setMapName(oldJbosRs.getString("SRC_NAME"));
		jobData.setSellerCode(oldJbosRs.getString("SELLER_CODE"));
		jobData.setExecutionId(oldJbosRs.getString("EXECUTION_ID"));
		jobData.setEntityType(oldJbosRs.getString("ENTITY_TYPE"));
		jobData.setStatus(oldJbosRs.getString("STATUS"));
		jobData.setChannelName(oldJbosRs.getString("CHANNEL_NAME"));
		jobData.setMediaDetails(oldJbosRs.getString("MEDIA_DTLS"));
		jobData.setRefId(oldJbosRs.getString("REF_ID"));
		jobData.setParentExecutionId(oldJbosRs.getString("PARENT_EXECUTION_ID"));
		return jobData;
	}
	
	
	/**
	 * Helper function to URLEncode a given string.
	 * 
	 * @param pstrToEncode
	 *            the string to be URLEncoded.
	 * @return the URLEncoded string.
	 */
	public static  String encode(String input)
	{
		String strTemp = null;
		
		try
		{
			strTemp = URLEncoder.encode(input, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
			if (logger.isWarnEnabled())
				logger.warn("Unexpected error has occurred while encoding the string " + input, ex);
			strTemp = input;
		}
		return strTemp;
	}
}
