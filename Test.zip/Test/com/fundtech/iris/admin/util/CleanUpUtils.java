/*------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.core.util
 * FILE     : CleanUpUtils.java
 * CREATED  : Mar 7, 2009 4:06:29 PM
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.io.XMLWriter;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;

/**
 * A utility class containing cleanup methods such as closing a <code>Closeable</code> closing a <code>Connection</code> etc.
 * 
 * @author Prasad P. Khandekar
 * @verion $Id: CleanUpUtils.java,v 1.8 2015/10/19 12:01:45 ramap Exp $
 * @since 1.0
 */
public abstract class CleanUpUtils
{
	private static final Log _log = LogFactory.getLog(CleanUpUtils.class.getName());
	
	/**
	 * Clean up the StringBuilder by deleting all buffered characters and resetting it's capacity to 0.
	 * 
	 * @param sb
	 *            the StringBuilder to be cleaned up.
	 */
	public static final void doClean (StringBuilder sb)
	{
		if (null == sb)
			return;
		sb.delete(0, sb.length());
		sb = null;
	}
	
	/**
	 * Clean up the Collection by deleting all contained elements.
	 * 
	 * @param col
	 *            the Collection to be cleaned up.
	 */
	public static final void doClean (Collection<?> col)
	{
		if (null == col)
			return;
		col.clear();
		col = null;
	}
	
	/**
	 * Clean up the Collection by deleting all contained elements.
	 * 
	 * @param col
	 *            the Collection to be cleaned up.
	 */
	public static final void doClean (Map<?, ?> col)
	{
		if (null == col)
			return;
		col.clear();
		col = null;
	}
	
	/**
	 * Clean up the Closeable by calling it's close method thereby giving it chance to cleanup the underlying system resources.
	 * 
	 * @param toClose
	 *            the Closeable to be cleaned up.
	 */
	public static final void doClose (Closeable toClose)
	{
		try
		{
			if (toClose != null)
				toClose.close();
		}
		catch (IOException ex)
		{
			if (_log.isWarnEnabled())
				_log.warn("Unknown error (" + ex.getMessage() + ") has occurred while cleaning up the closeable!", ex);
		}
		toClose = null;
	}
	
	/**
	 * Clean up the ResultSet by calling it's close method thereby giving it chance to cleanup the underlying system resources.
	 * 
	 * @param toClose
	 *            the ResultSet to be cleaned up.
	 */
	public static final void doClean (ResultSet rs)
	{
		try
		{
			if (rs != null)
				rs.close();
		}
		catch (SQLException ex)
		{
			if (_log.isWarnEnabled())
				_log.warn("Unknown error (" + ex.getMessage() + ") has occurred while cleaning up the resultset!", ex);
		}
		rs = null;
	}
	
	/**
	 * Clean up the Statement by calling it's close method thereby giving it chance to cleanup the underlying system resources.
	 * 
	 * @param toClose
	 *            the Statement to be cleaned up.
	 */
	public static final void doClean (Statement stmt)
	{
		try
		{
			if (stmt != null)
				stmt.close();
		}
		catch (SQLException ex)
		{
			if (_log.isWarnEnabled())
				_log.warn("Unknown error (" + ex.getMessage() + ") has occurred while cleaning up the statement!", ex);
		}
		stmt = null;
	}
	
	/**
	 * Clean up the Connection by calling it's close method thereby giving it chance to cleanup the underlying system resources.
	 * 
	 * @param toClose
	 *            the Connection to be cleaned up.
	 */
	public static final void doClean (Connection con)
	{
		try
		{
			if (con != null)
				con.close();
		}
		catch (SQLException ex)
		{
			if (_log.isWarnEnabled())
				_log.warn("Unknown error (" + ex.getMessage() + ") has occurred while cleaning up the connection!", ex);
		}
		con = null;
	}
	
	public static final void doClose (XMLWriter writer)
	{
		if (null == writer)
			return;
		
		try
		{
			writer.close();
		}
		catch (IOException exIgnore)
		{
			_log.warn("Unable to close closable!", exIgnore);
		}
		finally
		{
			writer = null;
		}
	}
	
	public static void doClean(ConnectionProvider dbProvider,Connection dbConnection)
	{
		try
		{
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
			
			dbProvider = null;
			
		}
		catch (Exception exp)
		{
			_log.error("Error:",exp);
			// DO NOTHING
		}
	}
}
