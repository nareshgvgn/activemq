/*------------------------------------------------------------------------------
 * PACKAGE  : com.cashtech.iris.util
 * FILE     : JMSMetadataHelper.java
 * CREATED  : Jun 12, 2006
 * COPYTIGHT: (C) CashTech Solutions (India) Limited.
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.util;

import java.util.Map;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.TextMessage;

import com.cashtech.iris.patterns.sdo.DataObject;

/**
 * Interface which allows setting custom headers on a message.
 * 
 * @author Vijay Birajdar
 * @author Prasad P. Khandekar
 * @version $Id: JMSMetadataHelper.java,v 1.2 2014/07/20 04:58:25 ramap Exp $
 */
public interface JMSMetadataHelper
{
	/**
	 * Set the custom headers to the provided TextMessage by fetching data from the dataObject & custom headers map which is the replication of
	 * parameters provided in metadata for the node.
	 * 
	 * @param jmsMessage
	 *            - message to which custom headers to be set
	 * @param customHeaders
	 *            - Map of properties to be set to jmsMessage
	 * @param dataObject
	 *            - DataObject from which header value to be fetched to set to the jmsMessage
	 * @throws JMSException
	 *             - in case of any error occurs setting custom header
	 */
	public void setMessageHeaders (TextMessage jmsMessage, Map customHeaders, DataObject dataObject) throws JMSException;
	
	/**
	 * Retrieves the custom headers from provided TextMessage and sets their values on to the DataObject. The Custom headers map contains the names of
	 * the custom headers to be retrieved.
	 * 
	 * @param jmsMessage
	 *            - message from which custom headers are to be fetched.
	 * @param customHeaders
	 *            - Map of custom header properties to be retrieved from jmsMessage. Can be null if no headers are configured in processdef.
	 * @param dataObject
	 *            - DataObject in which retrieved header value are be set.
	 * @throws JMSException
	 *             - in case of any error occures setting custom header
	 */
	public void getMessageHeaders (TextMessage jmsMessage, Map customHeaders, DataObject dataObject) throws JMSException;
	
	/**
	 * Set the custom headers to the provided TextMessage by fetching data from the dataObject & custom headers map which is the replication of
	 * parameters provided in metadata for the node.
	 * 
	 * @param jmsMessage
	 *            - message to which custom headers to be set
	 * @param customHeaders
	 *            - Map of properties to be set to jmsMessage
	 * @param dataObject
	 *            - DataObject from which header value to be fetched to set to the jmsMessage
	 * @throws JMSException
	 *             - in case of any error occurs setting custom header
	 */
	public void setMessageHeaders (BytesMessage jmsMessage, Map customHeaders, DataObject dataObject) throws JMSException;
	
	/**
	 * Retrieves the custom headers from provided TextMessage and sets their values on to the DataObject. The Custom headers map contains the names of
	 * the custom headers to be retrieved.
	 * 
	 * @param jmsMessage
	 *            - message from which custom headers are to be fetched.
	 * @param customHeaders
	 *            - Map of custom header properties to be retrieved from jmsMessage. Can be null if no headers are configured in processdef.
	 * @param dataObject
	 *            - DataObject in which retrieved header value are be set.
	 * @throws JMSException
	 *             - in case of any error occures setting custom header
	 */
	public void getMessageHeaders (BytesMessage jmsMessage, Map customHeaders, DataObject dataObject) throws JMSException;
}