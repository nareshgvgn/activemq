/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : NameSpaceElements.java
 * CREATED: Dec 1, 2014 1:44:41 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: NameSpaceElements.java,v 1.2 2016/02/29 06:19:20 ramap Exp $
 */
public class NameSpaceElements
{
	private String bandName = null;
	private String absoluteXPath1 = null;
	private String absoluteXPath2 = null;
	private String relativeXPath = null;
	private String nameSpaceURI = null;
	private String prefix = ""; // default value should be empty and not null.
	private String nameSpace = null;
	
	
	/**
	 * @return the bandName
	 */
	public String getBandName ()
	{
		return bandName;
	}
	/**
	 * @param bandName the bandName to set
	 */
	public void setBandName (String bandName)
	{
		this.bandName = bandName;
	}
	
	/**
	 * @return the absoluteXPath1
	 */
	public String getAbsoluteXPath1 ()
	{
		return absoluteXPath1;
	}
	/**
	 * @param absoluteXPath1 the absoluteXPath1 to set
	 */
	public void setAbsoluteXPath1 (String absoluteXPath1)
	{
		this.absoluteXPath1 = absoluteXPath1;
	}
	/**
	 * @return the absoluteXPath2
	 */
	public String getAbsoluteXPath2 ()
	{
		return absoluteXPath2;
	}
	/**
	 * @param absoluteXPath2 the absoluteXPath2 to set
	 */
	public void setAbsoluteXPath2 (String absoluteXPath2)
	{
		this.absoluteXPath2 = absoluteXPath2;
	}
	/**
	 * @return the relativeXPath
	 */
	public String getRelativeXPath ()
	{
		return relativeXPath;
	}
	/**
	 * @param relativeXPath the relativeXPath to set
	 */
	public void setRelativeXPath (String relativeXPath)
	{
		this.relativeXPath = relativeXPath;
	}
	/**
	 * @return the nameSpaceURI
	 */
	public String getNameSpaceURI ()
	{
		return nameSpaceURI;
	}
	/**
	 * @param nameSpaceURI the nameSpaceURI to set
	 */
	public void setNameSpaceURI (String nameSpaceURI)
	{
		this.nameSpaceURI = nameSpaceURI;
	}
	/**
	 * @return the prefix
	 */
	public String getPrefix ()
	{
		return prefix;
	}
	/**
	 * @param prefix the prefix to set
	 */
	public void setPrefix (String prefix)
	{
		this.prefix = prefix;
	}
	/**
	 * @return the nameSpace
	 */
	public String getNameSpace ()
	{
		return nameSpace;
	}
	/**
	 * @param nameSpace the nameSpace to set
	 */
	public void setNameSpace (String nameSpace)
	{
		this.nameSpace = nameSpace;
	}
	
	
}
