/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.exceptions
 * FILE   : LoadingException.java
 * CREATED: Feb 6, 2013 4:38:35 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.exceptions;

import com.cashtech.iris.message.messages.ApplicationException;

/**
 * Thrown when an application fails load Model and Interface definition<br>
 * TODO need to adjust this doc Some causes are as below,
 * <ul>
 * <li>If a node get a file for processing which is not in a format attached to that node
 * <li>If no band found with a mentioned band identifier string
 * <li>Any error occures during running Iris application like throwing of <code>NullPointerException</code> by some of the subporcess
 * </ul>
 * 
 * @author Babu Paluri
 * @version $Id: LoadingException.java,v 1.4 2014/07/20 04:58:27 ramap Exp $
 * @since 1.0.0
 */
public class LoadingException extends ApplicationException
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructor constructs <code>LoadingException</code>
	 * 
	 * @param key
	 *            - unique key which is used to search user readable error message from error file
	 * @param args
	 *            - Array of args to be shown to user for analyzing resons of exception
	 * @param cause
	 *            - root cause of this exception e.g. <code>NullPointerException</code>
	 */
	public LoadingException(String key, Object[] args, Throwable cause)
	{
		super(key, args, cause);
	}
}
