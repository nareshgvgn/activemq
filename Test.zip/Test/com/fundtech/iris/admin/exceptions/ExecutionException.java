/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.exceptions
 * FILE   : ExecutionException.java
 * CREATED: May 1, 2013 11:07:37 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.exceptions;

import com.cashtech.iris.message.messages.ApplicationException;

/**
 * TODO need to write Doc
 * 
 * @author Babu Paluri
 * @version $Id: ExecutionException.java,v 1.3 2014/07/20 04:58:27 ramap Exp $
 * @since 1.0.0
 */
public class ExecutionException extends ApplicationException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructor constructs <code>ExecutionException</code>
	 * 
	 * @param key
	 *            - unique key which is used to search user readable error message from error file
	 * @param args
	 *            - Array of args to be shown to user for analyzing resons of exception
	 * @param cause
	 *            - root cause of this exception e.g. <code>NullPointerException</code>
	 */
	public ExecutionException(String key, Object[] args, Throwable cause)
	{
		super(key, args, cause);
	}
}
