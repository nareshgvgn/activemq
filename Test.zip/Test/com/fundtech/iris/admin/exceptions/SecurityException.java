/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.exceptions
 * FILE   : FormatException.java
 * CREATED: Jun 13, 2013 7:19:39 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.exceptions;

import com.cashtech.iris.message.messages.ApplicationException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: SecurityException.java,v 1.3 2014/07/20 04:58:27 ramap Exp $
 * @since 1.0.0
 */
public class SecurityException extends ApplicationException
{
	private static final long serialVersionUID = 1L;
	
	public SecurityException(String key, Object[] args, Throwable cause)
	{
		super(key, args, cause);
	}
}
