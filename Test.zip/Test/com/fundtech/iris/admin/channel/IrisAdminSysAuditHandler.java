/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel
 * FILE   : IrisAdminSysAuditHandler.java
 * CREATED: Jun 25, 2015 1:17:38 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

import oracle.jdbc.OracleConnection;
import oracle.sql.CLOB;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisAdminSysAuditHandler.java,v 1.13 2016/01/15 13:34:49 ramap Exp $
 */
public class IrisAdminSysAuditHandler extends AbstractAuditHandler
{
	private static Logger logger =  LoggerFactory.getLogger(IrisAdminSysAuditHandler.class);
	private Map<ReferencesEnum, String> references = new HashMap<ReferencesEnum, String>();
	private ApplicationContext applicationContext = null;
	private static final String insSql = "INSERT INTO iris_audit_activity (audit_id, process_name, execution_id,  ENTITY_CODE, audit_type, audit_data)"
										+ " VALUES (?, ?, ?, ?, ?, ?)";
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisAdminSysAuditHandler()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IAuditHandler#audit(java.util.Map)
	 */
	@Override
	public Object auditRecord (Map<String, Object> inputParms, int type)
	{
		ExecutionJobData jobData = null;
		Clob clob = null;
		String message = null;
		PreparedStatement psInsert = null;
		ConnectionProvider dbProvider = null;
		Connection dbConnection = null;
		try
		{
			jobData = (ExecutionJobData)inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			message = (String) inputParms.get(IAuditHandler.AUDIT_SOURCE_DATA);
			dbProvider = getDBProvider();
			dbConnection = dbProvider.getConnection();
			psInsert = dbConnection.prepareStatement(insSql);
			psInsert.clearParameters();
			psInsert.setString(1, createID());
			psInsert.setString(2, jobData.getMapName());
			psInsert.setString(3,jobData.getExecutionId());
			psInsert.setString(4, jobData.getEntityCode());
			psInsert.setInt(5, type);
			clob = clob(message, dbConnection);
			psInsert.setClob(6, clob);
			psInsert.executeUpdate();
			dbConnection.commit();
		}
		catch (SQLException e)
		{
			logger.warn("Not able to audit the record coz:{}", e.getMessage(), e);
		}
		catch ( Exception exp)
		{
			logger.warn("Not able to audit the record coz:{}", exp.getMessage(), exp);
		}
		finally
		{
			free(clob);
			HelperUtils.doClose(psInsert);
			psInsert = null;
			cleanup(dbProvider, dbConnection);
			message = null;
		}
		return null;
	}
	
	
	private final void free(Clob clob)
	{
		try
		{
			if ( clob != null)
				clob.free();
		}
		catch (Exception e)
		{
			logger.error("Error:",e);
			//do nothing
		}
	}
	private final Clob clob(String string, Connection dbConnection)   throws SQLException 
	{
		       
		Clob clob = null;
		OracleConnection oraConnection = null;
		
		oraConnection =  IrisAdminUtils.getOracleConnection(dbConnection);
		clob = CLOB.createTemporary(oraConnection, false, CLOB.DURATION_SESSION);
		clob.setString(1, string);
		return clob;
	}
		 
	

	public static String createID()
	{
	    return UUID.randomUUID().toString();
	}
		 
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IAuditHandler#cleanup()
	 */
	@Override
	public void cleanup ()
	{
	}
	
	public void cleanup(ConnectionProvider dbProvider,Connection dbConnection )
	{
		try
		{
			
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
			
			dbProvider = null;
			
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
	}
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	private ConnectionProvider getDBProvider ()
	{
		String dbResourceName = null;
		ConnectionProvider dbProvider = null;
		try
		{
			dbResourceName = getReferences().get(ReferencesEnum.DB_CONN);
				if (dbResourceName != null)
					dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
				else
					dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
							ResourceTypeEnum.IRIS_DATABASE);
				
		}
		catch (Exception e)
		{
			logger.error("DB Error:", e);
		}
		return dbProvider;
	}

	/**
	 * @return the references
	 */
	public Map<ReferencesEnum, String> getReferences ()
	{
		return references;
	}

	/**
	 * @param references the references to set
	 */
	public void setReferences (Map<ReferencesEnum, String> references)
	{
		this.references = references;
	}

	/**
	 * @param applicationContext the applicationContext to set
	 */
	public void setApplicationContext (ApplicationContext applicationContext)
	{
		this.applicationContext = applicationContext;
	}
	
	
	
}
