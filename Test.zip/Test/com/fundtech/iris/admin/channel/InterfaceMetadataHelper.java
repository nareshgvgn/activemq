/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.spring
 * FILE   : InterfaceMetadataHelper.java
 * CREATED: Apr 26, 2014 4:21:41 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.util.Map;

import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceMetadataHelper.java,v 1.1 2014/07/20 04:58:26 ramap Exp $
 */
public class InterfaceMetadataHelper
{
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public InterfaceMetadataHelper()
	{
		
	}
	
	public ExecutionJobData createExecutionJobData (Map<String, Object> parms)
	{
		ExecutionJobData jobData = null;
		
		return jobData;
	}
	
}
