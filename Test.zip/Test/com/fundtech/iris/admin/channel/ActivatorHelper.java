/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator
 * FILE   : ActivatorHelper.java
 * CREATED: Jul 2, 2014 10:13:18 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.ProcessExecution;
import com.cashtech.iris.core.processor.SimpleProcess;
import com.cashtech.iris.core.processor.SimpleProcessExecution;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.util.IRISLogger;
import com.dh.iris.admin.channels.iris.IDataObject;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.interfaces.LoadInterfaceDef;
import com.fundtech.iris.admin.sqlparser.IrisAdminDowloadListener;
import com.fundtech.iris.admin.sqlparser.SqlParserEngine;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.fundtech.iris.admin.util.OracleType;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: ActivatorHelper.java,v 1.56 2017/01/05 11:55:34 ramap Exp $
 */
public class ActivatorHelper
{
	
	private Connection dbConnection = null;
	private static Logger logger = LoggerFactory.getLogger(ActivatorHelper.class);
	private PreparedStatement interfaceMapStmt = null;
	private PreparedStatement secProfileStmt = null;
	private ApplicationContext applicationContext = null;
	private String FILTER_PARMS="FILTER_PARMS";
	private String INTERFACE_MAP="INTERFACE_MAP";
	private String SECURITY_PROFILE = "SECURITY_PROFILE";
	private String INTERFACE_DEF = "INTERFACE_DEF";
	private Map<String, Object> cache = new HashMap<String, Object>();
	
	public ActivatorHelper()
	{
	}
	
	public void initialize (Connection dbConnection, ApplicationContext applicationContext) throws SQLException
	{
		this.applicationContext = applicationContext;
		this.dbConnection = dbConnection;
		interfaceMapStmt = dbConnection.prepareStatement(getInterfaceMapSql());
		secProfileStmt = dbConnection.prepareStatement("select * from PRF_SECURITY_MST where PROFILE_ID =?");
	}
	
	
	public String createJob (Map<String, ?> helperData) throws LoadingException
	{
		String executionId = null;
		CallableStatement stProc = null;
		String procName = "{CALL pkg_integrate_gcp.h2h_upload(?,?,?,?,?,?,?,?,?,?)}";
		String entityType = null;
		String entityCode = null;
		String mediaType = null;
		String mapName = null;
		String errorVal = null;
		String errorMsg = null;
		String messageId = null;
		String parentExecutionId = null;
		OracleType runtimeParms = null;
		LoadingException lExp = null;
		OracleConnection oraConnection = null;
		ARRAY array = null;
		Map<String, Object> inputParms = null;
		OracleType[] types = new OracleType[1];
		OracleType  oracleType = null;
		
		try
		{
			entityType = (String)helperData.get(IrisAdminConstants.ENTITY_TYPE);
			entityCode = (String)helperData.get(IrisAdminConstants.ENTITY_CODE);
			mapName = (String) helperData.get(IrisAdminConstants.MAP_NAME);
			messageId = (String)helperData.get(IrisAdminConstants.MEDIA_DETAIL);
			mediaType = (String)helperData.get(IrisAdminConstants.CHANNEL);
			inputParms = (Map<String, Object>)helperData.get(IrisAdminConstants.FILTER_PARMS);
			parentExecutionId = (String)helperData.get(IrisAdminConstants.PARENT_EXECUTION_ID);
				
			if ( IrisAdminConstants.MEDIA_HTTP_CW.equals(mediaType) || IrisAdminConstants.MEDIA_EVENT_RQ.equals(mediaType))
				types = getFilterParms(dbConnection, entityCode, entityType, mapName, inputParms);
			else
			{
				types = new OracleType[1];
				oracleType = new OracleType(null, null, null);
				types[0] = oracleType;
			}
				
			oraConnection = IrisAdminUtils.getOracleConnection(dbConnection);
			array =  HelperUtils.createTypeValue(oraConnection, OracleTypes.ARRAY, "NT_KEY_VALUE_PAIR", types);
			stProc = oraConnection.prepareCall(procName);
			stProc.setString(1, mediaType);
			stProc.setString(2, messageId);
			stProc.setString(3, entityType);
			stProc.setString(4, entityCode);
			stProc.setString(5, mapName);
			stProc.setString(6,parentExecutionId);
			stProc.setObject(7, array, OracleTypes.ARRAY);
			stProc.registerOutParameter(8, Types.VARCHAR);
			stProc.registerOutParameter(9, Types.VARCHAR);
			stProc.registerOutParameter(10, Types.VARCHAR);
			stProc.executeUpdate();
			executionId = stProc.getString(8);
			errorVal = stProc.getString(9);
			errorMsg = stProc.getString(10);
			
			if (executionId == null)
			{
				logger.error("Error Code:" + errorVal + "  Error Message:" + errorMsg);
				lExp = new LoadingException("error.admin.createjob", new Object[]{ procName, mediaType, messageId, entityType, entityCode, mapName, runtimeParms }, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
			dbConnection.commit(); // commit it so that process gets execution data.
		}
		catch (LoadingException exp)
		{
			throw exp;
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[] { procName, mediaType, messageId, entityType, entityCode, mapName, runtimeParms }, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[] { procName, mediaType, messageId, entityType, entityCode, mapName, runtimeParms }, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(stProc);
		}
		
		return executionId;
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param executionId
	 * @param isAccumulate
	 * @param ftpPath
	 * @return
	 * @throws LoadingException
	 * </pre></p>
	 */
	public ExecutionJobData fetchJobData (String executionId, boolean isAccumulate, String ftpPath) throws LoadingException
	{
		ExecutionJobData jobData = null;
		ResultSet rsJob = null;
		PreparedStatement stJob = null;
		String jobSql = "SELECT * FROM IRIS_JOB_QUEUE WHERE EXECUTION_ID = ? ";
		LoadingException lExp = null;
		
		try
		{
			stJob = dbConnection.prepareStatement(jobSql);
			stJob.clearParameters();
			stJob.setString(1, executionId);
			rsJob = stJob.executeQuery();
			
			if (rsJob.next())
				jobData = fetchJobData(rsJob, isAccumulate, ftpPath);
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.secProfile", new Object[]{ executionId, "MQ",}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rsJob);
			HelperUtils.doClose(stJob);
		}
		return jobData;
	}
	
	/**
	 * 
	 * <p>This helper method creates the dataObject by using Pick Up SQL result Set
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param rsPickup
	 * @param isAccumulate
	 * @param ftpPath
	 * @return
	 * @throws LoadingException
	 * </pre></p>
	 */
	private void fetchDynamicJobData (ExecutionJobData jobData) throws LoadingException
	{
		Map<String, String> filterParameters = null;
		LoadingException lExp = null;
		InterfaceMap interfaceMap = null;
		String runtimeCharSet = null;
		String secProfileRecordKey = null;
		String processDefRecordKey = null;
		SecurityProfile secProfile = null;
		InterfaceDef interfaceDef = null;
		try
		{
			
			if (cache.containsKey(FILTER_PARMS))
				filterParameters = (Map<String, String>)cache.get(FILTER_PARMS);
			else
			{
				filterParameters = fetchJobParams(jobData);
				cache.put(FILTER_PARMS, filterParameters);
			}
			jobData.setFilterParameters(filterParameters);
			jobData.addFilterParemeter("P_EXECUTION_ID", jobData.getExecutionId());
			
			if ( cache.containsKey(INTERFACE_MAP))
				interfaceMap = (InterfaceMap)cache.get(INTERFACE_MAP);
			else
			{
				interfaceMap = getInterfaceMapDetails(jobData);
				cache.put(INTERFACE_MAP, interfaceMap);
			}
			
			if (cache.containsKey(SECURITY_PROFILE))
				secProfile = (SecurityProfile) cache.get(SECURITY_PROFILE);
			else
			{
				secProfileRecordKey = interfaceMap.getSecProfileRecordKey();
				processDefRecordKey = interfaceMap.getInterfaceDefRecordKey();
				secProfile = getSecurityProfile(secProfileRecordKey);
				interfaceMap.setSecurityProfile(secProfile);
			}
			jobData.setInterfaceMap(interfaceMap);
			
			if ( cache.containsKey(INTERFACE_DEF))
				interfaceDef = (InterfaceDef) cache.get(INTERFACE_DEF);
			else
			{
				interfaceDef = getDefinition(jobData,processDefRecordKey);
				cache.put(INTERFACE_DEF, interfaceDef);
			}
				
			jobData.setInterfaceDef(interfaceDef);
			runtimeCharSet = jobData.getFilterParameter(IrisAdminConstants.FILTER_INTERNAL_CHATSET);
			jobData.setCharSet(runtimeCharSet);
			jobData.setFormatterType(interfaceDef.getFormatterType());
			jobData.setMediumType(interfaceDef.getMediumType());
		}
		catch ( LoadingException exp)
		{
			throw exp;
		}
		catch (Exception e)
		{
			lExp = new LoadingException("error.admin.jobData", new Object[]{ jobData}, e);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param rsPickup
	 * @param isAccumulate
	 * @param ftpPath
	 * @return
	 * </pre></p>
	 */
	public ExecutionJobData fetchJobData (ResultSet rsPickup, boolean isAccumulate, String ftpPath) 
	{
		ExecutionJobData jobData = null;
		Map<String, String> filterParameters = null;
		LoadingException lExp = null;
		String srcType = null;
		InterfaceMap interfaceMap = null;
		String runtimeCharSet = null;
		String secProfileRecordKey = null;
		String processDefRecordKey = null;
		SecurityProfile secProfile = null;
		String lineSeparator = null;
		InterfaceDef interfaceDef = null;
		String srcSubType = null;
		String gcpVersion = IrisAdminConstants.VERSION_4_3;
		try
		{
			jobData = new ExecutionJobData();
			jobData.setEntityCode(rsPickup.getString("ENTITY_CODE"));
			srcType = rsPickup.getString("SRC_TYPE");
			srcSubType = rsPickup.getString("src_sub_type");
			
			if ( IrisAdminConstants.DEFINITION_TYPE_RE_UPLOAD.equals(srcType))
			{
				srcType = IrisAdminConstants.DEFINITION_TYPE_UPLOAD;
				jobData.setReUpload(true);
			}
			jobData.setMapType(srcType);
			jobData.setSrcSubType(srcSubType);
			jobData.setMapName(rsPickup.getString("SRC_NAME"));
			jobData.setSellerCode(rsPickup.getString("SELLER_CODE"));
			jobData.setExecutionId(rsPickup.getString("EXECUTION_ID"));
			jobData.setEntityType(rsPickup.getString("ENTITY_TYPE"));
			jobData.setStatus(rsPickup.getString("STATUS"));
			jobData.setChannelName(rsPickup.getString("CHANNEL_NAME"));
			jobData.setMediaDetails(rsPickup.getString("MEDIA_DTLS"));
			jobData.setRefId(rsPickup.getString("REF_ID"));
			jobData.setParentExecutionId(rsPickup.getString("PARENT_EXECUTION_ID"));
			jobData.setPriority(rsPickup.getString("PRIORITY"));
			jobData.setEntryDate(rsPickup.getDate("ENTRY_DATE"));
			jobData.setExecutionDate(rsPickup.getDate("EXECUTION_DATE"));
			jobData.setStartDate(rsPickup.getDate("START_DATE"));
			jobData.setEndDate(rsPickup.getDate("END_DATE"));
			jobData.setAccumulateErros(isAccumulate);
			jobData.setFtpPath(ftpPath);
			jobData.setStatus("P");
			lineSeparator = getLineSeparator(jobData);
			jobData.setLinSeparator(lineSeparator);
			
			/*
			 * Do not execute profile jobs properties here, it should load for each job
			 */
			if ( ! IrisAdminConstants.SCH_PROFILE.equals(srcType))
			{
				filterParameters = fetchJobParams(jobData);
				jobData.setFilterParameters(filterParameters);
				interfaceMap = getInterfaceMapDetails(jobData);
				secProfileRecordKey = interfaceMap.getSecProfileRecordKey();
				processDefRecordKey = interfaceMap.getInterfaceDefRecordKey();
				secProfile = getSecurityProfile(secProfileRecordKey);
				interfaceMap.setSecurityProfile(secProfile);
				jobData.setInterfaceMap(interfaceMap);
				runtimeCharSet = jobData.getFilterParameter(IrisAdminConstants.FILTER_INTERNAL_CHATSET);
				jobData.setCharSet(runtimeCharSet);
				
				/*
				 * IRIS type will have their own process def, so we should not load interface def
				 */
				if ( IrisAdminConstants.IRIS_ADMIN.equals(srcSubType) || IrisAdminConstants.SCH_PROFILE.equals(srcSubType) || IrisAdminConstants.SCH_SEGMENTED.equals(srcSubType))
				{
					interfaceDef = getDefinition(jobData,processDefRecordKey);
					jobData.setInterfaceDef(interfaceDef);
					jobData.setFormatterType(interfaceDef.getFormatterType());
					jobData.setMediumType(interfaceDef.getMediumType());
					gcpVersion = jobData.getInterfaceDef().getMosdelDef().getGcpVersion();
				}
			}
			
			if (IrisAdminConstants.VERSION_4_3.compareTo(gcpVersion) < 0 )
			{
				if (( IrisAdminConstants.IRIS_ADMIN.equals(srcSubType) || IrisAdminConstants.SCH_PROFILE.equals(srcSubType) || IrisAdminConstants.SCH_SEGMENTED.equals(srcType) ) && ! IrisAdminConstants.SCH_PROFILE.equals(srcType)) 
					setWhereCondition(jobData);
			}

		}
		catch ( LoadingException exp)
		{
			jobData.setStatus("L");
			//do not throw Exception
		}
		catch (Exception e)
		{
			lExp = new LoadingException("error.admin.jobData", new Object[]{ jobData}, e);
			logger.error(IRISLogger.getText(lExp));
			jobData.setStatus("L");
			//do not throw Exception
		}
		return jobData;
		
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * </pre></p>
	 */
	private void setWhereCondition (ExecutionJobData jobData) throws LoadingException
	{
		String parsedCondition = null;
		String dummySql = "select * from dual ";
		IrisAdminDowloadListener listener = null;
		SqlParserEngine engine = null;
		LoadingException lExp = null;
		String originalCondition = null;
		
		try
		{
			originalCondition = jobData.getInterfaceDef().getParsendCondition();
			
			logger.trace("Original Where Condition:{}", originalCondition);
			if ( StringUtils.isEmpty(originalCondition))
				return;
			if ( StringUtils.startsWithIgnoreCase(originalCondition, "WHERE"))
				originalCondition = dummySql + originalCondition;
			else
				originalCondition = dummySql + " WHERE " + originalCondition;
			
			listener = new IrisAdminDowloadListener(jobData);
			engine = new SqlParserEngine();
			engine.parse(originalCondition, listener);
			parsedCondition = listener.getWhereCondition();
			logger.trace("Parsed Where condition:{}", parsedCondition);
			jobData.setWhereCondition(parsedCondition);
		}
		catch ( Exception exp)
		{
			logger.error("Error While parsing where condition:  {}", originalCondition);
			lExp = new LoadingException("error.admin.download.wherconditionParse", new Object[]{ originalCondition,parsedCondition}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		
	}

	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param secProfileRecordKey
	 * @return
	 * @throws LoadingException
	 * </pre></p>
	 */
	private SecurityProfile getSecurityProfile (String secProfileRecordKey) throws LoadingException
	{
		SecurityProfile secProfile = null;
		ResultSet secRs = null;
		LoadingException lExp = null;
		try
		{
			secProfile = new SecurityProfile();
			if (secProfileRecordKey != null)
			{
				
				secProfileStmt.clearParameters();
				secProfileStmt.setString(1, secProfileRecordKey);
				secRs = secProfileStmt.executeQuery();
				if (secRs.next())
				{
					secProfile.setChannelCertName(secRs.getString("FTP_CERTIFICATE_NAME"));
					secProfile.setChannelBasePath(secRs.getString("FTP_BASE_DIRECTORY"));
					secProfile.setChannelIPAddress(secRs.getString("FTP_IPADDRESS"));
					secProfile.setChannelMode(secRs.getString("FTP_TRANSFER_MODE"));
					secProfile.setChannelPassword(secRs.getString("FTP_PASSWORD"));
					secProfile.setChannelPort(secRs.getInt("FTP_PORT"));
					secProfile.setChannelType(secRs.getString("FTP_PROTOCOL_TYPE"));
					secProfile.setChannelUser(secRs.getString("FTP_USER"));
					secProfile.setEmailId(secRs.getString("EMAIL_ID"));
					secProfile.setEncryptionAlgo(secRs.getString("ENCRYPTION_ALGO"));
					secProfile.setEncryptionKey(secRs.getString("ENCRYPTION_KEY"));
					secProfile.setEncryptionRequired(secRs.getString("ENCRYPTION_FLAG"));
					secProfile.setEncryptionType(secRs.getString("ENCRYPTION_TYPE"));
					secProfile.setEncryptionKeyLength(secRs.getInt("ENCRYPTION_KEY_LENGTH"));
					secProfile.setIntegrityAlgo(secRs.getString("INTEGRITY_CHECK_ALGO"));
					secProfile.setIntegrityCheckRequired(secRs.getString("INTEGRITY_CHECK_FLAG"));
					secProfile.setName(secRs.getString("PROFILE_NAME"));
					secProfile.setNotifySucess(secRs.getString("NOTIFY_SUCCESS"));
					secProfile.setNotifyFailure(secRs.getString("NOTIFY_FAIL"));
					secProfile.setPdfPassword(secRs.getString("PDF_PASSPHRASE"));
					secProfile.setSigningType(secRs.getString("SIGNING_TYPE"));
					secProfile.setSiginingRequired(secRs.getString("SIGNING_FLAG"));
					secProfile.setSiginingAlgo(secRs.getString("SIGNING_ALGO"));
					secProfile.setZipType(secRs.getString("ZIP_MODE"));
					secProfile.setZipPassword(secRs.getString("ZIP_PASSPHRASE"));
					secProfile.setSigningKey(secRs.getString("SIGNING_KEY"));
				}
			}
			
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.secProfile", new Object[]{ secProfileRecordKey}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(secRs);
		}
		
		return secProfile;
	}
	
	/**
	 * This Helper method fetches the run time parameter values for given schedule id TODO
	 * 
	 * @param jobData
	 * @return
	 */
	private Map<String, String> fetchJobParams (ExecutionJobData jobData)  throws LoadingException
	{
		String query = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		LoadingException lExp = null;
		Map<String, String> filterParameters = new HashMap<String, String>();
		try
		{
			query = "SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM IRIS_JOB_PARAM_TXN WHERE EXECUTION_ID =?";
			stmt = dbConnection.prepareStatement(query);
			stmt.setString(1, jobData.getExecutionId());
			rs = stmt.executeQuery();
			while (rs.next())
			{
				filterParameters.put(rs.getString(1), rs.getString(2));
			}
			filterParameters.put("P_EXECUTION_ID", jobData.getExecutionId());
			
		}
		catch (SQLException e)
		{
			lExp = new LoadingException("error.admin.jobparams", new Object[]{ jobData.toString()}, e);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rs);
			HelperUtils.doClose(stmt);
			query = null;
		}
		
		return filterParameters;
	}
	
	/**
	 * This helper method creates interface map object from database
	 * 
	 * @param jobData
	 * @return
	 */
	private InterfaceMap getInterfaceMapDetails (ExecutionJobData jobData)  throws LoadingException
	{
		InterfaceMap interfaceMap = null;
		ResultSet mapRs = null;
		LoadingException lExp = null;
		String  entityType = null;
		try
		{
			interfaceMapStmt.clearParameters();
			interfaceMapStmt.setString(1, jobData.getMapName());
			entityType = jobData.getEntityType();
			interfaceMapStmt.setString(2, entityType);
			interfaceMapStmt.setString(3, jobData.getEntityCode());
			if ( "BANK".equals(entityType))
				interfaceMapStmt.setString(4, "BANK");
			else
				interfaceMapStmt.setString(4, jobData.getEntityCode());
			
			mapRs = interfaceMapStmt.executeQuery();
			
			if (mapRs.next())
			{
				interfaceMap = new InterfaceMap();
				interfaceMap.setName(mapRs.getString("MAP_NAME"));
				interfaceMap.setType(mapRs.getString("MAP_TYPE"));
				interfaceMap.setInterfaceDefRecordKey(mapRs.getString("INTERFACE_RECORD_KEY_NMBR"));
				interfaceMap.setModeuleCode(mapRs.getString("MODULE_CODE"));
				interfaceMap.setSecProfileRecordKey(mapRs.getString("SECURITY_PROFILE_ID"));
			}
			else
			{
				// TODO else should not come at all coz with map code only client can upload file.that
				// means record avl, but better to throw error coz H2H may fall in this case??? made coz BAGL guys messed up this 
				
				logger.error("Map Code configuration is wrong");
				lExp = new LoadingException("error.admin.interfaceMap", new Object[]{ jobData.toString()}, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
			
		}
		catch (SQLException e)
		{
			lExp = new LoadingException("error.admin.interfaceMap", new Object[]{ jobData.toString()}, e);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch ( LoadingException exp)
		{
			throw exp;
		}
		catch(NullPointerException exp)
		{
			logger.error("Map Code configuration is wrong");
			lExp = new LoadingException("error.admin.interfaceMap", new Object[]{ jobData.toString()}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(mapRs);
		}
		return interfaceMap;
	}
	
	private String getInterfaceMapSql ()
	{
		String sql = "SELECT MAP_NAME, MAP_TYPE, MODULE_CODE, INTERFACE_RECORD_KEY_NMBR, SECURITY_PROFILE_ID FROM IRIS_INT_MAP_MST T"
				+ " WHERE T.MAP_NAME = ? AND T.ENTITY_TYPE = ? AND (T.ENTITY_CODE = ? OR T.ENTITY_CODE=?)";
		return sql;
	}
	
	public String getFtpPath (String id, String ftpProperty) throws LoadingException
	{
		String sql = "SELECT PARAMETER_VALUE FROM SYSTEM_PARAMETERS_MST WHERE PARAMETER_CODE =?";
		PreparedStatement statement = null;
		ResultSet rSet = null;
		File ftpFile = null;
		String ftpPath = null;
		LoadingException lExp = null;
		
		try
		{
			statement = dbConnection.prepareStatement(sql);
			statement.clearParameters();
			statement.setString(1, ftpProperty);
			rSet = statement.executeQuery();
			if (rSet.next())
			{
				ftpPath = rSet.getString("PARAMETER_VALUE");
				ftpFile = new File(ftpPath);
				ftpPath = ftpFile.getAbsolutePath();
			}
			else
			{
				lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rSet);
			HelperUtils.doClose(statement);
			ftpFile = null;
		}
		
		return ftpPath;
	}
	
	public void cleanUp ()
	{
		HelperUtils.doClose(interfaceMapStmt);
		HelperUtils.doClose(secProfileStmt);
		CleanUpUtils.doClean(cache);
	}
	
	private InterfaceDef getDefinition (ExecutionJobData jobData, String processDefRecordKey) throws LoadingException
	{
		InterfaceDef interfaceDef = null;
		LoadInterfaceDef loadDefinition = null;
		
		loadDefinition = new LoadInterfaceDef(dbConnection, jobData, processDefRecordKey);
		interfaceDef = loadDefinition.getinterfaceDef();
		return interfaceDef;
	}
	
	/**
	 * This helper method creates line separator
	 * 
	 * @return line separator
	 */
	private String getLineSeparator (ExecutionJobData jobData)
	{
		String inputSeparator = null;
		
		inputSeparator = jobData.getFilterParameter(IrisAdminConstants.FILTER_INTERNAL_LINESEPARATOR);
		if (inputSeparator == null || "".equals(inputSeparator.trim()))
			return System.getProperty("line.separator");
		
		if ("CRLF".equals(inputSeparator))
			return "\r\n";
		else if ("LF".equals(inputSeparator))
			return "\n";
		else if ("CR".equals(inputSeparator))
			return  "\r";
		else
			return System.getProperty("line.separator");
	}
	
	public ExecutionJobData runProcess(Map<String, Object> inputParms, String mediaType, boolean isAccumulate, String ftpPath) throws ExecutionException
	{
		String processName = null;
		String processId = null;
		Packet packet = null;
		SimpleProcess simpleProcess = null;
		ProcessExecution simpleProcessExecution = null;
		ExecutionException eExp = null;
		Map<String, Object> sourceData = null;
		Map<String, Object> outData = null;
		String executionId = null;
		ExecutionJobData jobData = null;
		ExecutionJobData requestJobData = null;
		Identifier procIdetifier = null;
		Map<String, Object> jmsHeaderData  = null;
		String inputMsg = null;
		String messageId = null; 
		String inputFileName = null;
		Map<String, Object> auditParms = null;
		IAuditHandler auditHandler = null;
		Connection hookConnection = null;
		ConnectionProvider dbProvider = null;
		String srcSubType = null;
		DataObject inputDo = null;
		IDataObject dataObjectHelper = null;
		Map<String, Object> dataObjectParms = null;
		String mapName = null;
		
		try
		{
			procIdetifier = (Identifier)inputParms.get(IrisAdminConstants.PROCESS_IDENTIFIER);
			requestJobData = (ExecutionJobData)inputParms.get(IrisAdminConstants.REQUEST_JOB_DATA);
			
			if (procIdetifier == null)
			{
				logger.error("process name to execute is not configured");
				eExp = new ExecutionException("error.app.noProcIdentifier", new Object[] {}, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			dbProvider = IrisAdminUtils.getDBProvider(null, applicationContext);
			hookConnection = dbProvider.getConnection();
			sourceData = new HashMap<String, Object>();
			sourceData.put(IrisAdminConstants.DB_CONNECTION, hookConnection);
			
			if (IrisAdminConstants.MEDIA_MQ.equals(mediaType))
			{
				jmsHeaderData = (Map<String, Object>)inputParms.get(IrisAdminConstants.JMS_HEADER_DATA);
				inputMsg = (String)inputParms.get(IrisAdminConstants.JMS_MESSAGE);
				messageId = (String) inputParms.get(IrisAdminConstants.MEDIA_DETAIL);
				
				sourceData.put(IrisAdminConstants.JMS_MESSAGE, inputMsg);
				sourceData.put(IrisAdminConstants.JMS_HEADER_DATA, jmsHeaderData);
			}
			else if (IrisAdminConstants.MEDIA_EVENT_RQ.equals(mediaType))
			{
				sourceData.put(IrisAdminConstants.EVENT_EXECUTION_JOB, inputParms.get(IrisAdminConstants.EVENT_EXECUTION_JOB));
			}
			
			if (IrisAdminConstants.MEDIA_WEBSERVICE.equals(mediaType))
			{
				inputMsg = (String)inputParms.get(IrisAdminConstants.WEBSERVICE_MESSAGE);
				messageId = (String) inputParms.get(IrisAdminConstants.MEDIA_DETAIL);
				
				sourceData.put(IrisAdminConstants.WEBSERVICE_MESSAGE, inputMsg);
			}
			else if (IrisAdminConstants.MEDIA_HTTP_RESPONSE.equals(mediaType))
			{
				inputMsg = (String)inputParms.get(IrisAdminConstants.HTTP_RESPONSE_MESSAGE);
				messageId = (String) inputParms.get(IrisAdminConstants.MEDIA_DETAIL);
				
				sourceData.put(IrisAdminConstants.HTTP_RESPONSE_MESSAGE, inputMsg);
				
			}
			else if (IrisAdminConstants.MEDIA_FILE.equals(mediaType) )
			{
				inputFileName = (String) inputParms.get(IrisAdminConstants.MEDIA_DETAIL);
				sourceData.put(IrisAdminConstants.MEDIA_DETAIL, inputFileName);
			}
			else if (IrisAdminConstants.MEDIA_ISO.equals(mediaType) )
			{
				sourceData.put(IrisAdminConstants.MEDIA_DETAIL, inputParms.get(IrisAdminConstants.ISO_MESSAGE));
				sourceData.put(IrisAdminConstants.MAP_NAME, requestJobData.getMapName());
			}
			else if (IrisAdminConstants.MEDIA_HTTP_CW.equals(mediaType) || IrisAdminConstants.MEDIA_EVENT_RQ.equals(mediaType))
			{
				sourceData.put(IrisAdminConstants.FILTER_PARMS, inputParms.get(IrisAdminConstants.FILTER_PARMS));
			}
			
			sourceData.put(IrisAdminConstants.REQUEST_JOB_DATA, requestJobData);
			
			outData = (Map<String, Object>)procIdetifier.identify(sourceData);
			
			mapName = (String) outData.get(Identifier.MAP_NAME);
			
			
			if ( StringUtils.isBlank(mapName) )
			{
				logger.error("Interfaace Map code is empty, so ignoreing this execution!!");
				return null;
			}
			if (IrisAdminConstants.MEDIA_MQ.equals(mediaType))
				outData.put(IrisAdminConstants.MEDIA_DETAIL, messageId);
			else if (IrisAdminConstants.MEDIA_FILE.equals(mediaType) )
				outData.put(IrisAdminConstants.MEDIA_DETAIL, inputFileName);
			else if ( IrisAdminConstants.MEDIA_FILE.equals(mediaType))
			; //do nothing 
			else if (IrisAdminConstants.MEDIA_ISO.equals(mediaType) )
				//do nothing, we will add it to jobData
				;
			else if ( IrisAdminConstants.MEDIA_HTTP_CW.equals(mediaType) || IrisAdminConstants.MEDIA_EVENT_RQ.equals(mediaType) )
				outData.put(IrisAdminConstants.FILTER_PARMS, inputParms.get(IrisAdminConstants.FILTER_PARMS));
			
			if (IrisAdminConstants.MEDIA_EVENT_RQ.equals(mediaType))
			{
				outData.put(IrisAdminConstants.MEDIA_DETAIL,  inputParms.get(IrisAdminConstants.MEDIA_DETAIL));
				sourceData.put(IrisAdminConstants.FILTER_PARMS, inputParms.get(IrisAdminConstants.FILTER_PARMS));
			}
			if (requestJobData != null)
				outData.put(IrisAdminConstants.PARENT_EXECUTION_ID, requestJobData.getExecutionId());
			
			outData.put(IrisAdminConstants.CHANNEL, (String)inputParms.get(IrisAdminConstants.CHANNEL));
			processName = (String) outData.get(IrisAdminConstants.EXECUTE_PROCESS);
			
			executionId = createJob(outData);
			
			if (requestJobData != null )
				jobData = fetchJobData(executionId,requestJobData.isAccumulateErros(),ftpPath);
			else
			{
				jobData = fetchJobData(executionId,isAccumulate,ftpPath);
				if (IrisAdminConstants.MEDIA_MQ.equals(mediaType) || IrisAdminConstants.MEDIA_WEBSERVICE.equals(mediaType) || 
								IrisAdminConstants.MEDIA_HTTP_RESPONSE.equals(mediaType))
				{
					auditHandler = (IAuditHandler) inputParms.get(IrisAdminConstants.AUDIT_SOURCE);
					auditParms = new HashMap<String, Object>();
					auditParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
					auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, inputMsg);
					auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
				}
			}
			
			jobData.setMediumType(mediaType);
			jobData.setMessageData(inputMsg);
			jobData.setDataObject(inputParms.get(IrisAdminConstants.ISO_MESSAGE));
			
			packet = new Packet(null, null);
			simpleProcess = applicationContext.getProcessDefinition().getProcess(processName);
			simpleProcessExecution = new SimpleProcessExecution(simpleProcess);
			processId = getExecutionId(mediaType,jobData.getMapName(), jobData.getExecutionId());
			srcSubType = jobData.getSrcSubType();
			packet.setContext(HelperUtils.createContext());
			
			if ( "IRIS".equals(srcSubType))
			{
				dataObjectParms = new HashMap<String, Object>();
				dataObjectParms.put(IDataObject.MAP_NAME, processName);
				dataObjectParms.put(IDataObject.MEDIA_DETAIL, jobData.getMediaDetails());
				dataObjectParms.put(IDataObject.EXECUTION_ID, jobData.getExecutionId());
				dataObjectParms.put(IDataObject.SCHEDULE_ID, jobData.getRefId());
				
				
				if ( IrisAdminConstants.MEDIA_HTTP_CW.equals(mediaType))
					dataObjectParms.put(IDataObject.HTTP_PARMS, outData.get(IrisAdminConstants.FILTER_PARMS));
				
				else if ( IrisAdminConstants.MEDIA_MQ.equals(mediaType))
				{
					dataObjectParms.put(IDataObject.JMS_MESSAGE, inputMsg);
					dataObjectParms.put(IDataObject.JMS_HEADER_DATA, jmsHeaderData);
					dataObjectParms.put(IDataObject.MEDIA_DETAIL, messageId);
				}
				dataObjectHelper = (IDataObject)inputParms.get(IrisAdminConstants.DATAOBJECT_HELPER);
				inputDo = dataObjectHelper.createDataObject(dataObjectParms);
				packet.setDataObject(inputDo);
			}
			else
				packet.getContext().getExecutionContext().put(IrisAdminConstants.ZEROPROOFING_DATA, new ZeroProofings());
			
			packet.getContext().getExecutionContext().put(ProcessExecution.PROCESS_NAME, processName);
			packet.getContext().getExecutionContext().put(ProcessExecution.PROCESS_EXECUTION_ID, processId);
			packet.getContext().getExecutionContext().put(IrisAdminConstants.EXECUTION_DATA, jobData);
			simpleProcessExecution.setPacket(packet);
			simpleProcessExecution.executeProcess();
			
			if ( "IRIS".equals(srcSubType))
			{
				IrisAdminUtils.finishProcess("C", "Sucess", "Sucess", jobData, null, applicationContext,false);
				jobData.setIrisDataObject(packet.getDataObject());
				jobData.setStatus("C");
			}
		}
		catch ( ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			if ( "IRIS".equals(srcSubType))
			{
				IrisAdminUtils.finishProcess("E", "ERROR", "Execution Error", jobData, null, applicationContext, false);
			}
			
			eExp = new ExecutionException("error.app.unknnown", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			if (simpleProcess != null)
				simpleProcess = null;
			if (simpleProcessExecution != null)
				simpleProcessExecution = null;
			
			CleanUpUtils.doClean(dbProvider, hookConnection);
			CleanUpUtils.doClean(sourceData);
		}
		
		return jobData;
	}
	
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------*
 * 								HELPER METHODS
 *----------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
		
	private OracleType[] getFilterParms(Connection dbConnection, String entityCode, String entityType , String mapName, Map<String, Object> valuesMap) throws LoadingException
	{
		PreparedStatement parmSt = null;
		ResultSet  parmRs = null;
		String parmCode = null;
		String parmDesc = null;
		String value = null;
		LoadingException lExp = null;
		OracleType oracleType = null;
		OracleType[] types = null;
		String[] retVal = null;
		Object obj = null;
		List<OracleType> oracleLst = new ArrayList<OracleType>();
		String parmSql = "select * from iris_int_filter_param t, iris_int_map_mst m where t.parent_record_key_nmbr = m.INTERFACE_RECORD_KEY_NMBR and m.entity_type = ? "
				+ "and m.entity_code = ? and m.map_name = ?";
		try
		{
			parmSt = dbConnection.prepareStatement(parmSql);
			parmSt.setString(1,entityType);
			parmSt.setString(2,entityCode);
			parmSt.setString(3,mapName);
			
			parmRs  = parmSt.executeQuery();
			while ( parmRs.next())
			{
				parmCode = parmRs.getString("PARAMETER_NAME");
				parmDesc = parmRs.getString("PARAMETER_DESC");
				if ( valuesMap.containsKey(parmDesc.trim()))
				{
					obj = valuesMap.get(parmDesc.trim());
					if ( obj instanceof String[] )
					{
						retVal = (String[])obj;
						value = retVal[0];
						
					}
					else
						value = (String)obj;
				}
				else if ( valuesMap.containsKey(parmCode.trim()))
				{
					obj = valuesMap.get(parmCode.trim());
					if ( obj instanceof String[] )
					{
						retVal = (String[])obj;
						value = retVal[0];
						
					}
					else
						value = (String)obj;
				}
				else
					value = null;
				
				if ( value == null)
					value = parmRs.getString("DEFAULT_VALUE");
				
				oracleType = new OracleType(parmCode, value, "RUNTIME");
				oracleLst.add(oracleType);
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.filterpaarm.loading", new Object[] {parmSql, entityCode, mapName},  exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(parmRs);
			HelperUtils.doClose(parmSt);
		}
		
		if (oracleLst.size() > 0)
		{
			int index = 0;
			types = new OracleType[oracleLst.size()];
			for ( OracleType oraType : oracleLst)
			{
				types[index] = oraType;
				index = index + 1;
			}
		}
		else
		{
			types = new OracleType[1];
			oracleType = new OracleType(null, null, null);
			types[0] = oracleType;
		}
		return types;
	}
	
	private  String getExecutionId (String prefix , String interfaceName, String executionId)
	{
		String pidRet = null;
		
		try
		{
			pidRet = prefix + "_" + interfaceName + "_" + executionId;
		}
		finally
		{
		}
		
		if (logger.isInfoEnabled())
			logger.info("Changing thread name [" + Thread.currentThread().getName() + "] to [" + pidRet + "]");
		
		Thread.currentThread().setName(pidRet);
		return pidRet;
	}
	
	
	/**
	 * <p>This helper method gives number of Max threads can be used for an activator. This Method used for Segmentation and Schedule Profile
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param refId
	 * @return
	 * </pre></p>
	 */
	public int getMaxThreads(String refId)
	{
		int maxThreads = 1;
		String sql = "select t.max_threads from iris_schedule_mst t where t.schedule_id=?";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			stmt =  dbConnection.prepareStatement(sql);
			stmt.setString(1, refId);
			rs = stmt.executeQuery();
			if ( rs.next())
				maxThreads = rs.getInt("max_threads");
			
		}
		catch ( Exception e)
		{
			//DO not throw Exception
			logger.error("Errror Wile teching Max THread Count:{}" , e.getMessage(), e);
		}
		finally 
		{
			CleanUpUtils.doClean(rs);
			CleanUpUtils.doClean(stmt);
		}
		
		return maxThreads;
	}
}
