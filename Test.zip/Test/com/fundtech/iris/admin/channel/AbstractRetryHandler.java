/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel
 * FILE   : AbstractRetryHandler.java
 * CREATED: Jun 27, 2015 1:11:31 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.util.Map;

import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AbstractRetryHandler.java,v 1.2 2015/06/29 12:30:21 ramap Exp $
 */
public abstract class AbstractRetryHandler implements IRetryHandler
{
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public AbstractRetryHandler()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IRetryHandler#retry(java.util.Map)
	 */
	@Override
	public final Object retry (Map<String, Object> inputParms)
	{
		int retryStatus = 0;
		
		try
		{
			retryStatus = (Integer) retryAgain(inputParms);
			return retryStatus;
		}
		finally
		{
			if ( retryStatus != IRetryHandler.CONTINUE_RETRY)
			{
				cleanup();
				CleanUpUtils.doClean(inputParms);
			}
		}
			
	}
	
	public abstract Object retryAgain(Map<String, Object> inputParms);
	
}
