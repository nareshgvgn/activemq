/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.jms
 * FILE   : AbstractRequestReceiver.java
 * CREATED: Mar 3, 2015 11:48:58 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AbstractRequestReceiver.java,v 1.5 2015/12/03 06:16:12 ramap Exp $
 */
public abstract class AbstractRequestReceiver implements IRequestReceiver
{
	
	private static Logger logger = LoggerFactory.getLogger(AbstractRequestReceiver.class);
	
	
	private int TIMEOUT = 50000;
	private ConnectionProvider dbProvider = null;
	private Identifier procIdentifier = null;
	private ApplicationContext applicationContext = null;
	private IRetryHandler retryHandler = null;
	private IAuditHandler auditHandler = null;
	private Map<ReferencesEnum, String> references = new HashMap<ReferencesEnum, String>();
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	public ConnectionProvider getDBProvider ()
	{
		String dbResourceName = null;
		try
		{
			dbResourceName = getReferences().get(ReferencesEnum.DB_CONN);
			if (dbProvider == null)
			{
				if (dbResourceName == null)
					dbResourceName = ResourceTypeEnum.IRIS_DATABASE;
				
				dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
			}
		}
		catch (Exception e)
		{
			logger.error("DB Error:", e);
		}
		return dbProvider;
	}
	
	
	public boolean cleanup (Connection dbConnection)
	{
		try
		{
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
		return true;
	}
	
	
	public int getTIMEOUT()
	{
		return TIMEOUT;
	}
	
	public void setTIMEOUT(int tIMEOUT)
	{
		TIMEOUT = tIMEOUT;
	}
	
	
	public Map<ReferencesEnum, String> getReferences ()
	{
		return references;
	}
	
	
	public void setReferences (Map<ReferencesEnum, String> references)
	{
		this.references = references;
	}
	
	
	public Identifier getProcIdentifier ()
	{
		return procIdentifier;
	}
	
	
	public void setProcIdentifier (Identifier procIdentifier)
	{
		this.procIdentifier = procIdentifier;
	}


	/**
	 * @return the applcationContext
	 */
	public ApplicationContext getApplicationContext ()
	{
		return applicationContext;
	}

	/**
	 * @param applcationContext the applcationContext to set
	 */
	public void setApplicationContext (ApplicationContext applicationContext)
	{
		this.applicationContext = applicationContext;
	}
	
	/**
	 * @return the retryHandler
	 */
	public IRetryHandler getRetryHandler ()
	{
		if ( retryHandler == null)
			retryHandler = new IrisAdminSysNoRetryHandler();
		return retryHandler;
	}

	/**
	 * @param retryHandler the retryHandler to set
	 */
	public void setRetryHandler (IRetryHandler retryHandler)
	{
		this.retryHandler = retryHandler;
	}

	/**
	 * @return the aduitHandler
	 */
	public IAuditHandler getAuditHandler ()
	{
		if ( auditHandler == null)
			auditHandler = new IrisAdminSysNoAuditHandler();
		return auditHandler;
	}

	/**
	 * @param aduitHandler the aduitHandler to set
	 */
	public void setAuditHandler (IAuditHandler auditHandler)
	{
		this.auditHandler = auditHandler;
	}
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	public ConnectionProvider getHostDBProvider ()
	{
		String dbResourceName = null;
		ConnectionProvider dbProvider = null;
		try
		{
			dbResourceName = getReferences().get(ReferencesEnum.HOST_DB_CONN);
			dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
		}
		catch (Exception e)
		{
			logger.error("DB Error:", e);
		}
		return dbProvider;
	}
	
	
	public boolean cleanupHostDB (Connection dbConnection, ConnectionProvider dbProvider)
	{
		try
		{
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
			dbProvider = null;
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
		return true;
	}
	
	public Object getBean(String beanName)
	{
		Object returnObject = null;
		try
		{
			returnObject =  ContextManager.getInstance().getBeanObject(beanName);
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
		
		return returnObject;
	}
	
}
