/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.mail
 * FILE   : IrisAdminMailService.java
 * CREATED: Aug 2, 2014 9:27:44 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.mail;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.fundtech.iris.admin.util.StringUtils;


/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisAdminMailService.java,v 1.5 2016/02/08 10:49:37 ramap Exp $
 */
public class IrisAdminMailService
{
	private static Logger logger = LoggerFactory.getLogger(IrisAdminMailService.class);
	private JavaMailSender mailSender = null;
	private String fromAddress = null;
	private String toAddresses = null;
	private String ccAddresses = null;
	private String bccAddresses = null;
	private String subject = null;
	private String messageBody = null;
	
	public void sendMail() throws MessagingException
	{
		List<String> fileList = null;
		
		sendMail(fileList, false);
	}
	
	public void sendMail( String fileName) throws MessagingException
	{
		List<String> fileList = null;;
		
		fileList = new ArrayList<String>();
		fileList.add(fileName);
		sendMail(fileList, false);
	}
	
	public void sendMail(String fileName, boolean isInLine) throws MessagingException
	{
		List<String> fileList = null;;
		
		fileList = new ArrayList<String>();
		fileList.add(fileName);
		sendMail(fileList, isInLine);
	}
	
	public void sendMail(List<String> fileList, boolean isInLine) throws MessagingException
	{
		MimeMessage minmeMessage = null;
		MimeMessageHelper helper = null;
		FileSystemResource res = null;
		InternetAddress[] address = null;
		File file = null;
		
		minmeMessage = mailSender.createMimeMessage();
		helper = new MimeMessageHelper(minmeMessage, true);
		helper.setFrom(fromAddress);
		
		if (!StringUtils.isEmpty(toAddresses))
		{
			address = parseAddress(toAddresses);
			helper.setTo(address);
		}
		if (!StringUtils.isEmpty(ccAddresses))
		{
			address = parseAddress(ccAddresses);
			helper.setCc(address);
		}
		
		if (!StringUtils.isEmpty(bccAddresses))
		{
			address = parseAddress(bccAddresses);
			helper.setBcc(address);
		}
		
		helper.setSubject(subject);
		helper.setText(messageBody);

		if ( fileList != null)
		{
			
			for ( String fileName : fileList)
			{
				file = new File(fileName);
				res = new FileSystemResource(file);
				if ( isInLine)
					helper.addInline(file.getName(), res);
				else
					helper.addAttachment(file.getName(), res);
			}
		}
			
		mailSender.send(minmeMessage);
	}
	

	private InternetAddress[] parseAddress (String addresses) 
	{
		String[] values = addresses.split(",");
		int arrayLength = values.length;
		String addess = null;
		InternetAddress[] internetAddresses = new InternetAddress[arrayLength];
		
		for (int i = 0; i < arrayLength; i++)
		{
			try
			{
				addess = values[i];
				internetAddresses[i] = new InternetAddress(addess);
			}
			catch (AddressException ae)
			{
				logger.error("Not able to convert address:{}", addess, ae);
			}
		}
		return internetAddresses;
	}
	

	/**
	 * @param mailSender the mailSender to set
	 */
	public void setMailSender (JavaMailSender mailSender)
	{
		this.mailSender = mailSender;
	}

	/**
	 * @param fromAddress the fromAddress to set
	 */
	public void setFromAddress (String fromAddress)
	{
		this.fromAddress = fromAddress;
	}

	/**
	 * @param toAddresses the toAddresses to set
	 */
	public void setToAddresses (String toAddresses)
	{
		this.toAddresses = toAddresses;
	}

	/**
	 * @param ccAddresses the ccAddresses to set
	 */
	public void setCcAddresses (String ccAddresses)
	{
		this.ccAddresses = ccAddresses;
	}

	/**
	 * @param bccAddresses the bccAddresses to set
	 */
	public void setBccAddresses (String bccAddresses)
	{
		this.bccAddresses = bccAddresses;
	}

	/**
	 * @return the subject
	 */
	public String getSubject ()
	{
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject (String subject)
	{
		this.subject = subject;
	}

	/**
	 * @return the messageBody
	 */
	public String getMessageBody ()
	{
		return messageBody;
	}

	/**
	 * @param messageBody the messageBody to set
	 */
	public void setMessageBody (String messageBody)
	{
		this.messageBody = messageBody;
	}
	
	
}
