/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel
 * FILE   : IRetryHandler.java
 * CREATED: Jun 25, 2015 9:57:57 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.util.Map;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IRetryHandler.java,v 1.2 2016/02/08 05:36:04 ramap Exp $
 */
public interface IRetryHandler 
{
	public final static int CONTINUE_RETRY = 1;
	public final static int NO_RETRY = 0;
	public final static int STOP_RETRY = -1;
	public final static String ERROR_MESSAGE = "ERROR_MESSAGE";
	public final static String RECEIVED_MESSAGE = "RECEIVED_MESSAGE";
	
	public Object retry(Map<String, Object> inputParms);
	public void cleanup();
}
