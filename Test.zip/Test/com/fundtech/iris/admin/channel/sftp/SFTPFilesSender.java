/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.sftp
 * FILE   : SFTPFilesSender.java
 * CREATED: Feb 1, 2015 3:26:32 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.sftp;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;

import com.fundtech.iris.admin.channel.IFileSender;

/**
 * <p> This helper bean sends the file to remote server and removes the file if requires  
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * 	&lt;bean id="CustReportSFTPSenderFactory"
		class="org.springframework.integration.sftp.session.DefaultSftpSessionFactory"&gt;
		&lt;property name="host" value="${custReport.sftp.sender.Host}"/&gt;
		&lt;property name="port" value="${custReport.sftp.sender.serverPort}"/&gt;
		&lt;property name="user" value="${custReport.sftp.sender.user}"/&gt;
		&lt;property name="password" value="${custReport.sftp.sender.password}"/&gt;
	&lt;/bean&gt;
	
	&lt;bean id="CustReportSFTPCachinngFactory" class="org.springframework.integration.file.remote.session.CachingSessionFactory"&gt;
    	&lt;constructor-arg ref="CustReportSFTPSenderFactory"/&gt;
    	&lt;property name="poolSize" value="10"/&gt;
    	&lt;property name="sessionWaitTimeout" value="1000"/&gt;
	&lt;/bean&gt;
	
	&lt;int:channel id="CustReportSFTPSenderChannel"/&gt;
	&lt;int:channel id="CustReportSFTPRmChannel"/&gt;
	
	&lt;int-sftp:outbound-channel-adapter id="CustReportSFTPOutbound"	channel="CustReportSFTPSenderChannel"  session-factory="CustReportSFTPSenderFactory"
		remote-directory="${custReport.sftp.sender.remote.directory}" /&gt;
		
	&lt;int-sftp:outbound-gateway  session-factory="CustReportSFTPSenderFactory"  request-channel="CustReportSFTPRmChannel"  reply-channel="nullChannel"
        remote-file-separator="/"   command="rm"  expression="headers['file_remoteDirectory'] + '/' +  headers['file_remoteFile']" /&gt;
        
	&lt;bean id="CustReportSFTPSender" class="com.fundtech.iris.admin.channel.sftp.SFTPFilesSender" scope="prototype"&gt;
    	&lt;constructor-arg ref="CustReportSFTPSenderChannel"/&gt;
    	&lt;constructor-arg ref="CustReportSFTPRmChannel"/&gt;
    	&lt;property name="targetDirectory" value="${custReport.sftp.sender.remote.directory}"/&gt;
	&lt;/bean&gt;
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: SFTPFilesSender.java,v 1.3 2016/01/04 12:05:09 ramap Exp $
 */
public class SFTPFilesSender implements IFileSender
{
	private static final Logger logger = LoggerFactory.getLogger(SFTPFilesSender.class);
	private MessageChannel sFTPChannnel = null;
	private MessageChannel removeChannel = null;
	private String targetDirectory = null; 
	
	/**
	 * This constructor accept {@link MessageChannel}.
	 * @param sFTPChannnel -- from this channel, we upload the files in to remote location
	 */
	public SFTPFilesSender(MessageChannel sFTPChannnel)
	{
		this.sFTPChannnel =  sFTPChannnel;
	}
	
	
	/**
	 * This constructor accept 2 {@link MessageChannel}.
	 * @param sFTPChannnel -- from this channel, we upload the files in to remote location
	 * @param removeChannel -- From this channel, we remove the file in remote location
	 */
	public SFTPFilesSender(MessageChannel sFTPChannnel, MessageChannel removeChannel)
	{
		this.sFTPChannnel =  sFTPChannnel;
		this.removeChannel = removeChannel;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IFileSender#sendFiles(java.util.List)
	 */
	@Override
	public Object sendFiles(List<String> fileList)
	{
		File file = null;
		Message<File> message = null;
		
		for ( String strFile : fileList)
		{
			logger.trace("Sending the file:{}", strFile);
			file = new File(strFile);
			message = MessageBuilder.withPayload(file).build();
			sFTPChannnel.send(message);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IFileSender#removeFile(java.util.List)
	 */
	@Override
	public void removeFile (List<String> fileList)
	{
		Message<Boolean> message = null;
		
		for ( String strFile : fileList)
		{
			logger.trace("Removing the file:{}", strFile);
			try
			{
				
				message =MessageBuilder.withPayload(true)
						.setHeader("file_remoteDirectory", targetDirectory)
						.setHeader("file_remoteFile", strFile)
						.build();
				removeChannel.send(message);
			}
			catch ( Exception exp)
			{
				/*
				 * This catch is required as to print in log , otherwise system sees this as exception
				 */
				logger.error("Error Wile deleteing file from Report Server{}" , exp.getMessage(), exp);
			}
		}
	}

	/**
	 * @return the targetDirectory
	 */
	public String getTargetDirectory ()
	{
		return targetDirectory;
	}

	/**
	 * @param targetDirectory the targetDirectory to set
	 */
	public void setTargetDirectory (String targetDirectory)
	{
		this.targetDirectory = targetDirectory;
	}
	
}
