/*
 * (C) CashTech Solutions India Private Limited Use strictly pursuant to license conditions only
 */
package com.fundtech.iris.admin.channel;

import java.util.Map;

import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * Interface to be used to identify process name
 * 
 * @author vijay
 * @version $Id: Identifier.java,v 1.2 2015/09/10 04:13:17 ramap Exp $
 */
public interface Identifier
{
	public static final String JMS_MESSAGE = "JMS_MESSAGE";
	public static final String JMS_HEADER_DATA = "JMS_HEADER_DATA";
	public static final String MEDIA_DETAIL = "MEDIA_DETAIL";
	public static final String MAP_NAME = "MAP_NAME";
	public static final String DB_CONNECTION = "DB_CONNECTION";
	/**
	 * Set the Map of parameters provided in the metadata
	 * 
	 * @param parameters
	 */
	public void setProperties (Map<String, String> properties);
	
	/**
	 * Initializes the process identifier Read the parameters and assign their value to member variables
	 * 
	 * @throws ConfigurationException
	 */
	public void initialize () throws ConfigurationException;
	
	/**
	 * Returns the name of the process
	 * 
	 * @param source
	 *            from which file name need to be generated
	 * @return The object of the identified process, null if unable to resolve the process.
	 * @throws NodeProcessingException
	 */
	public Object identify (Object source) throws ExecutionException;
}