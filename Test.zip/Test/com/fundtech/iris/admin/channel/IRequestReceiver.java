/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.jms
 * FILE   : IRequestReceiver.java
 * CREATED: Mar 3, 2015 11:39:43 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.util.Map;

import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IRequestReceiver.java,v 1.2 2016/01/17 08:59:40 ramap Exp $
 */
public interface IRequestReceiver
{
	
	public abstract void sendMessage (Map<String, Object> inputParms) throws ExecutionException;
	
	/**
	 * @return the tIMEOUT
	 */
	public abstract int getTIMEOUT ();
	
	/**
	 * @param tIMEOUT the tIMEOUT to set
	 */
	public abstract void setTIMEOUT (int tIMEOUT);
	
	/**
	 * @return the references
	 */
	public abstract Map<ReferencesEnum, String> getReferences ();
	
	/**
	 * @param references
	 *            the references to set
	 */
	public abstract void setReferences (Map<ReferencesEnum, String> references);
	
	/**
	 * @return the procIdentifier
	 */
	public abstract Identifier getProcIdentifier ();
	
	/**
	 * @param procIdentifier the procIdentifier to set
	 */
	public abstract void setProcIdentifier (Identifier procIdentifier);
	
	/**
	 * @return the retryHandler
	 */
	public IRetryHandler getRetryHandler ();
	

	/**
	 * @param retryHandler the retryHandler to set
	 */
	public void setRetryHandler (IRetryHandler retryHandler);
	

	/**
	 * @return the aduitHandler
	 */
	public IAuditHandler getAuditHandler ();

	/**
	 * @param aduitHandler the aduitHandler to set
	 */
	public void setAuditHandler (IAuditHandler auditHandler);
	
}