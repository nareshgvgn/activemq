/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.spring
 * FILE   : AbstractActivator.java
 * CREATED: Apr 25, 2014 1:01:00 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue ;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.cashtech.iris.core.processor.resource.Resource;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.util.IRISLogger;
import com.dh.iris.admin.channels.iris.IDataObject;
import com.fundtech.iris.admin.exceptions.LoadingException;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: AbstractActivator.java,v 1.15 2015/12/01 07:22:30 ramap Exp $
 */
public abstract class AbstractActivator implements ApplicationContextAware, InitializingBean, DisposableBean
{
	private Identifier procIdentifier = null;
	private ApplicationContext applicationContext;
	private String executeProcess = null;
	private String rmExecuteProcess = null;
	private Map<ReferencesEnum, String> references = new HashMap<ReferencesEnum, String>();
	private boolean accumulateErrors = true;
	private Map<String, String> staticProperties = new HashMap<String, String>();
	private int poolingSleepInSecs = 10;
	private int reattemptSleepInSecs = 10;
	private int processId = -1;
	private IAuditHandler auditHandler = null;
	private int maxPoolSize = 10;
	private int minPoolSize = 1;
	private int maxQueueSize = 1;
	private long poolKeepAliveTime = 300000L;
	private IDataObject dataObjectHelper = null;
	private boolean noThreadCache = true;
	private String initJobStatusTo = "E";
	private String ftpPath = null;
	private String ftpProperty = null;
	private Resource dbResource = null;
	
	/**
	 * ThreadPool of Request Executions - used for concurrency
	 */
	protected ThreadPoolExecutor activatorPool;
	private Logger logger = LoggerFactory.getLogger(AbstractActivator.class);
	
	/**
	 * @return the procIdentifier
	 */
	public Identifier getProcIdentifier ()
	{
		return procIdentifier;
	}
	
	/**
	 * @param procIdentifier
	 *            the procIdentifier to set
	 */
	public void setProcIdentifier (Identifier procIdentifier)
	{
		this.procIdentifier = procIdentifier;
	}
	
	/**
	 * @return the applicationContext
	 */
	public com.cashtech.iris.contexts.ApplicationContext getApplicationContext ()
	{
		return (com.cashtech.iris.contexts.ApplicationContext) applicationContext.getBean("ApplicationContext");
	}
	
	public Object getBean(String key)
	{
		return this.applicationContext.getBean(key);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	@Override
	public void setApplicationContext (ApplicationContext applicationContext) throws BeansException
	{
		this.applicationContext = applicationContext;
	}
	
	/**
	 * @return the executeProcess
	 */
	public String getExecuteProcess ()
	{
		return executeProcess;
	}
	
	/**
	 * @param executeProcess
	 *            the executeProcess to set
	 */
	public void setExecuteProcess (String executeProcess)
	{
		this.executeProcess = executeProcess;
	}
	
	/**
	 * @return the references
	 */
	public Map<ReferencesEnum, String> getReferences ()
	{
		return references;
	}
	
	/**
	 * @param references
	 *            the references to set
	 */
	public void setReferences (Map<ReferencesEnum, String> references)
	{
		this.references = references;
	}
	
	
	/**
	 * @return the accumulateErrors
	 */
	public boolean isAccumulateErrors ()
	{
		return accumulateErrors;
	}
	
	/**
	 * @param accumulateErrors
	 *            the accumulateErrors to set
	 */
	public void setAccumulateErrors (boolean accumulateErrors)
	{
		this.accumulateErrors = accumulateErrors;
	}
	
	/**
	 * @return the staticProperties
	 */
	public Map<String, String> getStaticProperties ()
	{
		return staticProperties;
	}
	
	/**
	 * @param staticProperties
	 *            the staticProperties to set
	 */
	public void setStaticProperties (Map<String, String> staticProperties)
	{
		this.staticProperties = staticProperties;
	}
	
	/**
	 * @return the poolingSleepInSecs
	 */
	public int getPoolingSleepInSecs ()
	{
		return poolingSleepInSecs;
	}
	
	/**
	 * @param poolingSleepInSecs
	 *            the poolingSleepInSecs to set
	 */
	public void setPoolingSleepInSecs (int sleepinSecs)
	{
		this.poolingSleepInSecs = sleepinSecs;
	}
	
	/**
	 * A helper method to gracefully shutdown the thread pool
	 * 
	 * @param tpExecutor  The thread pool to be shutdown
	 */
	protected void clearThreadPool ()
	{
		if (null == activatorPool)
			return;
		try
		{
			activatorPool.shutdown();
			activatorPool.awaitTermination(60000, TimeUnit.MILLISECONDS);
		}
		catch (InterruptedException intEx)
		{
			logger.error("", intEx);
		}
	}
	
	
	/**
	 * Initialize a thread pool for activator. This is required in case of HTTP or Socket Listeners The behaviour of the Activator Pool can be
	 * controlled with the attributues such as,
	 * 
	 * <PRE>
	 * minPoolSize		- Minumum threads waiting to service requests.
	 * maxPoolSize		- Maximum thread that will service requests.
	 * poolKeepAliveTime	- the number of milliseconds to keep threads alive waiting for
	 * 			  new commands. A negative value means to wait forever.
	 * 			  A zero value means not to wait at all.
	 * maxQueueSize		- If currently all Threads in the pool are busy then new requests
	 * 			  will be queued up to <i>maxQueueSize</i>.queuing can be useful in
	 * 			  smoothing out transient bursts of requests, especially in such
	 * 			  socket-based services, it is not very well behaved when commands continue
	 * 			  to arrive on average faster than they can be processed.
	 * </PRE>
	 * 
	 * @throws ConfigurationException
	 *             in case any problem occures initializing Activator Pool
	 */
	public void initializeActivatorPool () throws LoadingException
	{
		BlockingQueue<Runnable> workQueue = null;
		LoadingException lExp  = null;
		
		try
		{
			if(noThreadCache)
				workQueue = new SynchronousQueue<Runnable>();
			else
				workQueue = new ArrayBlockingQueue<Runnable>(maxQueueSize, true);
			
			this.activatorPool = new ThreadPoolExecutor(minPoolSize, maxPoolSize, poolKeepAliveTime, TimeUnit.MILLISECONDS, workQueue);
			workQueue = null;
		}
		catch (Exception e)
		{
			lExp = new LoadingException("error.iris.admin.evennt.propertynotconfigured", new Object[]{ "processId" }, e);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
	}
	
	public int getCurrentPoolSize()
	{
		return activatorPool.getActiveCount();
	}
	
	public void addThreadInThreadPool (Runnable runnable, int sleepInsec) throws InterruptedException
	{
		boolean accepted = false;
		long sleepinMillis = sleepInsec * 100L;
		int count = 1;
		int returnVal = 1;
		
		while (!accepted)
		{
			try
			{
				this.activatorPool.execute(runnable);
				logger.trace("Thread accepted by Thread Pool Executor for execution. "
						+ " It does not mean that thread pool will start thread immediately." + " It can be queued.");
				accepted = true;
			}
			catch (RejectedExecutionException re)
			{
				if ( (count % 30) < 1  )
					returnVal = 1;
				if (returnVal == 1 )
				{
					
					logger.trace("Error:", re);
					logger.warn("No more threads availabe in Activator Pool for processing, wait till previous files get processed OR configure Activator Pool accordingly!. "
							+ "Sleeping for {} seconds for next attempt.", sleepInsec);
				}
				Thread.sleep(sleepinMillis);
				accepted = false;
				count = count + 1;
			}
			if ( returnVal == 1)
				logger.info("Approximate number of threads running currently for this activator : " + this.activatorPool.getActiveCount());
			returnVal = 0;
		}
	}
	
	/**
	 * @return the reattemptSleepInSecs
	 */
	public int getReattemptSleepInSecs ()
	{
		return reattemptSleepInSecs;
	}
	
	/**
	 * @param reattemptSleepInSecs
	 *            the reattemptSleepInSecs to set
	 */
	public void setReattemptSleepInSecs (int reattemptSleepInSecs)
	{
		this.reattemptSleepInSecs = reattemptSleepInSecs;
	}
	
	/**
	 * @return the processId
	 */
	public int getProcessId ()
	{
		return processId;
	}
	
	/**
	 * @param processId
	 *            the processId to set
	 */
	public void setProcessId (int processId)
	{
		this.processId = processId;
	}
	
	@Override
	public void afterPropertiesSet ()
	{
		LoadingException lExp = null;
		try
		{
			if (-1 == getProcessId())
			{
				logger.error("Process Code not configured!!");
				lExp = new LoadingException("error.iris.admin.evennt.propertynotconfigured", new Object[]{ "processId" }, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
			
			if (getExecuteProcess() == null)
			{
				logger.error("Process Code not configured!!");
				lExp = new LoadingException("error.iris.admin.evennt.propertynotconfigured", new Object[]{ "executeProcess" }, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
			
			initializeActivatorPool();
		}
		catch (Exception exp)
		{
			throw new IllegalStateException(exp);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.beans.factory.DisposableBean#destroy()
	 */
	@Override
	public void destroy () throws Exception
	{
		
	}

	/**
	 * @return the aduitHandler
	 */
	public IAuditHandler getAuditHandler ()
	{
		if ( auditHandler == null)
			auditHandler = new IrisAdminSysNoAuditHandler();
		return auditHandler;
	}

	/**
	 * @param auditHandler the auditHandler to set
	 */
	public void setAuditHandler (IAuditHandler auditHandler)
	{
		this.auditHandler = auditHandler;
	}

	/**
	 * @param maxPoolSize the maxPoolSize to set
	 */
	public void setMaxPoolSize (int maxPoolSize)
	{
		this.maxPoolSize = maxPoolSize;
	}

	/**
	 * @param minPoolSize the minPoolSize to set
	 */
	public void setMinPoolSize (int minPoolSize)
	{
		this.minPoolSize = minPoolSize;
	}

	/**
	 * @param maxQueueSize the maxQueueSize to set
	 */
	public void setMaxQueueSize (int maxQueueSize)
	{
		this.maxQueueSize = maxQueueSize;
	}

	/**
	 * @param poolKeepAliveTime the poolKeepAliveTime to set
	 */
	public void setPoolKeepAliveTime (long poolKeepAliveTime)
	{
		this.poolKeepAliveTime = poolKeepAliveTime;
	}

	/**
	 * @return the dataObjectHelper
	 */
	public IDataObject getDataObjectHelper ()
	{
		return dataObjectHelper;
	}

	/**
	 * @param dataObjectHelper the dataObjectHelper to set
	 */
	public void setDataObjectHelper (IDataObject dataObjectHelper)
	{
		this.dataObjectHelper = dataObjectHelper;
	}

	/**
	 * @param noThreadCache the noThreadCache to set
	 */
	public void setNoThreadCache (boolean noThreadCache)
	{
		this.noThreadCache = noThreadCache;
	}
	
	/**
	 * @param initJobStatusTo the initJobStatusTo to set
	 */
	public void setInitJobStatusTo (String initJobStatusTo)
	{
		this.initJobStatusTo = initJobStatusTo;
	}


	/**
	 * @param ftpProperty the ftpProperty to set
	 */
	public void setFtpProperty (String ftpProperty)
	{
		this.ftpProperty = ftpProperty;
	}

	/**
	 * @return the ftpPath
	 */
	public String getFtpPath ()
	{
		return ftpPath;
	}

	/**
	 * @param ftpPath the ftpPath to set
	 */
	public void setFtpPath (String ftpPath)
	{
		this.ftpPath = ftpPath;
	}

	/**
	 * @return the initJobStatusTo
	 */
	public String getInitJobStatusTo ()
	{
		return initJobStatusTo;
	}

	/**
	 * @return the ftpProperty
	 */
	public String getFtpProperty ()
	{
		return ftpProperty;
	}
	
	/**
	 * @return the dbResource
	 */
	private void  fetchDbResource (String resourceId) throws LoadingException
	{
		LoadingException lExp = null;
		
		try
		{
			if ( dbResource == null)
				dbResource = getApplicationContext().getProcessDefinition().getResource(resourceId);
		}
		catch (ConfigurationException exp)
		{
			lExp = new LoadingException("error.admin.dbResourceId", new Object[]{ "FTP path not found", resourceId}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch ( Exception exp)
		{
			lExp = new LoadingException("error.admin.dbResourceId", new Object[]{ "FTP path not found", resourceId}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
	}
	
	public Resource getDBResource(String resourceId) throws LoadingException
	{
		if ( dbResource == null)
			 fetchDbResource(resourceId);
		return dbResource;
	}

	/**
	 * @return the rmExecuteProcess
	 */
	public String getRmExecuteProcess ()
	{
		return rmExecuteProcess;
	}

	/**
	 * @param rmExecuteProcess the rmExecuteProcess to set
	 */
	public void setRmExecuteProcess (String rmExecuteProcess)
	{
		this.rmExecuteProcess = rmExecuteProcess;
	}
}
