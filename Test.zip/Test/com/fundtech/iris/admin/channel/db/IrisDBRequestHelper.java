/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.db
 * FILE   : IrisDBRequestHelper.java
 * CREATED: Aug 6, 2015 9:54:20 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.channel.AbstractRequestReceiver;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisDBRequestHelper.java,v 1.5 2016/01/20 18:52:01 ramap Exp $
 */
public class IrisDBRequestHelper extends AbstractRequestReceiver
{
	private static Logger logger =  LoggerFactory.getLogger(IrisDBRequestHelper.class);
	private long batchSize = 10000;
	private long  batchCount = 0;
	private Map<String, PreparedStatement> pstMtMap = new LinkedHashMap<String, PreparedStatement>();
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisDBRequestHelper()
	{
		// BABU Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IRequestReceiver#sendMessage(java.util.Map)
	 */
	@Override
	public void sendMessage (Map<String, Object> inputParms) throws ExecutionException
	{
		ConnectionProvider dbProvider = null;
		Connection dbConnection = null;
		ExecutionException eExp = null;
		StringBuilder dmlBuilder = null;
		StringBuilder colsBuilder = null;
		StringBuilder valuesBuilder = null;
		String errorMsg = null;
		IrisAdminError error = null;
		Map<String, Object> auditParms = null;
		ExecutionJobData jobData = null;
		IrisError irisError = null;
		
		try
		{
			dbProvider = getHostDBProvider();
			dbConnection = dbProvider.getConnection();
			jobData = (ExecutionJobData) inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			fillPreParesStmts(inputParms, dbConnection);
			clearBatch(jobData);
			dbOperation(dbConnection, "commit");
		}
		catch ( ExecutionException exp)
		{
			dbOperation(dbConnection, "rollBack");
			jobData.setStatus("E");
			throw exp;
		}
		catch ( Exception exp)
		{
			dbOperation(dbConnection, "rollBack");
			jobData.setStatus("E");
			errorMsg = "Not able to process-" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.dbtodbintegration", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError("999", errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			clearPrepareStmts();
			CleanUpUtils.doClean(auditParms);
			cleanupHostDB(dbConnection, dbProvider);
			CleanUpUtils.doClean(inputParms);
			CleanUpUtils.doClean(dmlBuilder);
			CleanUpUtils.doClean(colsBuilder);
			CleanUpUtils.doClean(valuesBuilder);
		}
	}
	
	
	/**
	 * @param batchSize the batchSize to set
	 */
	public void setBatchSize (long batchSize)
	{
		this.batchSize = batchSize;
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param action
	 * </pre></p>
	 */
	private void dbOperation ( Connection dbConnection, String action) 
	{
		try
		{
			if ( dbConnection == null)
				return;
			
			if ("commit".equals(action))
					dbConnection.commit();
			else
				dbConnection.rollback();
		}
		catch ( Exception exp)
		{
			logger.error("Error While executing action{}  error is {}", action, exp.getMessage(), exp);
		}
	}
	
	
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param inputParms
	 * @param dbConnection
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private void fillPreParesStmts (Map<String, Object> inputParms, Connection dbConnection) throws ExecutionException
	{
		InterfaceBandDef childDef = null;
		String bandName = null;
		String fldVal = null;
		ExecutionException eExp = null;
		List<MappingField> listFields = null;
		DataField dataField = null;
		Map<String, DataField> fieldsList = null;
		
		String errorMsg = null;
		IrisAdminError error = null;
		ExecutionJobData jobData = null;
		RootBand rootBand = null;
		Map<String, InterfaceBandDef> pBandDefs = null;
		String tableName = null;
		IrisError irisError = null;
		PreparedStatement bandStmt = null;
		int indexCount = 1;
		
		try
		{
			
			jobData = (ExecutionJobData) inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			rootBand = (RootBand) inputParms.get(IrisAdminConstants.DATA_ROOT_BAND);
			pBandDefs = jobData.getInterfaceDef().getBandsDefinition().getBandDefinitions();
			fillPreParesStmts(jobData, pBandDefs, rootBand.getBatches(), dbConnection);
			
//			for (BatchBand batchBand : rootBand.getBatches())
//			{
//				for ( Band band : batchBand.getBatchBands())
//				{
//					indexCount = 1;
//					bandName = band.getName();
//					childDef = pBandDefs.get(bandName);
//					listFields  = childDef.getMappingFields();
//					fieldsList = band.getFieldRow();
//					tableName = childDef.getRelativeXPath();
//					if (pstMtMap.containsKey(tableName) )
//						bandStmt = pstMtMap.get(tableName);
//					else
//					{
//						bandStmt = createPreparedStmts(tableName, listFields, dbConnection, jobData);
//						pstMtMap.put(tableName, bandStmt);
//					}
//					for (MappingField field : listFields)
//					{
//						if (IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType())
//						{
//							if (logger.isTraceEnabled())
//								logger.trace("BandName:{}, FieldName:{} ", childDef.getBandName(), field.getFieldName());
//							
//							dataField = fieldsList.get(field.getFieldName());
//							fldVal = dataField.getValue();
//							if (null == field.getAbsoluteXPath1())
//								continue;
//							
//							bandStmt.setString(indexCount, fldVal);
//							indexCount ++;
//						}
//					}
//					bandStmt.addBatch();
//					incrementBatch(jobData);
//				}
//			}
		}
		catch ( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Not able to process-" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.fillingpreparedstmt", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError("999", errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(inputParms);
		}
	}
	
	private void fillPreParesStmts (ExecutionJobData jobData, Map<String, InterfaceBandDef> pBandDefs, List<BatchBand> batchBands, Connection dbConnection) 
																														throws ExecutionException
	{
		InterfaceBandDef childDef = null;
		String bandName = null;
		String fldVal = null;
		ExecutionException eExp = null;
		List<MappingField> listFields = null;
		DataField dataField = null;
		Map<String, DataField> fieldsList = null;
		List<BatchBand> childBatchBands = null;
		String errorMsg = null;
		IrisAdminError error = null;
		RootBand rootBand = null;
		String tableName = null;
		IrisError irisError = null;
		PreparedStatement bandStmt = null;
		int indexCount = 1;
		
		try
		{
			
			for (BatchBand batchBand : batchBands)
			{
				for ( Band band : batchBand.getBatchBands())
				{
					indexCount = 1;
					bandName = band.getName();
					childDef = pBandDefs.get(bandName);
					listFields  = childDef.getMappingFields();
					fieldsList = band.getFieldRow();
					tableName = childDef.getRelativeXPath();
					if (pstMtMap.containsKey(tableName) )
						bandStmt = pstMtMap.get(tableName);
					else
					{
						bandStmt = createPreparedStmts(tableName, listFields, dbConnection, jobData);
						pstMtMap.put(tableName, bandStmt);
					}
					for (MappingField field : listFields)
					{
						if (IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType())
						{
							if (logger.isTraceEnabled())
								logger.trace("BandName:{}, FieldName:{} ", childDef.getBandName(), field.getFieldName());
							
							dataField = fieldsList.get(field.getFieldName());
							fldVal = dataField.getValue();
							if (null == field.getAbsoluteXPath1())
								continue;
							
							bandStmt.setString(indexCount, fldVal);
							indexCount ++;
						}
					}
					bandStmt.addBatch();
					incrementBatch(jobData);
					childBatchBands  = band.getChildBatches();
					if ( childBatchBands.size() > 0)
					{
						fillPreParesStmts(jobData, childDef.getChildDefinitions().getBandDefinitions(), childBatchBands, dbConnection);
					}
				}
			}
		}
		catch ( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Not able to process-" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.fillingpreparedstmt", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError("999", errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
		}
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param tableName
	 * @param listFields
	 * @param dbConnection
	 * @param jobData
	 * @return
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private PreparedStatement createPreparedStmts (String tableName, List<MappingField> listFields, Connection dbConnection, ExecutionJobData  jobData) throws ExecutionException
	{
		ExecutionException eExp = null;
		StringBuilder dmlBuilder = null;
		StringBuilder colsBuilder = null;
		StringBuilder valuesBuilder = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		PreparedStatement bandStmt = null;
		String finalSql = null;
		boolean isFirst = true;
		
		try
		{
			dmlBuilder = new StringBuilder();
			colsBuilder = new StringBuilder();
			valuesBuilder = new StringBuilder();
			valuesBuilder.append(" VALUES (");
			dmlBuilder.append("INSERT INTO ");
			dmlBuilder.append(tableName);
			dmlBuilder.append(" (");
			
			for (MappingField field : listFields)
			{
				if (IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType())
				{
					if (null == field.getAbsoluteXPath1())
					{
						continue;
					}
					
					if ( !isFirst)
					{
						colsBuilder.append(",");
						valuesBuilder.append(",");
					}
					colsBuilder.append(field.getAbsoluteXPath1());
					valuesBuilder.append("?");
					isFirst = false;
				}
			}
			
			colsBuilder.append(")");
			valuesBuilder.append(")");
			dmlBuilder.append(colsBuilder.toString());
			dmlBuilder.append(valuesBuilder.toString());
			finalSql = dmlBuilder.toString();
			CleanUpUtils.doClean(colsBuilder);
			CleanUpUtils.doClean(valuesBuilder);
			bandStmt = dbConnection.prepareStatement(finalSql);
			logger.debug("Statement Created {}" , finalSql);
			return bandStmt;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Not able to process-" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.dbtodbPreparedstmt", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError("999", errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(dmlBuilder);
			CleanUpUtils.doClean(colsBuilder);
			CleanUpUtils.doClean(valuesBuilder);
		}
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private void incrementBatch(ExecutionJobData jobData) throws ExecutionException
	{
		batchCount++;
		if ( batchCount == batchSize)
			clearBatch(jobData);
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private void clearBatch(ExecutionJobData jobData) throws ExecutionException
	{
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		PreparedStatement pstmt = null;
		String tableName = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		int[] updateCount = null;
		
		
		try
		{
			if ( batchCount > 0 )
			{
				for (Map.Entry<String, PreparedStatement> entry : pstMtMap.entrySet())
				{
					startTime = System.currentTimeMillis();
					tableName = entry.getKey();
					pstmt = entry.getValue();
					updateCount = pstmt.executeBatch();
					pstmt.clearBatch();
					endTime = System.currentTimeMillis();
					delta = (endTime - startTime) / 1000.00;
					logger.debug("For tale:{} number of inserts are:{} and taken time {} sec", tableName, updateCount.length, delta);
				}
			}
		}
		catch (SQLException exp)
		{
			jobData.setStatus("E");
			errorMsg = "Error while executing batch SQLs";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Error while executing batch SQLs";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			batchCount = 0;
		}
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param stmtMap2
	 * </pre></p>
	 */
	private void clearPrepareStmts ()
	{
		
		for (Map.Entry<String, PreparedStatement> entry : pstMtMap.entrySet())
		{
			CleanUpUtils.doClean(entry.getValue());
		}
		pstMtMap = null;
	}
	
}
