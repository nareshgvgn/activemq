/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator
 * FILE   : IrisAdminEventActivator.java
 * CREATED: Jul 5, 2014 12:40:17 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.activator.session.EventSession;
import com.fundtech.iris.admin.channel.AbstractActivator;
import com.fundtech.iris.admin.channel.ReferencesEnum;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IrisAdminEventActivator.java,v 1.11 2016/10/27 09:01:16 ramap Exp $
 */
public class IrisAdminEventActivator extends AbstractActivator implements Runnable
{
	
	private static final Logger logger = LoggerFactory.getLogger(IrisAdminEventActivator.class);
	private String id = "Event";
	private ConnectionProvider dbProvider = null;
	private Connection dbConnection = null;
	private PreparedStatement jobStmt = null;
	private PreparedStatement updateStmt = null;
	private EventActivatorHelper eventHelper = null;
	private int poolingInMilliSecs = 0;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run ()
	{
		int intCount = 0;
		try
		{
			poolingInMilliSecs = getPoolingSleepInSecs() * 100;
			eventHelper = EventActivatorHelper.getInstance();
			dbConnection = getDBConnection();
			
			if (dbConnection != null)
				initialiseStmts();
			
			while (true)
			{
				
				if (!isConnectionAlive())
				{
					
					if (makeReconnection(intCount))
						intCount = 0;
					else
						intCount = 1;
				}
				else
				{
					executeProcess();
				}
				Thread.sleep(poolingInMilliSecs);
			}
		}
		catch (Exception se)
		{
			logger.error("Error:",se);
			throw new RuntimeException("Activator [" + id + "] terminating!");
		}
		finally
		{
		}
		
	}
	
	
	public void start ()
	{
		Thread myThread = null;
		
		myThread = new Thread(this, id);
		myThread.start();
	}
	
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------*
 * HELPER METHODS
 *----------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * This helper method picks the SQL from IL_INTERFACE_MST, and binds it to this instance of activator
	 * 
	 * @throws ConfigurationException
	 * @throws SQLException
	 */
	private void initialiseStmts () throws ConfigurationException, SQLException, LoadingException
	{
		ConfigurationException confiEx = null;
		PreparedStatement psSelect = null;
		String interfaceType = null;
		ResultSet rsSelect = null;
		String strPickupSql = null;
		String updateSql = null;
		String selectQuery = "SELECT PICKUP_SQL, INTERFACE_TYPE, INSERT_SQL1 FROM IL_INTERFACE_MST WHERE TXNCODE = ?";
		try
		{
			psSelect = dbConnection.prepareStatement(selectQuery);
			psSelect.clearParameters();
			psSelect.setInt(1, getProcessId());
			rsSelect = psSelect.executeQuery();
			if (rsSelect.next())
			{
				strPickupSql = rsSelect.getString("PICKUP_SQL");
				interfaceType = rsSelect.getString("INTERFACE_TYPE");
				updateSql = rsSelect.getString("INSERT_SQL1");
				logger.info("Pickup SQL: {}" , strPickupSql);
				logger.info("Type of(U/D/R) interfaces executing: {}" , interfaceType);
			}
			else
			{
				// Need to throw an error as activator can not be configured without PICKSQL
				confiEx = IRISLogger.getConfigEx("error.admin.configuration", new Object[]{ getProcessId(), selectQuery }, null);
				logger.error(IRISLogger.getText(confiEx));
				throw confiEx;
			}
			// initializeOldJobs(updateSql, interfaceType);
			jobStmt = dbConnection.prepareStatement(strPickupSql);
			updateStmt = dbConnection.prepareStatement(updateSql);
			eventHelper.initilize(dbConnection);
		}
		catch (SQLException e)
		{
			throw e;
		}
		catch ( LoadingException exp)
		{
			throw exp;
		}
		finally
		{
			HelperUtils.doClose(rsSelect);
			HelperUtils.doClose(psSelect);
		}
	}
	
	private void executeProcess ()
	{
		ResultSet jobRs = null;
		EventProcessJob eventProcessJob = null;
		EventSession session = null;
		
		try
		{
			jobRs = jobStmt.executeQuery();
			while (jobRs.next())
			{
				eventProcessJob = eventHelper.getEventJob(jobRs, dbConnection, getProcessId());
				updateJob(eventProcessJob.getJournalNmbr());
				session = new EventSession(getExecuteProcess(), eventProcessJob);
				session.setApplicationContext(getApplicationContext());
				addThreadInThreadPool(session, getReattemptSleepInSecs());
				dbConnection.commit();
			}
		}
		catch (Exception e)
		{
			logger.error("Error:",e);
			
			logger.error("Error occurred in runProcess...");
			rollback();
		}
	}
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	private Connection getDBConnection ()
	{
		String dbResourceName = null;
		try
		{
			dbResourceName = (String) getReferences().get(ReferencesEnum.DB_CONN);
			if (dbProvider == null)
			{
				if (dbResourceName != null)
					dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
				else
					dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN,
							ResourceTypeEnum.IRIS_DATABASE);
			}
			dbConnection = dbProvider.getConnection();
		}
		catch (Exception e)
		{
			logger.error("DB Error:", e);
			dbConnection = null;
		}
		return dbConnection;
	}
	
	/**
	 * This method checks connection alive or not
	 * 
	 * @param connection
	 * @return boolean
	 */
	private boolean isConnectionAlive ()
	{
		try
		{
			dbConnection.setAutoCommit(true);
			dbConnection.setAutoCommit(false);
		}// try
		catch (Exception e)
		{
			logger.error("Error:",e);
			cleanup();
			return false;
		}// catch
		return true;
	}
	
	/**
	 * <p>
	 * This Helper method cleans up the connection by releasing to pool
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void cleanup ()
	{
		try
		{
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
			dbProvider = null;
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
	}
	
	/**
	 * This helper method re creates the connection and should not throw any exception
	 * 
	 * @param boolean
	 * @return
	 */
	private boolean makeReconnection (int intCount)
	{
		try
		{
			if (intCount == 0)
				logger.warn("DATABASE CONNECTION LOST... " + "SO TRYING TO FETCH CONNECTION AGAIN");
			
			dbConnection = getDBConnection();
			if (dbConnection == null)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				Thread.sleep(getPoolingSleepInSecs() * 100);
			}
			else
			{
				jobStmt = null;
				updateStmt = null;
				initialiseStmts();
				return true;
			}
		}
		catch (InterruptedException e)
		{
			logger.error("Error:" + e.getMessage());
		}
		catch (SQLException e)
		{
			logger.error("SQLEXCEPTION : ", e);
		}
		catch (Exception e)
		{
			logger.error("Error:" + e.getMessage(), e);
		}
		
		return false;
	}
	
	/**
	 * @return the name
	 */
	public String getId ()
	{
		return id;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setId (String id)
	{
		this.id = id;
	}
	
	
	public boolean updateJob (String jrnlNbr) throws SQLException
	{
		int updateCount = 0;
		
		updateStmt.setString(1, jrnlNbr);
		updateCount = updateStmt.executeUpdate();
		
		if (logger.isDebugEnabled())
			logger.debug("Updated event jobs table with count:" + updateCount);
		return true;
	}
	
	private void rollback ()
	{
		try
		{
			dbConnection.rollback();
		}
		catch (Exception e)
		{
			logger.error("Error:",e);
			// Ignore this exception
		}
	}
}
