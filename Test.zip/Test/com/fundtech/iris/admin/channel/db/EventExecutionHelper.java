/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.db
 * FILE   : EventExecutionHelper.java
 * CREATED: Oct 13, 2014 3:34:06 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.core.processor.resource.Resource;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.EventExecutionJob;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EventExecutionHelper.java,v 1.7 2016/10/27 09:01:16 ramap Exp $
 */
public class EventExecutionHelper
{
	private static EventExecutionHelper helper = null;
	private Logger logger = LoggerFactory.getLogger(EventExecutionHelper.class);
	
	private EventExecutionHelper()
	{
	}
	
	public static EventExecutionHelper getInstance ()
	{
		if (helper == null)
			helper = new EventExecutionHelper();
		
		return helper;
	}
	
	public EventExecutionJob getEventJob (ResultSet rsSelectJobs, Resource dbResource, int eventType, Connection dbConnection) throws LoadingException
	{
		EventExecutionJob eventJob = null;
		LoadingException lExp =  null;
		
		try
		{
			eventJob = new EventExecutionJob();
			
			eventJob.setNotificationId(rsSelectJobs.getString("NOTOFICATION_ID"));
			eventJob.setJournalNmbr(rsSelectJobs.getString("EVENT_JOURNAL_NMBR"));
			eventJob.setEventName(rsSelectJobs.getString("EVENT_NAME"));
			eventJob.setEventSource(rsSelectJobs.getString("EVENT_SOURCE"));
			eventJob.setRecipientName(rsSelectJobs.getString("RECIPIENT_NAME"));
			eventJob.setEntityCode(rsSelectJobs.getString("ENTITY_CODE"));	
			eventJob.setClientCode(rsSelectJobs.getString("CLIENT_CODE"));
			eventJob.setStatus(rsSelectJobs.getString("STATUS"));
			eventJob.setTxnCode(eventType);
			
			if ( 1207 == eventType || 1209 == eventType || 1210 == eventType) //email or attachment
			{
				eventJob.setToEmailId(rsSelectJobs.getString("TO_EMAIL_ID"));
				eventJob.setBccMailId(rsSelectJobs.getString("BCC_EMAIL_ID"));
				eventJob.setCcMailId(rsSelectJobs.getString("CC_EMAIL_ID"));
				eventJob.setFromMailId(rsSelectJobs.getString("FROM_MAIL_ID"));
			}
			else if ( 1208 == eventType) // SMS
			{
				eventJob.setSmsMessage(rsSelectJobs.getString("SMS_MESSAGE"));
				eventJob.setSenderNumber(rsSelectJobs.getString("SENDER_NMBR"));
				eventJob.setRecipientNumber(rsSelectJobs.getString("RECIPIENT_NMBR"));
			}
			
			
			if( 1207 == eventType) //email
			{
				eventJob.setEmailMessage(rsSelectJobs.getString("EMAIL_MESSAGE"));
				eventJob.setEmailSubject(rsSelectJobs.getString("EMAIL_SUBJECT"));
			}
			else if ( 1209 == eventType) //attachment
			{
				eventJob.setEmailMessage(rsSelectJobs.getString("ATTACHMENT_MESSAGE"));
				eventJob.setEmailSubject(rsSelectJobs.getString("ATTACHMENT_SUBJECT"));
				eventJob.setReportCode(rsSelectJobs.getString("REPORT_CODE"));
				eventJob.setReportLanguage(rsSelectJobs.getString("REPORT_LANGUAGE"));
				eventJob.setParamString(rsSelectJobs.getString("REPORT_PARAMETER"));
				String passwordFlag = rsSelectJobs.getString("PASSWORD_FLAG");
				
				if ( IrisAdminConstants.CONSTANT_Y.equals(passwordFlag))
					eventJob.setPDFPasswordRequired(true);
				
				eventJob.setPassword(rsSelectJobs.getString("PDF_PASSWORD"));
				setDBDetails(eventJob, dbResource);
			}
			else if ( 1210 == eventType)
			{
				eventJob.setEmailMessage(rsSelectJobs.getString("INT_MESSAGE"));
				eventJob.setEmailSubject(rsSelectJobs.getString("INT_SUBJECT"));
				eventJob.setEntityType(rsSelectJobs.getString("ENTITY_TYPE"));
				eventJob.setMapCode(rsSelectJobs.getString("MAP_CODE"));
				
				String passwordFlag = rsSelectJobs.getString("ZIP_FLAG");
				
				if ( IrisAdminConstants.CONSTANT_Y.equals(passwordFlag))
					eventJob.setZipRequired(true);
				
				eventJob.setPassword(rsSelectJobs.getString("zip_password"));
				eventJob.setFilterParameters(fetchJobParams(eventJob, dbConnection ));
			}
		}
		
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.fetchevent", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch(Exception exp)
		{
			lExp = new LoadingException("error.admin.fetchevent", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			// Do not close resultSet
		}
		
		return eventJob;
	}
	
	private void setDBDetails (EventExecutionJob jobData, Resource dbResource) throws LoadingException
	{
		
		Object dbSidObj = null;
		String dbHost = null;
		String dbUserId = null;
		String dbUserPwd = null;
		String portValue = null;
		Map<String, Object> dbResourceParamMap = null;
		String dbResourceName = null;
		LoadingException lExp = null;
		
		try
		{
			if (dbResource == null)
				return;
			
			dbResourceName = dbResource.getId();
			dbResourceParamMap = dbResource.getParams();
			dbUserId = (String) dbResourceParamMap.get("DBUSER");
			dbUserPwd = (String) dbResourceParamMap.get("DBPASSWORD");
			dbSidObj = dbResourceParamMap.get("DBSID");
			if (dbSidObj != null)
			{
				dbSidObj = (String) dbResourceParamMap.get("DBSID");
				dbHost = (String) dbResourceParamMap.get("DBHOST");
				portValue = (String) dbResourceParamMap.get("DBPORT");
				jobData.setDbHost(dbHost);
				jobData.setDbPort(portValue);
				jobData.setDbSid((String) dbSidObj);
				if (dbResourceParamMap.get("REPDBURL") != null)
					jobData.setRepDdUrl((String) dbResourceParamMap.get("REPDBURL"));
			}
			else
			{
				if (dbResourceParamMap.get("REPDBURL") == null)
					jobData.setDbUrl((String) dbResourceParamMap.get("DBURL"));
				else
					jobData.setRepDdUrl((String) dbResourceParamMap.get("REPDBURL"));
			}
			jobData.setDbUser(dbUserId);
			jobData.setDbPass(dbUserPwd);
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.dbconnection", new Object[]{dbResourceName}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			
		}
	}
	
	/**
	 * This Helper method fetches the run time parameter values for given schedule id TODO
	 * 
	 * @param jobData
	 * @return
	 */
	private Map<String, String> fetchJobParams (EventExecutionJob jobData, Connection dbConnection)  throws LoadingException
	{
		String query = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		LoadingException lExp = null;
		Map<String, String> filterParameters = new HashMap<String, String>();
		try
		{
			query = "SELECT PARAMETER_NAME, PARAMETER_VALUE FROM EVENT_INT_PARM_TXN WHERE event_journal_nmbr =? and notofication_id = ?";
			stmt = dbConnection.prepareStatement(query);
			stmt.setString(1, jobData.getJournalNmbr());
			stmt.setString(2, jobData.getNotificationId());
			rs = stmt.executeQuery();
			while (rs.next())
			{
				filterParameters.put(rs.getString(1), rs.getString(2));
			}
			
		}
		catch (SQLException e)
		{
			lExp = new LoadingException("error.admin.jobparams", new Object[]{ jobData.toString()}, e);
			logger.error(IRISLogger.getText(lExp));
			// do not throw exception
		}
		finally
		{
			HelperUtils.doClose(rs);
			HelperUtils.doClose(stmt);
			query = null;
		}
		
		return filterParameters;
	}
}
