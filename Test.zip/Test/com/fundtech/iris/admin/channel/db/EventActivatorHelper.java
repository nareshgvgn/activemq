/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator
 * FILE   : EventActivatorHelper.java
 * CREATED: Jul 5, 2014 3:32:56 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.DataAttribute;
import com.fundtech.iris.admin.event.data.DataFormatValue;
import com.fundtech.iris.admin.event.data.EventDataMapping;
import com.fundtech.iris.admin.event.data.EventDef;
import com.fundtech.iris.admin.event.data.EventDefinitions;
import com.fundtech.iris.admin.event.data.EventRecipientDef;
import com.fundtech.iris.admin.event.data.RecipientDef;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: EventActivatorHelper.java,v 1.16 2016/10/27 09:01:16 ramap Exp $
 */
public class EventActivatorHelper
{
	private static EventActivatorHelper helper = null;
	private final String DATE = "Date";
	private final String BIGDECIMAL = "BigDecimal";
	private final String TIMESTAMP = "Timestamp";
	private Logger logger = LoggerFactory.getLogger(EventActivatorHelper.class);
	private static final String updateSql = "UPDATE EVENT_TXN T SET t.status = 'L', T.END_DATE = SYSDATE WHERE T.EVENT_JOURNAL_NMBR =?";
	
	private EventActivatorHelper()
	{
	}
	
	public static EventActivatorHelper getInstance ()
	{
		if (helper == null)
			helper = new EventActivatorHelper();
		
		return helper;
	}
	
	public void initilize (Connection dbConnection) throws LoadingException
	{
		if (EventDefinitions.getInstance().isEmpty())
		{
			loadEvents(dbConnection);
			loadEventDataMappings(dbConnection);
			loadRecipients(dbConnection);
			loadEventRecipients(dbConnection);
		}
	}
	
	public EventProcessJob getEventJob (ResultSet rsSelectJobs, Connection dbConnection, int txnCode) throws LoadingException
	{
		EventProcessJob eventProcessJob = null;
		String eventName = null;
		String eventSource = null;
		EventDefinitions eventDefinitions = null;
		EventDef eventDef = null;
		String formWeight = null;
		LoadingException lExp = null;
		
		try
		{
			eventProcessJob = new EventProcessJob();
			eventName = rsSelectJobs.getString("EVENT_NAME");
			eventSource = rsSelectJobs.getString("EVENT_SOURCE");
			eventProcessJob.setTxnCode(txnCode);
			eventProcessJob.setJournalNmbr(rsSelectJobs.getString("EVENT_JOURNAL_NMBR"));
			eventProcessJob.setAdhocEmailId(rsSelectJobs.getString("ADHOC_EMAIL_ID"));
			eventProcessJob.setAdhocFax(rsSelectJobs.getString("ADHOC_FAX"));
			eventProcessJob.setAdhocMobile(rsSelectJobs.getString("ADHOC_MOBILE"));
			eventProcessJob.setBeneficiaryCode(rsSelectJobs.getString("BENEFICIARY_CODE"));
			eventProcessJob.setClientCode(rsSelectJobs.getString("CLIENT_CODE"));
			eventProcessJob.setCoordinatorCode(rsSelectJobs.getString("COORDINATOR_CODE"));
			eventProcessJob.setCourierCode(rsSelectJobs.getString("COURIER_CODE"));
			eventProcessJob.setDispatchBankCode(rsSelectJobs.getString("DISPATCH_BANK_CODE"));
			eventProcessJob.setDrawerCode(rsSelectJobs.getString("DRAWER_CODE"));
			eventProcessJob.setEmailId(rsSelectJobs.getString("EMAIL_ID"));
			eventProcessJob.setEventName(eventName);
			eventProcessJob.setEventDate(rsSelectJobs.getString("EVENT_DATE"));
			eventProcessJob.setEventSource(eventSource);
			eventProcessJob.setFax(rsSelectJobs.getString("FAX"));
			eventProcessJob.setFormId(rsSelectJobs.getString("FORM_ID"));
			eventProcessJob.setMakerCode(rsSelectJobs.getString("MAKER_CODE"));
			eventProcessJob.setMobile(rsSelectJobs.getString("MOBILE"));
			eventProcessJob.setRowKeyField(rsSelectJobs.getString("ROW_KEY_FIELD"));
			eventProcessJob.setSellerCode(rsSelectJobs.getString("SELLER_CODE"));
			eventProcessJob.setTableName(rsSelectJobs.getString("TABLE_NAME"));
			eventProcessJob.setCorpCode((rsSelectJobs.getString("CORPORATION_CODE")))
			;
			formWeight = rsSelectJobs.getString("FORM_WEIGHT");
			if (formWeight != null)
				eventProcessJob.setFormWeight(Integer.parseInt(formWeight));
				
			eventProcessJob.setStatus("P");
			eventDefinitions = EventDefinitions.getInstance();
			eventDef = eventDefinitions.getEventDef(eventSource + "." + eventName);
			eventProcessJob.setEventDef(eventDef);
			attchDataAttributes(eventProcessJob, eventDef, rsSelectJobs);
		}
		catch(LoadingException exp )
		{
			updateJobStatus(dbConnection, eventProcessJob);
			throw exp;
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.loadingEvent", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			updateJobStatus(dbConnection, eventProcessJob);
			throw lExp;
		}
		catch(Exception exp)
		{
			lExp = new LoadingException("error.admin.loadingEvent", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			updateJobStatus(dbConnection, eventProcessJob);
			throw lExp;
		}
		finally
		{
			// Do not close resultSet
		}
		
		return eventProcessJob;
	}
	
	/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------*
	 * 				HELPER  METHODS
	 *----------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
	private void updateJobStatus (Connection dbConnection, EventProcessJob jobData) 
	{
		PreparedStatement updateSt = null;
		int status = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String errorMsg = null;
		
		try
		{
			executionId = jobData.getJournalNmbr();
			logger.debug("Job:{}  Record status updated to L" , executionId);
			updateSt = dbConnection.prepareStatement(updateSql);
			updateSt.clearParameters();
			updateSt.setString(1, executionId);
			status = updateSt.executeUpdate();
			
			if (status < 0)
				logger.warn("Job:" + executionId + " record not available for status update");
			
			dbConnection.commit();
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.loadingEvent", new Object[]
			{ errorMsg, updateSql }, exp);
			logger.error(IRISLogger.getText(eExp));
		}
		catch (Exception exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.loadingEvent", new Object[]
			{ errorMsg, updateSql }, exp);
			logger.error(IRISLogger.getText(eExp));
		}
		finally
		{
			HelperUtils.doClose(updateSt);
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param eventJob
	 * @param eventDef
	 * @param rsSelectJobs
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @throws SQLException
	 */
	private void attchDataAttributes (EventProcessJob jobData, EventDef eventDef, ResultSet rsSelectJobs) throws LoadingException
	{
		Map<String, DataAttribute> dataAttributes = null;
		String dataKeyColumnName = null;
		DataAttribute dataAttribute = null;
		String dataKeyDisplayName = null;
		Object value = null;
		DataFormatValue dataFormatValue = null;
		String format = null;
		EventDataMapping dataMapping = null;
		LoadingException lExp = null;
		String reportParmName = null;
		String intParmName = null;
		String executionId = null;
		String eventName = null;
		
		try
		{
			executionId = jobData.getJournalNmbr();
			eventName = eventDef.getEventName();
			dataMapping =  eventDef.getEventDataMapping();
			if ( dataMapping == null)
				return;
			dataAttributes = dataMapping.getDataAttributes();
			
			for (Map.Entry<String, DataAttribute> entry : dataAttributes.entrySet())
			{
				dataKeyColumnName = entry.getKey();
				dataAttribute = entry.getValue();
				if (dataAttribute != null)
				{
					reportParmName = dataAttribute.getRepParameterName();
					intParmName = dataAttribute.getIntParameterName();
					jobData.addReportParameter(dataKeyColumnName, reportParmName);
					if ( intParmName != null)
						jobData.addIntParameter(dataKeyColumnName, intParmName);
					dataKeyDisplayName = dataAttribute.getDataKeyDisplayName();
					format = dataAttribute.getFormat();
					value = rsSelectJobs.getObject(dataKeyColumnName);
					
					dataFormatValue = new DataFormatValue(dataKeyDisplayName, dataKeyColumnName, dataAttribute.getDataType(), dataAttribute.getFormat(),
							dataAttribute.getMask(), value);
					jobData.addDataFormatValue(dataKeyDisplayName, dataFormatValue);

					if (value != null)
						value = getValue(value, dataFormatValue);
					
					jobData.addDataMapping(dataKeyColumnName, value);
				}
			}
		}
		catch (SQLException exp)
		{
			logger.error("Error While Loading event {}  with JrNumber  {}  for dataKeyColumnName: {} , dataKeyDisplayName: {} , value: {} ,  format: {}",
					eventName, executionId, dataKeyColumnName, dataKeyDisplayName, value, format );
			lExp = new LoadingException("error.admin.loadingEventAtb", new Object[]{eventName,executionId}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch(Exception exp)
		{
			logger.error("Error While Loading event {}  with JrNumber  {}  for dataKeyColumnName: {} , dataKeyDisplayName: {} , value: {} ,  format: {}",
					eventName, executionId, dataKeyColumnName, dataKeyDisplayName, value, format );
			lExp = new LoadingException("error.admin.loadingEventAtb", new Object[]{eventName,executionId}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
	}
	
	private Object getValue(Object inputValue,  DataFormatValue dataFormatValue) throws ParseException
	{
		String format = null;
		NumberFormat numberFormat = null;
		SimpleDateFormat dateFormat = null;
		String dataType = null;
		
		format = dataFormatValue.getFormat();
		dataType = dataFormatValue.getDataType();
		
		if ((dataType.equals(DATE) || dataType.equals(TIMESTAMP)))
		{
			
			if (format == null)
			{
				logger.debug("Format not Specified. So using a Default Format for Date :: " + inputValue);
				format = "dd/MM/yyyy";
			}
			dateFormat = new SimpleDateFormat(format);
			if ( inputValue instanceof Date || inputValue instanceof Timestamp)
				inputValue = dateFormat.format(inputValue);
			else
				dateFormat.parse((String)inputValue);// only validate
		}
		else if (dataType.equals(BIGDECIMAL)  )
		{
			if (format != null)
			{
				numberFormat = new DecimalFormat(format);
				if ( inputValue instanceof BigDecimal)
					inputValue = numberFormat.format(inputValue);
				else
					numberFormat.parse((String)inputValue);// only validate
			}
		}
		return inputValue;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void loadEventDataMappings (Connection dbConnection) throws LoadingException
	{
		String eventSql = "SELECT * FROM EVENT_DATA_MAPPING_MST ORDER BY EVENT_SOURCE, EVENT_NAME";
		PreparedStatement stEvent = null;
		ResultSet rsEvent = null;
		EventDataMapping eventDataMapping = null;
		String eventSource = null;
		String eventName = null;
		String key = null;
		EventDef eventDef = null;
		DataAttribute dataAttribute = null;
		String booleanVal = null;
		LoadingException lExp = null;
		Map<String, EventDataMapping> tempmap = null;
		
		try
		{
			tempmap = new HashMap<String, EventDataMapping>();
			stEvent = dbConnection.prepareStatement(eventSql);
			rsEvent = stEvent.executeQuery();
			while (rsEvent.next())
			{
				eventSource = rsEvent.getString("EVENT_SOURCE");
				eventName = rsEvent.getString("EVENT_NAME");
				key = eventSource + "." + eventName;
				dataAttribute = new DataAttribute();
				
				if (tempmap.containsKey(key))
					eventDataMapping = tempmap.get(key);
				else
					eventDataMapping = new EventDataMapping();
				
				dataAttribute.setMappingId(rsEvent.getString("MAPPING_ID"));
				dataAttribute.setDataKeyColumnName(rsEvent.getString("DATA_KEY_COLUMN_NAME"));
				dataAttribute.setDataKeyDisplayName(rsEvent.getString("DATA_KEY_DISPLAY_NAME"));
				dataAttribute.setDataType(rsEvent.getString("DATA_TYPE"));
				dataAttribute.setFormat(rsEvent.getString("data_format"));
				dataAttribute.setMask(rsEvent.getString("data_mask_format"));
				dataAttribute.setDefineRule(rsEvent.getString("DEFINE_RULE"));
				dataAttribute.setDisplayType(rsEvent.getString("DISPLAY_TYPE"));
				dataAttribute.setDerivationClass(rsEvent.getString("DERIVATION_CLASS"));
				dataAttribute.setRepParameterName(rsEvent.getString("report_parameter_name"));
				
				booleanVal = rsEvent.getString("MAIL_FLAG");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					dataAttribute.setForMail(true);
				
				booleanVal = rsEvent.getString("SMS_FLAG");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					dataAttribute.setForSms(true);
				
				booleanVal = rsEvent.getString("screen_flag");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					dataAttribute.setForOnScreen(true);
				
				dataAttribute.setRepParameterName(rsEvent.getString("REPORT_PARAMETER_NAME"));
				dataAttribute.setIntParameterName(rsEvent.getString("INT_PARAMETER_NAME"));
				eventDataMapping.addDataAttribute(dataAttribute);
				tempmap.put(key, eventDataMapping);
			}
			
			for (Map.Entry<String, EventDataMapping> entry : tempmap.entrySet())
			{
				eventDef = EventDefinitions.getInstance().getEventDef(entry.getKey());
				eventDef.setEventDataMapping(entry.getValue());
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch(Exception exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rsEvent);
			HelperUtils.doClose(stEvent);
			CleanUpUtils.doClean(tempmap);
			tempmap = null;
			eventSource = null;
			eventName = null;
			key = null;
		}
		
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void loadEventRecipients (Connection dbConnection) throws LoadingException
	{
		String eventSql = "SELECT * FROM EVENT_RECIPIENT_MST";
		PreparedStatement stEvent = null;
		ResultSet rsEvent = null;
		EventRecipientDef eventRecipientDef = null;
		String eventSource = null;
		String eventName = null;
		String key = null;
		String recipientName = null;
		EventDef eventDef = null;
		LoadingException lExp = null;
		
		try
		{
			stEvent = dbConnection.prepareStatement(eventSql);
			rsEvent = stEvent.executeQuery();
			while (rsEvent.next())
			{
				eventRecipientDef = new EventRecipientDef();
				eventRecipientDef.setName(rsEvent.getString("EVENT_RECIPIENT_NAME"));
				eventRecipientDef.setEmailId(rsEvent.getString("entity_email_id"));
				eventSource = rsEvent.getString("EVENT_SOURCE");
				eventName = rsEvent.getString("EVENT_NAME");
				key = eventSource + "." + eventName;
				eventDef = EventDefinitions.getInstance().getEventDef(key);
				recipientName = rsEvent.getString("RECIPIENT_NAME");
				eventRecipientDef.setFaxNumber(rsEvent.getString("entity_fax"));
				eventRecipientDef.setMobileNumber(rsEvent.getString("entity_mobile"));
				eventRecipientDef.setSellerCode(rsEvent.getString("SELLER_CODE"));
				eventRecipientDef.setSubscriptionCode(rsEvent.getString("subscription_name"));
				eventRecipientDef.setUserCode(rsEvent.getString("entity_code"));
				eventRecipientDef.setUserDescription(rsEvent.getString("entity_description"));
				eventRecipientDef.setUserType(rsEvent.getString("event_recipient_category"));
				eventRecipientDef.setRecipientDef(EventDefinitions.getInstance().getRecipientDef(recipientName));
				eventDef.addEventRecipientDef(eventRecipientDef);
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch(Exception exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rsEvent);
			HelperUtils.doClose(stEvent);
			
			eventSource = null;
			eventName = null;
			key = null;
			recipientName = null;
		}
		
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void loadRecipients (Connection dbConnection) throws LoadingException
	{
		String reciSql = "SELECT * FROM RECIPIENT_MST";
		PreparedStatement stReci = null;
		ResultSet rsReci = null;
		RecipientDef recipientDef = null;
		LoadingException lExp = null;
		
		try
		{
			stReci = dbConnection.prepareStatement(reciSql);
			rsReci = stReci.executeQuery();
			while (rsReci.next())
			{
				recipientDef = new RecipientDef();
				recipientDef.setName(rsReci.getString("RECIPIENT_NAME"));
				recipientDef.setProviderClass(rsReci.getString("PROVIDER_CLASS"));
				recipientDef.setSellecrCode(rsReci.getString("SELLER_CODE"));
				EventDefinitions.getInstance().addRecipientDef(recipientDef);
			}
			
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch(Exception exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rsReci);
			HelperUtils.doClose(stReci);
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void loadEvents (Connection dbConnection) throws LoadingException
	{
		String eventSql = "SELECT * FROM EVENT_MST";
		PreparedStatement stEvent = null;
		ResultSet rsEvent = null;
		EventDef eventDef = null;
		String booleanVal = null;
		LoadingException lExp = null;
		
		try
		{
			stEvent = dbConnection.prepareStatement(eventSql);
			rsEvent = stEvent.executeQuery();
			while (rsEvent.next())
			{
				eventDef = new EventDef();
				eventDef.setEventName(rsEvent.getString("EVENT_NAME"));
				eventDef.setEventSource(rsEvent.getString("EVENT_SOURCE"));
				eventDef.setScreenName(rsEvent.getString("screen_name"));
				eventDef.setSellerCode(rsEvent.getString("SELLER_CODE"));
				eventDef.setModule(rsEvent.getString("event_module"));
				eventDef.setGroup(rsEvent.getString("event_group"));
				eventDef.setType(rsEvent.getString("event_type"));
				
				booleanVal = rsEvent.getString("APPLICABLE");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					eventDef.setApplicable(true);
				
				booleanVal = rsEvent.getString("attachment_notify");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					eventDef.setAttachmentNotify(true);
				
				booleanVal = rsEvent.getString("email_notify");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					eventDef.setEmailNotify(true);
				
				booleanVal = rsEvent.getString("fax_notify");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					eventDef.setFaxNotify(true);
				
				booleanVal = rsEvent.getString("screen_notify");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					eventDef.setOnScreenNotify(true);
				
				booleanVal = rsEvent.getString("sms_notify");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					eventDef.setSmsNotify(true);
				
				booleanVal = rsEvent.getString("interface_notify");
				if (IrisAdminConstants.CONSTANT_Y.equals(booleanVal))
					eventDef.setInterfaceNotify(true);
				
				EventDefinitions.getInstance().addEventDef(eventDef);
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch(Exception exp)
		{
			lExp = new LoadingException("error.admin.createjob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rsEvent);
			HelperUtils.doClose(stEvent);
		}
	}
}
