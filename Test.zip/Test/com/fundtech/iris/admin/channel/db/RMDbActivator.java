package com.fundtech.iris.admin.channel.db;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.RejectedExecutionException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.core.processor.activators.AbstractActivator;
import com.cashtech.iris.core.processor.resource.ReferenceTypeEnum;
import com.cashtech.iris.core.processor.resource.Resource;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.MapDataObject;
import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.activator.session.RMDbSession;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.report.LoadReportDef;

/**
 * 
 * <p>
 * This Activator used for IRIS Admin interfaces for download and upload.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * &lt;Activator id="IrisAdminUpload" activatorClass="com.fundtech.iris.admin.activator.RMDbActivator"&gt;
 * 	&lt;Parameter name="TriggerProcesses" value="IrisAdminUpload"/&gt;
 * 	&lt;Parameter name="SleepTimeInMillis" value="5000"/&gt;
 * 	&lt;Parameter name="maxPoolSize" value="20"/&gt;
 * 	&lt;Parameter name="minPoolSize" value="2"/&gt;
 * 	&lt;Parameter name="maxWarmThreadsinPool" value="2"/&gt;
 * 	&lt;Parameter name="poolKeepAliveTime" value="10000"/&gt;
 * 	&lt;Parameter name="maxQueueSize" value="1"/&gt;
 * 	&lt;Parameter name="InterfaceSpecificCode" value="1202"/&gt;
 * 	&lt;Parameter name="FTPProperty" value="DNROOT"/&gt;
 * 	&lt;Parameter name="InitJobStatusTo" value="E"/&gt;
 * 	&lt;Parameter name="AccumulateErrors" value="true"/&gt;
 * 	&lt;References&gt;
 * 		&lt;Reference name="reportType" type="OUTPUT_TYPE"/&gt;
 * 		&lt;Reference name="IRIS_DB" type="DB_CONN"/&gt;
 * 	&lt;/References&gt;
 * &lt;/Activator&gt;
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>TriggerProcesses:-</h3> IrisAdminUpload/IrisAdminDownload process.
 * </p>
 * <p>
 * <h3>SleepTimeInMillis:-</h3> This value is in milliseconds. This property is for sleep interval between jobs query execution and if all threads are
 * busy. Default value is 60000 if nothing given.
 * </p>
 * <p>
 * <h3>InitJobStatusTo:-</h3> This property is for the jobs which are abnormally ended due to db connection lose or iris down. Default value is E (
 * jobs will be marked as Error ). If Value is N then job will be initiated again.
 * </p>
 * <p>
 * <h3>AccumulateErrors:-</h3> This property is for accumulate errors while doing parsing of incoming data. Default is false.
 * </p>
 * 
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">IRIS Admin</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>IrisAdminUpload.xml/IrisAdminDownload.xml</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: RMDbActivator.java,v 1.16 2016/07/21 06:01:06 ramap Exp $
 */
public class RMDbActivator extends AbstractActivator
{
	private final static Logger logger = LoggerFactory.getLogger(RMDbActivator.class);
	private long sleepTimeinMillis = 60000;
	private boolean shallIRun = true;
	private Connection dbConnection = null;
	private ConnectionProvider dbProvider = null;
	private int intTxnCode = -1;
	private PreparedStatement psUpdate = null;
	private PreparedStatement psPickup = null;
	private PreparedStatement secProfileStmt = null;
	private String ftpProperty = null;
	private String ftpPath = null;
	private String reportCodePrefix = null;
	private String initJobStatusTo = "E";
	private final static String PARAMETER_NAME = "PARAMETER_NAME";
	private final static String PARAMETER_VALUE = "PARAMETER_VALUE";
	private String fileSenderName = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.activators.Activator#initialize()
	 */
	public void initialize () throws ConfigurationException
	{
		ConfigurationException confiEx = null;
		String strSleepTime = null;
		try
		{
			initializeActivatorPool();
			
			if (null == this.references.get(ReferenceTypeEnum.OUTPUT_TYPE))
			{
				confiEx = IRISLogger.getConfigEx("error.app.referenceNotProvided", new Object[]	{ ReferenceTypeEnum.OUTPUT_TYPE });
				logger.error(IRISLogger.getText(confiEx));
				throw confiEx;
			}
			
			strSleepTime = (String) parameters.get("SleepTimeInMillis");
			if (strSleepTime != null)
				sleepTimeinMillis = Long.parseLong(strSleepTime);
			
			fileSenderName = (String) parameters.get("fileSender");
			
			intTxnCode = Integer.valueOf((String) parameters.get("InterfaceSpecificCode"));
			if (-1 == intTxnCode)
			{
				confiEx = IRISLogger.getConfigEx("InterfaceSpecificCode is null or empty.", new Object[] { "InterfaceSpecificTxnCode" });
				logger.error(IRISLogger.getText(confiEx));
				throw confiEx;
			}
			
			ftpProperty = (String) parameters.get("FTPProperty");
			if (ftpProperty == null)
				ftpProperty = "DNROOT";
			
			if (parameters.containsKey("InitJobStatusTo"))
				initJobStatusTo = (String) parameters.get("InitJobStatusTo");
			
			initializeTriggerProcesses();
		}
		catch (ConfigurationException cfx)
		{
			throw cfx;
		}
		catch (Exception e)
		{
			confiEx = new ConfigurationException("error.app.activatorInitializationFailed", new Object[] {}, e);
			logger.error(IRISLogger.getText(confiEx));
			throw confiEx;
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run ()
	{
		int intCount = 0;
		try
		{
			Thread.currentThread().setName(this.getId() + "_" + intTxnCode);
			dbConnection = getDBConnection();
			
			if (null == dbConnection)
			{
				throw new RuntimeException("Activator [" + id + "] terminating!");
			}
			
////			IrisChannel ftpChannel = applicationContext.getOutBoundSFTPChannel();
//			IrisChannel ftpChannel = applicationContext.getInBoundSFTPChannel();
//			Map<String, String> parms = new HashMap<String, String>();
//			parms.put(IrisOutBoundChannel.HOST, "localhost");
//			parms.put(IrisOutBoundChannel.USER, "babu");
//			parms.put(IrisOutBoundChannel.PASSWORD, "babu");
//			parms.put("FTPScan.pool.size", "1");
////			parms.put(IrisOutBoundChannel.REMOTE_DIR, "/input");
//			
//			parms.put(IrisOutBoundChannel.REMOTE_DIR, "/test");
////			ftpChannel.send( parms, new File("C:/Temp/test1.xml"));
//			File file = (File) ftpChannel.receive(parms);
			
			initialiseStmts();
			getFtpPath();
			while (shallIRun)
			{
				if (!isConnectionAlive())
				{
					if (makeReconnection(intCount))
						intCount = 0;
					else
						intCount = 1;
				}
				else
					executeProcess();
				
				Thread.sleep(sleepTimeinMillis);
			}
		}
		catch (ConfigurationException e)
		{
			throw new RuntimeException("Activator [" + id + "] terminating!", e);
		}
		catch (SQLException e)
		{
			throw new RuntimeException("Activator [" + id + "] terminating!", e);
		}
		catch (Exception e)
		{
			throw new RuntimeException("Activator [" + id + "] terminating!", e);
		}
		finally
		{
			HelperUtils.doClose(psUpdate);
			HelperUtils.doClose(psPickup);
			HelperUtils.doClose(secProfileStmt);
			psPickup = null;
			psUpdate = null;
			secProfileStmt = null;
		}
	}
	
	public boolean isCreateAudit ()
	{
		return createAudit;
	}
	
	@Override
	protected String getExecutionId ()
	{
		return "";
	}
	
	public void doCleanup ()
	{
		shallIRun = false;
		Thread.currentThread().interrupt();
	}
	
	/*-----------------------------------------------------------------------------------------------------------------------------------*
	 * HELPER METHODS
	 *-----------------------------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * This helper method picks the SQL from IL_INTERFACE_MST, and binds it to this instance of activator
	 * 
	 * @throws ConfigurationException
	 * @throws SQLException
	 */
	private void initialiseStmts () throws ConfigurationException, SQLException
	{
		ConfigurationException confiEx = null;
		PreparedStatement psSelect = null;
		String updateSql = null;
		String interfaceType = null;
		ResultSet rsSelect = null;
		String strPickupSql = null;
		String selectQuery = "SELECT PICKUP_SQL, INTERFACE_TYPE, INSERT_SQL1, INSERT_SQL2 FROM IL_INTERFACE_MST WHERE TXNCODE = ?";
		String updateQuery = null;
		try
		{
			psSelect = dbConnection.prepareStatement(selectQuery);
			psSelect.clearParameters();
			psSelect.setInt(1, intTxnCode);
			rsSelect = psSelect.executeQuery();
			if (rsSelect.next())
			{
				strPickupSql = rsSelect.getString("PICKUP_SQL");
				interfaceType = rsSelect.getString("INTERFACE_TYPE");
				updateQuery = rsSelect.getString("INSERT_SQL1");
				updateSql = rsSelect.getString("INSERT_SQL2");
				
				if ( updateQuery == null)
					updateQuery = "UPDATE IRIS_JOB_QUEUE SET STATUS = 'P', END_DATE = null,  SYS_START_DATE = SYSDATE, START_DATE = pk_timezone.get_seller_time(?) "
							+ "	 WHERE EXECUTION_ID = ? AND STATUS = 'N'";
				
				if (logger.isInfoEnabled())
				{
					logger.info("Pickup SQL:" + strPickupSql);
					logger.info("Type of(U/D) interfaces executing: " + interfaceType);
				}
			}
			else
			{
				// Need to throw an error as activator can not be configured without PICKSQL
				confiEx = IRISLogger.getConfigEx("error.admin.configuration", new Object[]
				{ intTxnCode, selectQuery }, null);
				logger.error(IRISLogger.getText(confiEx));
				throw confiEx;
			}
			initializeOldJobs(updateSql, interfaceType);
			psPickup = dbConnection.prepareStatement(strPickupSql);
			psUpdate = dbConnection.prepareStatement(updateQuery);
			secProfileStmt = dbConnection.prepareStatement("select * from PRF_SECURITY_MST where PROFILE_ID =?");
		}
		catch (SQLException e)
		{
			throw e;
		}
		finally
		{
			HelperUtils.doClose(rsSelect);
			HelperUtils.doClose(psSelect);
			rsSelect = null;
			psSelect = null;
			
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void initializeOldJobs (String updateSql, String interfaceType) throws SQLException
	{
		PreparedStatement stJob = null;
		int updateCount = 0;
		try
		{
			if (updateSql == null)
				updateSql = "UPDATE IRIS_JOB_QUEUE SET STATUS = ? WHERE STATUS = 'P' AND SRC_TYPE = ?";
			
			stJob = dbConnection.prepareStatement(updateSql);
			stJob.clearParameters();
			stJob.setString(1, initJobStatusTo);
			stJob.setString(2, interfaceType);
			updateCount = stJob.executeUpdate();
			dbConnection.commit();
			if (logger.isDebugEnabled())
				logger.debug("Existing jobs status P are update to " + initJobStatusTo + ". Count:" + updateCount);
		}
		finally
		{
			HelperUtils.doClose(stJob);
		}
		
	}
	
	/**
	 * This helper method creates the dataObject by using Pick Up SQL result Set
	 * 
	 * @param rsPickup
	 * @return
	 */
	private RMJobData createJobData (ResultSet rsPickup) throws LoadingException
	{
		RMJobData jobData = new RMJobData();
		LoadingException lExp;
		try
		{
			jobData.setEntityCode(rsPickup.getString("ENTITY_CODE"));
			jobData.setSrcType(rsPickup.getString("SRC_TYPE"));
			jobData.setSrcId(rsPickup.getString("SRC_ID"));
			jobData.setSrcName(rsPickup.getString("SRC_NAME"));
			jobData.setSellerCode(rsPickup.getString("SELLER_CODE"));
			jobData.setExecutionId(rsPickup.getString("EXECUTION_ID"));
			jobData.setEntityType(rsPickup.getString("ENTITY_TYPE"));
			jobData.setStatus(rsPickup.getString("STATUS"));
			jobData.setChannelName(rsPickup.getString("CHANNEL_NAME"));
			jobData.setReportType(rsPickup.getString("SRC_SUB_TYPE"));
			jobData.setMediaDetails(rsPickup.getString("MEDIA_DTLS"));
			jobData.setRefId(rsPickup.getString("REF_ID"));
			jobData.setParentExecutionId(rsPickup.getString("PARENT_EXECUTION_ID"));
			jobData.setPriority(rsPickup.getString("PRIORITY"));
			jobData.setEntryDate(rsPickup.getDate("ENTRY_DATE"));
			jobData.setExecutionDate(rsPickup.getDate("EXECUTION_DATE"));
			jobData.setStartDate(rsPickup.getDate("START_DATE"));
			jobData.setEndDate(rsPickup.getDate("END_DATE"));
			setReportParams(jobData);
			jobData.setFtpPath(ftpPath);
			jobData.setReportCodePrefix(reportCodePrefix);
			jobData.setFileSenderName(fileSenderName);
			
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.jobData", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		return jobData;
		
	}
	
	/**
	 * This helper method creates the session object by using dataObject
	 * 
	 * @param dataObject
	 * @return
	 * @throws LoadingException
	 */
	private RMDbSession createSession (RMJobData jobData) throws LoadingException
	{
		RMDbSession session = null;
		DataObject dataObject = null;
		String secProfileRecordKey = null;
		SecurityProfile secProfile = null;
		LoadReportDef loadDef = null;
		
		try
		{
			dataObject = new MapDataObject(this.outputType);
			loadDef = new LoadReportDef(dbConnection, jobData);
			loadDef.loadData();
			setDBDetails(jobData);
			secProfileRecordKey = jobData.getJobParameter(IrisAdminConstants.SECURITY_RECORD_KEY);
			secProfile = getSecurityProfile(secProfileRecordKey);
			jobData.setSecurityProfile(secProfile);
			session = new RMDbSession(this.id, this.applicationContext, dataObject, jobData);
			session.setTriggerProcesses(triggerProcesses);
			jobData.setStatus("P");
		}
		
		catch (Exception exp)
		{
			LoadingException lexp = new LoadingException("error.admin.loading", new Object[]{ jobData.toString() }, exp);
			logger.error(IRISLogger.getText(lexp));
			throw lexp;
		}
		
		return session;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param secProfileRecordKey
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private SecurityProfile getSecurityProfile (String secProfileRecordKey) throws LoadingException
	{
		SecurityProfile secProfile = null;
		ResultSet secRs = null;
		LoadingException lExp = null;
		try
		{
			secProfile = new SecurityProfile();
			if (secProfileRecordKey != null)
			{
				
				secProfileStmt.clearParameters();
				secProfileStmt.setString(1, secProfileRecordKey);
				secRs = secProfileStmt.executeQuery();
				if (secRs.next())
				{
					secProfile.setChannelCertName(secRs.getString("FTP_CERTIFICATE_NAME"));
					secProfile.setChannelBasePath(secRs.getString("FTP_BASE_DIRECTORY"));
					secProfile.setChannelIPAddress(secRs.getString("FTP_IPADDRESS"));
					secProfile.setChannelMode(secRs.getString("FTP_TRANSFER_MODE"));
					secProfile.setChannelPassword(secRs.getString("FTP_PASSWORD"));
					secProfile.setChannelPort(secRs.getInt("FTP_PORT"));
					secProfile.setChannelType(secRs.getString("FTP_PROTOCOL_TYPE"));
					secProfile.setChannelUser(secRs.getString("FTP_USER"));
					secProfile.setEmailId(secRs.getString("EMAIL_ID"));
					secProfile.setEncryptionAlgo(secRs.getString("ENCRYPTION_ALGO"));
					secProfile.setEncryptionKey(secRs.getString("ENCRYPTION_KEY"));
					secProfile.setEncryptionRequired(secRs.getString("ENCRYPTION_FLAG"));
					secProfile.setEncryptionType(secRs.getString("ENCRYPTION_TYPE"));
					secProfile.setEncryptionKeyLength(secRs.getInt("ENCRYPTION_KEY_LENGTH"));
					secProfile.setIntegrityAlgo(secRs.getString("INTEGRITY_CHECK_ALGO"));
					secProfile.setIntegrityCheckRequired(secRs.getString("INTEGRITY_CHECK_FLAG"));
					secProfile.setName(secRs.getString("PROFILE_NAME"));
					secProfile.setNotifySucess(secRs.getString("NOTIFY_SUCCESS"));
					secProfile.setNotifyFailure(secRs.getString("NOTIFY_FAIL"));
					secProfile.setPdfPassword(secRs.getString("PDF_PASSPHRASE"));
					secProfile.setSigningType(secRs.getString("SIGNING_TYPE"));
					secProfile.setSiginingRequired(secRs.getString("SIGNING_FLAG"));
					secProfile.setSiginingAlgo(secRs.getString("SIGNING_ALGO"));
					secProfile.setZipType(secRs.getString("ZIP_MODE"));
					secProfile.setZipPassword(secRs.getString("ZIP_PASSPHRASE"));
				}
			}
			
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.secProfile", new Object[]{secProfileRecordKey}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(secRs);
		}
		
		return secProfile;
	}
	
	/**
	 * This helper method executes the thread by using pool object and should not throw any exception
	 * 
	 * @param session
	 * @param strServiceId
	 * @return
	 */
	private boolean executeSession (RMDbSession session)
	{
		try
		{
			activatorPool.execute(session);
			dbConnection.commit();
		}
		catch (RejectedExecutionException e)
		{
			logger.error("Error:", e);
			return false;
		}
		catch (SQLException e)
		{
			logger.error("Error:", e);
			return true;
		}
		return true;
	}
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	private Connection getDBConnection ()
	{
		String dbResourceName = null;
		
		try
		{
			dbResourceName = (String) this.references.get(ResourceTypeEnum.DB_CONN);
			if (dbProvider == null)
			{
				if (dbResourceName != null)
					dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
				else
					dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
							ResourceTypeEnum.IRIS_DATABASE);
			}
			
			dbConnection = dbProvider.getConnection();
		}
		catch (Exception e)
		{
			logger.error("DB Error:", e);
			dbConnection = null;
		}
		return dbConnection;
	}
	
	/**
	 * This method checks connection alive or not
	 * 
	 * @param connection
	 * @return boolean
	 */
	private boolean isConnectionAlive ()
	{
		try
		{
			dbConnection.setAutoCommit(true);
			dbConnection.setAutoCommit(false);
		}// try
		catch (Exception e)
		{
			logger.error("Error:", e);
			cleanup();
			return false;
		}// catch
		return true;
	}
	
	private void cleanup ()
	{
		try
		{
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
			dbProvider = null;
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// DO NOTHING
		}
	}
	
	/**
	 * This helper method re creates the connection and should not throw any exception
	 * 
	 * @param intCount
	 * @return
	 */
	private boolean makeReconnection (int intCount)
	{
		try
		{
			if (intCount == 0)
				logger.warn("DATABASE CONNECTION LOST... " + "SO TRYING TO FETCH CONNECTION AGAIN");
			
			dbConnection = getDBConnection();
			if (dbConnection == null)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				Thread.sleep(sleepTimeinMillis);
				
			}
			else
			{
				psPickup = null;
				psUpdate = null;
				initialiseStmts();
				return true;
			}
		}
		catch (InterruptedException e)
		{
			logger.error("Error:" + e.getMessage(),e);
		}
		catch (ConfigurationException e)
		{
			logger.error("Error:" + e.getMessage(),e);
		}
		catch (SQLException e)
		{
			logger.error("SQLEXCEPTION : ", e);
		}
		catch (Exception e)
		{
			logger.error("Error:" + e.getMessage(),e);
		}
		
		return false;
	}
	
	/**
	 * This helper method executes the process, and this method should not throw any exception
	 */
	private void executeProcess () throws LoadingException
	{
		ResultSet rsPickup = null;
		RMJobData jobData = null;
		RMDbSession dbSession = null;
		int intReturnStatus = -1;
		String strExecutionId = null;
		LoadingException lExp = null;
		
		try
		{
			rsPickup = psPickup.executeQuery();
			while (rsPickup.next())
			{
				strExecutionId = rsPickup.getString("EXECUTION_ID");
				jobData = createJobData(rsPickup);
				psUpdate.setString(1, jobData.getSellerCode());
				psUpdate.setString(2, strExecutionId);
				dbSession = createSession(jobData);
				if (dbSession != null)
				{
					logger.info("Execution ID:{} updating status to 'P'", strExecutionId);
					
					intReturnStatus = psUpdate.executeUpdate();
					if (intReturnStatus > 0)
					{
						while (true)
						{
							if (executeSession(dbSession))
								break;
							else
								Thread.sleep(sleepTimeinMillis);
						}
					}
					else
						logger.warn("Execution ID:{} status not able to change and return value:{}", strExecutionId , intReturnStatus);
				}
				else
				{
					logger.error("Error while loading job:" + strExecutionId);
					LoadingException load = new LoadingException("error.admin.loadingDefinition", new Object[]
					{ strExecutionId }, null);
					logger.error(IRISLogger.getText(load));
					updateError(jobData);
				}
				
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.executeJob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.executeJob", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rsPickup);
		}
	}
	
	/**
	 * TODO
	 * 
	 * @param executionJobData
	 */
	private void updateError (RMJobData jobData) throws LoadingException
	{
		PreparedStatement stmt = null;
		String updateQuery = "UPDATE IRIS_JOB_QUEUE SET STATUS = 'L', EXECUTION_DATE = SYSDATE, START_DATE = SYSDATE "
				+ ", END_DATE = SYSDATE WHERE EXECUTION_ID = ? AND STATUS = 'N'";
		LoadingException lExp = null;
		
		try
		{
			stmt = dbConnection.prepareStatement(updateQuery);
			stmt.clearParameters();
			stmt.setString(1, jobData.getExecutionId());
			stmt.executeUpdate();
			dbConnection.commit();
			finishJob(jobData);
			updateStatustoGCP(jobData);
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.updateJob", new Object[]{jobData, updateQuery}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
			
		}
		finally
		{
			HelperUtils.doClose(stmt);
		}
	}
	
	private void finishJob (RMJobData jobData) throws ExecutionException
	{
		CallableStatement cStmt = null;
		String sql = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		ExecutionException eExp = null;
		String executionId = null;
		
		try
		{
			startTime = System.currentTimeMillis();
			sql = "{CALL pkg_iris_admin.finish_iris_job (?, ?, ?, ?,?)}";
			cStmt = dbConnection.prepareCall(sql);
			executionId = jobData.getExecutionId();
			cStmt.setString(1, executionId);
			cStmt.setString(2, jobData.getRefId());
			cStmt.setString(3, "L");
			cStmt.setString(4, "IRIS-0001");
			cStmt.setString(5, "Not able to load the definition.");
			
			cStmt.executeUpdate();
			dbConnection.commit();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing pkg_iris_admin.finish_iris_job " + " StoredProcedure: " + delta);
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.finishjobproc", new Object[]
			{ executionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
	}
	
	private void updateStatustoGCP (RMJobData jobData) throws ExecutionException
	{
		CallableStatement cStmt = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String procCall = "{CALL pkg_integrate_gcp.update_gcp_status(?, ?, ?, ?)}";
		try
		{
			
			startTime = System.currentTimeMillis();
			cStmt = dbConnection.prepareCall(procCall);
			executionId = jobData.getExecutionId();
			cStmt.setString(1, executionId);
			cStmt.setString(2, jobData.getRefId());
			cStmt.setString(3, "IRIS-0001");
			cStmt.setString(4, "Not able to load the definition.");
			
			cStmt.executeUpdate();
			dbConnection.commit();
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing " + procCall + " StoredProcedure: " + delta);
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.finishjobproc", new Object[]{ executionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
	}
	
	/**
	 * This Helper method fetches the run time parameter values for given schedule id TODO
	 * 
	 * @param jobData
	 * @return
	 */
	private void setReportParams (RMJobData jobData) throws LoadingException
	{
		String query = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String parmType = null;
		LoadingException lExp = null;
		try
		{
			query = "SELECT T.PARAMETER_TYPE,T.PARAMETER_NAME, T.PARAMETER_VALUE FROM IRIS_JOB_PARAM_TXN T WHERE "
					+ "T.EXECUTION_ID = ? ORDER BY T.SEQUENCE_NMBR ASC";
			stmt = dbConnection.prepareStatement(query);
			stmt.clearParameters();
			stmt.setString(1, jobData.getExecutionId());
			rs = stmt.executeQuery();
			while (rs.next())
			{
				parmType = rs.getString("PARAMETER_TYPE");
				if ("RUNTIME".equals(parmType))
					jobData.addReportParameter(rs.getString(PARAMETER_NAME), rs.getString(PARAMETER_VALUE));
				else if ("JOB".equals(parmType))
					jobData.addJobParameter(rs.getString(PARAMETER_NAME), rs.getString(PARAMETER_VALUE));
				else if ("SYSTEM".equals(parmType))
					jobData.addSysParameter(rs.getString(PARAMETER_NAME), rs.getString(PARAMETER_VALUE));
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.reportParms", new Object[]{jobData}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rs);
			HelperUtils.doClose(stmt);
			query = null;
		}
		
	}
	
	private  String getFtpPath () throws LoadingException
	{
		String sql = "SELECT PARAMETER_VALUE, PARAMETER_CODE  FROM SYSTEM_PARAMETERS_MST WHERE PARAMETER_CODE in (?, 'REPINSTNAME')";
		PreparedStatement statement = null;
		ResultSet rSet = null;
		File ftpFile = null;
		LoadingException lExp = null;
		String parmCode = null;
		
		try
		{
			statement = dbConnection.prepareStatement(sql);
			statement.clearParameters();
			statement.setString(1, ftpProperty);
			rSet = statement.executeQuery();
			while(rSet.next())
			{
				parmCode = rSet.getString("PARAMETER_CODE");
				if ( ftpProperty.equals(parmCode))
				{
					ftpPath = rSet.getString("PARAMETER_VALUE");
					ftpFile = new File(ftpPath);
					ftpPath = ftpFile.getAbsolutePath();
				}
				else
					reportCodePrefix = rSet.getString("PARAMETER_VALUE");
			}
			if ( StringUtils.isEmpty(ftpPath))
			{
				lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rSet);
			HelperUtils.doClose(statement);
			ftpFile = null;
		}
		
		return ftpPath;
	}
	
	private void setDBDetails (RMJobData jobData) throws LoadingException
	{
		Resource dbResource = null;
		Object dbSidObj = null;
		String dbHost = null;
		String dbUserId = null;
		String dbUserPwd = null;
		String portValue = null;
		Map<String, Object> dbResourceParamMap = null;
		String dbResourceName = null;
		LoadingException lExp = null;
		
		try
		{
			
			dbResourceName = (String) this.references.get(ResourceTypeEnum.DB_CONN);
			dbResource = getResource(dbResourceName);
			dbResourceParamMap = dbResource.getParams();
			dbUserId = (String) dbResourceParamMap.get("DBUSER");
			dbUserPwd = (String) dbResourceParamMap.get("DBPASSWORD");
			dbSidObj = dbResourceParamMap.get("DBSID");
			if (dbSidObj != null)
			{
				dbSidObj = (String) dbResourceParamMap.get("DBSID");
				dbHost = (String) dbResourceParamMap.get("DBHOST");
				portValue = (String) dbResourceParamMap.get("DBPORT");
				jobData.setDbHost(dbHost);
				jobData.setDbPort(portValue);
				jobData.setDbSid((String) dbSidObj);
				if (dbResourceParamMap.get("REPDBURL") != null)
					jobData.setRepDdUrl((String) dbResourceParamMap.get("REPDBURL"));
			}
			else
			{
				if (dbResourceParamMap.get("REPDBURL") == null)
					jobData.setDbUrl((String) dbResourceParamMap.get("DBURL"));
				else
					jobData.setRepDdUrl((String) dbResourceParamMap.get("REPDBURL"));
			}
			jobData.setDbUser(dbUserId);
			jobData.setDbPass(dbUserPwd);
		}
		catch (NodeProcessingException exp)
		{
			lExp = new LoadingException("error.admin.dbconnection", new Object[]{dbResourceName}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			
		}
	}
}
