/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.db
 * FILE   : IrisIMJobActivator.java
 * CREATED: Jul 25, 2015 1:38:03 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.core.processor.resource.Resource;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.activator.session.IMJobSession;
import com.fundtech.iris.admin.activator.session.Session;
import com.fundtech.iris.admin.channel.AbstractActivator;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.ReferencesEnum;
import com.fundtech.iris.admin.channel.db.rm.RMActivatorHelper;
import com.fundtech.iris.admin.channel.db.rm.session.IrisRMJobSession;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.ConfigException;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisIMScheduleJobActivator.java,v 1.14 2016/12/21 11:09:41 ramap Exp $
 */
public class IrisIMScheduleJobActivator extends AbstractActivator
{
	
	private static final Logger logger = LoggerFactory.getLogger(IrisIMScheduleJobActivator.class);
	
	private  boolean CONTINUE_THREAD = true;;
	private String id = "IM";
	private ConnectionProvider dbProvider = null;
	private Connection dbConnection = null;
	private PreparedStatement jobStmt = null;
	private PreparedStatement updateStmt = null;
	private ActivatorHelper intActivatorHelper = null;
	private RMActivatorHelper rmActivatorHelper = null;
	private int localPoolingInMilliSecs = 0;
	private String scheduleId = null;
	private String srcType = "SCH_SEGMENTED";
	private Resource dbResource = null;
	private String fileSenderName = null;
	private String srcTypeStr = "SRC_TYPE";
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void execute ()
	{
		int intCount = 0;
		try
		{
			localPoolingInMilliSecs = getPoolingSleepInSecs() * 100;
			intActivatorHelper = new ActivatorHelper();
			rmActivatorHelper = new RMActivatorHelper();
			dbConnection = getDBConnection();
			
			if (dbConnection != null)
				initialiseStmts();
			
			while (CONTINUE_THREAD)
			{
				
				if (!isConnectionAlive())
				{
					if (makeReconnection(intCount))
						intCount = 0;
					else
						intCount = 1;
				}
				else
				{
					executeProcess();
				}
				Thread.sleep(localPoolingInMilliSecs);
			}
			
			while ( getCurrentPoolSize() >= 1 )
			{
				Thread.sleep(localPoolingInMilliSecs);
			}
				
			logger.info("Process:{} completed its job, clsoing itself!! ", Thread.currentThread().getName());
		}
		catch (Exception se)
		{
			logger.error("Error:", se);
			throw new RuntimeException("Activator [" + id + "] terminating!");
		}
		finally
		{
			if ( intActivatorHelper != null)
				intActivatorHelper.cleanUp();
			cleanup();
		}
		
	}
	
	
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------*
 * HELPER METHODS
 *----------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * This helper method picks the SQL from IL_INTERFACE_MST, and binds it to this instance of activator
	 * 
	 * @throws ConfigurationException
	 * @throws SQLException
	 */
	private void initialiseStmts () throws  ConfigException, LoadingException
	{
		PreparedStatement psSelect = null;
		String partialJobsSql = null;
		String interfaceType = null;
		ResultSet rsSelect = null;
		String strPickupSql = null;
		String selectQuery = "SELECT PICKUP_SQL, INTERFACE_TYPE, INSERT_SQL1, INSERT_SQL2 FROM IL_INTERFACE_MST WHERE TXNCODE = ?";
		String updateQuery = null;
		ConfigException cExp = null;
		
		try
		{
			psSelect = dbConnection.prepareStatement(selectQuery);
			psSelect.clearParameters();
			psSelect.setInt(1, getProcessId());
			rsSelect = psSelect.executeQuery();
			if (rsSelect.next())
			{
				strPickupSql = rsSelect.getString("PICKUP_SQL");
				interfaceType = rsSelect.getString("INTERFACE_TYPE");
				updateQuery = rsSelect.getString("INSERT_SQL1");
				partialJobsSql = rsSelect.getString("INSERT_SQL2");
				
				if ( updateQuery == null)
					updateQuery = "UPDATE IRIS_JOB_QUEUE SET STATUS = 'P', END_DATE = null,  SYS_START_DATE = SYSDATE, START_DATE = pk_timezone.get_seller_time(?) "
							+ "	 WHERE EXECUTION_ID = ? AND STATUS = 'N'";
				
				if (logger.isInfoEnabled())
				{
					logger.info("Pickup SQL:" + strPickupSql);
					logger.info("Type of(U/D) interfaces executing: " + interfaceType);
				}
			}
			else
			{
				cExp = new ConfigException("error.iris.admin.im.pickupsql", new Object[] {getProcessId(),selectQuery}, null);
				logger.error(IRISLogger.getText(cExp));
				throw cExp;
			}
			initializeOldJobs(partialJobsSql);
			jobStmt = dbConnection.prepareStatement(strPickupSql);
			jobStmt.clearParameters();
			jobStmt.setString(1, srcType);
			jobStmt.setString(2, scheduleId);
			updateStmt = dbConnection.prepareStatement(updateQuery);
			intActivatorHelper.initialize(dbConnection, getApplicationContext());
			rmActivatorHelper.initialize(dbConnection,getApplicationContext());
			setFtpPath(intActivatorHelper.getFtpPath(id, getFtpProperty()));
		}
		catch (SQLException exp)
		{
			LoadingException lExp = new LoadingException("error.iris.admin.im.pickupsql", new Object[] {getProcessId(),selectQuery}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch(ConfigException exp)
		{
			throw exp;
		}
		finally
		{
			HelperUtils.doClose(rsSelect);
			HelperUtils.doClose(psSelect);
		}
	}
	
	private void executeProcess ()
	{
		ResultSet jobRs = null;
		ExecutionJobData jobData = null;
		Session session = null;
		String dbResourceName = null;
		String srcType = null;
		RMJobData rmJobData = null;
		String executionId = null;
		String sellerCode = null;
		try
		{
			jobRs = jobStmt.executeQuery();
			dbResourceName = (String) getReferences().get(ReferencesEnum.DB_CONN);
			while (jobRs.next())
			{
				srcType = jobRs.getString(srcTypeStr);
				
				if ( IrisAdminConstants.DEFINITION_TYPE_REPORT.equals(srcType))
				{
					dbResource = getDBResource(dbResourceName);
					rmJobData = rmActivatorHelper.fetchJobData(jobRs, getFtpPath(),fileSenderName, dbResource);
					session = new IrisRMJobSession(rmJobData, getRmExecuteProcess());
					session.setApplicationContext(getApplicationContext());
					executionId = rmJobData.getExecutionId();
					sellerCode =  rmJobData.getSellerCode();
				}
				else
				{
					jobData = intActivatorHelper.fetchJobData(jobRs, isAccumulateErrors(), getFtpPath());
					if ( IrisAdminConstants.JOB_STATUS_LOADING_ISSUE.equals(jobData.getStatus()))
						updateError(jobData);
					else
					{
						session = new IMJobSession(getExecuteProcess(), jobData, dbResourceName, getDataObjectHelper());
						session.setApplicationContext(getApplicationContext());
						executionId = jobData.getExecutionId();
						sellerCode =  jobData.getSellerCode();
					}
				}
				
				if (updateJob(executionId, sellerCode))
				{
					addThreadInThreadPool(session, getReattemptSleepInSecs());
					dbConnection.commit();
				}
				srcType = null;
			}
			
			CONTINUE_THREAD = false;
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
			updateError(jobData);
			logger.error("Error occurred in runProcess...");
			rollback();
		}
		finally
		{
			CleanUpUtils.doClean(jobRs);
		}
	}
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	private Connection getDBConnection ()
	{
		String dbResourceName = null;
		try
		{
			dbResourceName = (String) getReferences().get(ReferencesEnum.DB_CONN);
			if (dbProvider == null)
			{
				if (dbResourceName != null)
					dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
				else
					dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN,
							ResourceTypeEnum.IRIS_DATABASE);
			}
			dbConnection = dbProvider.getConnection();
		}
		catch (Exception e)
		{
			logger.error("DB Error:", e);
			if ( dbConnection != null)
				cleanup();
		}
		return dbConnection;
	}
	
	/**
	 * This method checks connection alive or not
	 * 
	 * @param connection
	 * @return boolean
	 */
	private boolean isConnectionAlive ()
	{
		try
		{
			dbConnection.setAutoCommit(true);
			dbConnection.setAutoCommit(false);
		}// try
		catch (Exception e)
		{
			logger.error("Error:", e);
			intActivatorHelper.cleanUp();
			cleanup();
			return false;
		}// catch
		return true;
	}
	
	/**
	 * <p>
	 * This Helper method cleans up the connection by releasing to pool
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void cleanup ()
	{
		try
		{
			CleanUpUtils.doClean(jobStmt);
			CleanUpUtils.doClean(updateStmt);
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
			dbProvider = null;
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// DO NOTHING
		}
	}
	
	/**
	 * This helper method re creates the connection and should not throw any exception
	 * 
	 * @param boolean
	 * @return
	 */
	private boolean makeReconnection (int intCount)
	{
		try
		{
			if (intCount == 0)
				logger.warn("DATABASE CONNECTION LOST... " + "SO TRYING TO FETCH CONNECTION AGAIN");
			
			dbConnection = getDBConnection();
			if (dbConnection == null)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				Thread.sleep(getPoolingSleepInSecs() * 100);
			}
			else
			{
				jobStmt = null;
				updateStmt = null;
				initialiseStmts();
				return true;
			}
		}
		catch (InterruptedException e)
		{
			logger.error("Error:" + e.getMessage(), e);
		}
		catch (Exception e)
		{
			logger.error("Error:" + e.getMessage(), e);
		}
		
		return false;
	}
	
	/**
	 * @return the name
	 */
	public String getId ()
	{
		return id;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setId (String id)
	{
		this.id = id;
	}
	
	
	public boolean updateJob (String executionId, String sellerCode) throws SQLException
	{
		int updateCount = 0;
		
		updateStmt.clearParameters();
		updateStmt.setString(1, sellerCode);
		updateStmt.setString(2, executionId);
		updateCount = updateStmt.executeUpdate();
		logger.debug("Updated  jobs table with count:{}" , updateCount);
		return true;
	}
	
	private void rollback ()
	{
		try
		{
			dbConnection.rollback();
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
			// Ignore this exception
		}
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param updateSql
	 * @param interfaceType
	 * @throws SQLException
	 * </pre></p>
	 */
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param partialJobsSql
	 * @param interfaceType
	 * @throws SQLException
	 * </pre></p>
	 */
	private void initializeOldJobs (String partialJobsSql) throws ConfigException
	{
		PreparedStatement stJob = null;
		ConfigException cExp = null;
		ResultSet oldJbosRs = null;
		String executionId = null;
		ExecutionJobData jobData = null;
		
		try
		{
			stJob = dbConnection.prepareStatement(partialJobsSql);
			stJob.clearParameters();
			stJob.setString(1, srcType);
			stJob.setString(2, scheduleId);
			oldJbosRs = stJob.executeQuery();
			while(oldJbosRs.next())
			{
				jobData  = IrisAdminUtils.createErrorJOb(oldJbosRs);
				IrisAdminUtils.finishProcess("E", "Error", "Partially Executed", jobData , executionId, getApplicationContext(), false);
				jobData = null;
			}
			
		}
		catch(SQLException exp)
		{
			cExp = new ConfigException("error.iris.admin.im.pickupsql", new Object[] {getProcessId(),partialJobsSql}, exp);
			logger.error(IRISLogger.getText(cExp));
			throw cExp;
		}
		finally
		{
			HelperUtils.doClose(oldJbosRs);
			HelperUtils.doClose(stJob);
			jobData = null;
		}
	}


	/**
	 * TODO
	 * 
	 * @param executionJobData
	 */
	private void updateError (ExecutionJobData jobData)
	{
		
		String dbResourceName = null;
		
		try
		{
			dbResourceName = (String) getReferences().get(ReferencesEnum.DB_CONN);
			if ( jobData == null)
				 return;
			IrisAdminUtils.finishProcess("L", "IRIS-0001", "Not able to load the definition.", jobData, dbResourceName, getApplicationContext(), true);
		}
		catch (Exception e)
		{
			logger.error("Error While updating " , e);
			
		}
		finally
		{
		}
	}
	
		
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.beans.factory.DisposableBean#destroy()
	 */
	@Override
	public void destroy () throws Exception
	{
		
	}

	/**
	 * @param scheduleId the scheduleId to set
	 */
	public void setScheduleId (String scheduleId)
	{
		this.scheduleId = scheduleId;
	}

	/**
	 * @param srcType the srcType to set
	 */
	public void setSrcType (String srcType)
	{
		this.srcType = srcType;
	}


	/**
	 * @return the fileSenderName
	 */
	public String getFileSenderName ()
	{
		return fileSenderName;
	}


	/**
	 * @param fileSenderName the fileSenderName to set
	 */
	public void setFileSenderName (String fileSenderName)
	{
		this.fileSenderName = fileSenderName;
	}
}
