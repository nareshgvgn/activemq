/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.db.rm
 * FILE   : RMActivatorHelper.java
 * CREATED: Nov 17, 2015 6:17:04 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.db.rm;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.core.processor.resource.Resource;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.report.LoadReportDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: RMActivatorHelper.java,v 1.6 2016/10/03 10:22:08 ramap Exp $
 */
public class RMActivatorHelper implements Closeable
{
	private static Logger logger = LoggerFactory.getLogger(RMActivatorHelper.class);
	private final static String PARAMETER_NAME = "PARAMETER_NAME";
	private final static String PARAMETER_VALUE = "PARAMETER_VALUE";
	private final static String PARAMETER_TYPE = "PARAMETER_TYPE";
	private Connection dbConnection = null;
	private ApplicationContext applicationContext = null;
	private PreparedStatement secProfileStmt = null;
	private PreparedStatement parmsStmt = null;
	private Resource dbResource = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public RMActivatorHelper()
	{
		
	}
	
	public void initialize (Connection dbConnection, ApplicationContext applicationContext) throws SQLException
	{
		this.applicationContext = applicationContext;
		this.dbConnection = dbConnection;
		secProfileStmt = dbConnection.prepareStatement("select * from PRF_SECURITY_MST where PROFILE_ID =?");
		parmsStmt = dbConnection.prepareStatement("SELECT T.PARAMETER_TYPE,T.PARAMETER_NAME, T.PARAMETER_VALUE FROM IRIS_JOB_PARAM_TXN T WHERE "
					+ "T.EXECUTION_ID = ? ORDER BY T.SEQUENCE_NMBR ASC");
	}
	
	
	/**
	 * This helper method creates the dataObject by using Pick Up SQL result Set
	 * 
	 * @param rsPickup
	 * @return
	 */
	public RMJobData fetchJobData (ResultSet rsPickup, String ftpPath, String fileSenderName, Resource dbResource) throws LoadingException
	{
		RMJobData jobData = null;
		LoadingException lExp;
		
		String secProfileRecordKey = null;
		SecurityProfile secProfile = null;
		LoadReportDef loadDef = null;
		try
		{
			jobData = new RMJobData();
			jobData.setEntityCode(rsPickup.getString("ENTITY_CODE"));
			jobData.setSrcType(rsPickup.getString("SRC_TYPE"));
			jobData.setSrcId(rsPickup.getString("SRC_ID"));
			jobData.setSrcName(rsPickup.getString("SRC_NAME"));
			jobData.setSellerCode(rsPickup.getString("SELLER_CODE"));
			jobData.setExecutionId(rsPickup.getString("EXECUTION_ID"));
			jobData.setEntityType(rsPickup.getString("ENTITY_TYPE"));
			jobData.setStatus(rsPickup.getString("STATUS"));
			jobData.setChannelName(rsPickup.getString("CHANNEL_NAME"));
			jobData.setReportType(rsPickup.getString("SRC_SUB_TYPE"));
			jobData.setMediaDetails(rsPickup.getString("MEDIA_DTLS"));
			jobData.setRefId(rsPickup.getString("REF_ID"));
			jobData.setParentExecutionId(rsPickup.getString("PARENT_EXECUTION_ID"));
			jobData.setPriority(rsPickup.getString("PRIORITY"));
			jobData.setEntryDate(rsPickup.getDate("ENTRY_DATE"));
			jobData.setExecutionDate(rsPickup.getDate("EXECUTION_DATE"));
			jobData.setStartDate(rsPickup.getDate("START_DATE"));
			jobData.setEndDate(rsPickup.getDate("END_DATE"));
			setReportParams(jobData);
			jobData.setFtpPath(ftpPath);
			getReportPrefix(jobData);
			jobData.setFileSenderName(fileSenderName);
			setDBDetails(jobData, dbResource);
			secProfileRecordKey = jobData.getJobParameter(IrisAdminConstants.SECURITY_RECORD_KEY);
			secProfile = getSecurityProfile(secProfileRecordKey);
			jobData.setSecurityProfile(secProfile);
			jobData.setStatus("P");
			loadDef = new LoadReportDef(dbConnection, jobData);
			loadDef.loadData();
			
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.jobData", new Object[]{}, exp);
			logger.error(IRISLogger.getText(lExp));
			jobData.setStatus("L");
			//do not throw Exception
		}
		return jobData;
		
	}

	public String getFtpPath (String id, String ftpProperty) throws LoadingException
	{
		String sql = "SELECT PARAMETER_VALUE FROM SYSTEM_PARAMETERS_MST WHERE PARAMETER_CODE =?";
		PreparedStatement statement = null;
		ResultSet rSet = null;
		File ftpFile = null;
		String ftpPath = null;
		LoadingException lExp = null;
		
		try
		{
			statement = dbConnection.prepareStatement(sql);
			statement.clearParameters();
			statement.setString(1, ftpProperty);
			rSet = statement.executeQuery();
			if (rSet.next())
			{
				ftpPath = rSet.getString("PARAMETER_VALUE");
				ftpFile = new File(ftpPath);
				ftpPath = ftpFile.getAbsolutePath();
			}
			else
			{
				lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator [" + id + "] terminating! coz FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rSet);
			HelperUtils.doClose(statement);
			ftpFile = null;
		}
		
		return ftpPath;
	}
	
	
	private void setDBDetails (RMJobData jobData, Resource dbResource) throws LoadingException
	{
		
		Object dbSidObj = null;
		String dbHost = null;
		String dbUserId = null;
		String dbUserPwd = null;
		String portValue = null;
		Map<String, Object> dbResourceParamMap = null;
		String dbResourceName = null;
		LoadingException lExp = null;
		
		try
		{
			if (dbResource == null)
				return;
			
			dbResourceName = dbResource.getId();
			dbResourceParamMap = dbResource.getParams();
			dbUserId = (String) dbResourceParamMap.get("DBUSER");
			dbUserPwd = (String) dbResourceParamMap.get("DBPASSWORD");
			dbSidObj = dbResourceParamMap.get("DBSID");
			if (dbSidObj != null)
			{
				dbSidObj = (String) dbResourceParamMap.get("DBSID");
				dbHost = (String) dbResourceParamMap.get("DBHOST");
				portValue = (String) dbResourceParamMap.get("DBPORT");
				jobData.setDbHost(dbHost);
				jobData.setDbPort(portValue);
				jobData.setDbSid((String) dbSidObj);
				if (dbResourceParamMap.get("REPDBURL") != null)
					jobData.setRepDdUrl((String) dbResourceParamMap.get("REPDBURL"));
			}
			else
			{
				if (dbResourceParamMap.get("REPDBURL") == null)
					jobData.setDbUrl((String) dbResourceParamMap.get("DBURL"));
				else
					jobData.setRepDdUrl((String) dbResourceParamMap.get("REPDBURL"));
			}
			jobData.setDbUser(dbUserId);
			jobData.setDbPass(dbUserPwd);
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.dbconnection", new Object[]{dbResourceName}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			
		}
	}

	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param secProfileRecordKey
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private SecurityProfile getSecurityProfile (String secProfileRecordKey) throws LoadingException
	{
		SecurityProfile secProfile = null;
		ResultSet secRs = null;
		LoadingException lExp = null;
		try
		{
			secProfile = new SecurityProfile();
			if (secProfileRecordKey != null)
			{
				
				secProfileStmt.clearParameters();
				secProfileStmt.setString(1, secProfileRecordKey);
				secRs = secProfileStmt.executeQuery();
				if (secRs.next())
				{
					secProfile.setChannelCertName(secRs.getString("FTP_CERTIFICATE_NAME"));
					secProfile.setChannelBasePath(secRs.getString("FTP_BASE_DIRECTORY"));
					secProfile.setChannelIPAddress(secRs.getString("FTP_IPADDRESS"));
					secProfile.setChannelMode(secRs.getString("FTP_TRANSFER_MODE"));
					secProfile.setChannelPassword(secRs.getString("FTP_PASSWORD"));
					secProfile.setChannelPort(secRs.getInt("FTP_PORT"));
					secProfile.setChannelType(secRs.getString("FTP_PROTOCOL_TYPE"));
					secProfile.setChannelUser(secRs.getString("FTP_USER"));
					secProfile.setEmailId(secRs.getString("EMAIL_ID"));
					secProfile.setEncryptionAlgo(secRs.getString("ENCRYPTION_ALGO"));
					secProfile.setEncryptionKey(secRs.getString("ENCRYPTION_KEY"));
					secProfile.setEncryptionRequired(secRs.getString("ENCRYPTION_FLAG"));
					secProfile.setEncryptionType(secRs.getString("ENCRYPTION_TYPE"));
					secProfile.setEncryptionKeyLength(secRs.getInt("ENCRYPTION_KEY_LENGTH"));
					secProfile.setIntegrityAlgo(secRs.getString("INTEGRITY_CHECK_ALGO"));
					secProfile.setIntegrityCheckRequired(secRs.getString("INTEGRITY_CHECK_FLAG"));
					secProfile.setName(secRs.getString("PROFILE_NAME"));
					secProfile.setNotifySucess(secRs.getString("NOTIFY_SUCCESS"));
					secProfile.setNotifyFailure(secRs.getString("NOTIFY_FAIL"));
					secProfile.setPdfPassword(secRs.getString("PDF_PASSPHRASE"));
					secProfile.setSigningType(secRs.getString("SIGNING_TYPE"));
					secProfile.setSiginingRequired(secRs.getString("SIGNING_FLAG"));
					secProfile.setSiginingAlgo(secRs.getString("SIGNING_ALGO"));
					secProfile.setZipType(secRs.getString("ZIP_MODE"));
					secProfile.setZipPassword(secRs.getString("ZIP_PASSPHRASE"));
				}
			}
			
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.secProfile", new Object[]{secProfileRecordKey}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(secRs);
		}
		
		return secProfile;
	}
	
	
	/**
	 * This Helper method fetches the run time parameter values for given schedule id TODO
	 * 
	 * @param jobData
	 * @return
	 */
	private void setReportParams (RMJobData jobData) throws LoadingException
	{
		ResultSet rs = null;
		String parmType = null;
		LoadingException lExp = null;
		try
		{
			
			parmsStmt.clearParameters();
			parmsStmt.setString(1, jobData.getExecutionId());
			rs = parmsStmt.executeQuery();
			while (rs.next())
			{
				parmType = rs.getString(PARAMETER_TYPE);
				if ("RUNTIME".equals(parmType))
					jobData.addReportParameter(rs.getString(PARAMETER_NAME), rs.getString(PARAMETER_VALUE));
				else if ("JOB".equals(parmType))
					jobData.addJobParameter(rs.getString(PARAMETER_NAME), rs.getString(PARAMETER_VALUE));
				else if ("SYSTEM".equals(parmType))
					jobData.addSysParameter(rs.getString(PARAMETER_NAME), rs.getString(PARAMETER_VALUE));
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.reportParms", new Object[]{jobData}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rs);
		}
		
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		CleanUpUtils.doClean(secProfileStmt);
		CleanUpUtils.doClean(parmsStmt);
		
	}
	
	/**
	 * @return the dbResource
	 */
	private void  fetchDbResource (String resourceId) throws LoadingException
	{
		LoadingException lExp = null;
		
		try
		{
			if ( dbResource == null)
				dbResource = applicationContext.getProcessDefinition().getResource(resourceId);
		}
		catch (ConfigurationException exp)
		{
			lExp = new LoadingException("error.admin.dbResourceId", new Object[]{ "FTP path not found", resourceId}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch ( Exception exp)
		{
			lExp = new LoadingException("error.admin.dbResourceId", new Object[]{ "FTP path not found", resourceId}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
	}
	
	public Resource getDBResource(String resourceId) throws LoadingException
	{
		if ( dbResource == null)
			 fetchDbResource(resourceId);
		return dbResource;
	}
	
	public  void getReportPrefix (RMJobData jobData) throws LoadingException
	{
		String sql = "SELECT PARAMETER_VALUE, PARAMETER_CODE  FROM SYSTEM_PARAMETERS_MST WHERE PARAMETER_CODE in ('REPINSTNAME')";
		PreparedStatement statement = null;
		ResultSet rSet = null;
		LoadingException lExp = null;
		String reportCodePrefix = null;
		
		try
		{
			statement = dbConnection.prepareStatement(sql);
			statement.clearParameters();
			rSet = statement.executeQuery();
			while(rSet.next())
			{
				reportCodePrefix = rSet.getString("PARAMETER_VALUE");
				jobData.setReportCodePrefix(reportCodePrefix);
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator  terminating! coz FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "Activator  terminating! coz FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rSet);
			HelperUtils.doClose(statement);
		}
	}

}
