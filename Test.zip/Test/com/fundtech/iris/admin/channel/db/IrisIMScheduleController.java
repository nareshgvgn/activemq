/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.db
 * FILE   : IrisIMScheduleController.java
 * CREATED: Jul 29, 2015 9:56:34 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.util.CleanUpUtils;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.activator.session.IMScheduleSession;
import com.fundtech.iris.admin.channel.AbstractActivator;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.ReferencesEnum;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ConfigException;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisIMScheduleController.java,v 1.15 2016/12/08 11:25:42 ramap Exp $
 */
public class IrisIMScheduleController extends AbstractActivator  implements Runnable
{
	private static final Logger logger = LoggerFactory.getLogger(IrisIMScheduleController.class);
	private String id = "SCH";
	private ConnectionProvider dbProvider = null;
	private Connection dbConnection = null;
	private PreparedStatement jobStmt = null;
	private PreparedStatement updateStmt = null;
	private ActivatorHelper activatorHelper = null;
	private int localPoolingInMilliSecs = 0;
	private String jobActivatorBeanName = null;
	private String dbResourceName = null;
	private String hookToCall =  null;
	private String srcType = "SCH_SEGMENTED";
	private String sessionId = "SCG";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run ()
	{
		int intCount = 0;
		try
		{
			localPoolingInMilliSecs = getPoolingSleepInSecs() * 100;
			activatorHelper = new ActivatorHelper();
			dbConnection = getDBConnection();
			
			if (dbConnection != null)
				initialiseStmts();
			
			while (true)
			{
				
				if (!isConnectionAlive())
				{
					
					if (makeReconnection(intCount))
						intCount = 0;
					else
						intCount = 1;
				}
				else
					executeProcess();
				
				Thread.sleep(localPoolingInMilliSecs);
			}
		}
		catch (Exception se)
		{
			logger.error("Error:",se);
			throw new RuntimeException("Activator [" + id + "] terminating!");
		}
		finally
		{
		}
		
	}
	
	
	public void start () throws Exception
	{
		Thread myThread = null;
		resolveIds();
		myThread = new Thread(this, id);
		myThread.start();
	}
	
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------*
 * HELPER METHODS
 *----------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre></p>
	 */
	private void resolveIds ()
	{
		if ( "SCH_SEGMENTED".equals(srcType))
		{
			id = "SCG";
			sessionId = "SCG";
		}
		else if ( IrisAdminConstants.SCH_PROFILE.equals(srcType))
		{
			id = "PRF";
			sessionId = "PRF";
		}
		
		
	}


	/**
	 * This helper method picks the SQL from IL_INTERFACE_MST, and binds it to this instance of activator
	 * 
	 * @throws ConfigurationException
	 * @throws SQLException
	 */
	private void initialiseStmts () throws  ConfigException, LoadingException
	{
		PreparedStatement psSelect = null;
		String partialJobsSql = null;
		ResultSet rsSelect = null;
		String strPickupSql = null;
		String selectQuery = "SELECT PICKUP_SQL,  INSERT_SQL1, INSERT_SQL2 FROM IL_INTERFACE_MST WHERE TXNCODE = ?";
		String updateQuery = null;
		ConfigException cExp = null;
		
		try
		{
			psSelect = dbConnection.prepareStatement(selectQuery);
			psSelect.clearParameters();
			psSelect.setInt(1, getProcessId());
			rsSelect = psSelect.executeQuery();
			if (rsSelect.next())
			{
				strPickupSql = rsSelect.getString("PICKUP_SQL");
				updateQuery = rsSelect.getString("INSERT_SQL1");
				partialJobsSql = rsSelect.getString("INSERT_SQL2");
				hookToCall = getHookToCall();
				
				if ( updateQuery == null)
					updateQuery = "UPDATE IRIS_JOB_QUEUE SET STATUS = 'P', END_DATE = null,  SYS_START_DATE = SYSDATE, START_DATE = pk_timezone.get_seller_time(?) "
							+ "	 WHERE EXECUTION_ID = ? AND STATUS = 'N'";
				
				if (logger.isInfoEnabled())
				{
					logger.info("Pickup SQL:" + strPickupSql);
					logger.info("Type of(U/D) interfaces executing: " + srcType);
				}
			}
			else
			{
				cExp = new ConfigException("error.iris.admin.im.pickupsql", new Object[] {getProcessId(),selectQuery}, null);
				logger.error(IRISLogger.getText(cExp));
				throw cExp;
			}
			initializeOldJobs(partialJobsSql);
			jobStmt = dbConnection.prepareStatement(strPickupSql);
			jobStmt.clearParameters();
			jobStmt.setString(1, srcType);
			updateStmt = dbConnection.prepareStatement(updateQuery);
			activatorHelper.initialize(dbConnection, getApplicationContext());
		}
		catch (SQLException exp)
		{
			LoadingException lExp = new LoadingException("error.iris.admin.im.pickupsql", new Object[] {getProcessId(),selectQuery}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch(ConfigException exp)
		{
			throw exp;
		}
		finally
		{
			HelperUtils.doClose(rsSelect);
			HelperUtils.doClose(psSelect);
		}
	}
	
	
	
	private void executeProcess ()
	{
		ResultSet jobRs = null;
		ExecutionJobData jobData = null;
		IMScheduleSession session = null;
		IrisIMScheduleJobActivator jobActivator = null;
		int maxThreads = 0;
		
		try
		{
			jobRs = jobStmt.executeQuery();
			while (jobRs.next())
			{
				jobData = activatorHelper.fetchJobData(jobRs, isAccumulateErrors(), null);
				if ( IrisAdminConstants.JOB_STATUS_LOADING_ISSUE.equals(jobData.getStatus()))
					updateError(jobData);
				else if (updateJob(jobData.getExecutionId(), jobData.getSellerCode()))
				{
					/*
					 * Get the activator Bean
					 * sets thread pool size to it
					 * set the ID to actvator so that logger will be clean
					 * sets schedule id , so that activator pics only that schduled data
					 */
					jobActivator = (IrisIMScheduleJobActivator) getBean(jobActivatorBeanName);
					maxThreads = activatorHelper.getMaxThreads(jobData.getRefId());
					jobActivator.setMaxPoolSize(maxThreads);// need to get Dynamic Value
					jobActivator.setMinPoolSize(1);// put minimum as max thread could be less thann min threads 
					jobActivator.setId(sessionId);
					jobActivator.setSrcType(srcType);
					jobActivator.setScheduleId(jobData.getRefId());
					jobActivator.initializeActivatorPool();
					session = new IMScheduleSession(jobData, jobActivator, dbResourceName);
					session.setApplicationContext(getApplicationContext());
					session.setHookToCall(hookToCall);
					session.setId(sessionId);
					addThreadInThreadPool(session, getReattemptSleepInSecs());
					dbConnection.commit();
				}
			}
		}
		catch ( LoadingException exp)
		{
			logger.error("Error:",exp);
			updateError(jobData);
		}
		catch (Exception e)
		{
			logger.error("Error:",e);
			updateError(jobData);
			logger.error("Error occurred in runProcess...");
			rollback();
		}
		finally
		{
			CleanUpUtils.doClean(jobRs);
		}
	}
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	private Connection getDBConnection ()
	{
		
		try
		{
			dbResourceName = (String) getReferences().get(ReferencesEnum.DB_CONN);
			if (dbProvider == null)
			{
				if (dbResourceName != null)
					dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
				else
					dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN,
							ResourceTypeEnum.IRIS_DATABASE);
			}
			dbConnection = dbProvider.getConnection();
		}
		catch (Exception e)
		{
			logger.error("DB Error:", e);
			if ( dbConnection != null)
				cleanup();
		}
		return dbConnection;
	}
	
	/**
	 * This method checks connection alive or not
	 * 
	 * @param connection
	 * @return boolean
	 */
	private boolean isConnectionAlive ()
	{
		try
		{
			dbConnection.setAutoCommit(true);
			dbConnection.setAutoCommit(false);
		}// try
		catch (Exception e)
		{
			logger.error("Error:", e);
			activatorHelper.cleanUp();
			cleanup();
			return false;
		}// catch
		return true;
	}
	
	/**
	 * <p>
	 * This Helper method cleans up the connection by releasing to pool
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void cleanup ()
	{
		try
		{
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
			dbProvider = null;
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
	}
	
	/**
	 * This helper method re creates the connection and should not throw any exception
	 * 
	 * @param boolean
	 * @return
	 */
	private boolean makeReconnection (int intCount)
	{
		try
		{
			if (intCount == 0)
				logger.warn("DATABASE CONNECTION LOST... " + "SO TRYING TO FETCH CONNECTION AGAIN");
			
			dbConnection = getDBConnection();
			if (dbConnection == null)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				Thread.sleep(getPoolingSleepInSecs() * 100);
			}
			else
			{
				jobStmt = null;
				updateStmt = null;
				initialiseStmts();
				return true;
			}
		}
		catch (InterruptedException e)
		{
			logger.error("Error:" + e.getMessage(), e);
		}
		catch (Exception e)
		{
			logger.error("Error:" + e.getMessage(), e);
		}
		
		return false;
	}
	
	/**
	 * @return the name
	 */
	public String getId ()
	{
		return id;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setId (String id)
	{
		this.id = id;
	}
	
	
	public boolean updateJob (String executionId, String sellerCode) throws SQLException
	{
		int updateCount = 0;
		
		updateStmt.clearParameters();
		updateStmt.setString(1, sellerCode);
		updateStmt.setString(2, executionId);
		updateCount = updateStmt.executeUpdate();
		logger.debug("Updated  jobs table with count:{}" , updateCount);
		return true;
	}
	
	private void rollback ()
	{
		try
		{
			dbConnection.rollback();
		}
		catch (Exception e)
		{
			logger.error("Error:",e);
			// Ignore this exception
		}
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param updateSql
	 * @param interfaceType
	 * @throws SQLException
	 * </pre></p>
	 */
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param partialJobsSql
	 * @param interfaceType
	 * @throws SQLException
	 * </pre></p>
	 */
	private void initializeOldJobs (String partialJobsSql) throws ConfigException
	{
		PreparedStatement stJob = null;
		ConfigException cExp = null;
		ResultSet oldJbosRs = null;
		String executionId = null;
		ExecutionJobData jobData = null;
		
		try
		{
			stJob = dbConnection.prepareStatement(partialJobsSql);
			stJob.clearParameters();
			stJob.setString(1, srcType);
			oldJbosRs = stJob.executeQuery();
			while(oldJbosRs.next())
			{
				jobData  = IrisAdminUtils.createErrorJOb(oldJbosRs);
				IrisAdminUtils.finishProcess("E", "Error", "Partially Executed", jobData , executionId, getApplicationContext(), true);
				jobData = null;
			}
			
		}
		catch(SQLException exp)
		{
			cExp = new ConfigException("error.iris.admin.im.pickupsql", new Object[] {getProcessId(),partialJobsSql}, exp);
			logger.error(IRISLogger.getText(cExp));
			throw cExp;
		}
		finally
		{
			HelperUtils.doClose(oldJbosRs);
			HelperUtils.doClose(stJob);
			jobData = null;
		}
	}


	/**
	 * TODO
	 * 
	 * @param executionJobData
	 */
	private void updateError (ExecutionJobData jobData)
	{
		
		String dbResourceName = null;
		
		try
		{
			dbResourceName = (String) getReferences().get(ReferencesEnum.DB_CONN);
			if ( jobData == null)
				 return;
			IrisAdminUtils.finishProcess("L", "IRIS-0001", "Not able to load the definition.", jobData, dbResourceName, getApplicationContext(), true);
		}
		catch (Exception e)
		{
			logger.error("Error While updating " , e);
			
		}
		finally
		{
		}
	}
	
	@Override
	public void afterPropertiesSet ()
	{
		LoadingException lExp = null;
		try
		{
			if (-1 == getProcessId())
			{
				logger.error("Process Code not configured!!");
				lExp = new LoadingException("error.iris.admin.evennt.propertynotconfigured", new Object[]{ "processId" }, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
			
			if (jobActivatorBeanName == null)
			{
				logger.error("Process Code not configured!!");
				lExp = new LoadingException("error.iris.admin.evennt.propertynotconfigured", new Object[]{ "executeProcess" }, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
			
			if (srcType == null)
			{
				logger.error("Schedule Source Type not configured!!");
				lExp = new LoadingException("error.iris.admin.evennt.propertynotconfigured", new Object[]{ "srcType" }, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
			
			initializeActivatorPool();
		}
		catch (Exception exp)
		{
			throw new IllegalStateException(exp);
		}
	}

	/**
	 * @param jobActivatorBeanName the jobActivatorBeanName to set
	 */
	public void setJobActivatorBeanName (String jobActivatorBeanName)
	{
		this.jobActivatorBeanName = jobActivatorBeanName;
	}
	

	/**
	 * @param hookToCall the hookToCall to set
	 */
	private String getHookToCall()
	{
		String hookToCall = null;
		
		if ( IrisAdminConstants.SCH_SEGMENTED.equals(srcType))
			hookToCall = "{CALL pkg_integrate_host.host_handoff_wrapper(?,?,?,?,?)}";
		else if ( IrisAdminConstants.SCH_PROFILE.equals(srcType))
			hookToCall = "{CALL pkg_iris_admin.schedule_profile_wrapper(?,?,?,?,?)}";
		
		return hookToCall;
	}


	/**
	 * @param srcType the srcType to set
	 */
	public void setSrcType (String srcType)
	{
		this.srcType = srcType;
	}

}
