/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.dir
 * FILE   : FromFileProcIdentifier.java
 * CREATED: Sep 6, 2016 3:58:48 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.dir;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.cashtech.iris.exceptions.ConfigurationException;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.Identifier;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: FromFileProcIdentifier.java,v 1.1 2016/09/07 10:35:28 ramap Exp $
 */
public class FromFileProcIdentifier implements Identifier
{
	private int mapCodePosition = 0;
	private String  filenameSplitChar = "_";
	
	private Map<String, String> properties = null;
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public FromFileProcIdentifier()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.Identifier#setProperties(java.util.Map)
	 */
	@Override
	public void setProperties (Map<String, String> properties)
	{
		this.properties = properties;
		
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.Identifier#initialize()
	 */
	@Override
	public void initialize () throws ConfigurationException
	{
		// BABU Auto-generated method stub
		
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.Identifier#identify(java.lang.Object)
	 */
	@Override
	public Object identify (Object source) throws ExecutionException
	{
		Map<String, String> outData = null;
		String mapName = null;
		String processName = null;
		String entityType = null;
		String entityCode = null;
		String fileName = null;
		Map<String, Object> inputData = null;
		
		processName = properties.get("ExecuteIRISProcess");
		inputData = (Map<String, Object>)source;
		fileName = (String) inputData.get(IrisAdminConstants.MEDIA_DETAIL);
		
		mapName = getMapCode(fileName);
		entityType = properties.get("EntityType");
		entityCode = properties.get("EntityCode");
		outData = new HashMap<String, String>();
		outData.put(IrisAdminConstants.MAP_NAME, mapName);
		outData.put(IrisAdminConstants.ENTITY_TYPE, entityType);
		outData.put(IrisAdminConstants.ENTITY_CODE, entityCode);
		outData.put(IrisAdminConstants.EXECUTE_PROCESS, processName);
		return outData;
	}
	
	private String getMapCode(String inputFileName)
	{
		String outValue = null;
		String[] strArray = null;
		File file = null;
		
		file = new File(inputFileName);
		
		strArray = StringUtils.split(file.getName(), filenameSplitChar);
		outValue = strArray[mapCodePosition];
		return outValue;
	}

	/**
	 * @param mapCodePosition the mapCodePosition to set
	 */
	public void setMapCodePosition (int mapCodePosition)
	{
		this.mapCodePosition = mapCodePosition - 1;
	}

	/**
	 * @param filenameSplitChar the filenameSplitChar to set
	 */
	public void setFilenameSplitChar (String filenameSplitChar)
	{
		this.filenameSplitChar = filenameSplitChar;
	}
	
}
