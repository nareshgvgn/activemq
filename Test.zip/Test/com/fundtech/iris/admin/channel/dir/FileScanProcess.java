/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.dir
 * FILE   : FileScanProcess.java
 * CREATED: Dec 6, 2014 4:32:02 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.dir;

import java.io.File;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractActivator;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.ReferencesEnum;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p> This bean helps to scan a dir, as soon as it finds file, moves the file in configured DIr in property  <i><b>processingDir</b></i> for further processing.
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * &lt;bean id="Default-DirProcIdentifier" class="com.fundtech.iris.admin.channel.dir.IrisAdminDirProcIdentifier"&gt;
		&lt;property name="properties"&gt;
    		&lt;map&gt;
           		&lt;entry key="MapName" value="INTRADAYRES" /&gt;
           		&lt;entry key="ExecuteIRISProcess" value="IrisAdminUpload" /&gt;
           		&lt;entry key="EntityType" value="BANK" /&gt;
           		&lt;entry key="EntityCode" value="BANK" /&gt;
        	&lt;/map&gt;
  		&lt;/property&gt;
	&lt;/bean&gt;
	
	&lt;bean id="DirUpload" class="com.fundtech.iris.admin.channel.dir.FileScanProcess"&gt;
		&lt;property name="references"&gt;
			&lt;util:map id="references" key-type="com.fundtech.iris.admin.channel.ReferencesEnum"&gt;
        		&lt;entry key="DB_CONN" value="IRIS_DB"/&gt;
			&lt;/util:map&gt;
		&lt;/property&gt;
		&lt;property name="procIdentifier" ref="Default-DirProcIdentifier"/&gt;
		&lt;property name="accumulateErrors" value="true"/&gt;
		&lt;property name="processingDir" value="c:/temp/output"/&gt;
		&lt;property name="appendDate" value="true"/&gt;
	&lt;/bean&gt;
	
	&lt;bean  id="DirFilter" class="com.fundtech.iris.admin.channel.dir.FileScanFilter"&gt;
		&lt;property name="timeDifference" value="10000" /&gt;
	&lt;/bean&gt;
	
	&lt;bean id ="ScanOnce" class="org.springframework.integration.file.filters.AcceptOnceFileListFilter"/&gt;
	
	&lt;bean id="compositeFilter" class="org.springframework.integration.file.filters.CompositeFileListFilter"&gt;
    &lt;constructor-arg&gt;
        &lt;list&gt;
            &lt;ref bean="ScanOnce"/&gt;
            &lt;ref bean="DirFilter"/&gt;
        &lt;/list&gt;
    &lt;/constructor-arg&gt;
&lt;/bean&gt;

	&lt;int:service-activator input-channel="filesInChannel" ref="DirUpload" method="process" /&gt;
	
	&lt;int-file:inbound-channel-adapter id="filesInChannel" directory="file:/c:/temp/input" filter="compositeFilter"&gt;
		&lt;int:poller id="poller" fixed-rate="100" task-executor="DirScan" /&gt;
	&lt;/int-file:inbound-channel-adapter&gt;

	&lt;task:executor id="DirScan" pool-size="10" /&gt;
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">IRIS Admin</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>IrisAdminFileScanContext.xml</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: FileScanProcess.java,v 1.16 2016/07/14 06:59:29 ramap Exp $
 */
public class FileScanProcess extends AbstractActivator
{
	private static Logger logger = LoggerFactory.getLogger(FileScanProcess.class);
	private String processingDir = null;
	private boolean appendDate = true;
	

	public File process(File file) throws Exception
	{	
		File outFile = null;
		File processingFile = null;
		File finalFile = null;
		String inputFileName = null;
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		Map<String, Object> inputParms = null;
		ConnectionProvider dbProvider = null;
		ExecutionJobData jobData = null;
		String dbResourceName = null;
		try
		{
			inputFileName = file.getName();
			if ( appendDate)
			{
				SimpleDateFormat ft = new SimpleDateFormat ("yyMMddHHmmss");
				Date date = new Date();
				inputFileName = inputFileName + ft.format(date);
			}
			outFile = new File(processingDir);
			FileUtils.forceMkdir(outFile);
			processingFile = new File(outFile, inputFileName);
			
			logger.debug("File:{} is will be moved to Dir:{} for further processing!.", file.getAbsolutePath(), processingDir);
			
			FileUtils.moveFile(file, processingFile);
			
			activatorHelper = new ActivatorHelper();
			dbResourceName = getReferences().get(ReferencesEnum.DB_CONN);
			dbProvider = IrisAdminUtils.getDBProvider(dbResourceName, getApplicationContext());
			dbConnection = dbProvider.getConnection();
			activatorHelper.initialize(dbConnection, getApplicationContext());
			inputParms = new HashMap<String, Object>();
			inputParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, getProcIdentifier());
			inputParms.put(IrisAdminConstants.CHANNEL, IrisAdminConstants.CHANNEL_DIR);
			inputParms.put(IrisAdminConstants.MEDIA_DETAIL, processingFile.getAbsolutePath());
			inputParms.put(IrisAdminConstants.DATAOBJECT_HELPER, getDataObjectHelper());
			jobData = activatorHelper.runProcess(inputParms, IrisAdminConstants.MEDIA_FILE, isAccumulateErrors(), null);
			
			if(jobData != null)
				finalFile = new File(jobData.getMediaDetails());
			return finalFile;
		}
		catch ( Exception exp)
		{
			logger.error("Error While executing Dir Sacn Process" , exp);
		}
		finally
		{
			if (jobData != null)
				jobData.cleanup();
			activatorHelper.cleanUp();
			IrisAdminUtils.cleanup(dbProvider, dbConnection);
		}
		return processingFile;
	}
	
	/**
	 * @return the processingDir
	 */
	public String getProcessingDir ()
	{
		return processingDir;
	}


	/**
	 * @param processingDir the processingDir to set
	 */
	public void setProcessingDir (String processingDir)
	{
		this.processingDir = processingDir;
	}

	
	@Override
	public void afterPropertiesSet ()
	{
	}

	/**
	 * @return the appendDate
	 */
	public boolean isAppendDate ()
	{
		return appendDate;
	}

	/**
	 * @param appendDate the appendDate to set
	 */
	public void setAppendDate (boolean appendDate)
	{
		this.appendDate = appendDate;
	}
}
