/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.dir
 * FILE   : FileScanFilter.java
 * CREATED: Dec 6, 2014 4:30:56 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.dir;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.file.filters.FileListFilter;

/**
 * <p>This is a helper bean, which filters the file which is not modified before given time (timeDifference).
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 *&lt;bean  id="DirFilter" class="com.fundtech.iris.admin.channel.dir.FileScanFilter"&gt;
		&lt;property name="timeDifference" value="${DirFilter.timeDifference}" /&gt;
	&lt;/bean&gt;
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">IRIS Admin</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>IrisAdminFileScanContext.xml</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: FileScanFilter.java,v 1.3 2015/02/04 12:37:50 ramap Exp $
 */
public class FileScanFilter implements FileListFilter<File>
{
	
	private static final Logger logger = LoggerFactory.getLogger(FileScanFilter.class);
    long timeDifference = 1000L;
 
    public boolean accept(File file) 
    {
    	String fileName = null;
    	long lastModified = file.lastModified();
 	    long currentTime = System.currentTimeMillis();
 	    long timeDiff = 0;
    	
 	    if ( file.isDirectory())
 	    	return false;
 	    fileName = file.getName();
    	
	    if (".".equals(fileName) || "..".equals(fileName)) 
	        return false;
	    
	    timeDiff = currentTime - lastModified;
	    logger.trace("Time Difference: {}", timeDiff);
	    
	    if (timeDiff > timeDifference )
	    	
	    	return true;
	    else if (timeDiff < 0)
	    	
	    	return true;
	    else
	    	return false;
	    	
    }
 
    public void setTimeDifference(long timeDifference) 
    {
         this.timeDifference = timeDifference;
    }
    
	public  String getFilename(File file) {
		return (file != null) ? file.getName() : null;
	}

	public final List<File> filterFiles(File[] files) 
	{
        List<File> accepted = new ArrayList<File>();
        if (files != null) 
        {
            for (File file : files) 
            {
                if (this.accept(file)) 
                    accepted.add(file);
            }
        }
        return accepted;
    }
}

