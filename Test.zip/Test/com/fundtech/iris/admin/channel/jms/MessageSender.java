/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.jms
 * FILE   : MessageSender.java
 * CREATED: Jul 12, 2016 3:16:32 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.jms;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractRequestReceiver;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.IAuditHandler;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: MessageSender.java,v 1.1 2016/07/15 09:37:46 ramap Exp $
 */
public class MessageSender  extends AbstractRequestReceiver
{
	private static Logger logger = LoggerFactory.getLogger(MessageSender.class);
	private JmsTemplate jmsTemplate = null;
	private ProducerConsumerCallback sessionCallBack = null; 
	private Map<String, String> headerProperties = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 * @param applicationContext
	 */
	public MessageSender()
	{
		super();
	}
	
	public void sendMessage( Map<String, Object> inputParms) throws ExecutionException
	{
		ExecutionException eExp = null;
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		ExecutionJobData jobData = null;
		Map<String, Object> outputParms = null;
		Map<String, Object> auditParms = null;
		IAuditHandler auditHandler = null;
		
		try
		{
			jobData = (ExecutionJobData) inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			auditHandler = getAuditHandler();
			sessionCallBack.setJobData(jobData);
			sessionCallBack.setRetryHandler(getRetryHandler());
			sessionCallBack.setHeaderProperties(getHeaderProperties());
			auditParms = new HashMap<String, Object>();
			auditParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
			auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, jobData.getMessageData());
			auditHandler.audit(auditParms, IAuditHandler.REQUEST_TYPE);
			// Must pass true as the second param to start the connection
			getJmsTemplate().execute( sessionCallBack, true );
		}
		catch (Exception exp)
		{
			eExp = new ExecutionException("error.iris.admin.chain.sending", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		finally
		{
			CleanUpUtils.doClean(auditParms);
			CleanUpUtils.doClean(inputParms);
			CleanUpUtils.doClean(outputParms);
			if ( activatorHelper != null)
				activatorHelper.cleanUp();
			cleanup(dbConnection);
			
		}
		
	}
	
	public void setJmsTemplate (JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}
	
	/**
	 * @return the jmsTemplate
	 */
	public JmsTemplate getJmsTemplate ()
	{
		return jmsTemplate;
	}

	/**
	 * @return the sessionCallBack
	 */
	public ProducerConsumerCallback getSessionCallBack ()
	{
		return sessionCallBack;
	}

	/**
	 * @param sessionCallBack the sessionCallBack to set
	 */
	public void setSessionCallBack (ProducerConsumerCallback sessionCallBack)
	{
		this.sessionCallBack = sessionCallBack;
	}

	/**
	 * @return the headerProperties
	 */
	public Map<String, String> getHeaderProperties ()
	{
		return headerProperties;
	}

	/**
	 * @param headerProperties the headerProperties to set
	 */
	public void setHeaderProperties (Map<String, String> headerProperties)
	{
		this.headerProperties = headerProperties;
	}
	
	
	
}