/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator
 * FILE   : IrisAdminJMSActivator.java
 * CREATED: Apr 22, 2014 11:53:20 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.jms;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.listener.SessionAwareMessageListener;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractActivator;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.ReferencesEnum;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.DefaultJMSMetadata;

/**
 * 
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IrisAdminJMSActivator.java,v 1.11 2015/12/25 08:16:23 ramap Exp $
 */
public class IrisAdminJMSActivator extends AbstractActivator implements SessionAwareMessageListener<Message>
{
	
	private static final Logger logger = LoggerFactory.getLogger(IrisAdminJMSActivator.class);
	
	private boolean isReadUTF = false;
	private ConnectionProvider dbProvider = null;
	
	public void onMessage (Message message, Session session)
	{
		String currId = null;
		String inputMsg = null;
		String messageId = null;
		int length = 0;
		final int BUFLEN = 64;
		StringBuffer messageBuff = null;
		Map<String, Object> jmsHeaderData = null;
		
		try
		{
			currId = Thread.currentThread().getName();
			if (message instanceof TextMessage)
			{
				TextMessage textMessage = (TextMessage) message;
				inputMsg = textMessage.getText();
				if (logger.isDebugEnabled())
					logger.debug("Message received:-\n" + inputMsg);
				messageId = textMessage.getJMSMessageID();
				jmsHeaderData = DefaultJMSMetadata.getMessageHeaders(textMessage);
			}
			else if (message instanceof BytesMessage)
			{
				BytesMessage byteMessage = (BytesMessage) message;
				if (isReadUTF)
					inputMsg = byteMessage.readUTF();
				else
				{
					messageBuff = new StringBuffer();
					while (length != -1)
					{
						byte[] array = new byte[BUFLEN];
						length = byteMessage.readBytes(array);
						if (length != -1)
							messageBuff.append(new String(array));
						
						array = null;
					}
					inputMsg = messageBuff.toString().trim();
				}
				
				if (logger.isDebugEnabled())
					logger.debug("Message received:-\n" + inputMsg);
				messageId = byteMessage.getJMSMessageID();
				jmsHeaderData = DefaultJMSMetadata.getMessageHeaders(byteMessage);
			}
			else
			{
				if (logger.isDebugEnabled())
					logger.debug("Received: " + message);
				finishTransaction(session, true);
				return;
			}
			
			runProcess(inputMsg, messageId, jmsHeaderData);
			finishTransaction(session, true);
		}
		catch (JMSException jmsEx)
		{
			logger.warn("JMS Message is rolling Back!!");
			logger.error(IRISLogger.getNodeProcExText("error.app.errorListeningMessage", new Object[] {}, jmsEx));
			finishTransaction(session, false);
		}
		
		catch (ExecutionException npEx)
		{
			logger.error("Error:",npEx);
			finishTransaction(session, true);
		}
		catch (LoadingException exp)
		{
			logger.error("Error:",exp);
			if ( IrisAdminConstants.ERR_CODE_DB_NULL.equals(exp.getKey()))
			{
				logger.warn("JMS Message is rolling Back!!");
				finishTransaction(session, false);
			}
		}
		catch (Exception ex)
		{
			logger.warn("JMS Message is rolling Back!!");
			logger.error(IRISLogger.getNodeProcExText("error.app.errorListeningMessage", new Object[] {}, ex));
			finishTransaction(session, false);
		}
		finally
		{
			if (currId != null)
				Thread.currentThread().setName(currId);
		}
	}
	
	private void runProcess (String inputMsg, String messageId, Map<String, Object> jmsHeaderData) throws ExecutionException, LoadingException
	{
		ExecutionException eExp = null;
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		Map<String, Object> inputParms = null;

		try
		{
			activatorHelper = new ActivatorHelper();
			dbConnection = getDBProvider().getConnection();
			activatorHelper.initialize(dbConnection, getApplicationContext());
			inputParms = new HashMap<String, Object>();
			inputParms.put(IrisAdminConstants.MEDIA_DETAIL, messageId);
			inputParms.put(IrisAdminConstants.JMS_HEADER_DATA, jmsHeaderData);
			inputParms.put(IrisAdminConstants.JMS_MESSAGE, inputMsg);
			inputParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, getProcIdentifier());
			inputParms.put(IrisAdminConstants.CHANNEL, IrisAdminConstants.CHANNEL_JMS);
			inputParms.put(IrisAdminConstants.AUDIT_SOURCE, getAuditHandler());
			inputParms.put(IrisAdminConstants.DATAOBJECT_HELPER, getDataObjectHelper());
			activatorHelper.runProcess(inputParms, IrisAdminConstants.MEDIA_MQ, isAccumulateErrors(), null);
			
			
		}
		catch ( ExecutionException exp)
		{
			if ( "".equals(exp.getKey()))
				throw exp;
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.process", new Object[] {}, exp);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch (SystemException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (SQLException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			activatorHelper.cleanUp();
			cleanup(dbConnection);
		}
	}
	
	private void finishTransaction (Session session, boolean commit)
	{
		boolean isTransacted = false;
		
		try
		{
			isTransacted = session.getTransacted();
			if (isTransacted)
			{
				if (commit)
					session.commit();
				else
					session.rollback();
			}
		}
		catch (JMSException ex)
		{
			logger.warn("Error in finishTransaction", ex);
		}
	}
	
	/**
	 * @return the isReadUTF
	 */
	public boolean isReadUTF ()
	{
		return isReadUTF;
	}
	
	/**
	 * @param isReadUTF
	 *            the isReadUTF to set
	 */
	public void setReadUTF (boolean isReadUTF)
	{
		this.isReadUTF = isReadUTF;
	}
	
	protected String getExecutionId (String interfaceName, String executionId)
	{
		String pidRet = null;
		
		try
		{
			pidRet = "JMS_" + interfaceName + "_" + executionId;
		}
		finally
		{
		}
		if (logger.isInfoEnabled())
			logger.info("Changing thread name [" + Thread.currentThread().getName() + "] to [" + pidRet + "]");
		Thread.currentThread().setName(pidRet);
		return pidRet;
	}
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	private ConnectionProvider getDBProvider () throws LoadingException
	{
		String dbResourceName = null;
		LoadingException lExp = null;
		try
		{
			dbResourceName = getReferences().get(ReferencesEnum.DB_CONN);
			if (dbProvider == null)
			{
				if (dbResourceName != null)
					dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
				else
					dbProvider = new ConnectionProviderAdapter(getApplicationContext().getResourceFinder(), ResourceTypeEnum.DB_CONN,
							ResourceTypeEnum.IRIS_DATABASE);
			}
		}
		catch (Exception exp)
		{
			logger.error("DB Error:", exp);
			lExp = new LoadingException(IrisAdminConstants.ERR_CODE_DB_NULL, new Object[] {}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		return dbProvider;
	}
	
	private boolean cleanup (Connection dbConnection)
	{
		try
		{
			if (dbProvider != null)
				dbProvider.releaseConnection(dbConnection);
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
		return true;
	}
	
	@Override
	public void afterPropertiesSet ()
	{
		//do nothing
	}
	
}