/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.jms
 * FILE   : MQSenderCallback.java
 * CREATED: Jul 13, 2016 4:11:07 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.jms;

import java.util.HashMap;
import java.util.Map;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.JmsUtils;
import org.springframework.jms.support.destination.DestinationResolver;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.IRetryHandler;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.ibm.mq.jms.MQDestination;
import com.ibm.msg.client.wmq.WMQConstants;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: MQSenderCallback.java,v 1.1 2016/07/15 09:37:46 ramap Exp $
 */
public class MQSenderCallback implements ProducerConsumerCallback
{
	private Logger logger = LoggerFactory.getLogger(MQSenderCallback.class) ;
	private DestinationResolver destinationResolver = null;
    private String requestQueueName = null;
    private IRetryHandler retryHandler = null;
    private ExecutionJobData jobData = null;
    private Map<String, String> headerProperties = null;
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public MQSenderCallback()
	{
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.jms.core.SessionCallback#doInJms(javax.jms.Session)
	 */
	@Override
	public Message doInJms (Session session) throws JMSException
	{
		MessageProducer producer = null;
		String errorMsg = null;
		IrisAdminError error = null;
		int continueRetry = IRetryHandler.CONTINUE_RETRY;
		Map<String, Object> retryInput = null;
		JMSException jExp = null;
		ExecutionException eExp = null;
		Message returnMessage = null;
		IrisError irisError = null;
		String message = null;
		String key = null;
		String filterKey = null;
		String value = null;
		Destination requestQueue = null;
		
		retryInput = new HashMap<String, Object>();
		retryInput.put(IrisAdminConstants.EXECUTION_DATA, jobData);
		
		while( continueRetry == IRetryHandler.CONTINUE_RETRY)
		{
			try 
			{
				message = jobData.getMessageData();
				requestQueue = destinationResolver.resolveDestinationName( session, requestQueueName, false );
				((MQDestination) requestQueue).setMessageBodyStyle(WMQConstants.WMQ_MESSAGE_BODY_UNSPECIFIED);
				((MQDestination) requestQueue).setTargetClient(WMQConstants.WMQ_TARGET_DEST_MQ);
				final TextMessage textMessage = session.createTextMessage( message );
				
				if (headerProperties != null)
				{
					for (Map.Entry<String, String> entry : headerProperties.entrySet())
					{
						filterKey = entry.getKey();
						key = entry.getValue();
						value = jobData.getFilterParameter(filterKey);
						textMessage.setStringProperty(key, value);
					}
				}
				producer = session.createProducer( requestQueue );
				logger.trace("Sendinng the message:{}", textMessage);
				producer.send(textMessage );
				continueRetry = IRetryHandler.NO_RETRY;
				
			}
			catch (Exception exp )
			{
				errorMsg = exp.getMessage();
				retryInput.put(IRetryHandler.ERROR_MESSAGE, errorMsg);
				
				continueRetry = (Integer) retryHandler.retry(retryInput);
				if ( continueRetry != IRetryHandler.CONTINUE_RETRY)
				{
					retryInput.clear();
					errorMsg = "not abble to connect socket server after re-try count" ;
					jExp = new JMSException(errorMsg, "IRIS-999");
					eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw jExp;
				}
			}
			finally
			{
				// Don't forget to close your resources
				JmsUtils.closeMessageProducer( producer );
			}
		}
		return returnMessage;
		 
	    }	

	/**
	 * @return the jobData
	 */
	public ExecutionJobData getJobData ()
	{
		return jobData;
	}

	/**
	 * @param jobData the jobData to set
	 */
	public void setJobData (ExecutionJobData jobData)
	{
		this.jobData = jobData;
		this.requestQueueName = jobData.getFilterParameter(IrisAdminConstants.JMS_QUEUE_NAME);
	}

	/**
	 * @return the destinationResolver
	 */
	public DestinationResolver getDestinationResolver ()
	{
		return destinationResolver;
	}

	/**
	 * @param destinationResolver the destinationResolver to set
	 */
	public void setDestinationResolver (DestinationResolver destinationResolver)
	{
		this.destinationResolver = destinationResolver;
	}

	/**
	 * @return the retryHandler
	 */
	public IRetryHandler getRetryHandler ()
	{
		return retryHandler;
	}

	/**
	 * @param retryHandler the retryHandler to set
	 */
	public void setRetryHandler (IRetryHandler retryHandler)
	{
		this.retryHandler = retryHandler;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.jms.ProducerConsumerCallback#setHeaderProperties(java.util.Map)
	 */
	@Override
	public void setHeaderProperties (Map<String, String> headerProperties)
	{
		this.headerProperties = headerProperties;
		
	}
	
}
