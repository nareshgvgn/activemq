/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.jms
 * FILE   : JMSProducerConsumer.java
 * CREATED: Mar 2, 2015 10:02:59 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.jms;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.SessionCallback;
import org.springframework.jms.support.JmsUtils;
import org.springframework.jms.support.destination.DestinationResolver;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.IRetryHandler;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: JMSProducerConsumer.java,v 1.8 2016/07/15 09:37:46 ramap Exp $
 */
public class JMSProducerConsumer  implements ProducerConsumerCallback
{
	private Logger logger = LoggerFactory.getLogger(JMSProducerConsumer.class) ;
    private DestinationResolver destinationResolver = null;
    private String requestQueueName = null;
    private String responseQueueName = null;
    private String message = null;
    private int timeout = 0;
    private IRetryHandler retryHandler = null;
    private ExecutionJobData jobData = null;

    public JMSProducerConsumer( DestinationResolver destinationResolver, int timeout, IRetryHandler retryHandler, ExecutionJobData jobData) 
    {
        this.destinationResolver = destinationResolver;
        this.requestQueueName = jobData.getFilterParameter(IrisAdminConstants.JMS_QUEUE_NAME);
        this.responseQueueName = jobData.getFilterParameter(IrisAdminConstants.JMS_RESPONSE_QUEUE_NAME);
        this.message = jobData.getMessageData();
        this.timeout = timeout;
        this.retryHandler = retryHandler;
        this.jobData = jobData;
    }

    public Message doInJms( final Session session ) throws JMSException
    {
        MessageConsumer consumer = null;
        MessageProducer producer = null;
        String errorMsg = null;
		IrisAdminError error = null;
		int continueRetry = IRetryHandler.CONTINUE_RETRY;
		Map<String, Object> retryInput = null;
		JMSException jExp = null;
		ExecutionException eExp = null;
		Message returnMessage = null;
		IrisError irisError = null;
		
		retryInput = new HashMap<String, Object>();
		retryInput.put(IrisAdminConstants.EXECUTION_DATA, jobData);
		
		while( continueRetry == IRetryHandler.CONTINUE_RETRY)
		{
			try 
			{
				final String correlationId = UUID.randomUUID().toString();
				Destination requestQueue = destinationResolver.resolveDestinationName( session, requestQueueName, false );
				Destination replyQueue =  destinationResolver.resolveDestinationName( session, responseQueueName, false );
				// Create the consumer first!
				final TextMessage textMessage = session.createTextMessage( message );
				textMessage.setJMSCorrelationID( correlationId );
				textMessage.setJMSReplyTo(replyQueue );
				// Send the request second!
				producer = session.createProducer( requestQueue );
				producer.send(textMessage );
				consumer = session.createConsumer( replyQueue, "JMSCorrelationID = '" + correlationId + "'" );
				logger.trace("Sendinng the message:{}", textMessage);
				// Block on receiving the response with a timeout
				returnMessage = consumer.receive( timeout );
				retryInput.put(IRetryHandler.RECEIVED_MESSAGE, returnMessage);
				continueRetry = (Integer) retryHandler.retry(retryInput);
				retryInput.clear();
				 if ( IRetryHandler.STOP_RETRY == continueRetry)
					{
						errorMsg = "Re-try handler thrown error, Stop Retry invoked!!";
						eExp = new ExecutionException("error.iris.admin.socketerror", new Object[]	{ errorMsg }, null);
						logger.error(IRISLogger.getText(eExp));
						jobData.setStatus("E");
						error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
						irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						throw eExp;
					}
					else if (  IRetryHandler.CONTINUE_RETRY == continueRetry)
						logger.error("Re-try Handler thrownn error, so re-tryinng again");
						
				}
			catch ( ExecutionException exp)
			{
				jExp = new JMSException(errorMsg, "IRIS-999");
				jobData.setStatus("E");
				throw jExp;
			}
			catch (Exception exp )
			{
				errorMsg = exp.getMessage();
				retryInput.put(IRetryHandler.ERROR_MESSAGE, errorMsg);
				
				continueRetry = (Integer) retryHandler.retry(retryInput);
				if ( continueRetry != IRetryHandler.CONTINUE_RETRY)
				{
					retryInput.clear();
					errorMsg = "not abble to connect socket server after re-try count" ;
					jExp = new JMSException(errorMsg, "IRIS-999");
					eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw jExp;
				}
			}
			finally
			{
				// Don't forget to close your resources
				JmsUtils.closeMessageConsumer( consumer );
				JmsUtils.closeMessageProducer( producer );
			}
		}
		return returnMessage;
    }

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.jms.ProducerConsumerCallback#setJobData(com.fundtech.iris.admin.data.ExecutionJobData)
	 */
	@Override
	public void setJobData (ExecutionJobData jobData)
	{
		// BABU Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.jms.ProducerConsumerCallback#setRetryHandler(com.fundtech.iris.admin.channel.IRetryHandler)
	 */
	@Override
	public void setRetryHandler (IRetryHandler retryHandler)
	{
		// BABU Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.jms.ProducerConsumerCallback#setHeaderProperties(java.util.Map)
	 */
	@Override
	public void setHeaderProperties (Map<String, String> headerProperties)
	{
		// BABU Auto-generated method stub
		
	}	
}
