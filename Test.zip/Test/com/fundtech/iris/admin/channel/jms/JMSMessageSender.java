/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.jms
 * FILE   : JMSMessageSender.java
 * CREATED: Jul 3, 2014 12:50:53 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.jms;

import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractRequestReceiver;
import com.fundtech.iris.admin.channel.IAuditHandler;
import com.fundtech.iris.admin.channel.IRetryHandler;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: JMSMessageSender.java,v 1.14 2016/07/15 09:37:46 ramap Exp $
 */
@Deprecated
public class JMSMessageSender extends MessageSender
{
	private static Logger logger = LoggerFactory.getLogger(JMSMessageSender.class);
	private ExecutionJobData jobData = null;
	private String requestQueueName = null;
	private JmsTemplate jmsTemplate = null;
	private Map<String, String> headerProperties = null;
	
	
	public JMSMessageSender()
	{
		super();
	}
	
	@Override
	public void sendMessage (Map<String, Object> inputdata) throws ExecutionException
	{
		Map<String, Object> auditParms = null;
		Map<String, Object> retryInput = null;
		int continueRetry = IRetryHandler.CONTINUE_RETRY;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		ExecutionException eExp = null;
		IRetryHandler retryHandler = null;
		
		jobData = (ExecutionJobData) inputdata.get(IrisAdminConstants.EXECUTION_DATA);
		requestQueueName = jobData.getFilterParameter(IrisAdminConstants.JMS_QUEUE_NAME);
		auditParms = new HashMap<String, Object>();
		auditParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
		auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, jobData.getMessageData());
		getAuditHandler().audit(auditParms, IAuditHandler.REQUEST_TYPE);
		
		MessageCreator messageCreator = new MessageCreator()
		{
			public Message createMessage (Session session) throws JMSException
			{
				TextMessage msg = null;
				String key = null;
				String filterKey = null;
				String value = null;
				String message = null;
				
				message = jobData.getMessageData();
				msg = session.createTextMessage(message);
				if (getHeaderProperties() != null)
				{
					for (Map.Entry<String, String> entry : getHeaderProperties().entrySet())
					{
						filterKey = entry.getKey();
						key = entry.getValue();
						value = jobData.getFilterParameter(filterKey);
						msg.setStringProperty(key, value);
					}
				}
				logger.trace("Sendinng the message Headers:{}   Body:{} ", msg, message);
				return msg;
			}
		};
		
		retryInput = new HashMap<String, Object>();
		retryInput.put(IrisAdminConstants.EXECUTION_DATA, jobData);
		retryHandler =  getRetryHandler();
		while( continueRetry == IRetryHandler.CONTINUE_RETRY)
		{
			try
			{
				getJmsTemplate().send(requestQueueName, messageCreator);
				continueRetry = IRetryHandler.NO_RETRY;
			}
			catch (Exception exp)
			{
				errorMsg = exp.getMessage();
				retryInput.put(IRetryHandler.ERROR_MESSAGE, errorMsg);
				
				continueRetry = (Integer) retryHandler.retry(retryInput);
				if ( continueRetry != IRetryHandler.CONTINUE_RETRY)
				{
					retryInput.clear();
					errorMsg = "not abble to connect socket server after re-try count" ;
					eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw eExp;
				}
			}
		}
	}

	/**
	 * @return the headerProperties
	 */
	public Map<String, String> getHeaderProperties ()
	{
		return headerProperties;
	}

	/**
	 * @param headerProperties the headerProperties to set
	 */
	public void setHeaderProperties (Map<String, String> headerProperties)
	{
		this.headerProperties = headerProperties;
	}
	
	public void setJmsTemplate (JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}
	
	/**
	 * @return the jmsTemplate
	 */
	public JmsTemplate getJmsTemplate ()
	{
		return jmsTemplate;
	}
	
}
