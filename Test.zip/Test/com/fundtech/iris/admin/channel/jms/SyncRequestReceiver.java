/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.jms
 * FILE   : SyncRequestReceiver.java
 * CREATED: Mar 2, 2015 1:19:44 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.jms;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.destination.DestinationResolver;

import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractRequestReceiver;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.IAuditHandler;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.DefaultJMSMetadata;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: SyncRequestReceiver.java,v 1.11 2016/07/15 09:37:46 ramap Exp $
 */
@Deprecated
public class SyncRequestReceiver extends MessageSender
{
	
	private static Logger logger = LoggerFactory.getLogger(SyncRequestReceiver.class);
	private JmsTemplate jmsTemplate = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 * @param applicationContext
	 */
	public SyncRequestReceiver()
	{
		super();
	}
	
	public void sendMessage( Map<String, Object> inputParms) throws ExecutionException
	{
		Message receivedMessage = null;
		String inputMsg = null;
		Map<String, Object> jmsHeaderData = null;
		String messageId = null;
		DestinationResolver destinationResolver = null;
		JMSProducerConsumer producerConsumer = null;
		ExecutionException eExp = null;
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		ExecutionJobData jobData = null;
		Map<String, Object> outputParms = null;
		Map<String, Object> auditParms = null;
		IAuditHandler auditHandler = null;
		ExecutionJobData responseJobData = null;
		
		try
		{
			jobData = (ExecutionJobData) inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			auditHandler = getAuditHandler();
			destinationResolver = getJmsTemplate().getDestinationResolver();
			producerConsumer = new JMSProducerConsumer(destinationResolver, getTIMEOUT(), getRetryHandler(),jobData);
			auditParms = new HashMap<String, Object>();
			auditParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
			auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, jobData.getMessageData());
			auditHandler.audit(auditParms, IAuditHandler.REQUEST_TYPE);
			// Must pass true as the second param to start the connection
			receivedMessage = getJmsTemplate().execute( producerConsumer, true );
			
			
			if ( receivedMessage != null)
			{
				TextMessage textMessage = (TextMessage) receivedMessage;
				messageId = textMessage.getJMSMessageID();
				inputMsg = textMessage.getText();
				jmsHeaderData = DefaultJMSMetadata.getMessageHeaders(textMessage);
				logger.debug("Message received:-\n{}" , inputMsg);
				auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, inputMsg);
				auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
				activatorHelper = new ActivatorHelper();
				dbConnection = getDBProvider().getConnection();
				activatorHelper.initialize(dbConnection, getApplicationContext());
				outputParms = new HashMap<String, Object>();
				outputParms.put(IrisAdminConstants.MEDIA_DETAIL, messageId);
				outputParms.put(IrisAdminConstants.JMS_HEADER_DATA, jmsHeaderData);
				outputParms.put(IrisAdminConstants.JMS_MESSAGE, inputMsg);
				outputParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, getProcIdentifier());
				outputParms.put(IrisAdminConstants.REQUEST_JOB_DATA, jobData);
				outputParms.put(IrisAdminConstants.CHANNEL, "MQ");
				responseJobData = activatorHelper.runProcess(outputParms, IrisAdminConstants.MEDIA_MQ, jobData.isAccumulateErros(), null);
				jobData.setRespExecutionId(responseJobData.getExecutionId());
				
			}
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.timeout", new Object[] {}, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch (JMSException exp)
		{
			eExp = new ExecutionException("error.iris.admin.chain.sending", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( ExecutionException exp)
		{
			if ( "error.iris.admin.chain.timeout".equals(exp.getKey()))
				throw exp;
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.process", new Object[] {}, exp);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch (SystemException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (SQLException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(auditParms);
			CleanUpUtils.doClean(inputParms);
			CleanUpUtils.doClean(outputParms);
			if ( activatorHelper != null)
				activatorHelper.cleanUp();
			cleanup(dbConnection);
			
		}
		
	}
	
	public void setJmsTemplate (JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}
	
	/**
	 * @return the jmsTemplate
	 */
	public JmsTemplate getJmsTemplate ()
	{
		return jmsTemplate;
	}
}