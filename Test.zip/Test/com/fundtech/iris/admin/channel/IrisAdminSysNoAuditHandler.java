/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel
 * FILE   : IrisAdminSysNoAuditHandler.java
 * CREATED: Jun 25, 2015 1:16:16 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.util.Map;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisAdminSysNoAuditHandler.java,v 1.4 2015/07/03 10:04:57 ramap Exp $
 */
public class IrisAdminSysNoAuditHandler extends AbstractAuditHandler
{
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisAdminSysNoAuditHandler()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IAuditHandler#audit(java.util.Map)
	 */
	@Override
	public Object auditRecord (Map<String, Object> inputParms, int type)
	{
		//Do nothing
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IAuditHandler#cleanup()
	 */
	@Override
	public void cleanup ()
	{
		// BABU Auto-generated method stub
		
	}
	
}
