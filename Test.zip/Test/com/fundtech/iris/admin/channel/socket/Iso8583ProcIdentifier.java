/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.spring
 * FILE   : Iso8583ProcIdentifier.java
 * CREATED: Apr 25, 2014 12:25:41 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.socket;

import java.util.HashMap;
import java.util.Map;

import com.cashtech.iris.exceptions.ConfigurationException;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.Identifier;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: Iso8583ProcIdentifier.java,v 1.2 2015/06/24 14:03:58 ramap Exp $
 */
public class Iso8583ProcIdentifier implements Identifier
{
	private Map<String, String> properties = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public Iso8583ProcIdentifier()
	{
		
	}
	
	/**
	 * @param parameters
	 *            the parameters to set
	 */
	public void setProperties (Map<String, String> properties)
	{
		this.properties = properties;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.spring.Identifier#initialize()
	 */
	@Override
	public void initialize () throws ConfigurationException
	{
		// BABU Auto-generated method stub
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.spring.Identifier#identify(java.lang.Object)
	 */
	@Override
	public Map<String, String> identify (Object source) throws ExecutionException
	{
		Map<String, Object> sourceData = null;
		Map<String, String> outData = null;
		String mapName = null;
		String processName = null;
		String entityType = null;
		String entityCode = null;
		String requestMapName = null;
		
		sourceData = (Map<String, Object>) source;
		requestMapName = (String)sourceData.get(IrisAdminConstants.MAP_NAME);
		
		if ( requestMapName.equals("DBGLREQ"))
			mapName = "DBGLRES";
		else 
			mapName = "CRGLRES";
		
		processName = properties.get("ExecuteIRISProcess");
		entityType = properties.get("EntityType");
		entityCode = properties.get("EntityCode");
		outData = new HashMap<String, String>();
		outData.put(IrisAdminConstants.MAP_NAME, mapName);
		outData.put(IrisAdminConstants.ENTITY_TYPE, entityType);
		outData.put(IrisAdminConstants.ENTITY_CODE, entityCode);
		outData.put(IrisAdminConstants.EXECUTE_PROCESS, processName);
		return outData;
	}
	
}
