/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.socket
 * FILE   : Iso8583ClientService.java
 * CREATED: Jun 21, 2015 10:57:17 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.socket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: Iso8583ClientService.java,v 1.4 2015/12/18 14:40:28 ramap Exp $
 */
public class Iso8583ClientService implements SocketClientService
{
	private Socket socketClient = null;
	private String socketServerHost = null;
	private int socketServerPort = 0;
	private int socketConnTimeOut = 0;
	private int socketReadTimeOut = 0;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public Iso8583ClientService()
	{
		
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.socket.SocketClientService#getOutStream()
	 */
	@Override
	public OutputStream getOutStream () throws IOException
	{
		SocketAddress socketAddress = null;
		OutputStream outStream = null;
		
		socketAddress = new InetSocketAddress(socketServerHost, socketServerPort);
		socketClient = new Socket();
		socketClient.setSoTimeout(socketReadTimeOut);
		socketClient.connect(socketAddress, socketConnTimeOut);
		outStream = socketClient.getOutputStream();
		return outStream;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.socket.SocketClientService#cleanup()
	 */
	@Override
	public void cleanup ()
	{
		HelperUtils.doClose(socketClient);
		
	}

	

	/**
	 * @param socketServerHost the socketServerHost to set
	 */
	public void setSocketServerHost (String socketServerHost)
	{
		this.socketServerHost = socketServerHost;
	}

	

	/**
	 * @param socketServerPort the socketServerPort to set
	 */
	public void setSocketServerPort (int socketServerPort)
	{
		this.socketServerPort = socketServerPort;
	}


	/**
	 * @param socketConnTimeOut the socketConnTimeOut to set
	 */
	public void setSocketConnTimeOut (int socketConnTimeOut)
	{
		this.socketConnTimeOut = socketConnTimeOut;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.socket.SocketClientService#getInputStream()
	 */
	@Override
	public InputStream getInputStream () throws IOException
	{
		return socketClient.getInputStream();
	}

	/**
	 * @return the socketReadTimeOut
	 */
	public int getSocketReadTimeOut ()
	{
		return socketReadTimeOut;
	}

	/**
	 * @param socketReadTimeOut the socketReadTimeOut to set
	 */
	public void setSocketReadTimeOut (int socketReadTimeOut)
	{
		this.socketReadTimeOut = socketReadTimeOut;
	}
	
}
