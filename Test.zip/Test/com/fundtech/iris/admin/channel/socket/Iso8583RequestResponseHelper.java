/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.socket
 * FILE   : Iso8583RequestResponseHelper.java
 * CREATED: Jun 21, 2015 11:58:36 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel.socket;

import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.channel.AbstractRequestReceiver;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.IAuditHandler;
import com.fundtech.iris.admin.channel.IRetryHandler;
import com.fundtech.iris.admin.channel.Identifier;
import com.fundtech.iris.admin.channel.ReferencesEnum;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.solab.iso8583.IsoMessage;
import com.solab.iso8583.IsoType;
import com.solab.iso8583.MessageFactory;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: Iso8583RequestResponseHelper.java,v 1.19 2016/02/08 07:00:22 ramap Exp $
 */
public class Iso8583RequestResponseHelper extends AbstractRequestReceiver
{
	
	private static Logger logger =  LoggerFactory.getLogger(Iso8583RequestResponseHelper.class);
	
	private SocketClientService socketService = null;
	private int headerLength = 0;
	private boolean createBinaryBitmap = true;
	private MessageFactory<IsoMessage> isoMessageFactory = null;
	private Map<ReferencesEnum, String> references = new HashMap<ReferencesEnum, String>();
	private Identifier procIdentifier = null;
	private com.solab.iso8583.IsoMessage isoMessage = null;
	
	private static String NUMERIC = "NUMERIC";
	/** A fixed-length alphanumeric value. It is filled with spaces to the right. */
	private static String ALPHA = "ALPHA";
	/** A variable length alphanumeric value with a 2-digit header length. */
	private static String LLVAR = "LLVAR";
	/** A variable length alphanumeric value with a 3-digit header length. */
	private static String LLLVAR = "LLLVAR";
	/** A date in format MMddHHmmss */
	private static String DATE10 = "DATE10";
	/** A date in format MMdd */
	private static String DATE4 = "DATE4";
	/** A date in format yyMM */
	private static String DATE_EXP = "DATE_EXP";
	/** Time of day in format HHmmss */
	private static String TIME = "TIME";
	/** An amount, expressed in cents with a fixed length of 12. */
	private static String AMOUNT = "AMOUNT";
	/** Similar to ALPHA but holds byte arrays instead of strings. */
	private static String BINARY = "BINARY";
	/** Similar to LLVAR but holds byte arrays instead of strings. */
	private static String LLBIN = "LLBIN";
	/** Similar to LLLVAR but holds byte arrays instead of strings. */
	private static String LLLBIN = "LLLBIN";
	
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public Iso8583RequestResponseHelper()
	{
		
	}
	
	public void sendMessage (Map<String, Object> inputParms) throws  ExecutionException
	{
		InterfaceBandDef childDef = null;
		String bandName = null;
		String fldVal = null;
		ExecutionException eExp = null;
		List<MappingField> listFields = null;
		DataField dataField = null;
		Map<String, DataField> fieldsList = null;
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		Map<String, Object> outParms = null;
		com.solab.iso8583.IsoMessage resp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		Map<String, Object> auditParms = null;
		ExecutionJobData jobData = null;
		RootBand rootBand = null;
		Map<String, InterfaceBandDef> pBandDefs = null;
		IAuditHandler auditHandler = null;
		String threadIdName = null;
		String debugMsg = null;
		ExecutionJobData responseJobData = null;
		
		try
		{
			threadIdName = Thread.currentThread().getName();
			jobData = (ExecutionJobData) inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			rootBand = (RootBand) inputParms.get(IrisAdminConstants.DATA_ROOT_BAND);
			pBandDefs = jobData.getInterfaceDef().getBandsDefinition().getBandDefinitions();
			auditHandler = getAuditHandler();
			
			for (BatchBand batchBand : rootBand.getBatches())
			{
				for ( Band band : batchBand.getBatchBands())
				{
					bandName = band.getName();
					childDef = pBandDefs.get(bandName);
					listFields  = childDef.getMappingFields();
					fieldsList = band.getFieldRow();
					int messageId = Integer.parseInt(childDef.getBandId());
					isoMessage.setType(messageId);
					isoMessage.setBinaryBitmap(createBinaryBitmap);
					for (MappingField field : listFields)
					{
						if (IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType())
						{
							if (logger.isTraceEnabled())
								logger.trace("BandName:{}, FieldName:{} ", childDef.getBandName(), field.getFieldName());
							dataField = fieldsList.get(field.getFieldName());
							fldVal = dataField.getValue();
							if (null == field.getAbsoluteXPath1())
							{
								continue;
							}
							isoMessage.setValue(Integer.valueOf(field.getAbsoluteXPath1()), fldVal, getIsoType(field), Integer.valueOf(field.getRelativeXPath()));
						}
					}
					auditParms = new HashMap<String, Object>();
					auditParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
					debugMsg = isoMessage.debugString();
					auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA,debugMsg );
					auditHandler.audit(auditParms, IAuditHandler.REQUEST_TYPE);
					resp = sendIsoMessage(isoMessage, jobData, debugMsg);
					debugMsg =  resp.debugString();
					logger.trace("Response Message Received:{}", debugMsg);
					auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, debugMsg);
					auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
					activatorHelper = new ActivatorHelper();
					dbConnection = getDBProvider().getConnection();
					activatorHelper.initialize(dbConnection, getApplicationContext());
					outParms = new HashMap<String, Object>();
					outParms.put(IrisAdminConstants.MEDIA_DETAIL, 1210);
					outParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, procIdentifier);
					outParms.put(IrisAdminConstants.ISO_MESSAGE, resp);
					outParms.put(IrisAdminConstants.REQUEST_JOB_DATA, jobData);
					outParms.put(IrisAdminConstants.CHANNEL, "Socket");
					responseJobData = activatorHelper.runProcess(outParms, IrisAdminConstants.MEDIA_ISO, jobData.isAccumulateErros(), null);
					jobData.setRespExecutionId(responseJobData.getExecutionId());
				}
			}
		}
		catch ( ExecutionException exp)
		{
			throw exp;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Not able to process-" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError("999", errorMsg, null, null);
			jobData.addError(error);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
				
			logger.info("Changing thread name back from [{}] to [{}]", Thread.currentThread().getName(), threadIdName);
			Thread.currentThread().setName(threadIdName);
			if ( activatorHelper != null)
				activatorHelper.cleanUp();
			CleanUpUtils.doClean(auditParms);
			cleanup(dbConnection);
			CleanUpUtils.doClean(inputParms);
		}
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param IsoMessage
	 * @param jobData
	 * @return
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private IsoMessage sendIsoMessage (IsoMessage isoMessage, ExecutionJobData jobData, String strmsg) throws ExecutionException
	{
		IsoMessage returnMessage = null;
		ExecutionException eExp = null;
		OutputStream outStream = null;
		InputStream inStream = null;
		byte[] byteBuffer = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		int continueRetry = IRetryHandler.CONTINUE_RETRY;
		Map<String, Object> retryInput = null;
		IRetryHandler retryHandler = null;
		
		retryInput = new HashMap<String, Object>();
		retryInput.put(IrisAdminConstants.EXECUTION_DATA, jobData);
		retryHandler = getRetryHandler();
			while( continueRetry == IRetryHandler.CONTINUE_RETRY)
			{
				try
				{
					logger.trace("Sending Message:{}",strmsg);
					outStream = socketService.getOutStream();
					isoMessage.write(outStream, headerLength);
					inStream = socketService.getInputStream();
					byteBuffer = new byte[2000];
					inStream.read(byteBuffer);
					isoMessageFactory.setUseBinaryBitmap(true);
					returnMessage = isoMessageFactory.parseMessage(byteBuffer, headerLength);
					returnMessage.setType(1210);
					retryInput.put(IRetryHandler.RECEIVED_MESSAGE, returnMessage);
					continueRetry = (Integer) retryHandler.retry(retryInput);
					retryInput.clear();
					
					 if ( IRetryHandler.STOP_RETRY == continueRetry)
					{
						errorMsg = "Re-try handler thrown error, Stop Retry invoked!!";
						eExp = new ExecutionException("error.iris.admin.socketerror", new Object[]	{ errorMsg }, null);
						logger.error(IRISLogger.getText(eExp));
						jobData.setStatus("E");
						error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
						irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						throw eExp;
					}
					else if (  IRetryHandler.CONTINUE_RETRY == continueRetry)
						logger.error("Re-try Handler thrownn error, so re-tryinng again");
						
				}
				catch ( ExecutionException exp)
				{
					throw exp;
				}
				catch ( Exception exp)
				{
					errorMsg = exp.getMessage();
					errorMsg = "Error While Connecting Server, Error:" + errorMsg;
					logger.error(errorMsg);
					retryInput.put(IRetryHandler.ERROR_MESSAGE, errorMsg);
					continueRetry = (Integer) retryHandler.retry(retryInput);
					if ( continueRetry != IRetryHandler.CONTINUE_RETRY)
					{
						retryInput.clear();
						eExp = new ExecutionException("error.iris.admin.socketerror", new Object[]	{ errorMsg }, exp);
						logger.error(IRISLogger.getText(eExp));
						jobData.setStatus("E");
						error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
						irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						throw eExp;
					}
				}
				finally
				{
					HelperUtils.doClose(inStream);
					HelperUtils.doClose(outStream);
					socketService.cleanup();
				}
			}
			return returnMessage;
	}

	private IsoType getIsoType(MappingField field)
	{
		if ( ALPHA.equals(field.getAbsoluteXPath2()))
			return IsoType.ALPHA;
		else if ( NUMERIC.equals(field.getAbsoluteXPath2()))
			return IsoType.NUMERIC;
		else if ( LLVAR.equals(field.getAbsoluteXPath2()))
			return IsoType.LLVAR;
		else if ( LLLVAR.equals(field.getAbsoluteXPath2()))
			return IsoType.LLLVAR;
		else if ( DATE10.equals(field.getAbsoluteXPath2()))
			return IsoType.DATE10;
		else if ( DATE_EXP.equals(field.getAbsoluteXPath2()))
			return IsoType.DATE_EXP;
		else if ( DATE4.equals(field.getAbsoluteXPath2()))
			return IsoType.DATE4;
		else if ( TIME.equals(field.getAbsoluteXPath2()))
			return IsoType.TIME;
		else if ( AMOUNT.equals(field.getAbsoluteXPath2()))
			return IsoType.AMOUNT;
		else if ( BINARY.equals(field.getAbsoluteXPath2()))
			return IsoType.BINARY;
		else if ( LLBIN.equals(field.getAbsoluteXPath2()))
			return IsoType.LLBIN;
		else if ( LLLBIN.equals(field.getAbsoluteXPath2()))
			return IsoType.LLLBIN;
		else
		return IsoType.ALPHA;
	}
	
	/**
	 * @return the socketService
	 */
	public SocketClientService getSocketService ()
	{
		return socketService;
	}

	/**
	 * @param socketService the socketService to set
	 */
	public void setSocketService (SocketClientService socketService)
	{
		this.socketService = socketService;
	}

	/**
	 * @return the headerLength
	 */
	public int getHeaderLength ()
	{
		return headerLength;
	}

	/**
	 * @param headerLength the headerLength to set
	 */
	public void setHeaderLength (int headerLength)
	{
		this.headerLength = headerLength;
	}

	/**
	 * @return the createBinaryBitmap
	 */
	public boolean isCreateBinaryBitmap ()
	{
		return createBinaryBitmap;
	}

	/**
	 * @param createBinaryBitmap the createBinaryBitmap to set
	 */
	public void setCreateBinaryBitmap (boolean createBinaryBitmap)
	{
		this.createBinaryBitmap = createBinaryBitmap;
	}


	/**
	 * @param messageFactory the messageFactory to set
	 */
	public void setIsoMessageFactory (MessageFactory<IsoMessage> isoMessageFactory)
	
	{
		this.isoMessageFactory = isoMessageFactory;
	}
	
	public Map<ReferencesEnum, String> getReferences ()
	{
		return references;
	}
	
	
	public void setReferences (Map<ReferencesEnum, String> references)
	{
		this.references = references;
	}
	
	/**
	 * @return the procIdentifier
	 */
	public Identifier getProcIdentifier ()
	{
		return procIdentifier;
	}

	/**
	 * @param procIdentifier the procIdentifier to set
	 */
	public void setProcIdentifier (Identifier procIdentifier)
	{
		this.procIdentifier = procIdentifier;
	}

	/**
	 * @return the isoMessage
	 */
	public com.solab.iso8583.IsoMessage getIsoMessage ()
	{
		if ( isoMessage == null)
			isoMessage = new com.solab.iso8583.IsoMessage();
		return isoMessage;
	}

	/**
	 * @param isoMessage the isoMessage to set
	 */
	public void setIsoMessage (com.solab.iso8583.IsoMessage isoMessage)
	{
		this.isoMessage = isoMessage;
	}

}
