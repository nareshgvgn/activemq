/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.channel.socket
 * FILE   : IrisAdminSysRetryHandler.java
 * CREATED: Jun 25, 2015 10:19:26 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.channel;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisAdminSysRetryHandler.java,v 1.3 2015/12/18 14:40:15 ramap Exp $
 */
public class IrisAdminSysRetryHandler extends AbstractRetryHandler
{
	
	private int retryCount = 2;
	private long timeoutSleep = 120;
	private int count = 0;
	
	private static Logger logger =  LoggerFactory.getLogger(IrisAdminSysRetryHandler.class);
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisAdminSysRetryHandler()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IRetryHandler#retry(java.util.Map)
	 */
	@Override
	public Object retryAgain (Map<String, Object> inputParms)
	{
		String errorMessage = null;
		
		if ( count < retryCount)
		{
			count ++;
			errorMessage = (String) inputParms.get(ERROR_MESSAGE);
			logger.warn("Error While connecting Server- {} , present attempt:{} , total attempts:{}  and wait time in secs for each try:{}", 
					errorMessage, count, retryCount, timeoutSleep);
			try
			{
				Thread.sleep(1000 * timeoutSleep);
			}
			catch (InterruptedException e)
			{
				//Ignore
			}
			return CONTINUE_RETRY;
		}
		else
			logger.error("not abble to connect socket server after re-try count:{}"  , retryCount) ;
			return STOP_RETRY;
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IRetryHandler#cleanup()
	 */
	@Override
	public void cleanup ()
	{
		count = 0;
		
	}

	/**
	 * @return the retryCount
	 */
	public int getRetryCount ()
	{
		return retryCount;
	}

	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount (int retryCount)
	{
		this.retryCount = retryCount;
	}

	/**
	 * @return the timeoutSleep
	 */
	public long getTimeoutSleep ()
	{
		return timeoutSleep;
	}

	/**
	 * @param timeoutSleep the timeoutSleep to set
	 */
	public void setTimeoutSleep (long timeoutSleep)
	{
		this.timeoutSleep = timeoutSleep;
	}
	
}
