/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : IrisAdminPlugin.java
 * CREATED: Oct 17, 2013 10:42:35 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin;

import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.functions.IFunction;
import com.fundtech.iris.admin.hooks.IProcessHook;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: IrisAdminPlugin.java,v 1.7 2014/09/09 10:13:09 ramap Exp $
 * @since 1.0.0
 */
public abstract class IrisAdminPlugin implements IFunction, IPlugin, IProcessHook
{
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.plugins.IPlugin#initialize()
	 */
	public void initialize () throws ExecutionException
	{
		
	}
	
	/**
	 * 
	 * This helper method gets the reference value from the same band or same equal band from same parent or from parent
	 * 
	 * @param refKey
	 *            -- BandName.FieldName
	 * @param dataBand
	 *            -- PresentBand
	 * @param batchBand
	 *            -- Batch Band
	 * @return String ref Value
	 * @throws FormatException
	 * @throws ExecutionException
	 */
	public String getRefValue (String refField, Band dataBand, BatchBand batchBand) throws FormatException, ExecutionException
	{
		String fldVal = null;
		int firstIndex = -1;
		MappingField tempField = null;
		String bandRef = null;
		String fieldRef = null;
		String refKey = null;
		
		refKey = refField.trim();
		firstIndex = refKey.indexOf(".");
		bandRef = refKey.substring(0, firstIndex);
		fieldRef = refKey.substring(firstIndex + 1, refKey.length());
		tempField = new MappingField();
		tempField.setBandRef(bandRef);
		tempField.setFieldRef(fieldRef);
		fldVal = IrisAdminUtils.getRefValue(tempField, dataBand, batchBand);
		
		return fldVal;
	}
}
