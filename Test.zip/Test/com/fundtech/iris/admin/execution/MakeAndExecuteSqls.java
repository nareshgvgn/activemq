/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : MakeAndExecuteSqls.java
 * CREATED: Jul 15, 2013 12:41:18 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.ModelBand;
import com.fundtech.iris.admin.data.ModelRootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * 
 * <p>
 * This helper class formats the interface bands,makes SQLS and executes 1000 as batch
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: MakeAndExecuteSqls.java,v 1.29 2017/03/23 13:21:17 ramap Exp $
 */
public class MakeAndExecuteSqls
{
	private static Logger logger = LoggerFactory.getLogger(MakeAndExecuteSqls.class);
	private ModelRootBand rootBand = null;
	private ExecutionJobData jobData = null;
	private Connection dbConnection = null;
	private long myNumber = 1;
	private long parentNumber = 0;
	private long batchSize = 10000;
	private long  batchCount = 0;
	private Map<String, PreparedStatement> stmtMap = new LinkedHashMap<String, PreparedStatement>();
	
	@SuppressWarnings("unused")
	private MakeAndExecuteSqls()
	{
	}
	
	/**
	 * @param rootBand
	 * @param dbConnection
	 */
	public MakeAndExecuteSqls(ModelRootBand rootBand, Connection dbConnection, long batchSize, ExecutionJobData jobData)
	{
		this.rootBand = rootBand;
		this.dbConnection = dbConnection;
		this.jobData = jobData;
		if (batchSize > 0)
			this.batchSize = batchSize;
	}
	
	/**
	 * This helper method creates the sqls and executes based on batch wise
	 * 
	 * @throws ExecutionException
	 */
	public void createAndRunSQls () throws ExecutionException
	{
		List<String> dmls = null;
		Map<String, ModelBand> parentsBands = null;
		
		try
		{
			parentsBands = new HashMap<String, ModelBand>();
			dmls = new ArrayList<String>();
			for (ModelBand iDataBand : rootBand.getBatchBands())
			{
				makeInserts(iDataBand, dmls);
				parentNumber = 0; // Initialize back to zero as another root band may come.
			}
			
			clearBatch();
		}
		finally
		{
			clearPrepareStmts();
			CleanUpUtils.doClean(parentsBands);
			parentsBands = null;
			CleanUpUtils.doClean(rootBand.getBatchBands());
		}
	}
	
	private void incrementBatch() throws ExecutionException
	{
		batchCount++;
		if ( batchCount == batchSize)
			clearBatch();
	}
	
	private void clearBatch() throws ExecutionException
	{
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		PreparedStatement pstmt = null;
		String tableName = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		int[] updateCount = null;
		
		
		try
		{
			if ( batchCount > 0 )
			{
				for (Map.Entry<String, PreparedStatement> entry : stmtMap.entrySet())
				{
					startTime = System.currentTimeMillis();
					tableName = entry.getKey();
					pstmt = entry.getValue();
					updateCount = pstmt.executeBatch();
					pstmt.clearBatch();
					endTime = System.currentTimeMillis();
					delta = (endTime - startTime) / 1000.00;
					logger.debug("For tale:{} number of inserts are:{} and taken time {} sec", tableName, updateCount.length, delta);
				}
			}
		}
		catch (SQLException exp)
		{
			jobData.setStatus("E");
			errorMsg = "Unable to parse the file as per defined format";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ "Error while executing batch SQLs",  errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Unable to parse the file as per defined format";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ "Error while executing batch SQLs",  errorMsg}, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			batchCount = 0;
		}
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param stmtMap2
	 * </pre></p>
	 */
	private void clearPrepareStmts ()
	{
		
		for (Map.Entry<String, PreparedStatement> entry : stmtMap.entrySet())
		{
			CleanUpUtils.doClean(entry.getValue());
		}
		stmtMap = null;
	}

	/**
	 * This helper method creates sqls
	 * 
	 * @param dataBand
	 * @param dmls
	 * @param srNo
	 * @param parentSrNo
	 * @return
	 * @throws SQLException 
	 */
	private void makeInserts (ModelBand dataBand, List<String> dmls) throws ExecutionException
	{
		String sql = null;
		List<ModelBand> ichildBands = null;
		List<ModelBand> multiRecords = null;
		
		if (dataBand.getRows().isEmpty())
		{
			if (!dataBand.getFieldRow().isEmpty())
			{
				dataBand.setParentNo(parentNumber);
				dataBand.setMyNumber(myNumber);
				fillPreParesStmts(dataBand);
				dmls.add(sql);
				myNumber++;
			}
		}
		else
		{
			if (!dataBand.getRows().isEmpty())
			{
				multiRecords = dataBand.getRows();
				for (ModelBand iChildBand : multiRecords)
				{
					makeInserts(iChildBand, dmls);
				}
			}
		}
		
		if (!dataBand.getAllBands().isEmpty())
		{
			for (String key : dataBand.getAllBands())
			{
				ichildBands = dataBand.getChildBands(key);
				for (ModelBand ichildBand : ichildBands)
				{
					parentNumber = dataBand.getMyNumber();
					makeInserts(ichildBand, dmls);
				}
			}
		}
	}
	
	private void fillPreParesStmts (ModelBand dataBand) throws ExecutionException
	{
		Map<String, String> fieldList = null;
		String value = null;
		String tableName = null;
		PreparedStatement executeStmt = null;
		int indexCount = 1;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		
		try
		{
			tableName = dataBand.getName();
			if (stmtMap.containsKey(tableName))
				executeStmt = stmtMap.get(tableName);
			else
			{
				executeStmt = createPreparedStmts(dataBand);
				stmtMap.put(tableName, executeStmt);
			}

			executeStmt.setString(indexCount,dataBand.getCurrentSessionId());
			indexCount ++;
			executeStmt.setString( indexCount, ""+dataBand.getMyNumber());
			indexCount ++;
			if (dataBand.getParentNo() > 0)
			{
				executeStmt.setString( indexCount, ""+dataBand.getParentNo());
				indexCount ++;
			}
			fieldList = dataBand.getFieldRow();
			for (Map.Entry<String, String> entry : fieldList.entrySet())
			{
				value = entry.getValue();
				executeStmt.setString(indexCount, value);
				indexCount ++;
			}
			executeStmt.addBatch();
			incrementBatch();
		}
		catch (SQLException exp)
		{
			jobData.setStatus("E");
			errorMsg = "Error while executing batch SQLs";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Error while executing batch SQLs";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			
		}
	}
	
	private PreparedStatement createPreparedStmts (ModelBand dataBand) throws ExecutionException
	{
		PreparedStatement returnStmt = null;
		StringBuilder columnsSQL = null;
		StringBuilder valuesSQL = null;
		StringBuilder tableSQL = null;
		StringBuilder fullDML = null;
		Map<String, String> fieldList = null;
		String finalSQL = null;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		try
		{
			tableSQL = new StringBuilder();
			tableSQL.append("INSERT INTO ");
			tableSQL.append(dataBand.getName());
			tableSQL.append(" (");
			
			columnsSQL = new StringBuilder();
			columnsSQL.append("EXECUTION_ID");
			valuesSQL = new StringBuilder();
			valuesSQL.append(" VALUES (");
			valuesSQL.append("?");
			
			columnsSQL.append(",SR_NMBR");
			valuesSQL.append("," + "?");
			
			if (dataBand.getParentNo() > 0)
			{
				columnsSQL.append(",PARENT_SR_NMBR");
				valuesSQL.append("," + "?");
			}
			fullDML = new StringBuilder();
			fieldList = dataBand.getFieldRow();
			for (Map.Entry<String, String> entry : fieldList.entrySet())
			{
				columnsSQL.append(",");
				valuesSQL.append(",");
				columnsSQL.append(entry.getKey());
				valuesSQL.append("?");
			}
			columnsSQL.append(") ");
			valuesSQL.append(") ");
			fullDML.append(tableSQL);
			fullDML.append(columnsSQL);
			fullDML.append(valuesSQL);
			finalSQL = fullDML.toString();
			logger.trace("Insert Created:  {}" , finalSQL);
			returnStmt = dbConnection.prepareStatement(finalSQL);
		}
		catch (SQLException exp)
		{
			jobData.setStatus("E");
			errorMsg = "Error while executing batch SQLs";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Error while executing batch SQLs";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(columnsSQL);
			CleanUpUtils.doClean(valuesSQL);
			CleanUpUtils.doClean(fullDML);
			columnsSQL = null;
			valuesSQL = null;
			fullDML = null;
		}
		return returnStmt;
	}
}
