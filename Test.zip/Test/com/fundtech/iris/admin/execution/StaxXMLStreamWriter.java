/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : StaxXMLStreamWriter.java
 * CREATED: Nov 14, 2013 12:33:50 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: StaxXMLStreamWriter.java,v 1.4 2016/10/27 05:10:47 ramap Exp $
 * @since 1.0.0
 */
public class StaxXMLStreamWriter
{
	private static Logger logger = LoggerFactory.getLogger(StaxXMLStreamWriter.class);
	
	public static void main (String[] args)
	{
		String fileName = "c:/download/employee.xml";
		String rootElement = "Employee";
		StaxXMLStreamWriter xmlStreamWriter = new StaxXMLStreamWriter();
		Map<String, String> elementsMap = new HashMap<String, String>();
		elementsMap.put("id", "1");
		elementsMap.put("name", "Pankaj");
		elementsMap.put("age", "29");
		elementsMap.put("role", "Java Developer");
		elementsMap.put("gender", "Male");
		xmlStreamWriter.writeXML(fileName, rootElement, elementsMap);
	}
	
	private void writeXML (String fileName, String rootElement, Map<String, String> elementsMap)
	{
		XMLOutputFactory xmlOutputFactory = XMLOutputFactory.newInstance();
		FileOutputStream stream = null;
		try
		{
			stream = new FileOutputStream(fileName);
			XMLStreamWriter xmlStreamWriter = xmlOutputFactory.createXMLStreamWriter(stream, "UTF-8");
			// start writing xml file
			xmlStreamWriter.writeStartDocument("UTF-8", "1.0");
			xmlStreamWriter.writeCharacters("\n");
			xmlStreamWriter.writeStartElement(rootElement);
			
			// write id as attribute
			xmlStreamWriter.writeAttribute("id", elementsMap.get("id"));
			// write other elements
			xmlStreamWriter.writeCharacters("\n\t");
			xmlStreamWriter.writeStartElement("name\\test");
			xmlStreamWriter.writeCharacters("\n\t\t" + elementsMap.get("name"));
			xmlStreamWriter.writeCharacters("\n\t");
			xmlStreamWriter.writeEndElement();
			
			xmlStreamWriter.writeCharacters("\n\t");
			xmlStreamWriter.writeStartElement("age");
			xmlStreamWriter.writeCharacters("\n\t\t" + elementsMap.get("age"));
			xmlStreamWriter.writeCharacters("\n\t");
			xmlStreamWriter.writeEndElement();
			
			xmlStreamWriter.writeCharacters("\n\t");
			xmlStreamWriter.writeStartElement("gender");
			xmlStreamWriter.writeCharacters("\n\t\t" + elementsMap.get("gender"));
			xmlStreamWriter.writeCharacters("\n\t");
			xmlStreamWriter.writeEndElement();
			
			xmlStreamWriter.writeCharacters("\n\t");
			xmlStreamWriter.writeStartElement("role");
			xmlStreamWriter.writeCharacters("\n\t\t" + elementsMap.get("role"));
			xmlStreamWriter.writeCharacters("\n\t");
			xmlStreamWriter.writeEndElement();
			// write end tag of Employee element
			xmlStreamWriter.writeCharacters("\n");
			xmlStreamWriter.writeEndElement();
			
			// write end document
			xmlStreamWriter.writeEndDocument();
			
			// flush data to file and close writer
			xmlStreamWriter.flush();
			xmlStreamWriter.close();
			
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
		}
		finally
		{
			CleanUpUtils.doClose(stream);
		}
	}
	
}
