/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : FixedWidthFormatter.java
 * CREATED: Jan 27, 2014 1:16:31 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FixedWidthFormatter.java,v 1.16 2016/09/01 18:36:51 ramap Exp $
 */
public class FixedWidthFormatter extends AbstractFormatter
{
	private static Logger logger = LoggerFactory.getLogger(FixedWidthFormatter.class);
	
	public FixedWidthFormatter()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack)
	 */
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		FormatException fExp = null;
		boolean returnVal = false;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		InterfaceBandDef bandDef = null;
		
		try
		{
			bandDef = defStack.peekFirst();
			returnVal = createBand(lineNumber, obj, obj, defStack, dataStack);
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return returnVal;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#formatBandData(long, java.lang.Object,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		String fmtStr = null;
		Map<String, DataField> dataValues = null;
		String fldVal = null;
		List<MappingField> listFields = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		fmtStr = (String) obj;
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		
		try
		{
			for (MappingField field : listFields)
			{
				if ( IrisAdminConstants.MAPPING_TYPE_IGNORE == field.getMappingType())
				{
					fldVal = null;
				}
				else if (fmtStr.length() > field.getEndPosition())
					fldVal = fmtStr.substring(field.getStartPosition(), field.getEndPosition());
				else if (fmtStr.length() > field.getStartPosition())
					fldVal = fmtStr.substring(field.getStartPosition(), fmtStr.length());
				else
					fldVal = null;
				
				validateField(fldVal, field, bandDef, dataBand, dataValues);
			}
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, bandDef.toString(), obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return dataValues;
	}
	
	/**
	 * To get the band id field position.
	 * 
	 * @param bandIdPosition
	 *            - Position of band id
	 * @param mappingFields
	 *            - List of {@link MappingField}
	 * @return Returns the band id field position
	 */
	private int getBandIdFieldPosition (int bandIdPosition, List<MappingField> mappingFields)
	{
		int counter = 0, position = 0;
		if (bandIdPosition > 0)
		{
			for (MappingField field : mappingFields)
			{
				if (counter++ == bandIdPosition)
					break;
				position = position + field.getFieldLength();
			}
		}
		return position;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef)
	{
		String fmtStr = null;
		int bandIdPosition = 0;
		String bandValue = null;
		
		fmtStr = (String) obj;
		if (fmtStr.length() >= bandDef.getBandIdPosition())
		{
			if (bandDef.getBandIdPosition() > 0)
			{
				bandIdPosition = getBandIdFieldPosition(bandDef.getBandIdPosition() - 1, bandDef.getMappingFields());
				bandValue = fmtStr.substring(bandIdPosition, bandIdPosition + bandDef.getBandIdLength());
			}
		}
		return bandValue;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef)
	{
		String bandValue = null;
		
		if (bandDef.getBandId() == null)
			return true;
		
		bandValue = getBandId(obj, bandDef);
		
		if (bandDef.getBandId().equals(bandValue))
			return true;
		return false;
	}
	
}
