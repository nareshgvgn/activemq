package com.fundtech.iris.admin.execution.formatter;

import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: XMLDOMFormatter.java,v 1.13 2015/12/23 04:20:31 ramap Exp $
 * @since 1.0.0
 */
public class XMLDOMFormatter extends AbstractFormatter
{
	private static final Logger logger = LoggerFactory.getLogger(XMLDOMFormatter.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#uploadFormat(java.lang.Object, java.util.Stack, java.util.Stack,
	 * com.fundtech.iris.admin.data.RootBand)
	 */
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		
		XPath xPath = null;
		InterfaceBandDef bandDef = null;
		String expression = null;
		NodeList rootList = null;
		Node parentNode = null;
		Node childNode = null;
		Band dataBand = null;
		Map<String, DataField> dataValues = null;
		FormatException fExp = null;
		Band batchBand = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String bandName = null;
		String strBandDef = null;
		
		try
		{
			bandDef = defStack.peekFirst();
			bandName = bandDef.getBandName();
			batchBand = dataStack.peekFirst();
			dataBand = new Band();
			dataBand.setId(bandDef.getBandId());
			dataBand.setName(bandDef.getBandName());
			dataBand.setBandPath(bandDef.getBandPath());
			dataBand.setBandType(bandDef.getBandType());
			parentNode = (Node) obj;
			
			if (bandDef.getParentBandName() == null)
				dataBand.setParentBand(null);
			else
				dataBand.setParentBand(batchBand);
			
			batchBand.addChildBand(dataBand);
			dataStack.addFirst(dataBand);
			dataValues = formatBandData(lineNumber, parentNode, bandDef, dataBand);
			dataBand.addFields(dataValues);
			bandDefs = bandDef.getChildDefinitions().getBandDefinitions();
			for (InterfaceBandDef childDef : bandDefs.values())
			{
				expression = childDef.getRelativeXPath();
				xPath = XPathFactory.newInstance().newXPath();
				rootList = (NodeList) xPath.compile(expression).evaluate(parentNode, XPathConstants.NODESET);
				if (rootList == null)
				{
					logger.trace("{} or {} Doersn't have any data in xml", childDef.getBandName(), expression);
					
					if (childDef.isMandatory())
					{
						errorMsg = childDef.getBandName() + " or " + expression + " Doersn't have any data in xml";
						strBandDef = childDef.toString();
						fExp = new FormatException("err.irisadmin.format", new Object[]
						{ errorMsg, strBandDef }, null);
						error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, strBandDef, null);
						jobData.addError(error);
						logger.error(IRISLogger.getText(fExp));
						throw fExp;
					}
				}
				defStack.addFirst(childDef);
				for (int index = 0; null != rootList && index < rootList.getLength(); index++)
				{
					childNode = rootList.item(index);
					uploadFormat(lineNumber, childNode, defStack, dataStack);
				}
				defStack.removeFirst();
			}
			dataStack.removeFirst();
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (XPathExpressionException exp)
		{
			errorMsg = "Error While Creating band:" + bandName + "  " + exp.getMessage();
			if (bandDef != null)
				strBandDef = bandDef.toString();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, strBandDef }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, strBandDef, null);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating band:" + bandName;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, strBandDef }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, strBandDef, null);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			strBandDef = null;
		}
		
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#format(long, java.lang.Object,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	@Override
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		Map<String, DataField> dataValues = null;
		String fldVal = null;
		List<MappingField> listFields = null;
		FormatException fExp = null;
		String expression = null;
		XPath xPath = null;
		Node fieldNode = null;
		Node parentNode = null;
		String errorMsg = null;
		IrisAdminError error = null;
		
		dataValues = new HashMap<String, DataField>();
		parentNode = (Node) obj;
		listFields = bandDef.getMappingFields();
		xPath = XPathFactory.newInstance().newXPath();
		for (MappingField field : listFields)
		{
			try
			{
				if (field.getMappingType() == IrisAdminConstants.MAPPING_TYPE_DIRECT)
				{
					// remove [] if attribute comes
					expression = getExpression(field.getRelativeXPath());
					fieldNode = (Node) xPath.compile(expression).evaluate(parentNode, XPathConstants.NODE);
					
					if (fieldNode != null)
						fldVal = fieldNode.getNodeValue();
					
					checkMandatory(field, fldVal, expression);
				}
				
				validateField(fldVal, field, bandDef, dataBand, dataValues);
				fldVal = null;
			}
			catch (FormatException exp)
			{
				throw exp;
			}
			catch (Exception exp)
			{
				errorMsg = "Error While Creating Band";
				fExp = new FormatException("err.irisadmin.format", new Object[]
				{ errorMsg }, exp);
				error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
				jobData.addError(error);
				logger.error(IRISLogger.getText(fExp));
				throw fExp;
			}
		}
		return dataValues;
	}
	
	/**
	 * <p>
	 * This helper method checks the mandatory fields
	 * 
	 * @param field
	 * @param fldVal
	 * @param expression
	 * @throws FormatException
	 *             </pre>
	 *             </p>
	 */
	private void checkMandatory (MappingField field, String fldVal, String expression) throws FormatException
	{
		String errorMsg = null;
		IrisAdminError error = null;
		String fldName = null;
		FormatException fExp = null;
		
		if (field.isMandatory() && fldVal == null)
		{
			fldName = field.getFieldName();
			logger.trace("{} or {} Doersn't have any data in xml.", fldName, expression);
			errorMsg = "Value of Mandatory Field is NULL. Field Name:" + fldName + " Band:" + field.getBandName() + " Sequence No:"
					+ field.getsequenceNmbr() + " Expression:" + expression;
			fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
			{ errorMsg, field.toString() }, null);
			error = createError(IrisAdminConstants.ERR_CODE_MANDATORY, errorMsg, field.toString(), null);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param expression
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private String getExpression (String expression)
	{
		String temp1 = null;
		String temp2 = null;
		String finalExpression = null;
		
		if (!expression.contains("@"))
			return expression;
		// remove [] from xpath
		temp1 = expression.substring(0, expression.indexOf("@") - 1);
		temp2 = expression.substring(expression.indexOf("@"), expression.length() - 1);
		finalExpression = temp1 + "/" + temp2;
		
		return finalExpression;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#downloadFormat(com.fundtech.iris.admin.data.Band,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	public Object downloadFormat (Band dataBand, InterfaceBandDef def) throws FormatException
	{
		
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// No need of this method for XML Formatter
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// No need of this method for XML Formatter
		return false;
	}
	
}
