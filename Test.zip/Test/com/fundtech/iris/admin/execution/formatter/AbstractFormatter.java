/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : AbstractACHFormatter.java
 * CREATED: Jan 27, 2014 4:11:09 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.DateUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.CodeMap;
import com.fundtech.iris.admin.Definitions;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.ZeroProofing;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.functions.IFunction;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.interfaces.ZeroProofingDef;
import com.fundtech.iris.admin.model.ModelBandDef;
import com.fundtech.iris.admin.model.ModelField;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * This class is an Abstract implementation of {@link IFormatter}. This class implements initialize & cleanup methods. Reset of the methods are helper
 * methods.
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: AbstractFormatter.java,v 1.62 2017/02/27 13:21:08 ramap Exp $
 */
public abstract class AbstractFormatter implements IFormatter
{
	private static Logger logger = LoggerFactory.getLogger(AbstractFormatter.class);
	private ApplicationContext applicationContext = null;
	private ConnectionProvider conProvider = null;
	private Connection dbConnection = null;
	protected InterfaceDef interfaceDef = null;
	protected ExecutionJobData jobData = null;
	private ZeroProofings zeroProofings = null;
	private Map<String, Object> hooks = new HashMap<String, Object>();
	private long lineNumber = 0;
	public IrisError irisError = null;
	private String booleanPattern = "(?i)(TRUE|FASE|YES|NO|Y|N)";
	private String decimalPattern = "^[-,+]?+\\d+([,| ]\\d+)*(\\.\\d+)?$";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IFormatter#initialize()
	 */
	public void initialize (ApplicationContext applicationContext, InterfaceDef interfaceDef, ExecutionJobData jobData, ZeroProofings zeroProofings)
	{
		this.applicationContext = applicationContext;
		this.interfaceDef = interfaceDef;
		this.jobData = jobData;
		this.zeroProofings = zeroProofings;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#cleanup()
	 */
	public void cleanup ()
	{
		try
		{
			if (conProvider != null && dbConnection != null)
				conProvider.releaseConnection(dbConnection);
			conProvider = null;
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
	}
	
	/**
	 * <p>
	 * This helper methods assigns the code map. if the incoming value is null or empty, default value will be assigned. if the incoming value code
	 * mapped to default value, default value will be assigned
	 * <p>
	 * <i> Field which is having property of IrisAdminConstants.MAPPING_TYPE_CODEMAP</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandDef
	 * @param field
	 * @param fldVal
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String assignCodeMap (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		IrisAdminError error = null;
		String errorMsg = null;
		
		try
		{
			codeMap = field.getCodeMap();
			if (fldVal != null)
				fldVal = fldVal.trim();
			
			if (fldVal == null || "".equals(fldVal))
				codeMapVal = getDefaultCodeMap(bandDef, field, fldVal);
			else if (codeMap.contains(fldVal))
				codeMapVal = geGridCodeMap(bandDef, field, fldVal);
			else
				codeMapVal = getRestCodeMap(bandDef, field, fldVal);
			
			if (codeMapVal != null && codeMapVal.length() > field.getIFieldLength())
				codeMapVal = codeMapVal.substring(0, field.getIFieldLength());
			
		}
		catch (Exception exp)
		{
			errorMsg = "Code Map:" + codeMap.getCodeMapId() + " Value for Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:"
					+ field.getFieldName();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString(), field.toString() }, exp);
			error = createInterError(IrisAdminConstants.ERR_CODE_CODEMAP, errorMsg, bandDef.toString() + field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			errorMsg = null;
		}
		return codeMapVal;
	}
	
	
	/**
	 * <p>
	 * This helper method calls the function which is configured for a field. This function uses reference fields and static values only. This
	 * function will not read from file.
	 * <p>
	 * <i> This method reads the function data and breaks in to 2 parts. 1 part will be function name and 2nd part will be data based inside function.
	 * i.e with in ()</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param dataBand
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String assignCodeMapRef (InterfaceBandDef bandDef,MappingField field, Band dataBand, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		IrisAdminError error = null;
		String errorMsg = null;
		
		try
		{
					
			fldVal = IrisAdminUtils.getRefValue(field, dataBand, null);
			codeMap = field.getCodeMap();
			if (fldVal != null)
				fldVal = fldVal.trim();
			
			if (fldVal == null || "".equals(fldVal))
				codeMapVal = getDefaultCodeMap(bandDef, field, fldVal);
			else if (codeMap.contains(fldVal))
				codeMapVal = geGridCodeMap(bandDef, field, fldVal);
			else
				codeMapVal = getRestCodeMap(bandDef, field, fldVal);
			
			if (codeMapVal != null && codeMapVal.length() > field.getIFieldLength())
				codeMapVal = codeMapVal.substring(0, field.getIFieldLength());
			
		}
		catch (Exception exp)
		{
			errorMsg = "Code Map:" + codeMap.getCodeMapId() + " Value for Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:"
					+ field.getFieldName() + " Reference Field Name:" + field.getBandRef()+ "." + field.getFieldRef();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString(), field.toString() }, exp);
			error = createInterError(IrisAdminConstants.ERR_CODE_CODEMAP, errorMsg, bandDef.toString() + field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			errorMsg = null;
		}
		return codeMapVal;
	}
	
	public String assignIsNullCodeMapRef (InterfaceBandDef bandDef,MappingField field, Band dataBand, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		IrisAdminError error = null;
		String errorMsg = null;
		
		try
		{
			// if fldVal is not empty then keep that one only. if empty please bring from code map
			if ( StringUtils.isNotEmpty(fldVal))
					return fldVal;
					
			fldVal = IrisAdminUtils.getRefValue(field, dataBand, null);
			codeMap = field.getCodeMap();
			if (fldVal != null)
				fldVal = fldVal.trim();
			
			if (fldVal == null || "".equals(fldVal))
				codeMapVal = getDefaultCodeMap(bandDef, field, fldVal);
			else if (codeMap.contains(fldVal))
				codeMapVal = geGridCodeMap(bandDef, field, fldVal);
			else
				codeMapVal = getRestCodeMap(bandDef, field, fldVal);
			
			if (codeMapVal != null && codeMapVal.length() > field.getIFieldLength())
				codeMapVal = codeMapVal.substring(0, field.getIFieldLength());
			
		}
		catch (Exception exp)
		{
			errorMsg = "Code Map:" + codeMap.getCodeMapId() + " Value for Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:"
					+ field.getFieldName() + " Reference Field Name:" + field.getBandRef()+ "." + field.getFieldRef();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString(), field.toString() }, exp);
			error = createInterError(IrisAdminConstants.ERR_CODE_CODEMAP, errorMsg, bandDef.toString() + field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			errorMsg = null;
		}
		return codeMapVal;
	}
	
	/**
	 * <p>
	 * This helper methods assigns the constant value
	 * <p>
	 * <i> Field which is having property of IrisAdminConstants.MAPPING_TYPE_CONSTANT</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	public String assignConstant (MappingField field)
	{
		String fldVal = null;
		fldVal = field.getConstantValue();
		return fldVal;
	}
	
	/**
	 * <p>
	 * This helper method calls the function which is configured for a field. This function uses reference fields and static values only. This
	 * function will not read from file.
	 * <p>
	 * <i> This method reads the function data and breaks in to 2 parts. 1 part will be function name and 2nd part will be data based inside function.
	 * i.e with in ()</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param dataBand
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String callComplexFunction (InterfaceBandDef bandDef,MappingField field, Band dataBand) throws FormatException
	{
		String fldVal = null;
		FormatException fExp = null;
		IFunction function = null;
		Class<?> clazz = null;
		String functionClass = null;
		
		Map<String, Object> params = null;
		String[] functionData = null;
		String funcName = null;
		String functionparm = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String[] functionList = null;
		
		try
		{
			functionList = getFunctions(bandDef, field.getDerivationLogic1(), field.getDerivationLogic2());
			if (functionList == null)
				return null;
			makeDBConnection();
			for (String key : functionList)
			{
				functionData = getFunctionName(bandDef,key);
				if (functionData == null)
					return null;
				
				funcName = functionData[0];
				functionparm = functionData[1];
				functionClass = Definitions.getInstance().getFunctionClass(funcName);
				clazz = Class.forName(functionClass);
				function = (IFunction) clazz.newInstance();
				params = new HashMap<String, Object>();
				params.put(IFunction.FUNCTION_DATA, functionparm);
				params.put(IFunction.FUNCTION_FIELD, field);
				params.put(IFunction.FUNCTION_VALUE, fldVal);
				params.put(IFunction.EXECUTION_DATA, jobData);
				params.put(IFunction.EXECUTION_BAND, dataBand);
				params.put(IFunction.EXECUTION_BAND_DEF, bandDef);
				fldVal = (String) function.execute(dbConnection, params);
			}
			if (fldVal != null && fldVal.length() > field.getFieldLength())
				fldVal = fldVal.substring(0, field.getFieldLength());
		}
		catch (FormatException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(exp));
			
			if (!jobData.isAccumulateErros())
				throw exp;
		}
		catch (ExecutionException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, field.toString(), }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		catch (ClassNotFoundException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, field.toString(), }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (InstantiationException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString(), }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (IllegalAccessException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString(), }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString(), }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			CleanUpUtils.doClean(params);
			params = null;
			function = null;
			clazz = null;
			errorMsg = null;
		}
		return fldVal;
	}
	
	/**
	 * <p>
	 * This helper method calls the function which is configured for a field.
	 * <p>
	 * <i> This method reads the function data and breaks in to 2 parts. 1 part will be function name and 2nd part will be data based inside function.
	 * i.e with in ()</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String callFucntion (InterfaceBandDef bandDef,MappingField field, String fldVal) throws FormatException
	{
		IFunction function = null;
		Class<?> clazz = null;
		String functionClass = null;
		Map<String, Object> params = null;
		String[] functionData = null;
		String funcName = null;
		String functionparm = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String[] functionList = null;
		
		try
		{
			functionList = getFunctions(bandDef, field.getDerivationLogic1(), field.getDerivationLogic2());
			if (functionList == null)
				return null;
			makeDBConnection();
			for (String key : functionList)
			{
				functionData = getFunctionName(bandDef,key);
				if (functionData == null)
					return null;
				funcName = functionData[0];
				functionparm = functionData[1];
				
				functionClass = Definitions.getInstance().getFunctionClass(funcName);
				clazz = Class.forName(functionClass);
				function = (IFunction) clazz.newInstance();
				params = new HashMap<String, Object>();
				params.put(IFunction.FUNCTION_DATA, functionparm);
				params.put(IFunction.FUNCTION_FIELD, field);
				params.put(IFunction.FUNCTION_VALUE, fldVal);
				params.put(IFunction.EXECUTION_DATA, jobData);
				params.put(IFunction.EXECUTION_BAND_DEF, bandDef);
				fldVal = (String) function.execute(dbConnection, params);
			}
			if (fldVal != null && fldVal.length() > field.getIFieldLength())
				fldVal = fldVal.substring(0, field.getIFieldLength());
			
		}
		catch (FormatException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(exp));
			
			if (!jobData.isAccumulateErros())
				throw exp;
		}
		catch (ExecutionException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		catch (ClassNotFoundException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (InstantiationException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (IllegalAccessException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			CleanUpUtils.doClean(params);
			params = null;
			function = null;
			clazz = null;
			errorMsg = null;
		}
		return fldVal;
	}
	
	/**
	 * 
	 * <p>
	 * This helper method calls the function which is configured for a field.
	 * <p>
	 * <i> This method reads the function data and breaks in to 2 parts. 1 part will be function name and 2nd part will be data based inside function.
	 * i.e with in ()</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param dataBand
	 * @param fldVal
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String callHook (InterfaceBandDef bandDef,MappingField field, Band dataBand, String fldVal) throws FormatException
	{
		IFunction function = null;
		Class<?> clazz = null;
		String functionClass = null;
		Map<String, Object> params = null;
		String[] functionData = null;
		String funcName = null;
		String functionparm = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String[] functionList = null;
		int index = 1;
		
		try
		{
			functionList = getFunctions(bandDef, field.getDerivationLogic1(), field.getDerivationLogic2());
			if (functionList == null)
				return null;
			makeDBConnection();
			for (String key : functionList)
			{
				functionData = getFunctionName(bandDef,key);
				if (functionData == null)
					return null;
				funcName = functionData[0];
				functionparm = functionData[1];
				
				if (hooks.containsKey(field.getFieldName() + index))
				{
					function = (IFunction) hooks.get(field.getFieldName());
				}
				else
				{
					functionClass = Definitions.getInstance().getFunctionClass(funcName);
					clazz = Class.forName(functionClass);
					function = (IFunction) clazz.newInstance();
				}
				
				params = new HashMap<String, Object>();
				params.put(IFunction.FUNCTION_DATA, functionparm);
				params.put(IFunction.FUNCTION_FIELD, field);
				params.put(IFunction.FUNCTION_VALUE, fldVal);
				params.put(IFunction.EXECUTION_DATA, jobData);
				params.put(IFunction.EXECUTION_BAND, dataBand);
				params.put(IFunction.EXECUTION_BAND_DEF, bandDef);
				fldVal = (String) function.execute(dbConnection, params);
				hooks.put(field.getFieldName() + index, function);
				index ++;
			}
			if (fldVal != null && fldVal.length() > field.getFieldLength())
				fldVal = fldVal.substring(0, field.getFieldLength());
		}
		catch (FormatException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(exp));
			
			if (!jobData.isAccumulateErros())
				throw exp;
		}
		catch (ExecutionException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		catch (ClassNotFoundException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (InstantiationException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (IllegalAccessException exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While executing Function:" + funcName + " for  Field Name:" + field.getFieldName() + " and Field value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			params = null;
			function = null;
			clazz = null;
		}
		
		return fldVal;
	}
	
	/**
	 * 
	 * <p>
	 * Check the field mapping type to read from data or needs to derive
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param mappingType
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	public boolean checkFieldMappingType (int mappingType)
	{
		if (IrisAdminConstants.MAPPING_TYPE_CONSTANT == mappingType || IrisAdminConstants.MAPPING_TYPE_REFERENCED == mappingType
				|| IrisAdminConstants.MAPPING_TYPE_COMPLEX == mappingType || IrisAdminConstants.MAPPING_TYPE_FILTER == mappingType 
				|| IrisAdminConstants.MAPPING_TYPE_REFCODEMAP == mappingType || IrisAdminConstants.MAPPING_TYPE_IGNORE == mappingType)
		
		{
			return false;
		}
		return true;
	}
	
	public String checkLength (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		int fieldLength = 0;
		
		if ( fldVal == null)
			return null;
		fieldLength = field.getFieldLength();
		if (field.isRestrictToSize() && fieldLength < fldVal.length())
		{
			errorMsg = "Error While checking  size  for  Field Name:" + field.getFieldName() +" (Length-"+ fieldLength + ") and Field value:" + fldVal ;
			fExp = new FormatException("err.irisadmin.format.length", new Object[]	{ errorMsg, field.toString() }, null);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		else
			
			fldVal = StringUtils.substring(fldVal, 0,fieldLength);
			
		return fldVal;
	}
	
	/**
	 * <p>
	 * This helper method checks field is mandatory or not
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param field
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public void checkMandatory (InterfaceBandDef bandDef, MappingField field) throws FormatException
	{
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		
		if (field.isMandatory() && IrisAdminConstants.MAPPING_TYPE_IGNORE != field.getMappingType())
		{
			errorMsg = "Value of Mandatory Field is NULL. Field Name:" + field.getFieldName() + " Band:" + field.getBandName() + " Sequence No:"
					+ field.getsequenceNmbr();
			fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
			{ errorMsg, field.toString() }, null);
			error = createError(IrisAdminConstants.ERR_CODE_MANDATORY, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
	}
	
	/**
	 * <p>
	 * This helper method creates the Data Band
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param obj
	 * @param defDeque
	 * @param dataDeque
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	public boolean createBand (long lineNumber, Object original, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack)
			throws FormatException
	{
		InterfaceBandDef bandDef = null;
		Band dataBand = null;
		Map<String, DataField> dataValues = null;
		Band batchBand = null;
		FormatException fExp = null;
		boolean returnVal = false;
		String errorMsg = null;
		IrisAdminError error = null;
		String bandName = null;
		String strBandDef = null;
		
		try
		{
			this.lineNumber = lineNumber;
			bandDef = defStack.peekFirst();
			bandName = bandDef.getBandName();
			if (!dataStack.isEmpty())
				batchBand = dataStack.peekFirst();
			
			if (batchBand == null)
			{
				batchBand = new Band();
				dataStack.addFirst(batchBand);
			}
			
			if (bandName.equals(batchBand.getName()))
			{
				dataStack.removeFirst();// remove same band
				batchBand = dataStack.peekFirst();
			}
			
			dataBand = new Band();
			dataBand.setId(bandDef.getBandId());
			dataBand.setName(bandName);
			dataBand.setBandPath(bandDef.getBandPath());
			dataBand.setBandType(bandDef.getBandType());
			
			if (bandDef.getParentBandName() == null)
				dataBand.setParentBand(null);
			else
				dataBand.setParentBand(batchBand);
			
			batchBand.addChildBand(dataBand);
			dataValues = formatBandData(lineNumber, obj, bandDef, dataBand);
			findZeroProofing(bandDef, dataValues);
			dataBand.addFields(dataValues);
			dataStack.addFirst(dataBand);
			returnVal = true;
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating band:" + bandName;
			if (bandDef != null)
				strBandDef = bandDef.toString();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, strBandDef }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, strBandDef, "");
			jobData.addError(error);
			
			if ( bandDef != null)
				createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			else
				createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			if ( irisError != null)
			{
				arrangeError(bandDef.getBandType(), dataValues, lineNumber);
			}
			
			irisError = null;
			this.lineNumber = 0;
		}
		return returnVal;
	}
	
	
	

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandType
	 * @param dataValues
	 * </pre></p>
	 */
	public void arrangeError (String bandType, Map<String, DataField> dataValues, long lineNumber)
	{
		ModelBandDef modelDef = null;
		IrisError bandError = null;
		StringBuilder errorCode = new StringBuilder();
		Map<String, ModelField> modelFields = null;
		String fieldName  = null;
		int count = 0;
		String value = null;
		DataField dataField = null;
		
		try
		{
			
			modelDef = getModelDef(bandType);
			modelFields = modelDef.getInterfaceFields();
			bandError = new IrisError();
			bandError.addErrorDesc(irisError.getErrorDesc());
			bandError.setBandName(irisError.getBandName());
			bandError.setBandType(bandType);
			bandError.setLineNumber(lineNumber);
			
			
			for (ModelField field : modelFields.values())
			{
				if (field.isKeyField())
				{
					if (count != 0 )
						errorCode.append(", ");
					count = 1;
					fieldName = field.getFieldName();
					errorCode.append(fieldName);
					errorCode.append("=");
					dataField = dataValues.get(fieldName);
					if ( dataField != null)
					{
						value = dataField.getValue();
						if (value == null)
							errorCode.append(value);
					}
					
				}
			}
			
			bandError.setErrorCode(errorCode.toString());
			jobData.addIrisError(bandError);
		}
		catch ( Exception exp)
		{
			logger.error("Error:",exp);
			//Ignore Exception
		}
		finally
		{
			CleanUpUtils.doClean(errorCode);
			irisError = null;
		}
		
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandType
	 * @return
	 * </pre></p>
	 */
	private ModelBandDef getModelDef (String bandType)
	{
		 Map<String, ModelBandDef> modelBandDefs = null;
		 ModelBandDef returnModelDef = null;
		 
		 modelBandDefs = jobData.getInterfaceDef().getMosdelDef().getBandsDefinition().getBandDefinitions();
		 returnModelDef = getModelDef(bandType, modelBandDefs);
		return returnModelDef;
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandType
	 * @param modelBandDefs
	 * @return
	 * </pre></p>
	 */
	private ModelBandDef getModelDef (String bandType, Map<String, ModelBandDef> modelBandDefs)
	{
		ModelBandDef bandDef = null;
		 Map<String, ModelBandDef> childBandDefs = null;

		 if ( modelBandDefs.containsKey(bandType))
		 {
			 bandDef =  modelBandDefs.get(bandType);
			 return bandDef;
		 }
		 
		for (Map.Entry<String, ModelBandDef> entry : modelBandDefs.entrySet())
		{
			bandDef = entry.getValue();
			childBandDefs = bandDef.getChildBandDefs();
			bandDef = getModelDef(bandType, childBandDefs);
			if ( bandDef != null)
				break;
		}
		return bandDef;
	}

	public final void createIrisError (String bandType, String bandName, String errorMessage)
	{
		if ( irisError == null)
		{
			irisError = new IrisError();
			irisError.setBandType(bandType);
			irisError.setBandName(bandName);
			irisError.setLineNumber(lineNumber);
		}
		irisError.addErrorDesc(errorMessage);
	}
	
	public final IrisAdminError createError (String errCode, String errMsg, String info1, String errLine)
	{
		IrisAdminError error = null;
		
		error = new IrisAdminError(lineNumber, IrisAdminConstants.ERR_TYPE_ERROR, errCode, errMsg, info1, errLine);
		return error;
	}
	
	public final IrisAdminError createInterError (String errCode, String errMsg, String info1, String errLine)
	{
		IrisAdminError error = null;
		
		error = new IrisAdminError(lineNumber, IrisAdminConstants.ERR_TYPE_INTER, errCode, errMsg, info1, errLine);
		return error;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#downloadFormat(com.fundtech.iris.admin.data.BatchBand,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	@Override
	public Object downloadFormat (BatchBand dataBatchBand, InterfaceBandDef currentDef, Band dataBand) throws FormatException
	{
		return null;
	}
	
	/**
	 * 
	 * <p>
	 * This is an abstract method for this class. so that implementation classes can customize incoming data and this method will be called back
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param obj
	 * @param bandDef
	 * @param dataBand
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public abstract Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand)
			throws FormatException;
	
	/**
	 * <p>
	 * This helper method in upload reads the field value and converts to {@link DateUtils.ISO_DATEFORMAT}. In download it converts
	 * {@link DateUtils.ISO_DATEFORMAT} to user defined data format.
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String getDateAsString (InterfaceBandDef bandDef, MappingField field, String fldVal, Band dataBand) throws FormatException
	{
		SimpleDateFormat dateFormat = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		try
		{
			if ( fldVal == null || "".equals(fldVal.trim()))
				return fldVal;
			
			dateFormat = new SimpleDateFormat(field.getFormat());
			
			/*
			 * if lenient is true & input date is like 2005-13-06 [yyyy-MM-dd] this date will get converted as like 2006-01-06 i.e. if month is
			 * more that 12 it will increase year by 1 instead of throwing parsing error, so set lenient to false
			 */
			dateFormat.setLenient(false);
			dateFormat.parse(fldVal);
			//Ignore this date. Just we are checking date parsed or not.
			
		}
		catch (ParseException exp)
		{
			errorMsg = "Incorrect Date format for Field. Band Name:" + field.getBandName() + " FieldName:" + field.getFieldName() + " Field Value:"
					+ fldVal + " Field Format:" + field.getFormat();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Incorrect Date format for Field. Band Name:" + field.getBandName() + " FieldName:" + field.getFieldName() + " Field Value:"
					+ fldVal + " Field Format:" + field.getFormat();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			dateFormat = null;
			errorMsg = null;
		}
		return fldVal;
	}
	
	/**
	 * <p>
	 * This helper method assigns the default value
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	public String getDefaultValue (MappingField field)
	{
		String fldVal = null;
		fldVal = field.getDefaultValue();
		
		return fldVal;
	}
	
	/**
	 * <p>
	 * This helper method sets the filter parameter value to the field
	 * <p>
	 * <i> Filter parameters are read from {@link ExecutionJobData}</i></i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @param jobData
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	public String getFilterParameter (MappingField field, String fldVal, ExecutionJobData jobData)
	{
		String filterVal = null;
		filterVal = jobData.getFilterParameter(field.getFieldRef());
		
		return filterVal;
	}
	
	/**
	 * <p>
	 * This helper method creates key value pair for given line by using regular expression
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param line
	 * @param REGEX --regular expression
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public Map<String, String> getKeyValue (InterfaceBandDef bandDef,String line, String REGEX) throws FormatException
	{
		Matcher matcher = null;
		Pattern pattern = null;
		String key = null;
		String value = null;
		Map<String, String> data = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		
		try
		{
			pattern = Pattern.compile(REGEX);
			matcher = pattern.matcher(line);
			data = new HashMap<String, String>();
			while (matcher.find())
			{
				key = matcher.group(1);
				value = matcher.group(2);
				data.put(key, value);
			}
			
			if (key == null)
			{
				errorMsg = "No Valid data found in the line";
				fExp = new FormatException("err.irisadmin.format.parse", new Object[]
				{ errorMsg, REGEX }, null);
				error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, REGEX, line);
				jobData.addError(error);
				createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
				logger.error(IRISLogger.getText(fExp));
				throw fExp;
			}
			
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "No Valid data found in the line";
			fExp = new FormatException("err.irisadmin.format.parse", new Object[]
			{ errorMsg, REGEX }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, REGEX, line);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			pattern = null;
			matcher = null;
			key = null;
		}
		return data;
	}
	
	/**
	 * <p>
	 * This helper methods gets the reference value of own parent bands or same band which ever is referenced
	 * <p>
	 * <i> Field which is having property of IrisAdminConstants.MAPPING_TYPE_REFERENCED</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param dataBand
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	@Deprecated
	public String getRefValue (InterfaceBandDef bandDef,MappingField field, Band dataBand) throws FormatException
	{
		String bandRef = null;
		String fieldRef = null;
		boolean exists = false;
		Band parentBand = null;
		String fldVal = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		
		try
		{
			bandRef = field.getBandRef();
			fieldRef = field.getFieldRef();
			
			while (!exists)
			{
				if (dataBand.getName().equals(bandRef))
				{
					fldVal = dataBand.getFieldValue(fieldRef);
					exists = true;
				}
				else
				{
					parentBand = dataBand.getParentBand();
					if (parentBand == null)
						exists = true;
					else
					{
						fldVal = getRefValue(bandDef,field, parentBand);
						exists = true;
					}
				}
			}
		}
		catch (Exception exp)
		{
			errorMsg = "Ref Value for Field Val:" + fldVal + " BandRef:" + bandRef + " Field Ref:" + fieldRef;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createInterError(IrisAdminConstants.ERR_CODE_REFVAL, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			errorMsg = null;
		}
		
		return fldVal;
	}
	
	/**
	 * <p>
	 * This helper methods gets the reference value of own parent bands or same band which ever is referenced
	 * <p>
	 * <i> Field which is having property of IrisAdminConstants.MAPPING_TYPE_REFERENCED</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param dataBand
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	@Deprecated
	public DataField getRefField (InterfaceBandDef bandDef,MappingField field, Band dataBand) throws FormatException
	{
		String bandRef = null;
		String fieldRef = null;
		boolean exists = false;
		Band parentBand = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		DataField dataField = null;
		
		try
		{
			bandRef = field.getBandRef();
			fieldRef = field.getFieldRef();
			
			while (!exists)
			{
				if (dataBand.getName().equals(bandRef))
				{
					dataField = dataBand.getDataField(fieldRef);
					exists = true;
				}
				else
				{
					parentBand = dataBand.getParentBand();
					
					if (parentBand == null)
						exists = true;
					else
					{
						dataField = getRefField(bandDef,field, parentBand);
						exists = true;
					}
				}
			}
		}
		catch (Exception exp)
		{
			errorMsg = "Ref Value for Field Val:" + dataField + " BandRef:" + bandRef + " Field Ref:" + fieldRef;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createInterError(IrisAdminConstants.ERR_CODE_REFVAL, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		finally
		{
			errorMsg = null;
		}
		
		return dataField;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack,
	 * com.fundtech.iris.admin.data.RootBand)
	 */
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> stack, Deque<Band> dataValues) throws FormatException,
			ExecutionException
	{
		return false;
	}
	
	/**
	 * <p>
	 * This helper method validates the field and assign to data.
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param fldVal
	 * @param field
	 * @param bandDef
	 * @param dataBand
	 * @param dataValues
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public void validateField (String fldVal, MappingField field, InterfaceBandDef bandDef, Band dataBand, Map<String, DataField> dataValues)
			throws FormatException
	{
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		DataField dataField = null;
		try
		{
			fldVal = formatNonDirect(field, fldVal, dataBand, bandDef);
			
			if (fldVal != null && !fldVal.trim().equals(""))
			{
				fldVal = fldVal.trim();
			}
			else
				checkMandatory(bandDef, field);
			
			dataField = createDataField(field, fldVal);
			dataBand.setFieldValue(field.getFieldName(), dataField);
			dataValues.put(field.getFieldName(), dataField);
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Value of Mandatory Field is NULL. Field Name:" + field.getFieldName() + " Band:" + field.getBandName() + " Sequence No:"
					+ field.getsequenceNmbr() + " Field Value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
			{ errorMsg, bandDef.toString(), field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_VALIDATE, errorMsg, bandDef.toString() + field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private DataField createDataField (MappingField field, String fldVal)
	{
		DataField dataField = null;
		
		dataField = new DataField();
		dataField.setDataType(field.getDataType());
		dataField.setFieldLength(field.getFieldLength());
		dataField.setFieldType(field.getFieldType());
		dataField.setFormat(field.getFormat());
		dataField.setMappingType(field.getMappingType());
		dataField.setPrecision(field.getPrecision());
		dataField.setValue(fldVal);
		
		return dataField;
	}
	
	/**
	 * <p>
	 * This Helper method formats Non direct field mappings
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @param dataBand
	 * @param bandDef
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	protected String formatNonDirect (MappingField field, String fldVal, Band dataBand, InterfaceBandDef bandDef) throws FormatException
	{
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		try
		{
			/*
			 * Try to get as much data possible for the given MappingType
			 */
			if (fldVal == null || "".equals(fldVal.trim()))
				fldVal = getDefaultValue(field);
			/**
			 * Added this code to support restricted size
			 */
			fldVal = checkLength(bandDef,field, fldVal);
			
			if (IrisAdminConstants.MAPPING_TYPE_FILTER == field.getMappingType())
				/* 9 */fldVal = getFilterParameter(field, fldVal, jobData);
			
			if (IrisAdminConstants.MAPPING_TYPE_FUNCTION == field.getMappingType())
				/* 2 */fldVal = callFucntion(bandDef,field, fldVal);
			
			if (IrisAdminConstants.MAPPING_TYPE_ROUTINE == field.getMappingType())
				/* 10 */fldVal = callHook(bandDef,field, dataBand, fldVal);
			
			if (IrisAdminConstants.MAPPING_TYPE_CONSTANT == field.getMappingType())
				/* 5 */fldVal = assignConstant(field);
			
			if (IrisAdminConstants.MAPPING_TYPE_CODEMAP == field.getMappingType())
				/* 3 */fldVal = assignCodeMap(bandDef, field, (String) fldVal);
			
			if (IrisAdminConstants.MAPPING_TYPE_REFERENCED == field.getMappingType())
				/* 1 */fldVal = getRefValue(bandDef,field, dataBand);
			
			if (IrisAdminConstants.MAPPING_TYPE_REFCODEMAP == field.getMappingType())
				/* 13 */fldVal = assignCodeMapRef(bandDef,field, dataBand, fldVal);
			
			if (IrisAdminConstants.MAPPING_TYPE_ISNULLCODEMAP == field.getMappingType())
				/* 15 */fldVal = assignIsNullCodeMapRef(bandDef,field, dataBand, fldVal);
			
			if (IrisAdminConstants.MAPPING_TYPE_COMPLEX == field.getMappingType())
				/* 4 */fldVal = callComplexFunction(bandDef,field, dataBand);
			
			fldVal = formatVal(bandDef,field, fldVal, jobData, dataBand);
			// Check length
			
			
			if (fldVal == null)
			{
				fldVal = "";
			}
			
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While parsing fields.";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, bandDef.toString(), field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, bandDef.toString() + field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return fldVal;
	}
	
	/*------------------------------------------------------------------------------------------------------------------------------------
	 * HELPER METHODS
	 * ----------------------------------------------------------------------------------------------------------------------------------*/
	/**
	 * <p>
	 * This helper method sets the zero proofing values
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param zeroProofing
	 * @param fldPrime
	 * @param primeVal
	 * @param fldSource
	 * @param sourceVal
	 * </pre>
	 * 
	 * </p>
	 */
	private ZeroProofing createZeroProofing (String bandName, String fieldNaname, String fldVal)
	{
		ZeroProofing zeroProofing = null;
		
		zeroProofing = new ZeroProofing();
		zeroProofing.setSourceBandName(bandName);
		zeroProofing.setSourceFieldName(fieldNaname);
		zeroProofing.setSourceValue(Double.parseDouble(fldVal));
		
		return zeroProofing;
	}
	
	/**
	 * <p>
	 * This helper method finds the zero proofing
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param bandDef
	 * @param fldVal
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private void findZeroProofing (InterfaceBandDef bandDef, Map<String, DataField> dataValues) throws FormatException
	{
		String fldName = null;
		String bandName = null;
		boolean blnBand = false;
		List<MappingField> listFields = null;
		String fldVal = null;
		DataField dataField = null;
		
		listFields = bandDef.getMappingFields();
		bandName = bandDef.getBandName();
		
		for (MappingField field : listFields)
		{
			fldName = field.getFieldName();
			// if source field comes
			if (interfaceDef.containsZeroProofing(fldName) || interfaceDef.containsZeroProofing(bandDef.getBandName()))
			{
				dataField = dataValues.get(fldName);
				fldVal = dataField.getValue();
				if (!interfaceDef.containsZeroProofing(fldName))
				{
					if (blnBand)
						continue;
					
					blnBand = true;
					setSourceData(bandName, bandName, fldVal);
					
				}
				else
					setSourceData(bandName, fldName, fldVal);
			}
			else
			// prime field comes
			{
				if (interfaceDef.containsProofingPrimeKey(fldName))
				{
					dataField = dataValues.get(fldName);
					fldVal = dataField.getValue();
					setPrimeZeroProofing(bandName, fldName, fldVal);
				}
			}
		}
		
	}
	
	/**
	 * <p>
	 * This helper method formats DATE , DATE TIME and DECIMAL values
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @param jobData
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private String formatVal (InterfaceBandDef bandDef, MappingField field, String fldVal, ExecutionJobData jobData, Band dataBand) throws FormatException
	{
		
		if (IrisAdminConstants.DATA_TYPE_DATE.equals(field.getDataType()) || IrisAdminConstants.DATA_TYPE_DATETIME.equals(field.getDataType()))
			
			fldVal = getDateAsString(bandDef, field, fldVal, dataBand);
		
		else if (IrisAdminConstants.DATA_TYPE_DECIMAL.equals(field.getDataType()))
			
			fldVal = getDecimalVal(bandDef, field, fldVal, dataBand);
		
		else if (IrisAdminConstants.DATA_TYPE_NUMBER.equals(field.getDataType()))
			fldVal = getNumberVal(bandDef,field, fldVal);
		else if (IrisAdminConstants.DATA_TYPE_BOOLEAN.equals(field.getDataType()))
			fldVal = getBooleanVal(bandDef,field, fldVal);
		
		return fldVal;
	}
	
	private String geGridCodeMap (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		
		codeMap = field.getCodeMap();
		codeMapVal = codeMap.getCodeMap(fldVal);
		
		if (IrisAdminConstants.CODE_MAP_DEFAULT.equals(codeMapVal) )
			codeMapVal = getDefaultCodeMap(bandDef, field, fldVal);
		
		else if (IrisAdminConstants.CODE_MAP_ASIS.equals(codeMapVal))
			codeMapVal = fldVal;
		
		else if (IrisAdminConstants.CODE_MAP_UNDEFINED.equals(codeMapVal))
		{
			errorMsg = "Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:" + field.getFieldName()
					+ " is undefined in code map:" + codeMap.getCodeMapId();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, bandDef.toString(), field.toString() }, null);
			logger.warn(IRISLogger.getText(fExp));
			
			// Do not throw exception let process definition decide its required or not
			return null;
		}
		
		return codeMapVal;
	}
	
	private String getRestCodeMap (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		
		codeMap = field.getCodeMap();
		codeMapVal = codeMap.getRestVal();
		if (IrisAdminConstants.CODE_MAP_ASIS.equals(codeMapVal))
			codeMapVal = fldVal;
		
		else if (IrisAdminConstants.CODE_MAP_UNDEFINED.equals(codeMapVal))
		{
			errorMsg = "Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:" + field.getFieldName()
					+ " is undefined in code map:" + codeMap.getCodeMapId();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, bandDef.toString(), field.toString() }, null);
			logger.warn(IRISLogger.getText(fExp));
			
			// Do not throw exception let process definition decide its required or not
			return null;
		}
		
		return codeMapVal;
	}
	
	/**
	 * <p>
	 * This helper method formats decimal value.
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private String getDecimalVal (InterfaceBandDef bandDef, MappingField field, String fldVal, Band dataBand) throws FormatException
	{
		String definationType = null;
		double dbVal = 0;
		String paddedZeros = null;
		String strPrecision = null;
		DecimalFormat decimalFormat = null;
		Number nbVal = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		DataField dataField = null;
		Pattern pattern = null;
		Matcher matcher = null;
		
		try
		{
			if (null == fldVal || "".equals(fldVal.trim()))
				return fldVal;
			
			// check referenced field is DATE or DATETIME then its already formatted, so ignore doing formating again
			if (IrisAdminConstants.MAPPING_TYPE_REFERENCED == field.getMappingType())
			{
				dataField = getRefField(bandDef, field, dataBand);
				if (IrisAdminConstants.DATA_TYPE_DECIMAL.equals(dataField.getDataType()))
					return fldVal;
			}
			
			definationType = jobData.getMapType();
			paddedZeros = "";
			strPrecision = "1" + HelperUtils.paddingString(paddedZeros, field.getPrecision(), '0', true);
			
			
			
			if (field.getFormat() != null)
			{
				decimalFormat = new DecimalFormat(field.getFormat());
				
				if (IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(definationType))
				{
					pattern = Pattern.compile(decimalPattern);
					matcher = pattern.matcher(fldVal.trim());
					if ( !matcher.matches())
					{
						errorMsg = "Error while formatting decimal:" + field.getFieldName() + " Band:" + field.getBandName() + " Sequence No:"
								+ field.getsequenceNmbr() + " Field Value:" + fldVal + " Format:" + field.getFormat();
						fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
						{ errorMsg, field.toString() }, null);
						error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, field.toString(), null);
						jobData.addError(error);
						createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
						logger.error(IRISLogger.getText(fExp));
						if (!jobData.isAccumulateErros())
							throw fExp;
					}
					// First parse according to format
					nbVal = decimalFormat.parse(fldVal.trim());
					dbVal = nbVal.doubleValue();
					// if precision mentioned then divide
					if (field.getPrecision() > 0)
					{
						dbVal = nbVal.doubleValue() / Double.parseDouble(strPrecision);
					}
					fldVal = Double.toString(dbVal);
				}
				else
				{
					dbVal = Double.parseDouble(fldVal);
					// First check precision
					if (field.getPrecision() > 0)
					{
						dbVal = dbVal * Double.parseDouble(strPrecision);
					}
					// Format it according to download format
					fldVal = decimalFormat.format(dbVal);
				}
			}
		}
		catch ( FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error while formatting decimal:" + field.getFieldName() + " Band:" + field.getBandName() + " Sequence No:"
					+ field.getsequenceNmbr() + " Field Value:" + fldVal + " Format:" + field.getFormat();
			fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		
		return fldVal;
	}
	
	private String getDefaultCodeMap (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		
		codeMap = field.getCodeMap();
		codeMapVal = codeMap.getDefaultVal();
		if (IrisAdminConstants.CODE_MAP_UNDEFINED.equals(codeMapVal))
		{
			errorMsg = "Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:" + field.getFieldName()
					+ " is undefined in code map:" + codeMap.getCodeMapId();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, bandDef.toString(), field.toString() }, null);
			logger.warn(IRISLogger.getText(fExp));
			
			// Do not throw exception let process definition decide its required or not
			return null;
		}
		else if (IrisAdminConstants.CODE_MAP_ASIS.equals(codeMapVal))
			codeMapVal = fldVal;
		
		return codeMapVal;
	}
	
	/**
	 * 
	 * <p>
	 * This helper method is helper method for function calls to find the function name and function .
	 * <p>
	 * <i> Function name derives before fist occurrence of (. Function arguments taken between first occurrence of ( and last occurrence of )</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param derivationLogic1
	 * @param derivationLogic2
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private String[] getFunctions (InterfaceBandDef bandDef, String derivationLogic1, String derivationLogic2) throws FormatException
	{
		String data = null;
		String[] returnValues = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		
		if (derivationLogic1 == null)
			return returnValues;
		
		try
		{
			data = derivationLogic1;
			if (derivationLogic2 != null)
				data = data + derivationLogic2;
			
			returnValues = StringUtils.split(data, IrisAdminConstants.FUNCTION_SPLIT_CHARS);
		}
		catch (Exception exp)
		{
			errorMsg = "Error While finding function:" + data;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, null, null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		
		return returnValues;
	}
	/**
	 * 
	 * <p>
	 * This helper method is helper method for function calls to find the function name and function .
	 * <p>
	 * <i> Function name derives before fist occurrence of (. Function arguments taken between first occurrence of ( and last occurrence of )</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param derivationLogic1
	 * @param derivationLogic2
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private String[] getFunctionName (InterfaceBandDef bandDef, String functionDetails) throws FormatException
	{
		String value = null;
		String function = null;
		String[] returnValues = null;
		FormatException fExp = null;
		int firstIndex = -1;
		int secoundIndex = -1;
		String errorMsg = null;
		IrisAdminError error = null;
		
		if (functionDetails == null)
			return returnValues;
		
		try
		{
			firstIndex = functionDetails.indexOf("(");
			secoundIndex = functionDetails.indexOf(")");
			function = functionDetails.substring(0, firstIndex);
			value = functionDetails.substring(firstIndex + 1, secoundIndex);
			returnValues = new String[2];
			returnValues[0] = function;
			returnValues[1] = value;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While finding function:" + functionDetails;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FUNCT, errorMsg, null, null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return returnValues;
	}
	
	/**
	 * <p>
	 * This helper function validates that data is number or not
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private String getNumberVal (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String regEx = "\\d+";
		
		if (fldVal == null)
			return null;
		
		fldVal = fldVal.trim();
		
		if ("".equals(fldVal))
			return fldVal;
		
		try
		{
			if (fldVal.matches(regEx))
				return fldVal;
			
			errorMsg = "Error while formatting Number:" + field.getFieldName() + " Band:" + field.getBandName() + " Sequence No:"
					+ field.getsequenceNmbr() + " Field Value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
			{ errorMsg, field.toString() }, null);
			error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			if (!jobData.isAccumulateErros())
				throw fExp;
			
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error while formatting Number:" + field.getFieldName() + " Band:" + field.getBandName() + " Sequence No:"
					+ field.getsequenceNmbr() + " Field Value:" + fldVal;
			fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
			{ errorMsg, field.toString() }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, field.toString(), null);
			jobData.addError(error);
			createIrisError(bandDef.getBandType(), bandDef.getBandName(), errorMsg);
			logger.error(IRISLogger.getText(fExp));
			if (!jobData.isAccumulateErros())
				throw fExp;
		}
		return null;
	}
	
	
	/**
	 * <p>
	 * This helper function validates that data is number or not
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private String getBooleanVal(InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		
		if (fldVal == null)
			return returnBooleanVal(field);
		
		fldVal = fldVal.trim();
		
		if ("".equals(fldVal))
			return returnBooleanVal(field);
		
			if (fldVal.matches(booleanPattern))
				return fldVal;
			else
				return returnBooleanVal(field);
	}
	
	private String returnBooleanVal(MappingField field)
	{
		if ( field.getIFieldLength() > 1)
			return IrisAdminConstants.CONSTANT_NO;
		else
			return IrisAdminConstants.CONSTANT_N;
	}
	
	/**
	 * <p>
	 * This method creates the database connection for function
	 * <p>
	 * <i> It uses the resources as IRIS_DB Connection as default</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @throws SQLException
	 * @throws SystemException
	 * </pre>
	 * 
	 * </p>
	 */
	private void makeDBConnection () throws SQLException, SystemException
	{
		if (dbConnection == null)
		{
			conProvider = new ConnectionProviderAdapter(this.applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
					ResourceTypeEnum.IRIS_DATABASE);
			dbConnection = conProvider.getConnection();
		}
		
	}
	
	/**
	 * <p>
	 * This helper method checks the zero Proofing
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param primeBandName
	 * @param primeFldName
	 * @param primeFldVal
	 * </pre>
	 * 
	 * </p>
	 */
	private void setPrimeZeroProofing (String primeBandName, String primeFldName, String primeFldVal)
	{
		String sourceFldName = null;
		ZeroProofingDef zeroProofingDef = null;
		ZeroProofing zeroProofing = null;
		
		try
		{
			sourceFldName = interfaceDef.getZeroProofingSourceKey(primeFldName);
			
			if (zeroProofings.contains(sourceFldName))
				zeroProofing = zeroProofings.getZeroProofing(sourceFldName);
			else
			{
				zeroProofingDef = interfaceDef.getZeroProofing(sourceFldName);
				zeroProofing = createZeroProofing(zeroProofingDef.getSourceBandName(), sourceFldName, "0");
				zeroProofings.setZeroProofing(zeroProofing);
			}
			
			if (null == zeroProofing.getPrimeFieldName())
			{
				zeroProofing.setPrimeBandName(primeBandName);
				zeroProofing.setPrimeFieldName(primeFldName);
				zeroProofing.setPrimeValue(Double.parseDouble(primeFldVal));
			}
		}
		finally
		{
			sourceFldName = null;
		}
	}
	
	/**
	 * <p>
	 * This helper method sets the zero proofing data for source fields
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandName
	 * @param fieldName
	 * @param fldVal
	 * </pre>
	 * 
	 * </p>
	 */
	private void setSourceData (String bandName, String fieldName, String fldVal)
	{
		ZeroProofingDef zeroProofingDef = null;
		String strZPType = null;
		ZeroProofing zeroProofing = null;
		
		zeroProofingDef = interfaceDef.getZeroProofing(fieldName);
		strZPType = zeroProofingDef.getType();
		zeroProofing = zeroProofings.getZeroProofing(fieldName);
		
		if (null == zeroProofing)
		{
			if ("S".equals(strZPType))
				zeroProofing = createZeroProofing(bandName, fieldName, fldVal);
			else
				zeroProofing = createZeroProofing(bandName, fieldName, "1");
			
			zeroProofings.setZeroProofing(zeroProofing);
		}
		else
		{
			if ("S".equals(strZPType))
			{
				if (null != fldVal)
					zeroProofing.addSourceValue(Double.parseDouble(fldVal));
			}
			else
				zeroProofing.countSourceValue();
		}
		
	}

	/**
	 * @return the applicationContext
	 */
	public ApplicationContext getApplicationContext ()
	{
		return applicationContext;
	}
	
}
