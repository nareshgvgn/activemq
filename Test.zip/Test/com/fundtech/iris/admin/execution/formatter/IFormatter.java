/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : AFormatter.java
 * CREATED: Jan 27, 2014 4:08:50 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.Deque;

import com.cashtech.iris.contexts.ApplicationContext;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceDef;

/**
 * <p>
 * Every Formatter must implement this interface
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IFormatter.java,v 1.7 2014/07/20 04:58:17 ramap Exp $
 */
public interface IFormatter
{
	/**
	 * <p>
	 * This method cleans the resources which are opend
	 * <p>
	 * <i> Database Connection which is opened for functions, complex funcations and Hooks</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	public void cleanup ();
	
	/**
	 * <p>
	 * This method initializes the formatter
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param applicationContext
	 * @param interfaceDef
	 * @param jobData
	 * @param zeroProofings
	 * </pre>
	 * 
	 * </p>
	 */
	public void initialize (ApplicationContext applicationContext, InterfaceDef interfaceDef, ExecutionJobData jobData, ZeroProofings zeroProofings);
	
	/**
	 * 
	 * <p>
	 * This method formats the uploading file
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param obj
	 * @param Deque
	 * @param dataValues
	 * @return bandid
	 * @throws FormatException
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException;
	
	/**
	 * <p>
	 * This method gets the band value(ID) from file for given {@link InterfaceBandDef} <i>
	 * <p>
	 * Fixed Width will use band position and its length.
	 * </p>
	 * <p>
	 * Delimiter will use delimiter and parses the string
	 * </p>
	 * </i> <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param obj
	 * @param bandDef
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException;
	
	/**
	 * <p>
	 * This method checks the band value(ID) from file for given {@link InterfaceBandDef}
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param obj
	 * @param bandDef
	 * @return boolean
	 * </pre>
	 * 
	 * </p>
	 */
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException;
	
	/**
	 * <p>
	 * This Helper method formats the downloading data
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dataBatchBand
	 * @param currentDef
	 * @param dataBand
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public Object downloadFormat (BatchBand dataBatchBand, InterfaceBandDef currentDef, Band dataBand) throws FormatException;
}
