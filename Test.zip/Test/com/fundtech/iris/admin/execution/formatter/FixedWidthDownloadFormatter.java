/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : FixedWidthDownloadFormatter.java
 * CREATED: Dec 6, 2013 6:21:30 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceBandsDef;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FixedWidthDownloadFormatter.java,v 1.6 2014/07/20 04:58:16 ramap Exp $
 */
public class FixedWidthDownloadFormatter extends DownloadFormatter
{
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#downloadFormat(com.fundtech.iris.admin.data.BatchBand,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	public Object downloadFormat (BatchBand batchBand, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		String fldName = null;
		String fldVal = null;
		InterfaceBandsDef childDefs = null;
		InterfaceBandDef childDef = null;
		DataField dataField = null;
		for (MappingField field : bandDef.getMappingFields())
		{
			fldName = field.getFieldName();
			fldVal = dataBand.getFieldValue(fldName);
			fldVal = formatNonDirect(field, fldVal, dataBand, bandDef, batchBand);
			if (fldVal == null || "null".equals(fldVal))
				fldVal = "";
			
			fldVal = format(field, fldVal);
			dataField = createDataField(field, fldVal);
			dataBand.setFieldValue(fldName, dataField);
		}
		childDefs = bandDef.getChildDefinitions();
		for (BatchBand childBatchBand : dataBand.getChildBatches())
		{
			for (Band childBand : childBatchBand.getBatchBands())
			{
				childDef = childDefs.getBandDefinition(childBand.getName());
				downloadFormat(childBatchBand, childDef, childBand);
			}
		}
		/*
		 * This code should be here coz some bands may not have childs
		 */
		calulateBatchTotal(bandDef, batchBand, dataBand);
		resetRunningNumbers(bandDef.getBandName());
		return null;
	}
	
}
