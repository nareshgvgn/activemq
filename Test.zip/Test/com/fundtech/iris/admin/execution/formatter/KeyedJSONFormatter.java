/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : KeyedJSONFormatter.java
 * CREATED: Jan 2, 2017 3:38:58 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.KeyedJSONReader;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;

/**
 * <p>
 * This formatter uses {@code}{@link JSONObject} formatter. So we must use along with {@code}{@link KeyedJSONReader} .
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into medium_mst (MEDIUM_TYPE, MODEL_TYPE, FORMAT_TYPE, MEDIUM_NAME, DESCRIPTION, LINE_SEPARATOR, EXECUTION_CLASS, FORMATTER_CLASS, VALID_FLAG)
 * values ('REST_RES', 'U', 'JSON', 'JSON', 'JSON Format', null, 'com.fundtech.iris.admin.execution.KeyedJSONReader', 'com.fundtech.iris.admin.execution.formatter.KeyedJSONFormatter', 'Y');
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: KeyedJSONFormatter.java,v 1.1 2017/01/30 04:50:14 ramap Exp $
 */
public class KeyedJSONFormatter extends AbstractFormatter
{
	
private static Logger logger = LoggerFactory.getLogger(KeyedJSONFormatter.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#uploadFormat(java.lang.Object, java.util.Stack, java.util.Stack,
	 * com.fundtech.iris.admin.data.RootBand)
	 */
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		
		InterfaceBandDef bandDef = null;
		String expression = null;
		JSONArray rootList = null;
		Object childObj = null;
		JSONObject parentNode = null;
		JSONObject childNode = null;
		Band dataBand = null;
		Map<String, DataField> dataValues = null;
		FormatException fExp = null;
		Band batchBand = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String strBandDef = null;
		String bandName = null;
		
		try
		{
			bandDef = defStack.peekFirst();
			bandName = bandDef.getBandName();
			batchBand = dataStack.peekFirst();
			dataBand = new Band();
			dataBand.setId(bandDef.getBandId());
			dataBand.setName(bandName);
			dataBand.setBandPath(bandDef.getBandPath());
			dataBand.setBandType(bandDef.getBandType());
			parentNode = (JSONObject) obj;
			
			if (bandDef.getParentBandName() == null)
				dataBand.setParentBand(null);
			else
				dataBand.setParentBand(batchBand);
			
			batchBand.addChildBand(dataBand);
			dataStack.addFirst(dataBand);
			dataValues = formatBandData(lineNumber, parentNode, bandDef, dataBand);
			dataBand.addFields(dataValues);
			bandDefs = bandDef.getChildDefinitions().getBandDefinitions();
			for (InterfaceBandDef childDef : bandDefs.values())
			{
				expression = childDef.getBandName();
				childObj = parentNode.get(expression);
				if (childObj instanceof JSONObject)
				{
					rootList = new JSONArray();
					rootList.add((JSONObject) childObj);
				}
				else if (childObj instanceof JSONArray)
				{
					rootList = (JSONArray) childObj;
				}
						
				if (rootList == null)
				{
					if (logger.isTraceEnabled())
						logger.trace(childDef.getBandName() + " or " + expression + " Doersn't have any data in xml");
					if (childDef.isMandatory())
					{
						errorMsg = childDef.getBandName() + " or " + expression + " Doersn't have any data in xml";
						fExp = new FormatException("err.irisadmin.format", new Object[]
						{ errorMsg, bandDef.toString() }, null);
						error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, childDef.toString(), null);
						jobData.addError(error);
						logger.error(IRISLogger.getText(fExp));
						throw fExp;
					}
				}
				defStack.addFirst(childDef);
				for (int index = 0; null != rootList && index < rootList.size(); index++)
				{
					lineNumber++;
					childNode = (JSONObject)rootList.get(index);
					uploadFormat(lineNumber, childNode, defStack, dataStack);
				}
				defStack.removeFirst();
			}
			dataStack.removeFirst();
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating band:" + bandName;
			if (bandDef != null)
				strBandDef = bandDef.toString();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, strBandDef }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, strBandDef, null);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			if ( irisError != null)
			{
				arrangeError(bandDef.getBandType(), dataValues, lineNumber);
			}
			strBandDef = null;
		}
		
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#format(long, java.lang.Object,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	@Override
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		Map<String, DataField> dataValues = null;
		String fldVal = null;
		List<MappingField> listFields = null;
		FormatException fExp = null;
		String expression = null;
		JSONObject fieldNode = null;
		JSONObject parentNode = null;
		String errorMsg = null;
		IrisAdminError error = null;
		
		parentNode = (JSONObject) obj;
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		for (MappingField field : listFields)
		{
			try
			{
				if (checkFieldMappingType(field.getMappingType()))
				{
					expression = field.getRemarks();
					fldVal = parentNode.getAsString(expression);
//					if (fldVal == null)
//					{
//						if (logger.isTraceEnabled())
//							logger.trace(field.getFieldName() + " or " + expression + " Doersn't have any data in xml");
//						if (field.isMandatory())
//						{
//							errorMsg = "Value of Mandatory Field is NULL. Field Name:" + field.getFieldName() + " Band:" + field.getBandName()
//									+ " Sequence No:" + field.getsequenceNmbr() + " Expression:" + expression;
//							fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
//							{ errorMsg, field.toString() }, null);
//							error = createError(IrisAdminConstants.ERR_CODE_MANDATORY, errorMsg, field.toString(), null);
//							jobData.addError(error);
//							logger.error(IRISLogger.getText(fExp));
//							
//							if (!jobData.isAccumulateErros())
//								throw fExp;
//						}
//					}
					if (fldVal != null && fldVal.length() > field.getFieldLength())
						fldVal = fldVal.substring(0, field.getFieldLength());
				}
				
				validateField(fldVal, field, bandDef, dataBand, dataValues);
				fldVal = null;
			}
			catch (FormatException exp)
			{
				throw exp;
			}
			catch (Exception exp)
			{
				errorMsg = "Error While Creating Band";
				fExp = new FormatException("err.irisadmin.format", new Object[]
				{ errorMsg }, exp);
				error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
				jobData.addError(error);
				logger.error(IRISLogger.getText(fExp));
				throw fExp;
			}
		}
		return dataValues;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#downloadFormat(com.fundtech.iris.admin.data.Band,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	public Object downloadFormat (Band dataBand, InterfaceBandDef def) throws FormatException
	{
		
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// No need of this method for XML Formatter
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// No need of this method for XML Formatter
		return false;
	}
}
