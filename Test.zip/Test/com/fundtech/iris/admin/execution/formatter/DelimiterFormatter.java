/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : ACHDelimitterFormatter.java
 * CREATED: Jan 29, 2014 12:57:13 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: DelimiterFormatter.java,v 1.19 2016/12/21 11:09:41 ramap Exp $
 */
public class DelimiterFormatter extends AbstractFormatter
{
	private static Logger logger = LoggerFactory.getLogger(DelimiterFormatter.class);
	
	public DelimiterFormatter()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack)
	 */
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		String fmtStr = null;
		InterfaceBandDef bandDef = null;
		String[] tokens = null;
		FormatException fExp = null;
		boolean returnVal = false;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		try
		{
			fmtStr = (String) obj;
			bandDef = defStack.peekFirst();
			tokens = getAllTokens(fmtStr, bandDef.getDelimiter(), bandDef.getQualifier());
			returnVal = createBand(lineNumber, obj, tokens, defStack, dataStack);
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, bandDef.toString(),  obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return returnVal;
		
	}
	
	/**
	 * 
	 * <p>
	 * This Helper method creates the string tokens according to the delimiter and qualifier
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param fmtStr
	 * @param delimiter
	 * @param qualifier
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private String[] getAllTokens (String fmtStr, String delimiter, String qualifier)
	{
		String[] output = null;
		String regEx = "0(?=(?:[^1]*1[^1]*1)*(?![^1]*1))";
		Pattern pattern = null;
		if (qualifier == null)
			regEx = "0";
		else
			regEx = regEx.replaceAll("1", qualifier);
		
		regEx = regEx.replaceAll("0", "[" + delimiter + "]");
		pattern = Pattern.compile(regEx);
		output = pattern.split(fmtStr);
		return output;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.Formatter#format(java.lang.Object, java.lang.String, com.fundtech.iris.admin.band.BandsDefinition)
	 */
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		String[] tokens = null;
		Map<String, DataField> dataValues = null;
		String fldVal = null;
		List<MappingField> listFields = null;
		FormatException fExp = null;
		int fldPostion = 0;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		String fieldName = null;
		
		tokens = (String[]) obj;
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		try
		{
			
			for (MappingField field : listFields)
			{
				fieldName = field.getFieldName();
				if (checkFieldMappingType(field.getMappingType()))
				{
					fldPostion = field.getsequenceNmbr() - 1;
					if (fldPostion < tokens.length)
						fldVal = tokens[fldPostion];
					
					if ( ! StringUtils.isEmpty(fldVal) && StringUtils.startsWith(fldVal, bandDef.getQualifier()) && StringUtils.endsWith(fldVal, bandDef.getQualifier()))
						fldVal = fldVal.substring(1, fldVal.length()-1);
					
					if (interfaceDef.getQualifier() != null && fldVal != null)
						fldVal = fldVal.replaceAll(interfaceDef.getQualifier(), "");
					
//					if (fldVal != null && fldVal.length() > field.getFieldLength())
//						fldVal = fldVal.substring(0, field.getFieldLength());
				}
				validateField(fldVal, field, bandDef, dataBand, dataValues);
				
				fldVal = null;
			}
		}
		catch (ArrayIndexOutOfBoundsException exp)
		{
			errorMsg = " Field :" + fieldName + " Not present in file";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, bandDef.toString(),obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return dataValues;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	public String getBandId (Object obj, InterfaceBandDef bandDef)
	{
		String fmtStr = null;
		String bandValue = null;
		String[] tokens = null;
		
		try
		{
			fmtStr = (String) obj;
			tokens = getAllTokens(fmtStr, bandDef.getDelimiter(), bandDef.getQualifier());
			if (tokens.length >= bandDef.getBandIdPosition() && bandDef.getBandIdPosition() != 0)
				bandValue = tokens[bandDef.getBandIdPosition() - 1];
		}
		finally
		{
			tokens = null;
		}
		
		return bandValue;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef)
	{
		String bandValue = null;
		
		if (bandDef.getBandId() == null)
			return true;
		
		bandValue = getBandId(obj, bandDef);
		
		if (bandDef.getBandId().equals(bandValue))
			return true;
		
		return false;
	}
}
