/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : IrisDBToDBFormatter.java
 * CREATED: Jan 18, 2016 9:59:44 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.sqlparser.IrisSqlParserListenner;
import com.fundtech.iris.admin.sqlparser.SqlParserEngine;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.DBToDBUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisDBToDBFormatter.java,v 1.5 2017/01/30 04:50:14 ramap Exp $
 */
public class IrisDBToDBFormatter extends AbstractFormatter
{
	private static Logger logger = LoggerFactory.getLogger(IrisDBToDBFormatter.class);
	
	protected ConnectionProvider hostConProvider = null;
	protected Connection hostDbConnection = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IFormatter#initialize()
	 */
	@Override
	public void initialize (ApplicationContext applicationContext, InterfaceDef interfaceDef, ExecutionJobData jobData, ZeroProofings zeroProofings)
	{
		super.initialize(applicationContext, interfaceDef, jobData, zeroProofings);
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#uploadFormat(java.lang.Object, java.util.Stack, java.util.Stack,
	 * com.fundtech.iris.admin.data.RootBand)
	 */
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,ExecutionException
	{
		
		InterfaceBandDef bandDef = null;
		Object childObj = null;
		Band dataBand = null;
		Map<String, DataField> dataValues = null;
		FormatException fExp = null;
		Band batchBand = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String strBandDef = null;
		String bandName = null;
		SqlParserEngine parser = null;
		String bandSql = null;
		String bandSecoundSql = null;
		String selectSQL = null;
		IrisSqlParserListenner listener = null;
		PreparedStatement bandStmt = null;
		ResultSet bandRs = null;
		
		try
		{
			bandDef = defStack.peekFirst();
			bandName = bandDef.getBandName();
			selectSQL = getSelectSQL(bandDef);
			if ( selectSQL == null)
				return null;
			parser = new SqlParserEngine();
			bandSql = bandDef.getAbsoluteXPath1();
			bandSecoundSql = bandDef.getAbsoluteXPath2();
			if ( bandSecoundSql != null)
				bandSql = bandSql + bandSecoundSql;
			listener = new IrisSqlParserListenner(jobData);
			parser.parse(bandSql, listener);
			bandStmt = getPreparedStatement(listener, selectSQL);
			bandRs = bandStmt.executeQuery();
			
			// call the routine which is configured at band level, ignore if there is any error
			DBToDBUtils.callHostUpdate(bandDef,jobData, hostDbConnection);
			
			while ( bandRs.next())
			{
				batchBand = dataStack.peekFirst();
				dataBand = new Band();
				dataBand.setId(bandDef.getBandId());
				dataBand.setName(bandName);
				dataBand.setBandPath(bandDef.getBandPath());
				dataBand.setBandType(bandDef.getBandType());
				if (bandDef.getParentBandName() == null)
					dataBand.setParentBand(null);
				else
					dataBand.setParentBand(batchBand);
				
				batchBand.addChildBand(dataBand);
				dataStack.addFirst(dataBand);
				dataValues = formatBandData(lineNumber, bandRs, bandDef, dataBand);
				dataBand.addFields(dataValues);
				bandDefs = bandDef.getChildDefinitions().getBandDefinitions();
				for (InterfaceBandDef childDef : bandDefs.values())
				{
					defStack.addFirst(childDef);
					uploadFormat(lineNumber, childObj, defStack, dataStack);
					defStack.removeFirst();
				}
				dataStack.removeFirst();
			}
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating band:" + bandName;
			if (bandDef != null)
				strBandDef = bandDef.toString();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, strBandDef }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, strBandDef, null);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			if ( irisError != null)
			{
				arrangeError(bandDef.getBandType(), dataValues, lineNumber);
			}
			strBandDef = null;
			
			CleanUpUtils.doClean(bandRs);
			CleanUpUtils.doClean(bandStmt);
		}
		
		return null;
	}
	

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param listener
	 * @param selectSQL
	 * @return
	 * </pre></p>
	 */
	private PreparedStatement getPreparedStatement (IrisSqlParserListenner listener, String selectSQL) throws FormatException
	{
		PreparedStatement psStmt = null;
		StringBuilder builder = new StringBuilder();
		List<String> tablesList = null;
		List<String> whereConditionParms = null;
		boolean isFirst = true;
		String finalSql = null;
		String whereParmValue = null;
		builder.append(selectSQL);
		int index = 1;
		String errorMsg = null;
		IrisAdminError error = null;
		FormatException fExp = null;

		try
		{
			tablesList = listener.getTablesList();
			builder.append(" FROM ");
			for ( String tableName : tablesList)
			{
				if ( !isFirst)
					builder.append(",");
				
				builder.append(tableName);
				isFirst = false;
			}
			builder.append(listener.getWhereCondition());
			finalSql = builder.toString();
			logger.debug("Sql Statement executing: {}", finalSql);
			makeHostDBConnection(jobData.getFilterParameter(IrisAdminConstants.DB_SESSION_NAME));
			psStmt = hostDbConnection.prepareStatement(finalSql);
			psStmt.clearParameters();
			whereConditionParms = listener.getWhereConditionParms();
			for ( String key : whereConditionParms)
			{
				whereParmValue = jobData.getFilterParameter(key);
				psStmt.setString(index, whereParmValue);
				index ++;
			}
			return psStmt;
		}
		catch ( FormatException exp)
		{
			throw exp;
		}
		catch (SQLException exp)
		{
			errorMsg = "Error While Executing sql, Error:"  + exp.getMessage();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, finalSql);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Executing sql, Error:"  + exp.getMessage();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, finalSql);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandDef
	 * @return
	 * </pre></p>
	 */
	private String getSelectSQL (InterfaceBandDef bandDef) throws FormatException
	{
		StringBuilder selectSql = new StringBuilder();
		List<MappingField> listFields = null;
		String columnName = null;
		boolean isFirst = true;
		String errorMsg = null;
		IrisAdminError error = null;
		String strBandDef = null;
		FormatException fExp = null;
		String bandName = null;
		
		try
		{
			selectSql = selectSql.append("SELECT ");
			listFields = bandDef.getMappingFields();
			for (MappingField field : listFields)
			{
				columnName = field.getAbsoluteXPath1();
				if (columnName == null)
					continue;
				if (!isFirst)
					selectSql.append(",");
				
				if(IrisAdminConstants.DATA_TYPE_DATE.equals(field.getDataType()))
				{
					columnName = "to_char(" + columnName + ",'" + field.getFormat() + "') AS "+ columnName;
				}
				
				selectSql.append(columnName);
				isFirst  = false;
			}
			
			if ( isFirst)
				return null;
			
			return selectSql.toString();
		}
		catch (Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Error While Creating band:" + bandName;
			if (bandDef != null)
				strBandDef = bandDef.toString();
			fExp = new FormatException("err.irisadmin.format", new Object[]
					{ errorMsg, strBandDef }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, strBandDef, null);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#format(long, java.lang.Object,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	@Override
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		Map<String, DataField> dataValues = null;
		String fldVal = null;
		List<MappingField> listFields = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		ResultSet resultSet = null;
		String columnName = null;
		
		resultSet = (ResultSet) obj;
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		for (MappingField field : listFields)
		{
			try
			{
				if (checkFieldMappingType(field.getMappingType()))
				{
					columnName = field.getAbsoluteXPath1();
					if ( columnName != null)
					{
						fldVal = resultSet.getString(columnName);
					}
					else
						fldVal = null;
				}
				
				validateField(fldVal, field, bandDef, dataBand, dataValues);
				fldVal = null;
			}
			catch (FormatException exp)
			{
				throw exp;
			}
			catch (Exception exp)
			{
				errorMsg = "Error While Creating Band";
				fExp = new FormatException("err.irisadmin.format", new Object[]
						{ errorMsg }, exp);
				error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
				jobData.addError(error);
				logger.error(IRISLogger.getText(fExp));
				throw fExp;
			}
		}
		return dataValues;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#downloadFormat(com.fundtech.iris.admin.data.Band,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	public Object downloadFormat (Band dataBand, InterfaceBandDef def) throws FormatException
	{
		
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// No need of this method for XML Formatter
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// No need of this method for XML Formatter
		return false;
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#cleanup()
	 */
	@Override
	public void cleanup()
	{
		super.cleanup();
		try
		{
			CleanUpUtils.doClean(hostDbConnection);
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
	}
	
	/**
	 * <p>
	 * This method creates the database connection for function
	 * <p>
	 * <i> It uses the resources as IRIS_DB Connection as default</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @throws SQLException
	 * @throws SystemException
	 * </pre>
	 * 
	 * </p>
	 */
	private void makeHostDBConnection (String dbResourceName) throws FormatException
	{
		ContextManager manager = null;
		DataSource dataSource = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		org.apache.tomcat.jdbc.pool.DataSource test = null;
		
		try
		{
			if ( hostDbConnection == null)
			{
				manager = ContextManager.getInstance();
				dataSource = (DataSource)manager.getBeanObject(dbResourceName);
				hostDbConnection = dataSource.getConnection();
			}
		}
		catch (FileNotFoundException exp)
		{
			errorMsg = "Error While taking Host DB Connection, Error:"  + exp.getMessage();
			fExp = new FormatException("err.irisadmin.beanerror", new Object[]	{ errorMsg, dbResourceName }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, dbResourceName);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (BeanConfigException exp)
		{
			errorMsg =  "Error While taking Host DB Connection, Error:"  + exp.getMessage();
			fExp = new FormatException("err.irisadmin.beanerror", new Object[]	{  errorMsg, dbResourceName  }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, dbResourceName);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (SQLException exp)
		{
			errorMsg = "Error While taking Host DB Connection, Error:"  + exp.getMessage();
			fExp = new FormatException("err.irisadmin.hostdbconnection", new Object[]	{  errorMsg, dbResourceName  }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, dbResourceName);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		
	}
	
}
