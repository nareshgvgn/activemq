/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : SwiftFormatter.java
 * CREATED: Feb 17, 2014 1:27:31 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: SwiftFormatter.java,v 1.7 2016/04/07 05:34:44 ramap Exp $
 */
public class SwiftFormatter extends AbstractFormatter
{
	private static Logger logger = LoggerFactory.getLogger(SwiftFormatter.class);
	private String BODYREGX = ":[0-9A-Z]{2,3}:[\\w\\W\\s][^:]+.*?";
	private String BODYBANDID = "{4:";
	
	public SwiftFormatter()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack,
	 * com.fundtech.iris.admin.data.RootBand)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		boolean returnVal = false;
		Map<String, String> bandTagValues = null;
		String line = null;
		InterfaceBandDef bandDef = null;
		
		bandDef = defStack.peekFirst();
		bandTagValues = (Map<String, String>) obj;
		line = bandTagValues.get(bandDef.getBandId());
		
		returnVal = createBand(lineNumber, line, line, defStack, dataStack);
		
		return returnVal;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#formatBandData(long, java.lang.Object,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	@Override
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		Map<String, DataField> dataValues = null;
		List<MappingField> listFields = null;
		Iterator<MappingField> groupFields = null;
		Map<String, List<MappingField>> fieldGroups = null;
		String groupKey = null;
		String groupVal = null;
		Map<String, String> tokenMap = null;
		String line = null;
		String bandId = null;
		
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		bandId = bandDef.getBandId();
		line = (String) obj;
		if (machesBand(bandId))
		{
			if (BODYBANDID.equals(bandId))
				tokenMap = getKeyValue(bandDef, line, BODYREGX);
			
			fieldGroups = getFieldsGroups(listFields);
		}
		else
		{
			
		}
		
		for (Map.Entry<String, List<MappingField>> entry : fieldGroups.entrySet())
		{
			groupKey = entry.getKey();
			groupFields = entry.getValue().iterator();
			
			if ("{EMPTY}".equals(groupKey))
			{
				mapNonFileData(lineNumber, dataValues, groupFields, bandDef, dataBand);
			}
			else
			{
				if (BODYBANDID.equals(bandDef.getBandId()))
					groupVal = tokenMap.get(groupKey);
				else
					groupVal = line;
				mapFileData(lineNumber, dataValues, groupFields, groupVal, bandDef, dataBand);
			}
			
		}
		return dataValues;
	}
	
	/**
	 * <p>
	 * This helper method formats the non file fields
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param dataValues
	 * @param groupFields
	 * @param bandDef
	 * @param dataBand
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private void mapNonFileData (long lineNumber, Map<String, DataField> dataValues, Iterator<MappingField> groupFields, InterfaceBandDef bandDef,
			Band dataBand) throws FormatException
	{
		
		String fldVal = null;
		MappingField field = null;
		
		while (groupFields.hasNext())
		{
			field = groupFields.next();
			format(lineNumber, dataValues, dataBand, field, fldVal, bandDef);// passing null value
		}
	}
	
	/**
	 * <p>
	 * This helper method formats file data
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param dataValues
	 * @param groupFields
	 * @param groupVal
	 * @param bandDef
	 * @param dataBand
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private void mapFileData (long lineNumber, Map<String, DataField> dataValues, Iterator<MappingField> groupFields, String groupVal,
			InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		
		boolean isFirst = true;
		String fldVal = null;
		MappingField field = null;
		String expression = null;
		List<String> tokens = null;
		
		try
		{
			if (groupVal == null || "".equals(groupVal))
			{
				checkMandatory(lineNumber, groupFields, bandDef);
				return;// means no mandatory
			}
			while (groupFields.hasNext())
			{
				field = groupFields.next();
				if (isFirst)
				{
					expression = field.getAbsoluteXPath2();
					tokens = getTokens(expression, groupVal);
					isFirst = false;
				}
				fldVal = tokens.get(Integer.parseInt(field.getAbsoluteXPath1()));
				format(lineNumber, dataValues, dataBand, field, fldVal, bandDef);
			}
		}
		finally
		{
			CleanUpUtils.doClean(tokens);
			tokens = null;
		}
	}
	
	/**
	 * <p>
	 * This helper method creates the tokens of one tag based on regular expression
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param expression
	 * @param groupVal
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private List<String> getTokens (String expression, String line)
	{
		List<String> tokens = null;
		Pattern pattern = null;
		Matcher matcher = null;
		String value = null;
		
		try
		{
			pattern = Pattern.compile(expression);
			matcher = pattern.matcher(line);
			tokens = new ArrayList<String>();
			while (matcher.find())
			{
				value = matcher.group(0);
				tokens.add(value);
			}
		}
		finally
		{
			pattern = null;
			matcher = null;
		}
		return tokens;
	}
	
	/**
	 * <p>
	 * This helper method formats the fields and does zeroProofing check
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dataValues
	 * @param dataBand
	 * @param field
	 * @param fldVal
	 * @param bandDef
	 * </pre>
	 * 
	 * </p>
	 */
	private void format (long lineNumber, Map<String, DataField> dataValues, Band dataBand, MappingField field, String fldVal,
			InterfaceBandDef bandDef) throws FormatException
	{
		validateField(fldVal, field, bandDef, dataBand, dataValues);
	}
	
	/**
	 * <p>
	 * This helper method checks any mandatory fields are having without data in group Fields
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param groupFields
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private void checkMandatory (long lineNumber, Iterator<MappingField> groupFields, InterfaceBandDef bandDef) throws FormatException
	{
		
		MappingField field = null;
		try
		{
			while (groupFields.hasNext())
			{
				field = groupFields.next();
				checkMandatory(bandDef,field);
			}
		}
		catch (FormatException exp)
		{
			throw exp;
		}
	}
	
	/**
	 * <p>
	 * This helper method creates groups of tags
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param listFields
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private Map<String, List<MappingField>> getFieldsGroups (List<MappingField> listFields) throws FormatException
	{
		Map<String, List<MappingField>> fieldGroups = null;
		List<MappingField> groupFields = null;
		String currentTag = null;
		FormatException fExp = null;
		
		fieldGroups = new TreeMap<String, List<MappingField>>();
		
		try
		{
			for (MappingField field : listFields)
			{
				currentTag = field.getAbsoluteXPath1();
				if (currentTag == null)
					currentTag = "{EMPTY}";
				
				if (fieldGroups.containsKey(currentTag))
				{
					groupFields = fieldGroups.get(currentTag);
					groupFields.add(field);
				}
				else
				{
					groupFields = new ArrayList<MappingField>();
					groupFields.add(field);
					fieldGroups.put(currentTag, groupFields);
				}
			}
		}
		catch (Exception exp) // its definition error so we will not accumulate error
		{
			// jobData.setErrorMsg("Error in defination");
			fExp = new FormatException("error.iris.admin.regparsing", new Object[] {}, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return fieldGroups;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef)
	{
		String bandValue = null;
		Map<String, String> bandTagValues = null;
		String bandId = null;
		
		bandTagValues = (Map<String, String>) obj;
		bandId = bandDef.getBandId();
		
		if (bandTagValues.containsKey(bandId))
			return bandTagValues.get(bandId);
		
		// check for standard bands, if its sub band of standard band, accest band id which ever comes in
		if (!machesBand(bandId))
			bandValue = bandId;
		
		return bandValue;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef)
	{
		String bandValue = null;
		bandValue = getBandId(obj, bandDef);
		if (bandDef.getBandId().equals(bandValue))
			return true;
		return false;
	}
	
	private boolean machesBand (String bandId)
	{
		if (bandId == null)
			return false;
		
		return bandId.matches("\\{1:|\\{2:|\\{:3|\\{4:|\\{5:");
	}
	
}
