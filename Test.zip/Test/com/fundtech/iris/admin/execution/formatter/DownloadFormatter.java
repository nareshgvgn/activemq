/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : DownloadFormatter.java
 * CREATED: Dec 6, 2013 6:07:13 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.DateUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.CodeMap;
import com.fundtech.iris.admin.Definitions;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RunningNumber;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.functions.IFunction;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.fundtech.iris.admin.util.StringUtils;

/**
 * <p>
 * This abstract class formats the data in given delimiter or fixed width.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * </pre>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: DownloadFormatter.java,v 1.23 2016/07/19 08:00:54 ramap Exp $
 */
public abstract class DownloadFormatter implements IFormatter
{
	private static Logger logger = LoggerFactory.getLogger(DownloadFormatter.class);
	
	protected ApplicationContext applicationContext = null;
	private ConnectionProvider conProvider = null;
	private Connection dbConnection = null;
	protected InterfaceDef interfaceDef = null;
	protected ExecutionJobData jobData = null;
	protected ZeroProofings zeroProofings = null;
	protected Map<String, Object> hooks = new HashMap<String, Object>();
	protected Map<String, RunningNumber> runningNumberMap = new HashMap<String, RunningNumber>();
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#initialize(com.cashtech.iris.contexts.ApplicationContext,
	 * com.fundtech.iris.admin.interfaces.InterfaceDef, com.fundtech.iris.admin.data.ExecutionJobData, com.fundtech.iris.admin.data.ZeroProofings)
	 */
	public void initialize (ApplicationContext applicationContext, InterfaceDef interfaceDef, ExecutionJobData jobData, ZeroProofings zeroProofings)
	{
		this.applicationContext = applicationContext;
		this.interfaceDef = interfaceDef;
		this.jobData = jobData;
		this.zeroProofings = zeroProofings;
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#cleanup()
	 */
	public void cleanup ()
	{
		try
		{
			if (conProvider != null)
				conProvider.releaseConnection(dbConnection);
			conProvider = null;
			// HelperUtils.doClose(dbConnection);
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// DO NOTHING
		}
	}
	
	/*--------------------------------------------------------------------------------------------------
	 * COMMON HELPER METHODS
	 *------------------------------------------------------------------------------------------------*/
	/**
	 * This helper methods assigns the constant value
	 * 
	 * @param field
	 * @param fldVal
	 * @return constant value
	 */
	public String assignConstant (MappingField field)
	{
		String fldVal = null;
		fldVal = field.getConstantValue();
		return fldVal;
	}
	
	/**
	 * This helper method assigns the default value
	 * 
	 * @param field
	 * @param fldVal
	 * @return default value
	 */
	public String getDefaultValue (MappingField field)
	{
		String fldVal = null;
		
		fldVal = field.getDefaultValue();
		
		return fldVal;
	}
	
	/**
	 * <p>
	 * This helper methods assigns the code map. if the incoming value is null or empty, default value will be assigned. if the incoming value code
	 * mapped to default value, default value will be assigned
	 * <p>
	 * <i> Field which is having property of IrisAdminConstants.MAPPING_TYPE_CODEMAP</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandDef
	 * @param field
	 * @param fldVal
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String assignCodeMap (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		
		try
		{
			codeMap = field.getCodeMap();
			if (fldVal != null)
				fldVal = fldVal.trim();
			
			if (fldVal == null || "".equals(fldVal))
				codeMapVal = getDefaultCodeMap(bandDef, field, fldVal);
			else if (codeMap.contains(fldVal))
				codeMapVal = getGridCodeMap(bandDef, field, fldVal);
			else
				codeMapVal = getRestCodeMap(bandDef, field, fldVal);
			
			if (codeMapVal != null && codeMapVal.length() > field.getIFieldLength())
				codeMapVal = codeMapVal.substring(0, field.getIFieldLength());
			
		}
		catch (Exception exp)
		{
			errorMsg = "Code Map:" + codeMap.getCodeMapId() + " Value for Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:"
					+ field.getFieldName();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, bandDef.toString(), field.toString() }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
			
		}
		finally
		{
			errorMsg = null;
		}
		return codeMapVal;
	}
	
	private String getRestCodeMap (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		
		codeMap = field.getCodeMap();
		codeMapVal = codeMap.getRestVal();
		if (IrisAdminConstants.CODE_MAP_ASIS.equals(codeMapVal))
			codeMapVal = fldVal;
		
		else if (IrisAdminConstants.CODE_MAP_UNDEFINED.equals(codeMapVal))
		{
			errorMsg = "Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:" + field.getFieldName()
					+ " is undefined in code map:" + codeMap.getCodeMapId();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, bandDef.toString(), field.toString() }, null);
			logger.warn(IRISLogger.getText(fExp));
			
			// Do not throw exception let process definition decide its required or not
			return null;
		}
		
		return codeMapVal;
	}
	
	private String getGridCodeMap (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		
		codeMap = field.getCodeMap();
		codeMapVal = codeMap.getCodeMap(fldVal);
		
		if (IrisAdminConstants.CODE_MAP_DEFAULT.equals(codeMapVal) )
			codeMapVal = getDefaultCodeMap(bandDef, field, fldVal);
		else if (IrisAdminConstants.CODE_MAP_ASIS.equals(codeMapVal))
			codeMapVal = fldVal;
		else if (IrisAdminConstants.CODE_MAP_UNDEFINED.equals(codeMapVal))
		{
			errorMsg = "Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:" + field.getFieldName()	+ " is undefined in code map:" + codeMap.getCodeMapId();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString(), field.toString() }, null);
			logger.warn(IRISLogger.getText(fExp));
			
			// Do not throw exception let process definition decide its required or not
			return null;
		}
		
		return codeMapVal;
	}
	
	private String getDefaultCodeMap (InterfaceBandDef bandDef, MappingField field, String fldVal) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		
		codeMap = field.getCodeMap();
		codeMapVal = codeMap.getDefaultVal();
		
		if (IrisAdminConstants.CODE_MAP_UNDEFINED.equals(codeMapVal))
		{
			errorMsg = "Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:" + field.getFieldName()
					+ " is undefined in code map:" + codeMap.getCodeMapId();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, bandDef.toString(), field.toString() }, null);
			logger.warn(IRISLogger.getText(fExp));
			
			// Do not throw exception let process definition decide its required or not
			return null;
		}
		else if (IrisAdminConstants.CODE_MAP_ASIS.equals(codeMapVal))
			codeMapVal = fldVal;
		
		return codeMapVal;
	}
	
	/**
	 * 
	 * TODO
	 * 
	 * @param field
	 * @param fldVal
	 * @return
	 */
	public String checkLength (MappingField field, String fldVal)
	{
		/*
		 * Field reference and not decimal only truncate
		 */
		if (IrisAdminConstants.MAPPING_TYPE_REFERENCED == field.getMappingType() && !IrisAdminConstants.DATA_TYPE_DECIMAL.equals(field.getDataType()))
			if (fldVal != null && fldVal.length() > field.getFieldLength())
				fldVal = fldVal.substring(0, field.getFieldLength());
		
		return fldVal;
	}
	
	/**
	 * This helper method in upload reads the field value and converts to {@link DateUtils.ISO_DATEFORMAT}. In download it converts
	 * {@link DateUtils.ISO_DATEFORMAT} to user defined data format.
	 * 
	 * @param field
	 * @param fldVal
	 * @return
	 * @throws Exception
	 */
	public String getDateAsString (MappingField field, String fldVal) throws FormatException
	{
		SimpleDateFormat dateFormat = null;
		SimpleDateFormat isoDateFormat = null;
		FormatException fExp = null;
		
		try
		{
			if (IrisAdminConstants.MAPPING_TYPE_FUNCTION == field.getMappingType()
					|| IrisAdminConstants.MAPPING_TYPE_ROUTINE == field.getMappingType()
					|| IrisAdminConstants.MAPPING_TYPE_COMPLEX == field.getMappingType())
				return fldVal;
			
			if (fldVal != null && !"".equals(fldVal.trim()))
			{
				dateFormat = new SimpleDateFormat(field.getFormat());
				
				/*
				 * if lenient is true & input date is like 2005-13-06 [yyyy-MM-dd] this date will get converted as like 2006-01-06 i.e. if month is
				 * more that 12 it will increase year by 1 instead of throwing parsing error, so set lenient to false
				 */
				dateFormat.setLenient(false);
				
				if (IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(jobData.getMapType()))
				{
					isoDateFormat = new SimpleDateFormat(DateUtils.ISO_DATEFORMAT);
					fldVal = isoDateFormat.format(new Date(dateFormat.parse(fldVal).getTime()));
				}
				else
				{
					isoDateFormat = new SimpleDateFormat(DateUtils.ISO_DATEFORMAT);
					fldVal = dateFormat.format(new Date(isoDateFormat.parse(fldVal).getTime()));
				}
			}
		}
		catch (ParseException exp)
		{
			logger.error("Error While formatting data" + "Field Val:" + fldVal + " Date Format:" + field.getFormat() + " Field Name:"
					+ field.getFieldName() + " Band Name:" + field.getBandName());
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ "Field Val:" + fldVal, "Date Format:" + field.getFormat(), "Field Name:" + field.getFieldName() }, exp);
			
			throw fExp;
		}
		catch (Exception exp)
		{
			logger.error("Error While formatting data" + "Field Val:" + fldVal + " Date Format:" + field.getFormat() + " Field Name:"
					+ field.getFieldName());
			logger.error("Error While formatting data");
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ fldVal, field.getFormat(), field.getFieldName() }, exp);
			throw fExp;
		}
		finally
		{
			dateFormat = null;
			isoDateFormat = null;
		}
		return fldVal;
	}
	
	/**
	 * This helper method calls the function which is configured in mapping fields
	 * 
	 * @param field
	 * @param fldVal
	 * @param batchBand
	 * @return
	 */
	public String callFucntion (MappingField field, String fldVal, BatchBand batchBand)
	{
		IFunction function = null;
		Class<?> clazz = null;
		String functionClass = null;
		Map<String, Object> params = null;
		String[] functionData = null;
		String funcName = null;
		String functionparm = null;
		String[] functionList = null;
		
		try
		{
			functionList = getFunctions(field.getDerivationLogic1(), field.getDerivationLogic2());
			if(functionList ==  null)
				return null;
			makeDBConnection();
			for ( String key : functionList)
			{
				
				functionData = getFunctionName(key);
				if (null == functionData)
					return null;
				funcName = functionData[0];
				functionparm = functionData[1];
				
				functionClass = Definitions.getInstance().getFunctionClass(funcName);
				clazz = Class.forName(functionClass);
				function = (IFunction) clazz.newInstance();
				params = new HashMap<String, Object>();
				params.put(IFunction.FUNCTION_DATA, functionparm);
				params.put(IFunction.FUNCTION_FIELD, field);
				params.put(IFunction.FUNCTION_VALUE, fldVal);
				params.put(IFunction.EXECUTION_DATA, jobData);
				fldVal = (String) function.execute(dbConnection, params);
			}
			if (fldVal != null && fldVal.length() > field.getIFieldLength())
				fldVal = fldVal.substring(0, field.getIFieldLength());
			
		}
		catch (Exception ex)
		{
			logger.error("Error:", ex);
			// TODO DO WHAT?
		}
		finally
		{
			CleanUpUtils.doClean(params);
			params = null;
			function = null;
			clazz = null;
		}
		
		return fldVal;
	}
	
	/**
	 * TODO
	 * 
	 * @param field
	 * @param dataBand
	 * @return
	 */
	public String callComplexFunction (MappingField field, Band dataBand, BatchBand batchBand) throws FormatException
	{
		String bandRef = null;
		String fieldRef = null;
		String fldVal = null;
		FormatException fExp = null;
		IFunction function = null;
		Class<?> clazz = null;
		String functionClass = null;
		
		Map<String, Object> params = null;
		String[] functionData = null;
		String funcName = null;
		String functionparm = null;
		String[] functionList = null;
		
		try
		{
			functionList = getFunctions(field.getDerivationLogic1(), field.getDerivationLogic2());
			if(functionList ==  null)
				return null;
			makeDBConnection();
			for ( String key : functionList)
			{
				
				functionData = getFunctionName(key);
				if (functionData == null)
					return null;
				
				funcName = functionData[0];
				functionparm = functionData[1];
				functionClass = Definitions.getInstance().getFunctionClass(funcName);
				clazz = Class.forName(functionClass);
				function = (IFunction) clazz.newInstance();
				params = new HashMap<String, Object>();
				params.put(IFunction.FUNCTION_DATA, functionparm);
				params.put(IFunction.FUNCTION_FIELD, field);
				params.put(IFunction.FUNCTION_VALUE, fldVal);
				params.put(IFunction.EXECUTION_DATA, jobData);
				params.put(IFunction.EXECUTION_BAND, dataBand);
				params.put(IFunction.EXECUTION_BATCH, batchBand);
				fldVal = (String) function.execute(dbConnection, params);
			}
			
			
			if (fldVal != null && fldVal.length() > field.getFieldLength())
				fldVal = fldVal.substring(0, field.getFieldLength());
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			logger.error("Error While assigning Ref Value");
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ "Field Val:" + fldVal, "Band Ref:" + bandRef, "Field Ref:" + fieldRef }, exp);
			throw fExp;
		}
		finally
		{
			CleanUpUtils.doClean(params);
			params = null;
			function = null;
			clazz = null;
		}
		
		return fldVal;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param derivationLogic1
	 * @param derivationLogic2
	 * @return
	 * @throws FormatException
	 * </pre></p>
	 */
	private String[] getFunctions (String derivationLogic1, String derivationLogic2) throws FormatException
	{
		String data = null;
		String[] returnValues = null;
		FormatException fExp = null;
		String errorMsg = null;
		
		if (derivationLogic1 == null)
			return returnValues;
		
		try
		{
			data = derivationLogic1;
			if (derivationLogic2 != null)
				data = data + derivationLogic2;
			
			returnValues = org.apache.commons.lang3.StringUtils.split(data, IrisAdminConstants.FUNCTION_SPLIT_CHARS);
		}
		catch (Exception exp)
		{
			errorMsg = "Error While finding function:" + data;
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return returnValues;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param functionDetails
	 * @return
	 * @throws FormatException
	 * </pre></p>
	 */
	private String[] getFunctionName (String functionDetails) throws FormatException
	{
		String value = null;
		String function = null;
		String[] returnValues = null;
		FormatException fExp = null;
		
		int firstIndex = -1;
		int secoundIndex = -1;
		
		if (functionDetails == null)
			return returnValues;
		
		try
		{
			firstIndex = functionDetails.indexOf("(");
			secoundIndex = functionDetails.indexOf(")");
			function = functionDetails.substring(0, firstIndex);
			value = functionDetails.substring(firstIndex + 1, secoundIndex);
			returnValues = new String[2];
			returnValues[0] = function;
			returnValues[1] = value;
		}
		catch (Exception exp)
		{
			fExp = new FormatException("error.iris.admin.complexfunction", new Object[]
			{ functionDetails }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		
		return returnValues;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @param jobData
	 * @return
	 * </pre></p>
	 */
	public String getFilterParameter (MappingField field, String fldVal, ExecutionJobData jobData)
	{
		String filterVal = null;
		
		filterVal = jobData.getFilterParameter(field.getFieldRef());
		
		return filterVal;
	}
	
	/**
	 * 
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @param dataBand
	 * @param bandDef
	 * @param batchBand
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	protected String formatNonDirect (MappingField field, String fldVal, Band dataBand, InterfaceBandDef bandDef, BatchBand batchBand)
			throws FormatException
	{
		FormatException fExp = null;
		try
		{
			/*
			 * Try to get as much data possible for the given MappingType
			 */
			if (fldVal == null || "".equals(fldVal.trim()))
				fldVal = getDefaultValue(field);
			
			if (IrisAdminConstants.MAPPING_TYPE_FILTER == field.getMappingType())
				/* 2 */fldVal = getFilterParameter(field, fldVal, jobData);
			
			if (IrisAdminConstants.MAPPING_TYPE_FUNCTION == field.getMappingType())
				/* 2 */fldVal = callFucntion(field, fldVal, batchBand);
			
			if (IrisAdminConstants.MAPPING_TYPE_ROUTINE == field.getMappingType())
				/* 10 */fldVal = callHook(field, dataBand, fldVal, batchBand);
			
			if (IrisAdminConstants.MAPPING_TYPE_CONSTANT == field.getMappingType())
				/* 5 */fldVal = assignConstant(field);
			
			if (IrisAdminConstants.MAPPING_TYPE_RUNNING_NO == field.getMappingType())
				/* 6 */fldVal = getRunningNumber(field);
			
			if (IrisAdminConstants.MAPPING_TYPE_CODEMAP == field.getMappingType())
				/* 3 */fldVal = assignCodeMap(bandDef, field, (String) fldVal);
			
			if (IrisAdminConstants.MAPPING_TYPE_REFCODEMAP == field.getMappingType())
				/* 13 */fldVal = assignCodeMapRef(bandDef,field, dataBand, batchBand);
			
			if (IrisAdminConstants.MAPPING_TYPE_ISNULLCODEMAP == field.getMappingType())
				/* 14 */fldVal = assignIsNullCodeMapRef(fldVal, bandDef,field, dataBand, batchBand);
			
			if (IrisAdminConstants.MAPPING_TYPE_REFERENCED == field.getMappingType())
				/* 1 */fldVal = IrisAdminUtils.getRefValue(field, dataBand, batchBand);
			
			if (IrisAdminConstants.MAPPING_TYPE_COMPLEX == field.getMappingType())
				/* 4 */fldVal = callComplexFunction(field, dataBand, batchBand);
			
			fldVal = formatVal(field, fldVal, jobData);
			// Check length
			fldVal = checkLength(field, fldVal);
			
			if (fldVal == null)
			{
				fldVal = "";
			}
		}
		catch (FormatException exp)
		{
			
			// jobData.setErrorCode(IRISAdminErrors.FILE_FORMAT_ERROR_CODE);
			// jobData.setErrorMsg(IRISAdminErrors.FILE_FORMAT_ERROR_DESC + " Field:" + field.getFieldName()+ " Value:" + fldVal + " Format:" +
			// field.getFormat());
			throw exp;
		}
		catch (Exception exp)
		{
			logger.error("Error While assigning Code Map Value");
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ "Field Val:" + fldVal, "Field Name:" + field.getFieldName() }, exp);
			throw fExp;
		}
		return fldVal;
	}
	
	/**
	 * <p>
	 * This helper method calls the function which is configured for a field. This function uses reference fields and static values only. This
	 * function will not read from file.
	 * <p>
	 * <i> This method reads the function data and breaks in to 2 parts. 1 part will be function name and 2nd part will be data based inside function.
	 * i.e with in ()</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param dataBand
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String assignCodeMapRef (InterfaceBandDef bandDef,MappingField field, Band dataBand, BatchBand batchBand) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		String fldVal = null;
		
		try
		{
			fldVal = IrisAdminUtils.getRefValue(field, dataBand, batchBand);
			codeMap = field.getCodeMap();
			if (fldVal != null)
				fldVal = fldVal.trim();
			
			if (fldVal == null || "".equals(fldVal))
				codeMapVal = getDefaultCodeMap(bandDef, field, fldVal);
			else if (codeMap.contains(fldVal))
				codeMapVal = getGridCodeMap(bandDef, field, fldVal);
			else
				codeMapVal = getRestCodeMap(bandDef, field, fldVal);
			
			if (codeMapVal != null && codeMapVal.length() > field.getIFieldLength())
				codeMapVal = codeMapVal.substring(0, field.getIFieldLength());
			
		}
		catch (Exception exp)
		{
			errorMsg = "Code Map:" + codeMap.getCodeMapId() + " Value for Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:"
					+ field.getFieldName() + " Reference Field Name:" + field.getBandRef()+ "." + field.getFieldRef();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString(), field.toString() }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			errorMsg = null;
		}
		return codeMapVal;
	}
	
	public String assignIsNullCodeMapRef (String fldVal, InterfaceBandDef bandDef,MappingField field, Band dataBand, BatchBand batchBand) throws FormatException
	{
		CodeMap codeMap = null;
		FormatException fExp = null;
		String codeMapVal = null;
		String errorMsg = null;
		
		try
		{
			if (! org.apache.commons.lang3.StringUtils.isEmpty(fldVal))// is value is there then do not use code map
					return fldVal;
			
			fldVal = IrisAdminUtils.getRefValue(field, dataBand, batchBand);
			codeMap = field.getCodeMap();
			if (fldVal != null)
				fldVal = fldVal.trim();
			
			if (fldVal == null || "".equals(fldVal))
				codeMapVal = getDefaultCodeMap(bandDef, field, fldVal);
			else if (codeMap.contains(fldVal))
				codeMapVal = getGridCodeMap(bandDef, field, fldVal);
			else
				codeMapVal = getRestCodeMap(bandDef, field, fldVal);
			
			if (codeMapVal != null && codeMapVal.length() > field.getIFieldLength())
				codeMapVal = codeMapVal.substring(0, field.getIFieldLength());
			
		}
		catch (Exception exp)
		{
			errorMsg = "Code Map:" + codeMap.getCodeMapId() + " Value for Field Val:" + fldVal + " Band:" + bandDef.getBandName() + " Field Name:"
					+ field.getFieldName() + " Reference Field Name:" + field.getBandRef()+ "." + field.getFieldRef();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString(), field.toString() }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			errorMsg = null;
		}
		return codeMapVal;
	}
	
	/**
	 * TODO
	 * 
	 * @param field
	 * @return
	 */
	protected String getRunningNumber (MappingField field)
	{
		String key = null;
		RunningNumber runningNumber = null;
		
		key = field.getResetBandName() + field.getBandName() + field.getFieldName();
		
		if (runningNumberMap.containsKey(key))
			runningNumber = runningNumberMap.get(key);
		else
		{
			runningNumber = new RunningNumber();
			runningNumberMap.put(key, runningNumber);
		}
		return runningNumber.getNext();
	}
	
	protected void resetRunningNumbers (String bandName)
	{
		RunningNumber runningNumber = null;
		for (String key : runningNumberMap.keySet())
		{
			if (key.startsWith(bandName))
			{
				runningNumber = runningNumberMap.get(key);
				runningNumber.reset();
			}
			
		}
	}
	
	protected String callHook (MappingField field, Band dataBand, String fldVal, BatchBand batchBand)
	{
		IFunction function = null;
		Class<?> clazz = null;
		String functionClass = null;
		Map<String, Object> params = null;
		String[] functionData = null;
		String funcName = null;
		String functionparm = null;
		String[] functionList = null;
		int index = 1;
		
		try
		{
			functionList = getFunctions(field.getDerivationLogic1(), field.getDerivationLogic2());
			if(functionList ==  null)
				return null;
			makeDBConnection();
			for ( String key : functionList)
			{
				
				functionData = getFunctionName(key);
				if (functionData == null)
					return null;
				funcName = functionData[0];
				functionparm = functionData[1];
				
				if (hooks.containsKey(field.getFieldName() + index))
				{
					function = (IFunction) hooks.get(field.getFieldName() + index);
				}
				else
				{
					functionClass = Definitions.getInstance().getFunctionClass(funcName);
					clazz = Class.forName(functionClass);
					function = (IFunction) clazz.newInstance();
				}
				params = new HashMap<String, Object>();
				params.put(IFunction.FUNCTION_DATA, functionparm);
				params.put(IFunction.FUNCTION_FIELD, field);
				params.put(IFunction.FUNCTION_VALUE, fldVal);
				params.put(IFunction.EXECUTION_DATA, jobData);
				params.put(IFunction.EXECUTION_BAND, dataBand);
				params.put(IFunction.EXECUTION_BATCH, batchBand);
				fldVal = (String) function.execute(dbConnection, params);
				hooks.put(field.getFieldName() + index, function);
				index ++;
			}
			if (fldVal != null && fldVal.length() > field.getFieldLength())
				fldVal = fldVal.substring(0, field.getFieldLength());
			
		}
		catch (Exception ex)
		{
			logger.error("Error While Executing Hook:" + funcName, ex);
		}
		finally
		{
			params = null;
			function = null;
			clazz = null;
		}
		
		return fldVal;
	}
	/**
	 * 
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @param jobData
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	protected String formatVal (MappingField field, String fldVal, ExecutionJobData jobData) throws FormatException
	{
		
		if (IrisAdminConstants.DATA_TYPE_DATE.equals(field.getDataType()) || IrisAdminConstants.DATA_TYPE_DATETIME.equals(field.getDataType()))
			
			fldVal = getDateAsString(field, fldVal);
		
		else if (IrisAdminConstants.DATA_TYPE_DECIMAL.equals(field.getDataType()))
			
			fldVal = getDecimalVal(field, fldVal);
		
		return fldVal;
	}
	
	/**
	 * 
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	protected String getDecimalVal (MappingField field, String fldVal) throws FormatException
	{
		String definationType = null;
		double dbVal = 0;
		String paddedZeros = null;
		String strPrecision = null;
		DecimalFormat decimalFormat = null;
		Number nbVal = null;
		FormatException fExp = null;
		
		try
		{
			if (null == fldVal || "".equals(fldVal.trim()))
				return fldVal;
			
			definationType = jobData.getMapType();
			paddedZeros = "";
			strPrecision = "1" + HelperUtils.paddingString(paddedZeros, field.getPrecision(), '0', true);
			
			if (field.getFormat() != null)
			{
				decimalFormat = new DecimalFormat(field.getFormat());
				
				if (IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(definationType))
				{
					// First parse according to format
					nbVal = decimalFormat.parse(fldVal.trim());
					dbVal = nbVal.doubleValue();
					// if precision mentioned then divide
					if (field.getPrecision() > 0)
					{
						dbVal = nbVal.doubleValue() / Double.parseDouble(strPrecision);
					}
					fldVal = Double.toString(dbVal);
				}
				else
				{
					dbVal = Double.parseDouble(fldVal);
					// First check precision
					if (field.getPrecision() > 0)
					{
						dbVal = dbVal * Double.parseDouble(strPrecision);
					}
					// Format it according to download format
					fldVal = decimalFormat.format(dbVal);
				}
			}
		}
		catch (Exception exp)
		{
			logger.error("Error While assigning Code Map Value");
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ "Field Val:" + fldVal, "Field Name:" + field.getFieldName() }, exp);
			throw fExp;
		}
		
		return fldVal;
	}
	
	private void makeDBConnection () throws SQLException, SystemException
	{
		if (dbConnection == null)
		{
			conProvider = new ConnectionProviderAdapter(this.applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
					ResourceTypeEnum.IRIS_DATABASE);
			dbConnection = conProvider.getConnection();
		}
		
	}
	
	public void calulateBatchTotal (InterfaceBandDef currentDef, BatchBand batchBand, Band dataBand) throws FormatException
	{
		String fldVal = null;
		BigDecimal bdfldVal = null;
		DataField dataField = null;
		
		for (MappingField field : currentDef.getMappingFields())
		{
			if (IrisAdminConstants.MAPPING_TYPE_BATCH_TOTAL == field.getMappingType())
			{
				bdfldVal = getBatchTotal(field, dataBand, batchBand);
				if (bdfldVal == null)
					bdfldVal = new BigDecimal(0);
				fldVal = bdfldVal.toPlainString();
				
				if (field.getBatchTotalType().trim().equals("S"))
					fldVal = getDecimalVal(field, fldVal);
				
				fldVal = format(field, fldVal);
				dataField = createDataField(field, fldVal);
				dataBand.setFieldValue(field.getFieldName(), dataField);
			}
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	protected DataField createDataField (MappingField field, String fldVal)
	{
		DataField dataField = null;
		
		dataField = new DataField();
		dataField.setDataType(field.getDataType());
		dataField.setFieldLength(field.getFieldLength());
		dataField.setFieldType(field.getFieldType());
		dataField.setFormat(field.getFormat());
		dataField.setMappingType(field.getMappingType());
		dataField.setPrecision(field.getPrecision());
		dataField.setValue(fldVal);
		
		return dataField;
	}
	
	/**
	 * TODO
	 * 
	 * @param bandDef
	 * @param field
	 * @param dataBand
	 * @param batchBand
	 * @return
	 */
	private BigDecimal getBatchTotal (MappingField field, Band dataBand, BatchBand parentbatchBand)
	{
		String fldVal = null;
		String bandName = null;
		BigDecimal totalFldVal = null;
		String bandRef = null;
		String fieldRef = null;
		boolean found = false;
		BigDecimal bdfldVal = null;
		
		bdfldVal = new BigDecimal(0);
		bandRef = field.getBandRef();
		fieldRef = field.getFieldRef();
		
		bandName = dataBand.getName();
		if (!bandName.equals(bandRef))
		{
			// if there is child bands, totals should be taken from there.
			if (dataBand.getChildBatches().size() > 1)
			{
				for (BatchBand batchBand : dataBand.getChildBatches())
				{
					for (Band childBand : batchBand.getBatchBands())
					{
						bdfldVal = getBatchTotal(field, childBand, batchBand);
						if (bdfldVal != null)
						{
							if (!found)
								totalFldVal = new BigDecimal(0);
							totalFldVal = totalFldVal.add(bdfldVal);
							found = true;
						}
					}
				}
			}
			else if (parentbatchBand != null)
			{
				for (Band parentBand : parentbatchBand.getBatchBands())
				{
					// came to equal band
					for (BatchBand batchBand : parentBand.getChildBatches())
					{
						for (Band childBand : batchBand.getBatchBands())
						{
							bdfldVal = getBatchTotal(field, childBand, batchBand);
							if (bdfldVal != null)
							{
								if (!found)
									totalFldVal = new BigDecimal(0);
								totalFldVal = totalFldVal.add(bdfldVal);
								found = true;
								
							}
						}
					}
					if (found)
						break;
				}
			}
		}
		else
		{
			if (field.getBatchTotalType().trim().equals("S"))
			{
				bdfldVal = new BigDecimal(0);
				fldVal = dataBand.getFieldValue(fieldRef);
				if (fldVal == null)
					fldVal = "0";
				
				fldVal = fldVal.trim();
				
				if ("".equals(fldVal))
					fldVal = "0";
				
				if (fldVal.contains(","))
				{
					fldVal = fldVal.replace(",", "");
					bdfldVal.add(new BigDecimal(fldVal));
				}
				else
					bdfldVal = bdfldVal.add(new BigDecimal(fldVal));
			}
			else
			{
				bdfldVal = new BigDecimal(1);
				
			}
			totalFldVal = bdfldVal;
		}
		return totalFldVal;
	}
	
	/**
	 * TODO
	 * 
	 * @param field
	 * @param fldVal
	 * @return
	 */
	public String format (MappingField field, String fldVal)
	{
		int fieldlLength = 0;
		String filler = null;
		
		fieldlLength = field.getFieldLength();
		filler = field.getFiller();
		if (filler == null)
		{
			if (IrisAdminConstants.DATA_TYPE_DECIMAL.equals(field.getDataType()) || IrisAdminConstants.DATA_TYPE_NUMBER.equals(field.getDataType()))
				filler = "0";
			else
				filler = " ";
		}
		
		if ("R".equals(field.getAlignment()))
			fldVal = StringUtils.padLeft(fldVal, filler, fieldlLength);
		else if ("L".equals(field.getAlignment()))
			fldVal = StringUtils.padRight(fldVal, filler, fieldlLength);
		
		return fldVal;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack)
	 */
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> stack, Deque<Band> dataValues) throws FormatException,
			ExecutionException
	{
		// BABU Auto-generated method stub
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// BABU Auto-generated method stub
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// BABU Auto-generated method stub
		return false;
	}
}
