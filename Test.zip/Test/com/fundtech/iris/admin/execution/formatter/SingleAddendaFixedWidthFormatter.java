/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : SingleAddendaDelimitterFormatter.java
 * CREATED: Feb 3, 2014 11:22:19 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.Deque;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * This formatter formats the ACH Addenda record for single set enrichments for the CCD+ PPD ..etc like SEC codes. This formatter is not for multi set
 * enrichments .
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: SingleAddendaFixedWidthFormatter.java,v 1.7 2015/12/23 04:20:30 ramap Exp $
 */
public class SingleAddendaFixedWidthFormatter extends FixedWidthFormatter
{
	private static Logger logger = LoggerFactory.getLogger(SingleAddendaFixedWidthFormatter.class);
	
	public SingleAddendaFixedWidthFormatter()
	{
		super();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack)
	 */
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		String fmtStr = null;
		FormatException fExp = null;
		boolean returnVal = false;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		StringBuilder builder = new StringBuilder();
		InterfaceBandDef bandDef = null;
		try
		{
			fmtStr = (String) obj;
			builder.append(fmtStr.substring(0, 1));
			bandDef = defStack.peekFirst();
			fmtStr = fmtStr.substring(3, 83);// Remove 705 at the begining and last 11 chars
			fmtStr = fmtStr.replace("\\", "");
			builder.append(fmtStr);
			fmtStr = builder.toString();
			returnVal = (Boolean) super.uploadFormat(lineNumber, fmtStr, defStack, dataStack);
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			CleanUpUtils.doClean(builder);
			builder = null;
		}
		return returnVal;
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef)
	{
		String fmtStr = null;
		String bandValue = null;
		
		fmtStr = (String) obj;
		if (fmtStr.length() >= 1)
		{
			if (bandDef.getBandIdPosition() > 0)
				bandValue = fmtStr.substring(0, 1);
		}
		return bandValue;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef)
	{
		String bandValue = null;
		bandValue = getBandId(obj, bandDef);
		if (bandDef.getBandId().equals(bandValue))
			return true;
		return false;
	}
	
}
