/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : FedWireFormatter.java
 * CREATED: Jan 7, 2014 12:30:10 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * This helper class formats FedWire file.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into datastore_mst (DATASTORE_TYPE, INTERFACE_TYPE, FORMAT_TYPE, DATASTORE_NAME, DESCRIPTION, DATASTORE_VALUE, EXECUTION_CLASS, FORMATTER_CLASS, RECORD_KEY_NMBR, AUDIT_NMBR, VALID_FLAG, OPERATION_FLAG, CHECKER_ACTION, PREV_AUDIT_NMBR) 
 * values ('F', 'U', 'F', 'FED WIRE', 'Fed Wire Format', '', 'com.fundtech.iris.admin.execution.FileReader', 'com.fundtech.iris.admin.execution.formatter.FedWireFormatter', '', '', 'Y', '', '', '')
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: FedWireFormatter.java,v 1.14 2016/07/14 06:59:29 ramap Exp $
 */
public class FedWireFormatter extends AbstractFormatter
{
	private static Logger logger = LoggerFactory.getLogger(FedWireFormatter.class);
	private final String REGEX = "(\\{[0-9]{4}\\})(.+?)(?=$|\\{[0-9]{4}\\}|\\r\\n|\\n)";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack)
	 */
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		String fmtStr = null;
		Map<String, String> tokenMap = null;
		FormatException fExp = null;
		boolean returnVal = false;
		String errorMsg = null;
		IrisAdminError error = null;
		InterfaceBandDef bandDef = null;
		IrisError irisError = null;
		try
		{
			fmtStr = (String) obj;
			bandDef = defStack.peekFirst();
			tokenMap = getKeyValue(bandDef,fmtStr, REGEX);
			returnVal = createBand(lineNumber, obj, tokenMap, defStack, dataStack);
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return returnVal;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#formatBandData(long, java.lang.Object,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	@SuppressWarnings("unchecked")
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		Map<String, DataField> dataValues = null;
		List<MappingField> listFields = null;
		Iterator<MappingField> groupFields = null;
		String groupKey = null;
		Map<String, List<MappingField>> fieldGroups = null;
		String groupVal = null;
		Map<String, String> tokenMap = null;
		
		tokenMap = (Map<String, String>) obj;
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		fieldGroups = getFieldsGroups(bandDef,listFields);
		
		for (Map.Entry<String, List<MappingField>> entry : fieldGroups.entrySet())
		{
			groupKey = entry.getKey();
			groupFields = entry.getValue().iterator();
			
			if ("{EMPTY}".equals(groupKey))
			{
				mapNonFileData(lineNumber, dataValues, groupFields, bandDef, dataBand);
			}
			else
			{
				groupVal = tokenMap.get(groupKey);
				mapFileData(lineNumber, dataValues, groupFields, groupVal, bandDef, dataBand);
			}
			
		}
		return dataValues;
	}
	
	/**
	 * <p>
	 * This helper method formats the non file fields
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param dataValues
	 * @param groupFields
	 * @param bandDef
	 * @param dataBand
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private void mapNonFileData (long lineNumber, Map<String, DataField> dataValues, Iterator<MappingField> groupFields, InterfaceBandDef bandDef,
			Band dataBand) throws FormatException
	{
		
		String fldVal = null;
		MappingField field = null;
		
		while (groupFields.hasNext())
		{
			field = groupFields.next();
			format(lineNumber, dataValues, dataBand, field, fldVal, bandDef);// passing null value
		}
	}
	
	/**
	 * <p>
	 * This helper method formts file data
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param dataValues
	 * @param groupFields
	 * @param groupVal
	 * @param bandDef
	 * @param dataBand
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private void mapFileData (long lineNumber, Map<String, DataField> dataValues, Iterator<MappingField> groupFields, String groupVal,
			InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		
		long fieldln = 0;
		StringBuilder builder = null;
		String fldVal = null;
		MappingField field = null;
		
		if (groupVal == null || "".equals(groupVal))
		{
			checkMandatory(bandDef,groupFields);
			return;// means no mandatory
		}
		
		if (groupFields.hasNext())
		{
			field = groupFields.next();
			fieldln = field.getFieldLength();
		}
		
		builder = new StringBuilder();
		for (char c : groupVal.toCharArray())
		{
			if ("*".equals(Character.toString(c)) || builder.length() == fieldln)
			{
				if (builder.length() > 0)
					fldVal = builder.toString();
				
				format(lineNumber, dataValues, dataBand, field, fldVal, bandDef);
				fldVal = null;
				CleanUpUtils.doClean(builder);
				
				if (!"*".equals(Character.toString(c)))
					builder.append(c);
				
				if (groupFields.hasNext())
				{
					field = groupFields.next();
					fieldln = field.getFieldLength();
				}
				else
					break;
			}
			else
				builder.append(c);
		}
		if (builder.length() > 0)
		{
			fldVal = builder.toString();
			format(lineNumber, dataValues, dataBand, field, fldVal, bandDef);
			fldVal = null;
			CleanUpUtils.doClean(builder);
		}
		checkMandatory(bandDef,groupFields);
	}
	
	/**
	 * <p>
	 * This helper method formats the fields and does zeroProofing check
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dataValues
	 * @param dataBand
	 * @param field
	 * @param fldVal
	 * @param bandDef
	 * </pre>
	 * 
	 * </p>
	 */
	private void format (long lineNumber, Map<String, DataField> dataValues, Band dataBand, MappingField field, String fldVal,
			InterfaceBandDef bandDef) throws FormatException
	{
		validateField(fldVal, field, bandDef, dataBand, dataValues);
	}
	
	/**
	 * <p>
	 * This helper method checks any mandatory fields are having without data in group Fields
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param lineNumber
	 * @param groupFields
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private void checkMandatory (InterfaceBandDef bandDef, Iterator<MappingField> groupFields) throws FormatException
	{
		
		MappingField field = null;
		try
		{
			while (groupFields.hasNext())
			{
				field = groupFields.next();
				checkMandatory(bandDef,field);
			}
		}
		catch (FormatException exp)
		{
			throw exp;
		}
	}
	
	/**
	 * <p>
	 * This helper method creates groups of tags
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param listFields
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	private Map<String, List<MappingField>> getFieldsGroups (InterfaceBandDef bandDef, List<MappingField> listFields) throws FormatException
	{
		Map<String, List<MappingField>> fieldGroups = null;
		List<MappingField> groupFields = null;
		String currentTag = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		fieldGroups = new TreeMap<String, List<MappingField>>();
		
		try
		{
			for (MappingField field : listFields)
			{
				currentTag = field.getAbsoluteXPath1();
				if (currentTag == null)
					currentTag = "{EMPTY}";
				
				if (fieldGroups.containsKey(currentTag))
				{
					groupFields = fieldGroups.get(currentTag);
					groupFields.add(field);
				}
				else
				{
					groupFields = new ArrayList<MappingField>();
					groupFields.add(field);
					fieldGroups.put(currentTag, groupFields);
				}
			}
		}
		catch (Exception exp) // its definition error so we will not accumulate error
		{
			errorMsg = "Error in defination";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, listFields.toString(), null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return fieldGroups;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// This method need to implement for this Formatter coz its single band
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// this method always return true coz its single band
		return true;
	}
}
