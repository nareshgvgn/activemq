/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : Iso8583Formatter.java
 * CREATED: Jun 24, 2015 10:33:57 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.solab.iso8583.IsoMessage;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: Iso8583Formatter.java,v 1.4 2015/12/23 04:20:30 ramap Exp $
 */
public class Iso8583Formatter extends AbstractFormatter
{
	private static Logger logger = LoggerFactory.getLogger(Iso8583Formatter.class);
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public Iso8583Formatter()
	{
		// BABU Auto-generated constructor stub
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack)
	 */
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		InterfaceBandDef bandDef = null;
		String[] tokens = null;
		FormatException fExp = null;
		boolean returnVal = false;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		try
		{
			bandDef = defStack.peekFirst();
			returnVal = createBand(lineNumber, obj, obj, defStack, dataStack);
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, bandDef.toString(), obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return returnVal;
		
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		String bandValue = null;
		IsoMessage isoMessage = null;
		
		try
		{
			isoMessage = (IsoMessage) obj;
			bandValue = "" + isoMessage.getType();
		}
		finally
		{
		}
		
		return bandValue;
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		String bandValue = null;
		
		if (bandDef.getBandId() == null)
			return true;
		
		bandValue = getBandId(obj, bandDef);
		
		if (bandDef.getBandId().equals(bandValue))
			return true;
		
		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#formatBandData(long, java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	@Override
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		Map<String, DataField> dataValues = null;
		String fldVal = null;
		List<MappingField> listFields = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		String fieldName = null;
		IsoMessage isoMessage = null;
		
		isoMessage = (IsoMessage) obj;
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		try
		{
			
			for (MappingField field : listFields)
			{
				
				if ( field.getAbsoluteXPath1() != null)
				{
					if (isoMessage.getAt(Integer.valueOf(field.getAbsoluteXPath1())) != null)
						fldVal = isoMessage.getAt(Integer.valueOf(field.getAbsoluteXPath1())).toString();
				}
				else
					fldVal = null;
				
				validateField(fldVal, field, bandDef, dataBand, dataValues);
				
				fldVal = null;
			}
		}
		catch (ArrayIndexOutOfBoundsException exp)
		{
			errorMsg = " Field :" + fieldName + " Not present in file";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, bandDef.toString(),obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return dataValues;
	}
	
}
