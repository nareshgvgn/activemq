package com.fundtech.iris.admin.execution.formatter;

import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * This formatter uses SAX reader. So we must use along with XMLSAXReader.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into Datastore_Mst (DATASTORE_TYPE, INTERFACE_TYPE, DATASTORE_NAME, DESCRIPTION, DATASTORE_VALUE, EXECUTION_CLASS, FORMATTER_CLASS, RECORD_KEY_NMBR, AUDIT_NMBR, VALID_FLAG, OPERATION_FLAG, CHECKER_ACTION, PREV_AUDIT_NMBR)
 * values ('REST_REQ', 'U', 'X', 'XML File  Format', '', 'com.fundtech.iris.admin.execution.XMLSAXReader', 'com.fundtech.iris.admin.execution.formatter.XMLSAXFormatter', '', '', 'Y', '', '', '');
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: XMLSAXFormatter.java,v 1.20 2017/01/30 04:50:14 ramap Exp $
 */
public class XMLSAXFormatter extends AbstractFormatter
{
	private static Logger logger = LoggerFactory.getLogger(XMLSAXFormatter.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#uploadFormat(java.lang.Object, java.util.Stack, java.util.Stack,
	 * com.fundtech.iris.admin.data.RootBand)
	 */
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		
		InterfaceBandDef bandDef = null;
		String expression = null;
		List<Node> rootList = null;
		Object childObj = null;
		Node parentNode = null;
		Node childNode = null;
		Band dataBand = null;
		Map<String, DataField> dataValues = null;
		FormatException fExp = null;
		Band batchBand = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String strBandDef = null;
		String bandName = null;
		
		try
		{
			bandDef = defStack.peekFirst();
			bandName = bandDef.getBandName();
			batchBand = dataStack.peekFirst();
			dataBand = new Band();
			dataBand.setId(bandDef.getBandId());
			dataBand.setName(bandName);
			dataBand.setBandPath(bandDef.getBandPath());
			dataBand.setBandType(bandDef.getBandType());
			parentNode = (Node) obj;
			
			if (bandDef.getParentBandName() == null)
				dataBand.setParentBand(null);
			else
				dataBand.setParentBand(batchBand);
			
			batchBand.addChildBand(dataBand);
			dataStack.addFirst(dataBand);
			dataValues = formatBandData(lineNumber, parentNode, bandDef, dataBand);
			dataBand.addFields(dataValues);
			bandDefs = bandDef.getChildDefinitions().getBandDefinitions();
			for (InterfaceBandDef childDef : bandDefs.values())
			{
				expression = childDef.getRelativeXPath();
				childObj = parentNode.selectObject(expression);
				if (childObj instanceof Node)
				{
					rootList = new ArrayList<Node>();
					rootList.add((Node) childObj);
				}
				else if (childObj instanceof List)
				{
					rootList = (List<Node>) childObj;
				}
				if (rootList == null)
				{
					if (logger.isTraceEnabled())
						logger.trace(childDef.getBandName() + " or " + expression + " Doersn't have any data in xml");
					if (childDef.isMandatory())
					{
						errorMsg = childDef.getBandName() + " or " + expression + " Doersn't have any data in xml";
						fExp = new FormatException("err.irisadmin.format", new Object[]
						{ errorMsg, bandDef.toString() }, null);
						error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, childDef.toString(), null);
						jobData.addError(error);
						logger.error(IRISLogger.getText(fExp));
						throw fExp;
					}
				}
				defStack.addFirst(childDef);
				for (int index = 0; null != rootList && index < rootList.size(); index++)
				{
					childNode = rootList.get(index);
					uploadFormat(lineNumber, childNode, defStack, dataStack);
				}
				defStack.removeFirst();
			}
			dataStack.removeFirst();
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating band:" + bandName;
			if (bandDef != null)
				strBandDef = bandDef.toString();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, strBandDef }, exp);
			error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, strBandDef, null);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			if ( irisError != null)
			{
				arrangeError(bandDef.getBandType(), dataValues, lineNumber);
			}
			strBandDef = null;
		}
		
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#format(long, java.lang.Object,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	@Override
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		Map<String, DataField> dataValues = null;
		String fldVal = null;
		List<MappingField> listFields = null;
		FormatException fExp = null;
		String expression = null;
		Node fieldNode = null;
		Node parentNode = null;
		String errorMsg = null;
		IrisAdminError error = null;
		
		parentNode = (Node) obj;
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		for (MappingField field : listFields)
		{
			try
			{
				if (checkFieldMappingType(field.getMappingType()))
				{
					expression = field.getRelativeXPath();
					// remove [] if attribute comes
					if (expression.contains("@"))
						expression = getExpression(expression);
					fieldNode = parentNode.selectSingleNode(expression);
					if (fieldNode == null)
					{
						if (logger.isTraceEnabled())
							logger.trace(field.getFieldName() + " or " + expression + " Doersn't have any data in xml");
						if (field.isMandatory())
						{
							errorMsg = "Value of Mandatory Field is NULL. Field Name:" + field.getFieldName() + " Band:" + field.getBandName()
									+ " Sequence No:" + field.getsequenceNmbr() + " Expression:" + expression;
							fExp = new FormatException("err.irisadmin.format.mandatory", new Object[]
							{ errorMsg, field.toString() }, null);
							error = createError(IrisAdminConstants.ERR_CODE_MANDATORY, errorMsg, field.toString(), null);
							jobData.addError(error);
							logger.error(IRISLogger.getText(fExp));
							
							if (!jobData.isAccumulateErros())
								throw fExp;
						}
					}
					else
						fldVal = fieldNode.getText();
					
					if (fldVal != null && fldVal.length() > field.getFieldLength())
						fldVal = fldVal.substring(0, field.getFieldLength());
				}
				
				validateField(fldVal, field, bandDef, dataBand, dataValues);
				fldVal = null;
			}
			catch (FormatException exp)
			{
				throw exp;
			}
			catch (Exception exp)
			{
				errorMsg = "Error While Creating Band";
				fExp = new FormatException("err.irisadmin.format", new Object[]
				{ errorMsg }, exp);
				error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null,  obj);
				jobData.addError(error);
				logger.error(IRISLogger.getText(fExp));
				throw fExp;
			}
		}
		return dataValues;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#downloadFormat(com.fundtech.iris.admin.data.Band,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	public Object downloadFormat (Band dataBand, InterfaceBandDef def) throws FormatException
	{
		
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// No need of this method for XML Formatter
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		// No need of this method for XML Formatter
		return false;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param expression
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private String getExpression (String expression)
	{
		String temp1 = null;
		String temp2 = null;
		String returnExpression = null;
		
		// remove [] from xpath
		temp1 = expression.substring(0, expression.indexOf("@") - 1);
		temp2 = expression.substring(expression.indexOf("@"), expression.length() - 1);
		returnExpression = temp1 + "/" + temp2;
		
		return returnExpression;
	}
}
