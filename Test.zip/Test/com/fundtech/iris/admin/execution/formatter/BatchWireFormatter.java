/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : BatchWireFormatter.java
 * CREATED: Jan 5, 2014 1:29:14 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: BatchWireFormatter.java,v 1.13 2015/12/23 04:20:30 ramap Exp $
 */
public class BatchWireFormatter extends AbstractFormatter
{
	private static Logger logger = LoggerFactory.getLogger(BatchWireFormatter.class.getName());
	private final String REGEX = "([A-Z0-9]{3})=(.+?)(?=$|[A-Z0-9]{3}=|\\r\\n|\\n)";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.AbstractFormatter#uploadFormat(long, java.lang.Object, java.util.Stack, java.util.Stack)
	 */
	@Override
	public Object uploadFormat (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack) throws FormatException,
			ExecutionException
	{
		String fmtStr = null;
		Map<String, String> tokenMap = null;
		FormatException fExp = null;
		boolean returnVal = false;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		InterfaceBandDef bandDef = null;
		
		try
		{
			fmtStr = (String) obj;
			bandDef = defStack.peekFirst();
			tokenMap = getKeyValue(bandDef,fmtStr, REGEX);
			returnVal = createBand(lineNumber, obj, tokenMap, defStack, dataStack);
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, null, fmtStr);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return returnVal;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, DataField> formatBandData (long lineNumber, Object obj, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		Map<String, DataField> dataValues = null;
		String fldVal = null;
		List<MappingField> listFields = null;
		FormatException fExp = null;
		Map<String, String> tokenMap = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		dataValues = new HashMap<String, DataField>();
		listFields = bandDef.getMappingFields();
		tokenMap = (Map<String, String>) obj;
		try
		{
			for (MappingField field : listFields)
			{
				if (checkFieldMappingType(field.getMappingType()))
					fldVal = tokenMap.get(field.getAbsoluteXPath1());
				
				validateField(fldVal, field, bandDef, dataBand, dataValues);
			}
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While Creating Band";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, bandDef.toString(), obj);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return dataValues;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#getBandId(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public String getBandId (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		Map<String, String> tokenMap = null;
		String bandValue = null;
		try
		{
			tokenMap = getKeyValue(bandDef,(String) obj, REGEX);
			bandValue = tokenMap.get("RID");
		}
		finally
		{
			CleanUpUtils.doClean(tokenMap);
			tokenMap = null;
		}
		return bandValue;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#isBandExits(java.lang.Object, com.fundtech.iris.admin.interfaces.InterfaceBandDef)
	 */
	@Override
	public boolean isBandExits (Object obj, InterfaceBandDef bandDef) throws FormatException
	{
		String bandValue = null;
		bandValue = getBandId(obj, bandDef);
		if (bandDef.getBandId().equals(bandValue))
			return true;
		return false;
	}
}
