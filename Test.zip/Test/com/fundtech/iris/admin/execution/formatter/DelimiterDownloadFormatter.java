/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.formatter
 * FILE   : DelimiterDownloadFormatter.java
 * CREATED: Dec 10, 2013 10:49:38 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.formatter;

import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceBandsDef;

/**
 * <p>
 * This class formats the data in given delimiter. This class can be configured by using database preload
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into DATASTORE_MST (DATASTORE_TYPE, INTERFACE_TYPE, DATASTORE_NAME, DESCRIPTION, DATASTORE_VALUE, 
 * EXECUTION_CLASS, FORMATTER_CLASS, RECORD_KEY_NMBR, AUDIT_NMBR, VALID_FLAG, OPERATION_FLAG, CHECKER_ACTION, PREV_AUDIT_NMBR)
 * 	values ('F', 'D', 'D', 'Delimited File Format', '', 'com.fundtech.iris.admin.execution.FileWriter', 
 * 	'com.fundtech.iris.admin.execution.formatter.DelimiterDownloadFormatter', '', '', 'Y', '', '', '');
 * </pre>
 * 
 * </p>
 * <p>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: DelimiterDownloadFormatter.java,v 1.6 2014/07/20 04:58:17 ramap Exp $
 */
public class DelimiterDownloadFormatter extends DownloadFormatter
{
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.formatter.IFormatter#downloadFormat(com.fundtech.iris.admin.data.BatchBand,
	 * com.fundtech.iris.admin.interfaces.InterfaceBandDef, com.fundtech.iris.admin.data.Band)
	 */
	public Object downloadFormat (BatchBand batchBand, InterfaceBandDef bandDef, Band dataBand) throws FormatException
	{
		String fldName = null;
		String fldVal = null;
		InterfaceBandsDef childDefs = null;
		InterfaceBandDef childDef = null;
		String delimiter = null;
		String qualifier = null;
		DataField dataField = null;
		
		delimiter = interfaceDef.getDelimiter();
		qualifier = interfaceDef.getQualifier();
		for (MappingField field : bandDef.getMappingFields())
		{
			fldName = field.getFieldName();
			fldVal = dataBand.getFieldValue(fldName);
			
			fldVal = formatNonDirect(field, fldVal, dataBand, bandDef, batchBand);
			if (fldVal == null || "null".equals(fldVal))
				fldVal = "";
			
			if (delimiter != null && fldVal.contains(delimiter) && qualifier != null)
				fldVal = qualifier + fldVal + qualifier;
			
			dataField = createDataField(field, fldVal);
			dataBand.setFieldValue(fldName, dataField);
		}
		childDefs = bandDef.getChildDefinitions();
		for (BatchBand childBatchBand : dataBand.getChildBatches())
		{
			for (Band childBand : childBatchBand.getBatchBands())
			{
				childDef = childDefs.getBandDefinition(childBand.getName());
				downloadFormat(childBatchBand, childDef, childBand);
			}
		}
		/*
		 * This code should be here coz some bands may not have childs
		 */
		calulateBatchTotal(bandDef, batchBand, dataBand);
		resetRunningNumbers(bandDef.getBandName());
		return null;
	}
	
}
