/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : FormatDataNode.java
 * CREATED: Oct 10, 2013 11:05:23 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.FormatDownloadData;
import com.fundtech.iris.admin.interfaces.InterfaceDef;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: FormatDataNode.java,v 1.8 2016/08/04 05:35:42 ramap Exp $
 * @since 1.0.0
 */
public class FormatDataNode extends AbstractNode
{
	private static Logger logger = LoggerFactory.getLogger(FormatDataNode.class);
	
	@Override
	protected void doInitialize (DataObject arg0) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		
		Connection dbConnection = null;
		NodeProcessingException npEx = null;
		ExecutionContext exeContext = null;
		FormatDownloadData formatDownloadData = null;
		NodeProcessingException npExp = null;
		ExecutionJobData jobData = null;
		InterfaceDef interfaceDef = null;
		RootBand rootBand = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			interfaceDef = jobData.getInterfaceDef();
			rootBand = (RootBand) exeContext.get(IrisAdminConstants.PROCESS_DATA);
			
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npEx = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			formatDownloadData = new FormatDownloadData(this.applicationContext, interfaceDef, jobData, rootBand);
			formatDownloadData.formatData();
			exeContext.put(IrisAdminConstants.PROCESS_DATA, rootBand);
		}
		catch (FormatException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		finally
		{
			formatDownloadData = null;
		}
		return packet;
	}
}
