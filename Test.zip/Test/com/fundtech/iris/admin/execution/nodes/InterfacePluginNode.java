/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : InterfacePluginNode.java
 * CREATED: Oct 7, 2013 10:27:49 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Property;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.Definitions;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.ModelRootBand;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: InterfacePluginNode.java,v 1.7 2016/09/12 14:08:42 ramap Exp $
 * @since 1.0.0
 */
public class InterfacePluginNode extends AbstractNode
{
	private static final Logger logger = LoggerFactory.getLogger(InterfacePluginNode.class);
	private Class<?> helperClazz = null;
	private Map<String, String> staticProperties = null;
	
	@Override
	protected void doInitialize (DataObject config) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		Type cfgType = null;
		ConfigurationException conExp = null;
		String helperClass = null;
		DataObject argDO = null;
		Type argType = null;
		List<Property> argList = null;
		
		try
		{
			cfgType = config.getType();
			
			if (cfgType.containsProperty("HelperClass"))
				helperClass = (String) config.getValue("HelperClass");
			
			if (helperClass == null)
			{
				conExp = new ConfigurationException("error.iris.admin.pluginclass", new Object[]{ "HelperClass not configured properly" }, null);
				throw conExp;
			}
			
			helperClazz = Class.forName(helperClass);
			
			if (cfgType.containsProperty("CharSet"))
				charset = (String) config.getValue("CharSet");
			
			if (charset == null || "".equals(charset))
			{
				charset = "UTF-8";
			}
			
			if (cfgType.containsProperty("StaticParameters"))
			{
				staticProperties = new HashMap<String, String>();
				argDO = (DataObject) config.getValue("StaticParameters");
				argType = argDO.getType();
				argList = argType.getProperties();
				for (Property prop : argList)
				{
					staticProperties.put(prop.getName(), (String) argDO.getValue(prop.getName()));
				}
			}
		}
		catch (ClassNotFoundException exp)
		{
			conExp = new ConfigurationException("error.iris.admin.helperClass", new Object[]{ "Class Not found", helperClass }, exp);
			logger.error(IRISLogger.getText(conExp));
			throw conExp;
		}
		catch (ConfigurationException exp)
		{
			logger.error(IRISLogger.getText(exp));
			throw exp;
		}
		finally
		{
			if (argList != null)
				argList.clear();
			
			argList = null;
			argDO = null;
			argType = null;
		}
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		ExecutionJobData jobData = null;
		ExecutionContext exeContext = null;
		IPlugin plugin = null;
		Map<String, Object> pluginData = null;
		Connection dbConnection = null;
		ConnectionProvider conProvider = null;
		NodeProcessingException npExp = null;
		RootBand rootBand = null;
		Definitions definitions = null;
		String runtimeCharSet = null;
		ModelRootBand iRootBand = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			definitions = Definitions.getInstance();
			rootBand = (RootBand) exeContext.get(IrisAdminConstants.PROCESS_DATA);
			iRootBand = (ModelRootBand) exeContext.get(IrisAdminConstants.INTERFACE_DATA);
			runtimeCharSet = jobData.getCharSet();
			if (runtimeCharSet == null)
				jobData.setCharSet(charset);
			
			conProvider = getDBProvider();
			dbConnection = conProvider.getConnection();
			pluginData = new HashMap<String, Object>();
			pluginData.put(IPlugin.EXECUTION_DATA, jobData);
			pluginData.put(IPlugin.EXECUTION_STATIC_PROPS, staticProperties);
			pluginData.put(IrisAdminConstants.PROCESS_DATA, rootBand);
			pluginData.put(IrisAdminConstants.INTERFACE_DATA, iRootBand);
			pluginData.put(IrisAdminConstants.ROUTINE_CLASSES, definitions.getRoutineClasses());
			plugin = (IPlugin) helperClazz.newInstance();
			plugin.initialize();
			startTime = System.currentTimeMillis();
			plugin.execute(dbConnection, pluginData);
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			
			logger.debug("For executing Pluigin:{}  time taken:{}  sec" , helperClazz.getName() , delta );
		}
		catch (InstantiationException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]{ helperClazz.getName() }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (IllegalAccessException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]{ helperClazz.getName() }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (ExecutionException exp)
		{
//			 Do not set status message , take from hook class;
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			throw npExp;
		}
		catch( LoadingException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException(exp.getKey(), new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (SystemException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]	{ helperClazz.getName() }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		finally
		{
			close(conProvider, dbConnection);
		}
		
		return packet;
	}
	
	/**
	 * TODO
	 * 
	 * @param provider
	 * @param tmpConnection
	 */
	private void close (ConnectionProvider provider, Connection tmpConnection)
	{
		try
		{
			provider.releaseConnection(tmpConnection);
			
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// DO NOTHING
		}
		finally
		{
			provider = null;
		}
	}
	
	/**
	 * TODO
	 * 
	 * @return
	 * @throws SystemException
	 */
	private ConnectionProvider getDBProvider () throws LoadingException
	{
		ConnectionProvider conProvider = null;
		LoadingException lExp = null;
		
		try
		{
			
			conProvider = new ConnectionProviderAdapter(this.applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
					ResourceTypeEnum.IRIS_DATABASE);
		}
		catch (Exception exp)
		{
			logger.error("DB Error:", exp);
			lExp = new LoadingException(IrisAdminConstants.ERR_CODE_DB_NULL, new Object[] {}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		return conProvider;
	}
}
