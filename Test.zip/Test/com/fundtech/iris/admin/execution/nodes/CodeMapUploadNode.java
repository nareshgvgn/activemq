/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : CodeMapUploadNode.java
 * CREATED: Jul 4, 2016 3:19:17 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Property;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: CodeMapUploadNode.java,v 1.2 2016/10/19 14:04:55 ramap Exp $
 */
public class CodeMapUploadNode extends AbstractNode
{
	
	private static final Logger logger = LoggerFactory.getLogger(ReportPluginNode.class);
	private Class<?> helperClazz = null;
	private Map<String, String> staticProperties = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public CodeMapUploadNode()
	{
		// BABU Auto-generated constructor stub
	}
	
	@Override
	protected void doInitialize (DataObject config) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		Type cfgType = null;
		ConfigurationException conExp = null;
		String helperClass = null;
		DataObject argDO = null;
		Type argType = null;
		List<Property> argList = null;
		
		try
		{
			cfgType = config.getType();
			
			if (cfgType.containsProperty("HelperClass"))
				helperClass = (String) config.getValue("HelperClass");
			
			if (helperClass == null)
			{
				conExp = new ConfigurationException("error.iris.admin.pluginclass", new Object[]{ "HelperClass not configured properly" }, null);
				throw conExp;
			}
			
			helperClazz = Class.forName(helperClass);
			
			if (cfgType.containsProperty("CharSet"))
				charset = (String) config.getValue("CharSet");
			
			if (charset == null || "".equals(charset))
			{
				charset = "UTF-8";
			}
			
			if (cfgType.containsProperty("StaticParameters"))
			{
				staticProperties = new HashMap<String, String>();
				argDO = (DataObject) config.getValue("StaticParameters");
				argType = argDO.getType();
				argList = argType.getProperties();
				for (Property prop : argList)
				{
					staticProperties.put(prop.getName(), (String) argDO.getValue(prop.getName()));
				}
			}
		}
		catch (ClassNotFoundException exp)
		{
			conExp = new ConfigurationException("error.iris.admin.helperClass", new Object[]{ "Class Not found", helperClass }, exp);
			logger.error(IRISLogger.getText(conExp));
			throw conExp;
		}
		catch (ConfigurationException exp)
		{
			logger.error(IRISLogger.getText(exp));
			throw exp;
		}
		finally
		{
			if (argList != null)
				argList.clear();
			
			argList = null;
			argDO = null;
			argType = null;
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet)
			throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException, PatternMatchingException
	{
		
		ExecutionContext exeContext = null;
		Connection dbConnection = null;
		NodeProcessingException npEx = null;
		IPlugin plugin = null;
		Map<String, Object> pluginData = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		ExecutionJobData jobData = null;
		DataObject dataDo = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npEx = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			
			pluginData = new HashMap<String, Object>();
			pluginData.put(IPlugin.EXECUTION_DATA, jobData);
			pluginData.put(IPlugin.EXECUTION_STATIC_PROPS, staticProperties);
			plugin = (IPlugin) helperClazz.newInstance();
			plugin.initialize();
			startTime = System.currentTimeMillis();
			dataDo = (DataObject) plugin.execute(dbConnection, pluginData);
			createDetails(dbConnection, createheader(dbConnection), dataDo);
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			
			if (logger.isDebugEnabled())
				logger.debug("For executing Pluigin:" + helperClazz.getName() + " time taken:" + delta + " sec");
			
		}
		catch (InstantiationException e)
		{
			// BABU Auto-generated catch block
			e.printStackTrace();
		}
		catch (IllegalAccessException e)
		{
			// BABU Auto-generated catch block
			e.printStackTrace();
		}
		catch (ExecutionException e)
		{
			// BABU Auto-generated catch block
			e.printStackTrace();
		}
		catch (FormatException e)
		{
			// BABU Auto-generated catch block
			e.printStackTrace();
		}
		
		return packet;
	}
	
	private String createheader(Connection dbConnection)  throws NodeProcessingException
	{
		String recordKey = null;
		String recordSql = "select f_get_record_nmbr from dual";
		String insertSql = "insert into iris_codemap_mst (RECORD_KEY_NMBR, CODEMAP_NAME, CODEMAP_DESC, ENTITY_TYPE, ENTITY_CODE, SELLER_CODE, DEFAULT_VALUE, OTHERS_VALUE, "
				+ "SRC_RECORD_KEY_NMBR, SUBMIT_FLAG, REQUEST_STATE, LAST_REQUEST_STATE, VERSION, AUDIT_NMBR, VALID_FLAG, MAKER_ID, MAKER_TIMESTAMP, CHECKER_ID, "
				+ "CHECKER_TIMESTAMP, REJECT_REMARKS, PARENT_RECORD_KEY, MODEL_FIELD_NAME)"
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate, ?, sysdate, ?, ?, ?)";
		PreparedStatement recordSt = null;
		ResultSet recordRs = null;
		NodeProcessingException npEx = null;
		
		try
		{
			recordSt  = dbConnection.prepareStatement(recordSql);
			recordRs = recordSt.executeQuery();
			while ( recordRs.next())
			{
				recordKey = recordRs.getString(1);
			}
			CleanUpUtils.doClean(recordRs);
			CleanUpUtils.doClean(recordSt);
			recordSt  = dbConnection.prepareStatement(insertSql);
			recordSt.setString(1, recordKey);
			recordSt.setString(2, "BRANINGCODEMAP");
			recordSt.setString(3, "Branding code map");
			recordSt.setString(4, "BANK");
			recordSt.setString(5, "BANK");
			recordSt.setString(6, "OWNER");
			recordSt.setString(7, null);
			recordSt.setString(8, null);
			recordSt.setString(9, null);
			recordSt.setString(10, IrisAdminConstants.CONSTANT_N);
			recordSt.setString(11, "3");
			recordSt.setString(12, "0");
			recordSt.setString(13, "1");
			recordSt.setString(14, null);
			recordSt.setString(15, IrisAdminConstants.CONSTANT_Y);
			recordSt.setString(16, "00Y");
			
			recordSt.setString(17,"00X" );
			
			recordSt.setString(18, null);
			recordSt.setString(19, null);
			recordSt.setString(20, null);
			recordSt.executeUpdate();
		}
		catch (SQLException exp)
		{
			npEx = IRISLogger.getNodeProcEx("error.app.errorFormattingBand", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
		finally
		{
			CleanUpUtils.doClean(recordRs);
			CleanUpUtils.doClean(recordSt);
		}
		
		return recordKey;
	}
	
	private void createDetails(Connection dbConnection, String parentkey , DataObject dataDo) throws NodeProcessingException
	{
		String insertSql = "insert into iris_codemap_dtl (RECORD_KEY_NMBR, PARENT_RECORD_KEY_NMBR, CODEMAP_NAME, INPUT_VALUE, OUTPUT_VALUE) "
				+ "values (f_get_record_nmbr,?, 'BRANINGCODEMAP', ?, ?)";
		
		PreparedStatement recordSt = null;
		List<DataObject> doList = null;
		NodeProcessingException npEx = null;
		
		try
		{
			doList = (ArrayList<DataObject>)dataDo.getValue("CodeMap");
			recordSt  = dbConnection.prepareStatement(insertSql);
			recordSt.clearParameters();
			
			for (DataObject deatils : doList)
			{
				recordSt.setString(1, parentkey);
				recordSt.setString(2, (String) deatils.getValue("inputValue"));
				recordSt.setString(3,  (String) deatils.getValue("outputValue"));
				recordSt.addBatch();
			}
			recordSt.executeBatch();
			dbConnection.commit();
			
			
		}
		catch (SQLException exp)
		{
			npEx = IRISLogger.getNodeProcEx("error.app.errorFormattingBand", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
		catch (InappropriatePathTypeException exp)
		{
			npEx = IRISLogger.getNodeProcEx("error.app.errorFormattingBand", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
		finally
		{
			CleanUpUtils.doClean(recordSt);
		}
		
	}
	
	
}
