package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.Definitions;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.hooks.IProcessHook;
import com.fundtech.iris.admin.interfaces.InterfaceDef;

/**
 * This node Executes all Routine Types like 1) PRE_PROCESSING_ROUTINE 2) POST_PROCESSING_ROUTINE 3) POST_UPDATION_ROUTINE 4) REVERSE_UPDATE_ROUTINE
 * 
 * @author Babu Paluri
 * @version $Id: ExecutionRoutineNode.java,v 1.13 2015/10/19 12:06:39 ramap Exp $
 * @since 1.0.0
 */
public class ExecutionRoutineNode extends AbstractNode
{
	
	private String routineType = null;
	private static final Logger logger = LoggerFactory.getLogger(ExecutionRoutineNode.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doInitialize(com.cashtech.iris.patterns.sdo.DataObject)
	 */
	@Override
	protected void doInitialize (DataObject configuration) throws InappropriatePathTypeException, InvalidPropertyAccessException,
			ConfigurationException
	{
		Type cfgType = null;
		ConfigurationException conExp = null;
		
		try
		{
			cfgType = configuration.getType();
			if (cfgType.containsProperty("RoutineType"))
				routineType = (String) configuration.getValue("RoutineType");
			
			if (routineType == null || "".equals(routineType))
			{
				conExp = new ConfigurationException("error.iris.admin.routineType", new Object[]
				{ "RoutineType not configured" }, null);
				throw conExp;
			}
			if (cfgType.containsProperty("CharSet"))
				charset = (String) configuration.getValue("CharSet");
			
			if (charset == null || "".equals(charset))
			{
				charset = "UTF-8";
			}
		}
		catch (ConfigurationException exp)
		{
			logger.error(IRISLogger.getText(exp));
			throw exp;
		}
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		ExecutionContext exeContext = null;
		ExecutionJobData jobData = null;
		InterfaceDef interfaceDef = null;
		IProcessHook processHook = null;
		String routineClass = null;
		RootBand rootBand = null;
		Definitions definitions = null;
		Class<?> clazz = null;
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		NodeProcessingException npExp = null;
		String runtimeCharSet = null;
		Map<String, Object> hookData = null;
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			definitions = Definitions.getInstance();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			interfaceDef = jobData.getInterfaceDef();
			rootBand = (RootBand) exeContext.get(IrisAdminConstants.PROCESS_DATA);
			
			runtimeCharSet = jobData.getCharSet();
			if (runtimeCharSet == null)
				jobData.setCharSet(charset);
			
			if (IrisAdminConstants.PRE_PROCESSING_ROUTINE.equals(routineType))
			{
				routineClass = interfaceDef.getPreProcessingRoutine();
			}
			
			else if (IrisAdminConstants.POST_PROCESSING_ROUTINE.equals(routineType))
			{
				routineClass = interfaceDef.getPostProcessingRoutine();
			}
			
			else if (IrisAdminConstants.POST_UPDATION_ROUTINE.equals(routineType))
			{
				routineClass = interfaceDef.getPostUpdationRoutine();
				if (IrisAdminConstants.JOB_STATUS_SUCESS.equals(jobData.getStatus()))
					jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE);
			}
			
			else if (IrisAdminConstants.REVERSE_UPDATE_ROUTINE.equals(routineType))
			{
				routineClass = interfaceDef.getReverseUpdateRoutine();
				jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE);
			}
			
			if (routineClass == null || "".equals(routineClass))
				return packet;
			
			dbProvider = getDBProvider();
			dbConnection = dbProvider.getConnection();
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				
				npExp = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]
				{ this.name, ResourceTypeEnum.IRIS_DATABASE });
				logger.error(IRISLogger.getText(npExp));
				throw npExp;
			}
			/*
			 * Populate the additional requried Job Data from Process Defination.
			 */
			hookData = new HashMap<String, Object>();
			hookData.put(IProcessHook.DATA_ROOT_BAND, rootBand);
			hookData.put(IProcessHook.EXECUTION_DATA, jobData);
			clazz = Class.forName(definitions.getRoutineClass(routineClass));
			processHook = (IProcessHook) clazz.newInstance();
			processHook.initialize();
			processHook.execute(dbConnection, hookData);
		}
		catch (NodeProcessingException exp)
		{
			setStatus(jobData);
			throw exp;
		}
		catch (ExecutionException exp)
		{
			setStatus(jobData);
			npExp = new NodeProcessingException("error.iris.admin.routinecall", new Object[] {}, exp);
			throw npExp;
		}
		catch (ClassNotFoundException exp)
		{
			setStatus(jobData);
			npExp = new NodeProcessingException("error.iris.admin.routinecall", new Object[]
			{ "RoutineClass:" + routineClass + " not found" }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (InstantiationException exp)
		{
			setStatus(jobData);
			npExp = new NodeProcessingException("error.iris.admin.routinecall", new Object[]
			{ "RoutineClass:" + routineClass + " not able to Instantiation" }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (IllegalAccessException exp)
		{
			setStatus(jobData);
			npExp = new NodeProcessingException("error.iris.admin.routinecall", new Object[]
			{ "RoutineClass:" + routineClass + " not able to access" }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (Exception exp)
		{
			setStatus(jobData);
			npExp = new NodeProcessingException("error.iris.admin.routinecall", new Object[]
			{ "Un Known error" }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		finally
		{
			close(dbProvider, dbConnection);
		}
		return packet;
	}
	
	/*-------------------------------------------------------------------------------------------------*
	 * HELPER METHODS
	 *------------------------------------------------------------------------------------------------*/
	/**
	 * This helper method
	 * 
	 * @param jobData
	 */
	private void setStatus (ExecutionJobData jobData)
	{
		if (IrisAdminConstants.PRE_PROCESSING_ROUTINE.equals(routineType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
		else if (IrisAdminConstants.POST_PROCESSING_ROUTINE.equals(routineType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
		
		else if (IrisAdminConstants.POST_UPDATION_ROUTINE.equals(routineType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
		
		else if (IrisAdminConstants.REVERSE_UPDATE_ROUTINE.equals(routineType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
	}
	
	/**
	 * This helper method creates the connection provider. This connection taken like this coz hooks should execute with their own connection and
	 * hooks will decide to commit or rollback.
	 * 
	 * @return
	 * @throws SystemException
	 */
	private ConnectionProvider getDBProvider () throws SystemException
	{
		ConnectionProvider conProvider = null;
		
		conProvider = new ConnectionProviderAdapter(this.applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
				ResourceTypeEnum.IRIS_DATABASE);
		return conProvider;
	}
	
	/**
	 * This helper method release the DB Connection.
	 * 
	 * @param provider
	 * @param dbConnection
	 */
	private void close (ConnectionProvider provider, Connection dbConnection)
	{
		try
		{
			provider.releaseConnection(dbConnection);
			
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// DO NOTHING
		}
		finally
		{
			provider = null;
		}
	}
}
