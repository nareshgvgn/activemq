/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : InterfaceCryptographyNode.java
 * CREATED: Jul 2, 2013 12:00:53 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.NotSupportedException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceCryptographyNode.java,v 1.10 2015/10/21 07:15:41 ramap Exp $
 * @since 1.0.0
 */
public class InterfaceCryptographyNode extends AbstractNode
{
	private Logger logger = LoggerFactory.getLogger(InterfaceCryptographyNode.class);
	private Class<?> symmetricClazz = null;
	private Class<?> asymmetricClazz = null;
	private String passphrase  = null;
	@Override
	protected void doInitialize (DataObject config) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		
		Type cfgType = null;
		ConfigurationException conExp = null;
		String helperClass = null;
		DataObject argDO = null;
		Type argType = null;
		
		try
		{
			cfgType = config.getType();
			
			if (cfgType.containsProperty("SymmetricHelperClass"))
			{
				helperClass = (String) config.getValue("SymmetricHelperClass");
				symmetricClazz = Class.forName(helperClass);
			}
			
			if (cfgType.containsProperty("AsymmetricParameters"))
			{
				argDO = (DataObject) config.getValue("AsymmetricParameters");
				argType = argDO.getType();
				if ( argType.containsProperty("HelperClass"))
				{
					helperClass = (String) argDO.getValue("HelperClass");
					asymmetricClazz = Class.forName(helperClass);
				}
				else
				{
					conExp = new ConfigurationException("error.iris.admin.pluginclass", new Object[]{ "AsymmetricHelperClass not configured properly" }, null);
					throw conExp;
				}
				
				if (argType.containsProperty("Passphrase"))
					passphrase = (String) argDO.getValue("Passphrase");
				else
				{
					conExp = new ConfigurationException("error.iris.admin.pluginclass", new Object[]{ "passphrase not configured properly" }, null);
					throw conExp;
				}
			}
			if (helperClass == null)
			{
				conExp = new ConfigurationException("error.iris.admin.pluginclass", new Object[]
				{ "SymmetricHelperClass not configured properly" }, null);
				throw conExp;
			}
			
		}
		catch (ClassNotFoundException exp)
		{
			conExp = new ConfigurationException("error.iris.admin.helperClass", new Object[]
			{ "Class Not found", helperClass }, exp);
			logger.error(IRISLogger.getText(conExp));
			throw conExp;
		}
		catch (ConfigurationException exp)
		{
			logger.error(IRISLogger.getText(exp));
			throw exp;
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		NodeProcessingException nodeEx = null;
		ExecutionJobData jobData = null;
		ExecutionContext exeContext = null;
		String uploadFileName = null;
		InterfaceMap interfaceMap = null;
		String cryptoType = null;
		NotSupportedException nExp = null;
		IPlugin plugin = null;
		Map<String, Object> pluginData = null;
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		String signingType = null;
		SecurityProfile secProfile = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			interfaceMap = jobData.getInterfaceMap();
			secProfile = interfaceMap.getSecurityProfile();
			uploadFileName = jobData.getMediaDetails();
			
			if ((secProfile.isEncryptionRequired() || secProfile.isSiginingRequired())
					&& IrisAdminConstants.MEDIA_FILE.equals(jobData.getMediumType()))
			{
				dbProvider = getDBProvider();
				dbConnection = dbProvider.getConnection();
				if (null == dbConnection)
				{
					logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
					
					nodeEx = IRISLogger.getNodeProcEx(IrisAdminConstants.ERR_CODE_DB_NULL, new Object[]{ this.name, ResourceTypeEnum.IRIS_DATABASE });
					logger.error(IRISLogger.getText(nodeEx));
					throw nodeEx;
				}
				
				cryptoType = secProfile.getEncryptionType();
				signingType = secProfile.getSigningType();
				if (IrisAdminConstants.CRYPTOGRAPHY_TYPE_SY.equals(cryptoType) || IrisAdminConstants.SIGNING_TYPE_SY.equals(signingType))
				{
					pluginData = new HashMap<String, Object>();
					pluginData.put(IPlugin.EXECUTION_DATA, jobData);
					
					plugin = (IPlugin) symmetricClazz.newInstance();
					plugin.initialize();
					plugin.execute(dbConnection, pluginData);
				}
				
				else if (IrisAdminConstants.CRYPTOGRAPHY_TYPE_ASY.equals(cryptoType) || IrisAdminConstants.SIGNING_TYPE_ASY.equals(signingType))
				{
					pluginData = new HashMap<String, Object>();
					pluginData.put(IPlugin.EXECUTION_DATA, jobData);
					pluginData.put(IPlugin.PASS_PHRASE, passphrase);
					plugin = (IPlugin) asymmetricClazz.newInstance();
					plugin.initialize();
					plugin.execute(dbConnection, pluginData);
				}
				else
				{
					// jobData.setErrorMsg(cryptoType + "Not known..Not Supported");
					nExp = new NotSupportedException(cryptoType + "Not known..Not Supported");
					throw nExp;
				}
			}
		}
		catch (NotSupportedException exp)
		{
			setStatus(jobData);
			nodeEx = new NodeProcessingException("error.iris.admin", new Object[]{ uploadFileName }, exp);
			logger.error(IRISLogger.getText(nodeEx));
			throw nodeEx;
		}
		catch (ExecutionException exp)
		{
			setStatus(jobData);
			nodeEx = new NodeProcessingException("error.iris.admin", new Object[]{ uploadFileName }, exp);
			logger.error(IRISLogger.getText(nodeEx));
			throw nodeEx;
		}
		catch ( NodeProcessingException exp)
		{
			throw exp;
		}
		catch (Exception e)
		{
			setStatus(jobData);
			nodeEx = new NodeProcessingException("error.iris.admin", new Object[]{ uploadFileName }, e);
			logger.error(IRISLogger.getText(nodeEx));
			throw nodeEx;
		}
		finally
		{
			close(dbProvider, dbConnection);
		}
		return packet;
	}
	
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------*
 *									 HELPER METHODS
 *---------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	/**
	 * This helper method
	 * 
	 * @param jobData
	 */
	private void setStatus (ExecutionJobData jobData)
	{
		if (IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(jobData.getMapType()))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
		else
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
	}
	
	/**
	 * This helper method creates the connection provider. This connection taken like this coz hooks should execute with their own connection and
	 * hooks will decide to commit or rollback.
	 * 
	 * @return
	 * @throws SystemException
	 */
	private ConnectionProvider getDBProvider () throws NodeProcessingException
	{
		ConnectionProvider conProvider = null;
		NodeProcessingException nExp = null;
		
		try
		{
			
			conProvider = new ConnectionProviderAdapter(this.applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
					ResourceTypeEnum.IRIS_DATABASE);
		}
		catch (Exception exp)
		{
			logger.error("DB Error:", exp);
			nExp = new NodeProcessingException(IrisAdminConstants.ERR_CODE_DB_NULL, new Object[] {}, exp);
			logger.error(IRISLogger.getText(nExp));
			throw nExp;
		}
		return conProvider;
	}
	
	/**
	 * This helper method release the DB Connection.
	 * 
	 * @param provider
	 * @param dbConnection
	 */
	private void close (ConnectionProvider provider, Connection dbConnection)
	{
		try
		{
			if ( dbConnection != null)
				provider.releaseConnection(dbConnection);
			
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// DO NOTHING
		}
		finally
		{
			provider = null;
		}
	}
	
}
