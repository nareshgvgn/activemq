package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.execution.IWriter;
import com.fundtech.iris.admin.interfaces.InterfaceDef;

/**
 * This Node is to read data from actual tables.
 * 
 * @author Rohini Ghadge
 * @version $Id: FileWriterNode.java,v 1.11 2015/10/19 12:06:39 ramap Exp $
 */
public class FileWriterNode extends AbstractNode
{
	private static Logger logger = LoggerFactory.getLogger(FileWriterNode.class);
	private String fileNameClass = null;
	private String emptyFileNameClass = null;
	
	@Override
	protected void doInitialize (DataObject conf) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		Type cfgType = null;
		try
		{
			cfgType = conf.getType();
			if (cfgType.containsProperty("CharSet"))
				charset = (String) conf.getValue("CharSet");
			
			if (charset == null || "".equals(charset))
			{
				charset = "UTF-8";
			}
			
			if (cfgType.containsProperty("SysGenFileNameClass"))
				fileNameClass = (String) conf.getValue("SysGenFileNameClass");
			
			if (cfgType.containsProperty("SysGenEmptyFileNameClass"))
				emptyFileNameClass = (String) conf.getValue("SysGenEmptyFileNameClass");
			
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// Ignore
			charset = "UTF-8";
		}
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		Connection dbConnection = null;
		NodeProcessingException npEx = null;
		ExecutionContext exeContext = null;
		IWriter writeFile = null;
		NodeProcessingException npExp = null;
		ExecutionJobData jobData = null;
		String runtimeCharSet = null;
		InterfaceDef interfaceDef = null;
		RootBand rootBand = null;
		Class<?> clazz = null;
		String writerClass = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			interfaceDef = jobData.getInterfaceDef();
			rootBand = (RootBand) exeContext.get(IrisAdminConstants.PROCESS_DATA);
			
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			
			if (fileNameClass == null)
				jobData.addParms(IrisAdminConstants.CUST_GEN_DATA_FILE, IrisAdminConstants.SYS_GEN_DATA_FILE);
			else
				jobData.addParms(IrisAdminConstants.CUST_GEN_DATA_FILE, fileNameClass);
			
			if (emptyFileNameClass == null)
				jobData.addParms(IrisAdminConstants.CUST_GEN_EMPTY_FILE, IrisAdminConstants.SYS_GEN_EMPTY_FILE);
			else
				jobData.addParms(IrisAdminConstants.CUST_GEN_EMPTY_FILE, emptyFileNameClass);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npEx = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]
				{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			
			runtimeCharSet = jobData.getCharSet();
			if (runtimeCharSet == null)
				jobData.setCharSet(charset);
			
			writerClass = interfaceDef.getExecutionClass();
			clazz = Class.forName(writerClass);
			writeFile = (IWriter) clazz.newInstance();
			writeFile.initialize(this.applicationContext, interfaceDef, jobData, rootBand);
			writeFile.writeData();
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS);
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			npExp = new NodeProcessingException("error.iris.admin.execution", new Object[] {}, exp);
			IRISLogger.getText(npExp);
			throw npExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			npExp = new NodeProcessingException("error.iris.admin.execution", new Object[] {}, exp);
			IRISLogger.getText(npExp);
			throw npExp;
		}
		finally
		{
			writeFile = null;
		}
		return packet;
	}
}
