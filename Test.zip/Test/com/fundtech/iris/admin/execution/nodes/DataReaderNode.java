/*----------------------------------------------------------------------------------------------------------------------
 * PACKAGE  : com.fundtech.iris.admin.execution.nodes
 * FILE     : DataReaderNode.java
 * CREATED  : Jul 3, 2013 10:34:24 AM
 * COPYRIGHT: Copyright (c) 2008, Fundtech INDIA Ltd.
 *--------------------------------------------------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.execution.InterfaceDataReader;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.model.ModelDef;

/**
 * This Node is to read data from actual tables.
 * 
 * @author Rohini Ghadge
 * @version $Id: DataReaderNode.java,v 1.9 2014/12/08 05:44:36 ramap Exp $
 */
public class DataReaderNode extends AbstractNode
{
	private static Logger logger = LoggerFactory.getLogger(DataReaderNode.class);
	
	@Override
	protected void doInitialize (DataObject arg0) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		// TODO Auto-generated method stub
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		
		Connection dbConnection = null;
		NodeProcessingException npEx = null;
		RootBand rootBand = null;
		ExecutionContext exeContext = null;
		InterfaceDataReader interfaceReader = null;
		NodeProcessingException npExp = null;
		ExecutionJobData jobData = null;
		InterfaceDef interfaceDef = null;
		ModelDef modelDef = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			interfaceDef = jobData.getInterfaceDef();
			modelDef = interfaceDef.getMosdelDef();
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npEx = IRISLogger.getNodeProcEx( IrisAdminConstants.ERR_CODE_DB_NULL, new Object[]{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			interfaceReader = new InterfaceDataReader(interfaceDef, modelDef, jobData, dbConnection);
			rootBand = interfaceReader.loadInterfaceData();
			exeContext.put(IrisAdminConstants.PROCESS_DATA, rootBand);
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus("E");
			npExp = new NodeProcessingException("error.iris.admin.interfaceData", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch ( NodeProcessingException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("E");
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		
		return packet;
	}
	
}
