/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : InterfacePluginNode.java
 * CREATED: Oct 7, 2013 10:27:49 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Property;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.EventJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: EventPluginNode.java,v 1.7 2016/10/28 09:15:49 ramap Exp $
 * @since 1.0.0
 */
public class EventPluginNode extends AbstractNode
{
	private static final Logger logger = LoggerFactory.getLogger(EventPluginNode.class);
	private Class<?> helperClazz = null;
	private Map<String, String> staticProperties = null;
	
	@Override
	protected void doInitialize (DataObject config) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		Type cfgType = null;
		ConfigurationException conExp = null;
		String helperClass = null;
		DataObject argDO = null;
		Type argType = null;
		List<Property> argList = null;
		
		try
		{
			cfgType = config.getType();
			
			if (cfgType.containsProperty("HelperClass"))
				helperClass = (String) config.getValue("HelperClass");
			
			if (helperClass == null)
			{
				conExp = new ConfigurationException("error.iris.admin.pluginclass", new Object[]
				{ "HelperClass not configured properly" }, null);
				throw conExp;
			}
			
			helperClazz = Class.forName(helperClass);
			
			if (cfgType.containsProperty("CharSet"))
				charset = (String) config.getValue("CharSet");
			
			if (charset == null || "".equals(charset))
			{
				charset = "UTF-8";
			}
			
			if (cfgType.containsProperty("StaticParameters"))
			{
				staticProperties = new HashMap<String, String>();
				argDO = (DataObject) config.getValue("StaticParameters");
				argType = argDO.getType();
				argList = argType.getProperties();
				for (Property prop : argList)
				{
					staticProperties.put(prop.getName(), (String) argDO.getValue(prop.getName()));
				}
			}
		}
		catch (ClassNotFoundException exp)
		{
			conExp = new ConfigurationException("error.iris.admin.helperClass", new Object[]{ "Class Not found", helperClass }, exp);
			logger.error(IRISLogger.getText(conExp));
			throw conExp;
		}
		catch (ConfigurationException exp)
		{
			logger.error(IRISLogger.getText(exp));
			throw exp;
		}
		finally
		{
			if (argList != null)
				argList.clear();
			
			argList = null;
			argDO = null;
			argType = null;
		}
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		EventJob jobData = null;
		ExecutionContext exeContext = null;
		IPlugin plugin = null;
		Map<String, Object> pluginData = null;
		Connection dbConnection = null;
		ConnectionProvider conProvider = null;
		NodeProcessingException npExp = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (EventJob) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			conProvider = getDBProvider();
			dbConnection = conProvider.getConnection();
			pluginData = new HashMap<String, Object>();
			pluginData.put(IPlugin.EXECUTION_DATA, jobData);
			pluginData.put(IPlugin.EXECUTION_STATIC_PROPS, staticProperties);
			plugin = (IPlugin) helperClazz.newInstance();
			plugin.initialize();
			startTime = System.currentTimeMillis();
			plugin.execute(dbConnection, pluginData);
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			
			if (logger.isDebugEnabled())
				logger.debug("For executing Pluigin:" + helperClazz.getName() + " time taken:" + delta + " sec");
			jobData.setStatus("C");
		}
		catch (InstantiationException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ helperClazz.getName() }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (IllegalAccessException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ helperClazz.getName() }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (ExecutionException exp)
		{
			// Do not set status message , take from hook class;
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			throw npExp;
		}
		catch (SystemException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ helperClazz.getName() }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		finally
		{
			close(conProvider, dbConnection);
		}
		
		return packet;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param provider
	 * @param tmpConnection
	 * </pre></p>
	 */
	private void close (ConnectionProvider provider, Connection tmpConnection)
	{
		try
		{
			provider.releaseConnection(tmpConnection);
			
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// DO NOTHING
		}
		finally
		{
			provider = null;
		}
	}
	
	/**
	 * TODO
	 * 
	 * @return
	 * @throws SystemException
	 */
	private ConnectionProvider getDBProvider () throws SystemException
	{
		ConnectionProvider conProvider = null;
		
		conProvider = new ConnectionProviderAdapter(this.applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,
				ResourceTypeEnum.IRIS_DATABASE);
		return conProvider;
	}
}
