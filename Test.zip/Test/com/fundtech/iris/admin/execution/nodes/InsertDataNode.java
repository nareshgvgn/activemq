/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : InsertDataNode.java
 * CREATED: Jul 15, 2013 12:55:36 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.ModelRootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.execution.MakeAndExecuteSqls;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: InsertDataNode.java,v 1.9 2015/10/19 12:06:39 ramap Exp $
 * @since 1.0.0
 */
public class InsertDataNode extends AbstractNode
{
	private static Logger logger = LoggerFactory.getLogger(InsertDataNode.class);
	private long batchSize = 0;
	
	@Override
	protected void doInitialize (DataObject conf) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		Type cfgType = null;
		String batchlimit = null;
		try
		{
			cfgType = conf.getType();
			if (cfgType.containsProperty("BatchSize"))
				batchlimit = (String) conf.getValue("BatchSize");
			
			if (batchlimit == null || "".equals(batchlimit))
				batchSize = 10000;
			else
				batchSize = Long.parseLong(batchlimit);
			
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// Ignore
			batchSize = 10000;
		}
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		ExecutionContext exeContext = null;
		Connection dbConnection = null;
		NodeProcessingException npEx = null;
		ModelRootBand rootBand = null;
		MakeAndExecuteSqls execution = null;
		ExecutionJobData jobData = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			rootBand = (ModelRootBand) exeContext.get(IrisAdminConstants.INTERFACE_DATA);
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npEx = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]
				{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			execution = new MakeAndExecuteSqls(rootBand, dbConnection, batchSize, jobData);
			execution.createAndRunSQls();
			exeContext.remove(IrisAdminConstants.INTERFACE_DATA);
			
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npEx = new NodeProcessingException("error.iris.admin.datamapping", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
		catch (NodeProcessingException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			throw exp;
		}
		catch (Exception exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npEx = new NodeProcessingException("error.iris.admin.datamapping", new Object[]
			{ "UnKnown Error" }, exp);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
		
		return packet;
	}
	
}
