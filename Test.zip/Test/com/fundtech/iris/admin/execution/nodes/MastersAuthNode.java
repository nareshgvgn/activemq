/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : MastersAuthNode.java
 * CREATED: Jul 28, 2016 11:45:08 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Property;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * <p>This Node is used for authorization of Client, User and Role. 
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code
 * <?xml version="1.0"?>

<!-- ***************************************************************************************************
Purpose       :: Client, Role & User Authorization
Process Name  :: CLIENTMASTERSAUTH, ROLEMASTERSAUTH, USERMASTERSAUTH
TxnCode       :: 
Date	      :: 
Version       :: 1.0
Author        :: Babu Paluri
Released By   :: 
Content Chg   ::
*************************************************************************************************** -->
<ProcessDefinition>
    <Types>
        <Type name="masterAuth" uri="com.cashtech.iris.core.processor.config" instanceClass="com.cashtech.iris.core.sdo.DataObject">
        	<Property name="patentExecitionId"/>
			<Property name="operation"/>
			<Property name="JobId"/>
			</Type>
	</Types>
    
    <Processes>
   		<Process name="CLIENTMASTERSAUTH" type="Process" commitLevel="Process">
			<Nodes>
            <NodeDefinition id="ClientAuthNode" nodeClass="com.fundtech.iris.admin.execution.nodes.MastersAuthNode">
					<References>
						<Reference name="IRIS_DB" type="DB_CONN"/>
						<Reference name="FileInfo" type="INPUT_TYPE"/>
						<Reference name="CodeMap" type="OUTPUT_TYPE"/>
					</References>
					<Parameter name="HelperClass" value="com.dh.iris.admin.channel.dmt.EntityAuthorizer"/>
					<Parameter name="StaticParameters">
						<Parameter name="ACTION"  value="CLIENT_MASK_AUTH"/>
					</Parameter>
				</NodeDefinition>
				
            </Nodes>
            <Controllers>
                <ControllerDefinition id="FileListener" controllerClass="com.cashtech.iris.core.processor.processcontrollers.SimpleFileListener" />
            </Controllers>
            <ProcessGraph>
                <ProcessLoop id="Loop1">
                    <ProcessController id="Link1" controller="FileListener" next="ClientAuthNode" />
					<Channel id="ClientAuthNode" node="ClientAuthNode"/>
                </ProcessLoop>
            </ProcessGraph>
        </Process> 
        
        <Process name="ROLEMASTERSAUTH" type="Process" commitLevel="Process">
			<Nodes>
            <NodeDefinition id="RoleAuthNode" nodeClass="com.fundtech.iris.admin.execution.nodes.MastersAuthNode">
					<References>
						<Reference name="IRIS_DB" type="DB_CONN"/>
						<Reference name="FileInfo" type="INPUT_TYPE"/>
						<Reference name="CodeMap" type="OUTPUT_TYPE"/>
					</References>
					<Parameter name="HelperClass" value="com.dh.iris.admin.channel.dmt.EntityAuthorizer"/>
					<Parameter name="StaticParameters">
						<Parameter name="ACTION"  value="ROLE_MASK_AUTH"/>
					</Parameter>
				</NodeDefinition>
				
            </Nodes>
            <Controllers>
                <ControllerDefinition id="FileListener" controllerClass="com.cashtech.iris.core.processor.processcontrollers.SimpleFileListener" />
            </Controllers>
            <ProcessGraph>
                <ProcessLoop id="Loop1">
                    <ProcessController id="Link1" controller="FileListener" next="RoleAuthNode" />
					<Channel id="RoleAuthNode" node="RoleAuthNode"/>
                </ProcessLoop>
            </ProcessGraph>
        </Process> 
        
         <Process name="USERMASTERSAUTH" type="Process" commitLevel="Process">
			<Nodes>
            <NodeDefinition id="UserAuthNode" nodeClass="com.fundtech.iris.admin.execution.nodes.MastersAuthNode">
					<References>
						<Reference name="IRIS_DB" type="DB_CONN"/>
						<Reference name="FileInfo" type="INPUT_TYPE"/>
						<Reference name="CodeMap" type="OUTPUT_TYPE"/>
					</References>
					<Parameter name="HelperClass" value="com.dh.iris.admin.channel.dmt.EntityAuthorizer"/>
					<Parameter name="StaticParameters">
						<Parameter name="ACTION"  value="USER_AUTH"/>
					</Parameter>
				</NodeDefinition>
				
            </Nodes>
            <Controllers>
                <ControllerDefinition id="FileListener" controllerClass="com.cashtech.iris.core.processor.processcontrollers.SimpleFileListener" />
            </Controllers>
            <ProcessGraph>
                <ProcessLoop id="Loop1">
                    <ProcessController id="Link1" controller="FileListener" next="UserAuthNode" />
					<Channel id="UserAuthNode" node="UserAuthNode"/>
                </ProcessLoop>
            </ProcessGraph>
        </Process> 
    </Processes>
</ProcessDefinition>
 * 
 * }
 * 
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">IRIS Admin</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>MasterAuthDef.xml</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: MastersAuthNode.java,v 1.3 2016/08/23 18:06:32 ramap Exp $
 */
public class MastersAuthNode extends AbstractNode
{
	private static final Logger logger = LoggerFactory.getLogger(ReportPluginNode.class);
	private Class<?> helperClazz = null;
	private Map<String, String> staticProperties = null;
	
	
	/* (non-Javadoc)
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doInitialize(com.cashtech.iris.patterns.sdo.DataObject)
	 */
	@Override
	protected void doInitialize (DataObject config)
			throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		Type cfgType = null;
		ConfigurationException conExp = null;
		String helperClass = null;
		DataObject argDO = null;
		Type argType = null;
		List<Property> argList = null;
		
		try
		{
			cfgType = config.getType();
			
			if (cfgType.containsProperty("HelperClass"))
				helperClass = (String) config.getValue("HelperClass");
			
			if (helperClass == null)
			{
				conExp = new ConfigurationException("error.iris.admin.pluginclass", new Object[]{ "HelperClass not configured properly" }, null);
				throw conExp;
			}
			
			helperClazz = Class.forName(helperClass);
			
			if (cfgType.containsProperty("CharSet"))
				charset = (String) config.getValue("CharSet");
			
			if (charset == null || "".equals(charset))
			{
				charset = "UTF-8";
			}
			
			if (cfgType.containsProperty("StaticParameters"))
			{
				staticProperties = new HashMap<String, String>();
				argDO = (DataObject) config.getValue("StaticParameters");
				argType = argDO.getType();
				argList = argType.getProperties();
				for (Property prop : argList)
				{
					staticProperties.put(prop.getName(), (String) argDO.getValue(prop.getName()));
				}
			}
		}
		catch (ClassNotFoundException exp)
		{
			conExp = new ConfigurationException("error.iris.admin.helperClass", new Object[]{ "Class Not found", helperClass }, exp);
			logger.error(IRISLogger.getText(conExp));
			throw conExp;
		}
		catch (ConfigurationException exp)
		{
			logger.error(IRISLogger.getText(exp));
			throw exp;
		}
		finally
		{
			if (argList != null)
				argList.clear();
			
			argList = null;
			argDO = null;
			argType = null;
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet)
			throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException, PatternMatchingException
	{
		ExecutionContext exeContext = null;
		Connection dbConnection = null;
		NodeProcessingException npEx = null;
		IPlugin plugin = null;
		Map<String, Object> pluginData = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		ExecutionJobData jobData = null;
		NodeProcessingException  npExp =  null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npEx = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			
			pluginData = new HashMap<String, Object>();
			pluginData.put(IPlugin.EXECUTION_DATA, jobData);
			pluginData.put(IPlugin.EXECUTION_STATIC_PROPS, staticProperties);
			plugin = (IPlugin) helperClazz.newInstance();
			plugin.initialize();
			startTime = System.currentTimeMillis();
			plugin.execute(dbConnection, pluginData);
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			
			if (logger.isDebugEnabled())
				logger.debug("For executing Pluigin:" + helperClazz.getName() + " time taken:" + delta + " sec");
		}
		catch (InstantiationException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {helperClazz}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (IllegalAccessException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			npExp = new NodeProcessingException("error.iris.admin.masterauth", new Object[] {helperClazz}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			npExp = new NodeProcessingException("error.iris.admin.masterauth", new Object[] {helperClazz}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (FormatException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			npExp = new NodeProcessingException("error.iris.admin.masterauth", new Object[] {helperClazz}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		
		return packet;
	}
	
}
