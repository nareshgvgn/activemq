package com.fundtech.iris.admin.execution.nodes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.ModelRootBand;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.execution.InterfaceDataMapper;
import com.fundtech.iris.admin.model.ModelDef;

public class DataMapperNode extends AbstractNode
{
	private static final Logger logger = LoggerFactory.getLogger(DataMapperNode.class);
	
	@Override
	protected void doInitialize (DataObject arg0) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
	}
	
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		ExecutionContext exeContext = null;
		ExecutionJobData jobData = null;
		ModelDef iDef = null;
		ModelRootBand iRootBand = null;
		RootBand rootBand = null;
		NodeProcessingException npEx = null;
		InterfaceDataMapper dataMapper = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			iDef = jobData.getInterfaceDef().getMosdelDef();
			rootBand = (RootBand) exeContext.get(IrisAdminConstants.PROCESS_DATA);
			dataMapper = new InterfaceDataMapper(iDef, rootBand, jobData);
			iRootBand = dataMapper.createModelBands();
			exeContext.put(IrisAdminConstants.INTERFACE_DATA, iRootBand);
			
		}
		catch (ExecutionException exp)
		{
			if (jobData != null)
				jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npEx = new NodeProcessingException("error.iris.admin.datamapping", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
		catch (NodeProcessingException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			throw exp;
		}
		catch (Exception exp)
		{
			if (jobData != null)
				jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npEx = new NodeProcessingException("error.iris.admin.datamapping", new Object[]
			{ "UnKnown Error" }, exp);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
		return packet;
	}
	
}
