/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : StatusUpdateNode.java
 * CREATED: Jun 29, 2013 11:04:31 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: StatusUpdateNode.java,v 1.30 2016/01/12 06:49:03 ramap Exp $
 * @since 1.0.0
 */
public class StatusUpdateNode extends AbstractNode
{
	private static Logger logger = LoggerFactory.getLogger(StatusUpdateNode.class);
	private static final String updateSql ="UPDATE IRIS_JOB_QUEUE T SET T.STATUS = ?, T.SYS_END_DATE = SYSDATE , END_DATE = pk_timezone.get_seller_time(?) , ERROR_CODE= ? ,"
			+ " ERROR_MSG=? , MEDIA_DTLS= ? WHERE T.EXECUTION_ID = ?";
	
	@Override
	protected void doInitialize (DataObject arg0) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		ExecutionContext exeContext = null;
		Connection dbConnection = null;
		ExecutionJobData jobData = null;
		CallableStatement cStmt = null;
		NodeProcessingException npEx = null;
		String jobStatus = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npEx = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]
				{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			
			jobStatus = jobData.getStatus();
			updateJobStatus(dbConnection, jobData);
			
			/*
			 * E and S are ERROR and Sucess. S status comes after completion of Interface procedure call E Status comes if any error before interface
			 * procedure call
			 */
			
			if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus) || IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE.equals(jobStatus)
					|| IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
				finishJob(dbConnection, jobData);
			
		}
		catch (ExecutionException exp)
		{
			npEx = new NodeProcessingException("error.iris.admin.statusupdate", new Object[] {}, exp);
			throw npEx;
		}
		catch (NodeProcessingException exp)
		{
			throw exp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
		return packet;
		
	}
	
	private void updateJobStatus (Connection dbConnection, ExecutionJobData jobData) throws ExecutionException
	{
		PreparedStatement updateSt = null;
		int status = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String jobStatus = null;
		String errorCode = "Sucess";
		String errorMsg = "Sucess";
		List<String> fileList = null;
		try
		{
			if (jobData.getErrors().size() > 0 || "E".equals(jobData.getStatus()) || "R".equals(jobData.getStatus()))
			{
				errorCode = "Error";
				errorMsg = " Error: Please check the report";
			}
			fileList = jobData.getSplitFileList();
			executionId = jobData.getExecutionId();
			jobStatus = jobData.getStatus();
			
			
			updateSt = dbConnection.prepareStatement(updateSql);
			updateSt.clearParameters();
			updateSt.setString(1, jobStatus);
			updateSt.setString(2, jobData.getSellerCode());
			updateSt.setString(3, errorCode);
			
			if (fileList.size() > 0)
				updateSt.setString(4, "Please check Pre generated for files:" + fileList.size());
			else
				updateSt.setString(4, errorMsg);
			
			if (fileList.size() > 0)
				updateSt.setString(5, fileList.get(0));
			else
				updateSt.setString(5, jobData.getMediaDetails());
			
			updateSt.setString(6, executionId);
			status = updateSt.executeUpdate();
			
			if (status < 0)
				logger.warn("Job:" + executionId + " record not available for status update");
			else if (logger.isTraceEnabled())
				logger.debug("Job:" + executionId + " Record status updated");
			dbConnection.commit();
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.statusupdate", new Object[]
			{ "ExecutionId:" + executionId, "JobStatus:" + jobStatus, updateSql }, exp);
			IRISLogger.getText(eExp);
			throw eExp;
		}
		catch (Exception exp)
		{
			eExp = new ExecutionException("error.iris.admin.statusupdate", new Object[]
			{ "ExecutionId:" + executionId, "JobStatus:" + jobStatus, updateSql }, exp);
			IRISLogger.getText(eExp);
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(updateSt);
		}
		
	}
	
	public void finishJob (Connection dbConnection, ExecutionJobData jobData) throws ExecutionException
	{
		CallableStatement cStmt = null;
		String sql = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String errorCode = "Sucess";
		String errorMsg = "Sucess";
		String refId = null;
		
		try
		{
			moveFiles(jobData);
			
			if (jobData.getErrors().size() > 0 || "E".equals(jobData.getStatus()) || "R".equals(jobData.getStatus()))
			{
				errorCode = "Error";
				errorMsg = " Error: Please check the report";
			}
			
			startTime = System.currentTimeMillis();
			sql = "{CALL pkg_iris_admin.finish_iris_job (?, ?, ?, ?,?)}";
			cStmt = dbConnection.prepareCall(sql);
			executionId = jobData.getExecutionId();
			cStmt.setString(1, executionId);
			if (! IrisAdminConstants.SCH_SEGMENTED.equals(jobData.getSrcSubType()) && ! IrisAdminConstants.SCH_PROFILE.equals(jobData.getSrcSubType()))
				refId = jobData.getRefId();
			
			cStmt.setString(2, refId);
			cStmt.setString(3, jobData.getStatus());
			cStmt.setString(4, errorCode);
			cStmt.setString(5, errorMsg);
			
			cStmt.executeUpdate();
			dbConnection.commit();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing pkg_iris_admin.finish_iris_job " + " StoredProcedure: " + delta);
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.finishjobproc", new Object[]
			{ executionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
	}
	
	/**
	 * TODO
	 * 
	 * @param jobData
	 */
	private void moveFiles (ExecutionJobData jobData)
	{
		String interfaceType = null;
		String destPath = null;
		String jobStatus = null;
		String srcFileName = null;
		List<String> spList = null;
		String finalFilePath = null;
		List<String> finalList = null;
		
		try
		{
			
			jobStatus = jobData.getStatus();
			interfaceType = jobData.getMapType();
			
			if (IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(interfaceType))
			{
				if (IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE.equals(jobStatus))
					destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_DESTINATION_DIRECTORY);
				else if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus))
					destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
				else if (IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
					destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
				
			}
			else
			{
				if (IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE.equals(jobStatus))
					destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_DESTINATION_DIRECTORY);
				else if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus))
					destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
				else if (IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
					destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
				else if (IrisAdminConstants.JOB_STATUS_SUCESS.equals(jobStatus))
					destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_DESTINATION_DIRECTORY);
			}
			if (destPath == null)
				return;
			
			if (IrisAdminConstants.DEFINITION_TYPE_DOWNLOAD.equals(interfaceType))
			{
				finalList = new ArrayList<String>();
				spList = jobData.getSplitFileList();
				for (String fileName : spList)
				{
					srcFileName = fileName;
					finalFilePath = move(srcFileName, destPath, jobData);
					finalList.add(finalFilePath);
				}
				jobData.setSplitFile(finalList);
				return;
			}
		}
		finally
		{
			CleanUpUtils.doClean(spList);
			spList = null;
		}
	}
	
	private String move (String sourceFileName, String destFolder, ExecutionJobData jobData)
	{
		File sourceFile = null;
		File destFile = null;
		File finalDest = null;
		
		try
		{
			sourceFile = new File(sourceFileName);
			destFolder = jobData.getFtpPath() + File.separator + destFolder;
			destFile = new File(destFolder);
			
			if (!sourceFile.exists() && sourceFile.isDirectory())
				return null;
			if (!destFile.exists())
			{
				if (destFile.mkdirs())
				{
				}
				else
				{
					logger.error("Couldn't make folder creation:" + destFile.getAbsolutePath());
					return sourceFile.getAbsolutePath();
				}
			}
			
			finalDest = new File(destFile.getAbsolutePath(), sourceFile.getName());
			if (!sourceFile.getParent().equals(destFile.getAbsolutePath()))
			{
				sourceFile.renameTo(finalDest);
				logger.debug("File Moved from :{}   to:{}", sourceFile.getAbsolutePath(), finalDest.getAbsolutePath());
			}
			return finalDest.getAbsolutePath();
		}
		catch (Exception e)
		{
			logger.error("Error:",e);
			logger.error("Couldn't move file from:" + sourceFileName + " to:" + destFolder);
		}
		finally
		{
			sourceFile = null;
			destFile = null;
		}
		
		return sourceFileName;
	}
}
