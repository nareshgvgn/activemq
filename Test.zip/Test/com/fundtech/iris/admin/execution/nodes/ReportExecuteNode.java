/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : ReportExecuteNode.java
 * CREATED: Jun 12, 2014 12:01:55 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Property;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.execution.IReportExecutor;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: ReportExecuteNode.java,v 1.5 2016/02/18 07:36:59 ramap Exp $
 */
public class ReportExecuteNode extends AbstractNode
{
	
	private static Logger logger = LoggerFactory.getLogger(ReportExecuteNode.class);
	private Map<String, String> staticProperties = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doInitialize(com.cashtech.iris.patterns.sdo.DataObject)
	 */
	@Override
	protected void doInitialize (DataObject config) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		Type cfgType = null;
		DataObject argDO = null;
		Type argType = null;
		List<Property> argList = null;
		
		try
		{
			cfgType = config.getType();
			
			if (cfgType.containsProperty("StaticParameters"))
			{
				staticProperties = new HashMap<String, String>();
				argDO = (DataObject) config.getValue("StaticParameters");
				argType = argDO.getType();
				argList = argType.getProperties();
				for (Property prop : argList)
				{
					staticProperties.put(prop.getName(), (String) argDO.getValue(prop.getName()));
				}
			}
		}
		finally
		{
			if (argList != null)
				argList.clear();
			
			argList = null;
			argDO = null;
			argType = null;
		}
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		ExecutionContext exeContext = null;
		RMJobData jobData = null;
		Connection dbConnection = null;
		NodeProcessingException npExp = null;
		IReportExecutor reportExecutor = null;
		String executoreClass = null;
		Class<?> clazz = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		Map<String, Object> hooksParms = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (RMJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npExp = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]
				{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npExp));
				throw npExp;
			}
			
			startTime = System.currentTimeMillis();
			executoreClass = jobData.getExecutionClass();
			clazz = Class.forName(executoreClass);
			reportExecutor = (IReportExecutor) clazz.newInstance();
			hooksParms = new HashMap<String, Object>();
			hooksParms.put(IReportExecutor.EXECUTION_DATA, jobData);
			hooksParms.put(IReportExecutor.EXECUTION_STATIC_PROPS, staticProperties);
			reportExecutor.execute(dbConnection, hooksParms);
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS);
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing '" + executoreClass + "':  " + delta);
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (ClassNotFoundException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ executoreClass }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (InstantiationException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ executoreClass }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (IllegalAccessException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ executoreClass }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		finally
		{
			CleanUpUtils.doClean(hooksParms);
		}
		return packet;
	}
}
