/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : ErrorInfoNode.java
 * CREATED: Jul 2, 2013 11:13:40 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ErrorInfoNode.java,v 1.5 2014/07/20 04:58:23 ramap Exp $
 * @since 1.0.0
 */
public class ErrorInfoNode extends AbstractNode
{
	private static Logger logger = LoggerFactory.getLogger(ErrorInfoNode.class);
	
	@Override
	protected void doInitialize (DataObject arg0) throws InappropriatePathTypeException, InvalidPropertyAccessException, ConfigurationException
	{
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		ExecutionContext exeContext = null;
		ExecutionJobData jobData = null;
		
		exeContext = packet.getContext().getExecutionContext();
		jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
		
		logger.error(jobData.toString());
		logger.error(jobData.getInterfaceMap().toString());
		return packet;
	}
	
}
