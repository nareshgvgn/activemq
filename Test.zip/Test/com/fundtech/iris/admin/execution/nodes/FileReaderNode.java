package com.fundtech.iris.admin.execution.nodes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.IReader;
import com.fundtech.iris.admin.interfaces.InterfaceDef;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: FileReaderNode.java,v 1.8 2014/07/20 04:58:23 ramap Exp $
 * @since 1.0.0
 */
public class FileReaderNode extends AbstractNode
{
	private static Logger logger = LoggerFactory.getLogger(FileReaderNode.class);
	
	@Override
	protected void doInitialize (DataObject configuration) throws InappropriatePathTypeException, InvalidPropertyAccessException,
			ConfigurationException
	{
		
	}
	
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		RootBand rootBand = null;
		ExecutionContext exeContext = null;
		NodeProcessingException npExp = null;
		ExecutionJobData jobData = null;
		InterfaceDef interfaceDef = null;
		ZeroProofings zeroProofings = null;
		String readerClass = "com.fundtech.iris.admin.execution.FileReader";// TODO babu:This needs to change and needs to take at run time
		IReader dataReader = null;
		Class<?> clazz = null;
		
		try
		{
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			zeroProofings = (ZeroProofings) exeContext.get(IrisAdminConstants.ZEROPROOFING_DATA);
			interfaceDef = jobData.getInterfaceDef();
			readerClass = interfaceDef.getExecutionClass();
			clazz = Class.forName(readerClass);
			dataReader = (IReader) clazz.newInstance();
			dataReader.initialize(this.applicationContext, interfaceDef, jobData, zeroProofings);
			rootBand = dataReader.readData();
			
			exeContext.put(IrisAdminConstants.PROCESS_DATA, rootBand);
		}
		catch (FormatException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (ClassNotFoundException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ readerClass }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (InstantiationException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ readerClass }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (IllegalAccessException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[]
			{ readerClass }, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			npExp = new NodeProcessingException("error.iris.admin.format", new Object[] {}, exp);
			logger.error(IRISLogger.getText(npExp));
			throw npExp;
		}
		
		return packet;
	}
	
}
