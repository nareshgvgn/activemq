/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution.nodes
 * FILE   : ExecutionInterfaceProcNode.java
 * CREATED: Jun 25, 2013 3:02:29 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution.nodes;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.nodes.AbstractNode;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.exceptions.ConfigurationException;
import com.cashtech.iris.exceptions.InappropriatePathTypeException;
import com.cashtech.iris.exceptions.InvalidPropertyAccessException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.exceptions.PatternMatchingException;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Type;
import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISErrors;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.model.ModelDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ExecutionInterfaceProcNode.java,v 1.22 2016/12/08 11:25:41 ramap Exp $
 * @since 1.0.0
 */
public class ExecutionInterfaceProcNode extends AbstractNode
{
	
	private static final Logger logger = LoggerFactory.getLogger(ExecutionInterfaceProcNode.class);
	private String operationType = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doInitialize(com.cashtech.iris.patterns.sdo.DataObject)
	 */
	@Override
	protected void doInitialize (DataObject configuration) throws InappropriatePathTypeException, InvalidPropertyAccessException,
			ConfigurationException
	{
		
		Type cfgType = null;
		ConfigurationException conExp = null;
		
		try
		{
			cfgType = configuration.getType();
			if (cfgType.containsProperty("OperationType"))
				operationType = (String) configuration.getValue("OperationType");
			
			if (!(IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(operationType) || IrisAdminConstants.DEFINITION_TYPE_DOWNLOAD
					.equals(operationType)))
			{
				conExp = new ConfigurationException("error.iris.admin.opetaionType", new Object[]
				{ "OpetaionType not configured properly" }, null);
				throw conExp;
			}
		}
		catch (ConfigurationException exp)
		{
			logger.error(IRISLogger.getText(exp));
			throw exp;
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.core.processor.nodes.AbstractNode#doProcess(com.cashtech.iris.core.processor.Packet)
	 */
	@Override
	protected Packet doProcess (Packet packet) throws InappropriatePathTypeException, InvalidPropertyAccessException, NodeProcessingException,
			PatternMatchingException
	{
		ExecutionContext exeContext = null;
		ExecutionJobData jobData = null;
		ModelDef iDef = null;
		String routinueName = null;
		String procStr = null;
		Connection dbConnection = null;
		CallableStatement cStmt = null;
		NodeProcessingException npEx = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		IrisAdminError error = null;
		IrisError irisError = null;
		String errorMsg = null;
		String procRetVal = null;
		String procRetMsg = null;
		String modelSubType = null;
		
		try
		{
			startTime = System.currentTimeMillis();
			exeContext = packet.getContext().getExecutionContext();
			jobData = (ExecutionJobData) exeContext.get(IrisAdminConstants.EXECUTION_DATA);
			iDef = jobData.getInterfaceDef().getMosdelDef();
			
			dbConnection = (Connection) exeContext.getResource(ResourceTypeEnum.DB_CONN, dbConnectionRef);
			
			if (null == dbConnection)
			{
				logger.error(IRISErrors.NO_DB_CONNECTION + "|" + IRISErrors.NO_DB_CONNECTION_DESC);
				npEx = IRISLogger.getNodeProcEx("error.app.resourceNotFound", new Object[]
				{ this.name, dbConnectionRef });
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			// Its upload
			if (operationType.equals(jobData.getMapType()) && IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(operationType))
			{
				routinueName = iDef.getUploadRoutine();
				procStr = "{CALL " + routinueName + "(?, ?, ?)}";
				
				cStmt = dbConnection.prepareCall(procStr);
				cStmt.setString(1, jobData.getExecutionId());
				cStmt.registerOutParameter(2, Types.VARCHAR);
				cStmt.registerOutParameter(3, Types.VARCHAR);
				cStmt.executeUpdate();
				
				procRetVal = cStmt.getString(2);
				procRetMsg = cStmt.getString(3);
				if (procRetVal == null && procRetMsg == null)
				{
					dbConnection.commit();
					jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS);
				}
			}
			else
			{
				routinueName = "pkg_iris_admin.populate_download_data";
				if (logger.isDebugEnabled())
					logger.debug(routinueName + " exedcuting");
				procStr = "{CALL " + routinueName + "(?, ?,?, ?)}";
				cStmt = dbConnection.prepareCall(procStr);
				cStmt.setString(1, jobData.getExecutionId());
				cStmt.setString(2, jobData.getWhereCondition());
				cStmt.registerOutParameter(3, Types.VARCHAR);
				cStmt.registerOutParameter(4, Types.VARCHAR);
				cStmt.executeUpdate();
				procRetVal = cStmt.getString(3);
				procRetMsg = cStmt.getString(4);
				modelSubType = iDef.getModelSubType();
				if ( null != modelSubType && "REQUEST".equals(modelSubType))
					dbConnection.commit();
			}
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing " + routinueName + "' StoredProcedure: " + delta);
			if (procRetVal != null || procRetMsg != null)
			{
				logger.error("Procedure {} has Error:{}  {} ", routinueName, procRetVal, procRetMsg);
				npEx = new NodeProcessingException("iris.admin.error.procCall", new Object[]{ procRetMsg, procRetVal, routinueName }, null);
				logger.error(IRISLogger.getText(npEx));
				throw npEx;
			}
			
		}
		catch (SQLException exp)
		{
			setStatus(jobData);
			errorMsg = " SQL error while executing:" + routinueName;
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, exp.getMessage(), null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			npEx = new NodeProcessingException("error.iris.admin.routinecall", new Object[]	{ errorMsg }, exp);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
		catch (NodeProcessingException exp)
		{
			setStatus(jobData);
			if ( IrisAdminConstants.DEFINITION_TYPE_DOWNLOAD.equals(operationType))// do not capture upload error coz procedure is putting this
			{
				errorMsg = " Error while executing:" + routinueName;
				error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, exp.getMessage(), null);
				irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
				jobData.addIrisError(irisError);
				jobData.addError(error);
			}
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = " Error while executing:" + routinueName;
			npEx = new NodeProcessingException("error.iris.admin.routinecall", new Object[]
			{ errorMsg }, exp);
			logger.error(IRISLogger.getText(npEx));
			setStatus(jobData);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, exp.getMessage(), null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			throw npEx;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
		
		return packet;
	}
	
	/*-------------------------------------------------------------------------------------------------*
	 * HELPER METHODS
	 *------------------------------------------------------------------------------------------------*/
	/**
	 * This helper method
	 * 
	 * @param jobData
	 */
	private void setStatus (ExecutionJobData jobData)
	{
		if (operationType.equals(jobData.getMapType()) && IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(operationType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
		else
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
	}
}
