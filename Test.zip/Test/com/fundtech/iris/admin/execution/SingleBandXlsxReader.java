/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : SingleBandXlsxReader.java
 * CREATED: Jun 1, 2016 12:10:02 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.util.SAXHelper;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFReader.SheetIterator;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: SingleBandXlsxReader.java,v 1.8 2016/09/12 07:20:16 ramap Exp $
 */
public class SingleBandXlsxReader extends AbstractDataReader
{
	private int startRow = 0;
	private int endRow = -1;
	private int startCell = 0;
	private int endCell = -1;
	private boolean isContainError = false;
	private String DELIMITER = ",";
	private String QUALIFIER = "\"";
	
	private Logger logger = LoggerFactory.getLogger(SingleBandXlsxReader.class);
	
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.AbstractDataReader#formatData()
	 */
	@Override
	public RootBand formatData () throws FormatException
	{
		String orgSheetName = null;
		ReadOnlySharedStringsTable strings = null;
		XSSFReader xssfReader = null;
		StylesTable styles = null;
		XSSFReader.SheetIterator iter = null;
		InputStream stream = null;
		OPCPackage xlsxPackage = null;
		SheetToCSV xlsToCSV = null;
		String xlsxFile = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		Deque<InterfaceBandDef> defStack = null;
		Deque<Band> dataStack = null;
		IFormatter iFormatter = null;
		String formatterClass = null;
		Class<?> clazz = null;
		RootBand rootBand = null;
		Band batchBand = null;
		
		try
		{
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "Before loading file Data");
			xlsxFile =  jobData.getMediaDetails();
			bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			batchBand = new Band();
			defStack = new ArrayDeque<InterfaceBandDef>();
			dataStack = new ArrayDeque<Band>();
			dataStack.addFirst(batchBand);
			formatterClass = interfaceDef.getFormatterClass();
			clazz = Class.forName(formatterClass);
			iFormatter = (IFormatter) clazz.newInstance();
			iFormatter.initialize(appContext, interfaceDef, jobData, zeroProofings);
			rootBand = new RootBand();
			xlsxPackage = OPCPackage.open(xlsxFile, PackageAccess.READ);
			strings = new ReadOnlySharedStringsTable(xlsxPackage);
			xssfReader = new XSSFReader(xlsxPackage);
			styles = xssfReader.getStylesTable();
			iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
			
			for (InterfaceBandDef bandDef : bandDefs.values())
			{
				orgSheetName = bandDef.getRelativeXPath();
				setRowCoordinates(bandDef.getAbsoluteXPath2());
				setCellCoordinates(bandDef.getAbsoluteXPath1());
				logger.debug("SheetName:{} and start cell {} and start row {}", orgSheetName, startCell, startRow);
				bandDef.setDelimiter(DELIMITER);
				bandDef.setQualifier(QUALIFIER);
//				bandDef.setQualifier("\"" + "\"");
				defStack.addFirst(bandDef);
				stream = getXlsxStream(iter, orgSheetName);
				logger.trace("Conversion {}",  orgSheetName);
				xlsToCSV = new SheetToCSV(defStack, dataStack, iFormatter);
				processSheet(styles, strings, xlsToCSV, stream);
			}
			getLastbatchBand(dataStack, rootBand);
			validateRootBands(rootBand);
		}
		catch ( FormatException exp)
		{
			throw exp;
		}
		catch (InvalidFormatException exp)
		{
			errorMsg = "File:" + xlsxFile + " InvalidFormat";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (IOException exp)
		{
			errorMsg = "File:" + xlsxFile + " not able to read";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (SAXException exp)
		{
			errorMsg = "File:" + xlsxFile + " not correct file";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (OpenXML4JException exp)
		{
			errorMsg = "File:" + xlsxFile + " not valid file";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (ParserConfigurationException exp)
		{
			errorMsg = "File:" + xlsxFile + " not valid File";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (ClassNotFoundException exp)
		{
			errorMsg = "File:" + xlsxFile + " InvalidFormat";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (InstantiationException exp)
		{
			errorMsg = "File:" + xlsxFile + " InvalidFormat";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (IllegalAccessException exp)
		{
			errorMsg = "File:" + xlsxFile + " InvalidFormat";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			iFormatter.cleanup();
			CleanUpUtils.doClose(stream);
			CleanUpUtils.doClose(xlsxPackage);
		}
		return rootBand;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param absoluteXPath2
	 * </pre></p>
	 */
	private void setCellCoordinates (String absoluteXPath2)
	{
		String coordinates [] =  null;
		coordinates = absoluteXPath2.split(",");
		if ( coordinates.length == 2)
		{
			startCell = Integer.parseInt(coordinates[0]) -1  ;
			endCell =  Integer.parseInt(coordinates[1]) -1 ;
		}
		else if ( coordinates.length == 1)
		{
			startCell = Integer.parseInt(coordinates[0]) -1 ;
			endCell = -1;
		}
		else 
		{
			startCell = 0;
			endCell = -1;
		}
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param absoluteXPath1
	 * </pre></p>
	 */
	private void setRowCoordinates (String absoluteXPath1)
	{
		String coordinates [] =  null;
		coordinates = absoluteXPath1.split(",");
		if ( coordinates.length == 2)
		{
			startRow = Integer.parseInt(coordinates[0]) -1;
			endRow =  Integer.parseInt(coordinates[1]) -1 ;
		}
		else if ( coordinates.length == 1)
		{
			startRow = Integer.parseInt(coordinates[0]) - 1;
			endRow = -1;
		}
		else 
		{
			startRow = 0;
			endRow = -1;
		}
		
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param iter
	 * @param orgSheetName
	 * @return
	 * </pre></p>
	 */
	private InputStream getXlsxStream (SheetIterator iter, String orgSheetName) throws FormatException
	{
		InputStream stream = null;
		String sheetName = null;
		boolean isSheet = false;
		FormatException fExp =  null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		while (iter.hasNext())
		{
			stream = iter.next();
			sheetName = iter.getSheetName();
			if ( ! orgSheetName.equals(sheetName))
			{
				CleanUpUtils.doClose(stream);
				continue;
			}
			else
				isSheet = true;
			
			break;
		}
		
		if ( ! isSheet)
		{
			errorMsg = "Sheet " + orgSheetName + " not found, ";
			fExp = new FormatException("iris.admin.xlsx.notfound", new Object[]	{ errorMsg }, null);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		
		return stream;
	}

	/**
	 * <p>Parses and shows the content of one sheet using the specified styles and shared-strings tables.
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param styles
	 * @param strings
	 * @param sheetHandler
	 * @param sheetInputStream
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws FormatException
	 * </pre></p>
	 */
	private void processSheet (StylesTable styles, ReadOnlySharedStringsTable strings, SheetContentsHandler sheetHandler, InputStream sheetInputStream)
			throws IOException, ParserConfigurationException, SAXException, FormatException
	{
		DataFormatter formatter = null;
		InputSource sheetSource = null;
		XMLReader sheetParser = null;
		ContentHandler handler = null;
		FormatException fExp = null;
		
		try
		{
			formatter = new DataFormatter();
			sheetSource = new InputSource(sheetInputStream);
			sheetParser = SAXHelper.newXMLReader();
			handler = new XSSFSheetXMLHandler(styles, null, strings, sheetHandler, formatter, false);
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
			if ( isContainError)
			{
				fExp = new FormatException("", new Object[] {}, null);
				throw fExp;
			}
		}
		finally
		{
		}
	}
	

	/**
     * Uses the XSSF Event SAX helpers to do most of the work
     *  of parsing the Sheet XML, and outputs the contents
     *  as a (basic) CSV.
     */
    private class SheetToCSV implements SheetContentsHandler
    {
        private boolean firstCellOfRow = false;
        private int currentRow = 0;
        private int currentCol = 0;
        private StringBuilder output = null;
        private Deque<InterfaceBandDef> defStack = null;
		private Deque<Band> dataStack = null;
		private RootBand rootBand = new RootBand();
		private IFormatter iFormatter = null;

		public SheetToCSV(Deque<InterfaceBandDef> defStack, Deque<Band> dataStack, IFormatter iFormatter)
		{
			this.defStack = defStack;
			this.dataStack = dataStack;
			this.iFormatter = iFormatter;
		}
        public void startRow(int rowNum) 
        {
            firstCellOfRow = true;
            currentRow = rowNum;
            currentCol = 0;
            output = new StringBuilder();
        }

        public void endRow(int rowNum) 
        {
        	try
        	{
        		if (! StringUtils.isEmpty(output))
        		{
        			logger.debug("Processing Reccord:{}", output.toString());
        			iFormatter.uploadFormat(rowNum, output.toString(), defStack, dataStack);
        		}
        	}
        	catch (FormatException exp)
        	{
        		isContainError = true;
        	}
        	catch ( Exception exp)
        	{
        		isContainError = true;
        	}
        	finally
        	{
        		CleanUpUtils.doClean(output);
        	}
        }

        public void cell(String cellReference, String formattedValue, XSSFComment comment) 
        {
        	CellReference refCell = null;
         // gracefully handle missing CellRef here in a similar way as XSSFCell does
    		if (cellReference == null)
    		{
    			cellReference = new CellAddress(currentRow, currentCol).formatAsString();
    		}
    		
            refCell = new CellReference(cellReference);
            // Did we miss any cells?
            int thisCol = refCell.getCol();
            if ( thisCol >= startCell && startRow <= refCell.getRow())
    		{
            	
            	if (firstCellOfRow) 
            		firstCellOfRow = false;
            	else 
            		output.append(DELIMITER);
            	
            	int missedCols = thisCol - currentCol - 1;
            	
            	for (int i=0; i< missedCols; i++) 
            	{
            		output.append(DELIMITER);
            	}
            	
            	if ( ! StringUtils.isEmpty(formattedValue))
            	{
            		if (StringUtils.contains(formattedValue, DELIMITER))
            		{
            			output.append(QUALIFIER);
            			output.append(formattedValue);
            			output.append(QUALIFIER);
            		}
            		else
            			output.append(formattedValue);
            	}
    		}
            currentCol = thisCol;
        }
        
        public void headerFooter(String text, boolean isHeader, String tagName) 
        {
        }
    }
    
    private void validateRootBands (RootBand rootBand) throws FormatException
	{
		Map<String, InterfaceBandDef> bandDefs = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		FormatException fExp = null;
		
		bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
		for (InterfaceBandDef parentBandDef : bandDefs.values())
		{
			if (parentBandDef.isMandatory())
			{
				for (Band dataBand : rootBand.getBatchBands())
				{
					if (dataBand.getChildBands(parentBandDef.getBandName()) == null)
					{
						errorMsg = "Mandatory Band:" + parentBandDef.getBandName() + " ID:" + parentBandDef.getBandId() + " is not present.";
						fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, parentBandDef.toString() }, null);
						error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, parentBandDef.toString(), null);
						irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						logger.error(IRISLogger.getText(fExp));
						throw fExp;
					}
				}
			}
		}
	}
	
	/**
	 * This helper method adds last band to its parent
	 * @param dataStack
	 * @param rootBand
	 */
	private void getLastbatchBand (Deque<Band> dataStack, RootBand rootBand)
	{
		Band batchBand = null;
		boolean isRoot = true;
		while (isRoot)
		{
			batchBand = dataStack.removeFirst();
			if (dataStack.isEmpty())
				isRoot = false;
		}
		if (batchBand.getParentBand() == null)
			rootBand.addBatchBands(batchBand);
	}
}
