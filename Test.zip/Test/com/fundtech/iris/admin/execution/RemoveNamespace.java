/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : RemoveNamespace.java
 * CREATED: Dec 29, 2013 1:46:08 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.VisitorSupport;
import org.dom4j.tree.DefaultElement;

/**
 * <p>
 * This finall class removes the namesapces attached to document, attributes & elements
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">This class extends VisitorSupport}</td>
 * </tr>
 * 
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: RemoveNamespace.java,v 1.2 2014/07/20 04:58:21 ramap Exp $
 */
public final class RemoveNamespace extends VisitorSupport
{
	public void visit (Document document)
	{
		DefaultElement element = null;
		
		element = (DefaultElement) document.getRootElement();
		element.setNamespace(Namespace.NO_NAMESPACE);
		element.additionalNamespaces().clear();
	}
	
	public void visit (Namespace namespace)
	{
		namespace.detach();
	}
	
	public void visit (Attribute node)
	{
		if (node.toString().contains("xmlns") || node.toString().contains("xsi:"))
			node.detach();
	}
	
	public void visit (Element node)
	{
		if (node instanceof DefaultElement)
			((DefaultElement) node).setNamespace(Namespace.NO_NAMESPACE);
	}
}