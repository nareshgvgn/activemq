/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : MultiLevelXMLWriter.java
 * CREATED: Nov 14, 2013 9:03:03 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.dom4j.tree.DefaultElement;
import org.jaxen.SimpleNamespaceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.NameSpaceElements;
import com.fundtech.iris.admin.channel.IRequestReceiver;
import com.fundtech.iris.admin.channel.sftp.SFTPFilesSender;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.hooks.IProcessHook;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * 
 * <p>
 * This class creates the XML file. This class should be used only when band contains nested elements
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into Datastore_Mst (DATASTORE_TYPE, INTERFACE_TYPE, DATASTORE_NAME, DESCRIPTION, DATASTORE_VALUE, EXECUTION_CLASS, FORMATTER_CLASS, RECORD_KEY_NMBR, AUDIT_NMBR, VALID_FLAG, OPERATION_FLAG, CHECKER_ACTION, PREV_AUDIT_NMBR)
 * values ('F', 'D', 'X', 'XML File Format', '', 'com.fundtech.iris.admin.execution.MultiLevelXMLWriter', 'com.fundtech.iris.admin.execution.formatter.DelimiterDownloadFormatter', '', '', 'Y', '', '', '');
 * </pre>
 * 
 * </p>
 * <p>
 * 
 * @author Babu Paluri
 * @version $Id: MultiLevelXMLWriter.java,v 1.41 2017/02/27 13:21:08 ramap Exp $
 */
public class MultiLevelXMLWriter extends AbstractDataWriter
{
	
	private static Logger logger = LoggerFactory.getLogger(MultiLevelXMLWriter.class);
	private boolean isGenerated = false;
	private IProcessHook fileGenHook = null;
	private Map<String, Object> hookData = new HashMap<String, Object>();
	private Connection hookDBConnection = null;
	private String currentFileName = null;
	private boolean isFirst = true;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IWriter#writeData()
	 */
	public Object writeData () throws ExecutionException
	{
		Map<String, InterfaceBandDef> pBandDefs = null;
		OutputStreamWriter writer = null;
		OutputStream outStream = null;
		ExecutionException eExp = null;
		String fileNameClass = null;
		String fileName = null;
		String filePath = null;
		File outFile = null;
		String emptyFile = null;
		String errorMsg = null;
		IrisError irisError = null;
		
		try
		{
			pBandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			
			hookDBConnection = getDBConnection();
			hookData.put(IProcessHook.EXECUTION_DATA, jobData);
			hookData.put(IProcessHook.DATA_ROOT_BAND, rootBand);
			hookData.put(IProcessHook.FILE_GEN_FILTER_PARMS, getFileGenFilterParms());
			hookData.put(IProcessHook.FILE_GEN_INT_FIELDS, getFileGenInternalParms());
			emptyFile = jobData.getFilterParameter(IrisAdminConstants.FILTER_EMPTY_FILE);
			if (rootBand.getBatches().isEmpty())
			{
				
				if (IrisAdminConstants.CONSTANT_Y.equals(emptyFile))
				{
					if (IrisAdminConstants.EMPTYFILENAMEGEN_FLAG_YES == interfaceDef.isEmptyFileRequired())
						fileNameClass = interfaceDef.getEmptyFileNameClass();
					else
						fileNameClass = jobData.getParm(IrisAdminConstants.CUST_GEN_EMPTY_FILE);
					
					fileGenHook = getFileNameGenerator(fileNameClass);
					fileName = (String) fileGenHook.execute(hookDBConnection, hookData);
					filePath = jobData.getMediaDetails();
					outFile = new File(filePath, fileName);
					jobData.setMediaDetails(outFile.getAbsolutePath());
					outStream = new FileOutputStream(outFile);
					writer = new OutputStreamWriter(outStream, jobData.getCharSet());
					if (logger.isDebugEnabled())
						logger.error("Empty file generated:" + outFile.getAbsolutePath());
					jobData.setErrorCode("EMPTYGEN");
				}
				else
				{
					jobData.setNoData(true);
					logger.warn("No Data Present!!!");
					jobData.setErrorCode("EMPTYNOGEN");
				}
				
				return null;
			}
			if (IrisAdminConstants.FILENAMEGEN_FLAG_YES == interfaceDef.isGenFileNameRequired())
				fileNameClass = interfaceDef.getFileNameClass();
			else
				fileNameClass = jobData.getParm(IrisAdminConstants.CUST_GEN_DATA_FILE);
			
			if (interfaceDef.isSplitRequired())
				hookData.put(IProcessHook.SPLIT_FILE_PARMS, getSplitParms());
			;
			
			fileGenHook = getFileNameGenerator(fileNameClass);
			convertToOutput(pBandDefs);
		}
		catch ( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (SystemException exp)
		{
			jobData.setStatus("E");
			logger.error("Error While getting database connection");
			eExp = new ExecutionException("err.irisadmin.dbConnection", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("err.irisadmin.unknownError", new Object[] {errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		finally
		{
			fileGenHook = null;
			cleanup();
			CleanUpUtils.doClean(hookData);
			HelperUtils.doClose(writer);
			HelperUtils.doClose(outStream);
		}
		return null;
	}
	
	/**
	 * <p>
	 * This helper method creates a file from Process Data Bands
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param pBandDefs
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	private void convertToOutput (Map<String, InterfaceBandDef> pBandDefs) throws ExecutionException
	{
		ExecutionException eExp = null;
		Document document = null;
		String mediumType = null;
		String ftpProperty = null;
		ContextManager contextManager = null;
		SFTPFilesSender sftpSender = null;
		String errorMsg = null;
		IrisError irisError = null;
		
		try
		{
			mediumType = interfaceDef.getMediumType();
			for (BatchBand batchBand : rootBand.getBatches())
			{
				hookData.put(IProcessHook.EXECUTION_BATCH, batchBand);
				document = createDocument(document);
				batchBand.doWriteXMLDoc(IrisAdminConstants.XML_MULTI_LEVEL, document, pBandDefs, isFirst, -1);
				isFirst = false;// IMP If each batch needs to create a separate document. we must make this as true again
			}
			
			if (!rootBand.getBatches().isEmpty())
				writetToStream(document);
			
			if ( IrisAdminConstants.MEDIA_FTP.equals(mediumType))
			{
				ftpProperty = jobData.getFilterParameter(IrisAdminConstants.FTP_RESOURCE_NAME);
				if (ftpProperty.isEmpty() && "CLIENT".equals(jobData.getEntityType()))
				{
					//Client 
				}
				else
				{
					contextManager = ContextManager.getInstance();
					sftpSender = (SFTPFilesSender) contextManager.getBeanObject(ftpProperty);
					sftpSender.sendFiles(jobData.getSplitFileList());
				}
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch ( BeanConfigException exp)
		{
			errorMsg = "Error While accessing Bean Object" + ftpProperty;
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]	{errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("err.irisadmin.unknownError", new Object[] {errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
	}
	
	/**
	 * <p>
	 * This helper method creates a document based on split parameters
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param document
	 * @return
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	private Document createDocument (Document document) throws ExecutionException
	{
		ExecutionException eExp = null;
		String tempFileName = null;
		String errorMsg = null;
		IrisError irisError = null;
		String mediumType = null;
		
		try
		{
			mediumType = interfaceDef.getMediumType();
			if (interfaceDef.isSplitRequired())
			{
				if (IrisAdminConstants.MEDIA_FILE.equals(mediumType))
				{
					tempFileName = (String) fileGenHook.execute(hookDBConnection, hookData);
					if (!tempFileName.equals(currentFileName))
					{
						if (currentFileName != null)
						{
							isFirst = true;
							writetToStream(document);
						}
						
						currentFileName = tempFileName;
						document = DocumentFactory.getInstance().createDocument();
					}
				}
				else if (IrisAdminConstants.MEDIA_MQ.equals(mediumType) || IrisAdminConstants.MEDIA_WEBSERVICE.equals(mediumType) ||  
										IrisAdminConstants.MEDIA_HTTP_REQUEST.equals(mediumType))
				{
					isFirst = true;
					if (document != null)
					{
						writetToStream(document);
						document = null;
					}
					document = DocumentFactory.getInstance().createDocument();
				}
			}
			else if (!isGenerated)
			{
				currentFileName = (String) fileGenHook.execute(hookDBConnection, hookData);
				isGenerated = true;
				document = DocumentFactory.getInstance().createDocument();
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (FormatException exp)
		{
			errorMsg = "Error while executinng file generation hook:" + fileGenHook.toString();
			eExp = new ExecutionException("error.iris.admin.filegenHook", new Object[]	{ errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.unknown", new Object[]	{ errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		return document;
	}
	
	/**
	 * <p>
	 * This helper method creates the file
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param document
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	private void writetToStream (Document document) throws ExecutionException
	{
		OutputStream outStream = null;
		OutputFormat xmlForfmat = null;
		XMLWriter writer = null;
		OutputStreamWriter fileWriter = null;
		String filePath = null;
		File outFile = null;
		ExecutionException eExp = null;
		ContextManager contextManager = null;
		IRequestReceiver senderServiceSession = null;
		String senderServiceName = null;
		Element rootElement = null;
		String removeElements = "FALSE";
		String addNameSpace = "FALSE";
		Map<String, Object> inputParms = null;
		String errorMsg = null;
		IrisError irisError = null;
		String fullFile = null;
		String mediumType = null;
		String modelSubType = null;
		
		try
		{
			if (jobData.getFilterParameters().containsKey(IrisAdminConstants.REMOVE_EMPTY_ELEMENTS) )
					removeElements = jobData.getFilterParameter(IrisAdminConstants.REMOVE_EMPTY_ELEMENTS);
			
			if (jobData.getFilterParameters().containsKey(IrisAdminConstants.ADD_NAME_SPACE) )
				addNameSpace = jobData.getFilterParameter(IrisAdminConstants.ADD_NAME_SPACE);
			
			mediumType = interfaceDef.getMediumType();
			modelSubType = interfaceDef.getMosdelDef().getModelSubType();
			rootElement = document.getRootElement();
			setNameSpaces(rootElement);
			
			if ( IrisAdminConstants.CONSTANT_YES.equalsIgnoreCase(addNameSpace) || IrisAdminConstants.CONSTANT_TRUE.equalsIgnoreCase(addNameSpace))
					addNameSpace(rootElement);
			
			if ( IrisAdminConstants.CONSTANT_YES.equalsIgnoreCase(removeElements) || IrisAdminConstants.CONSTANT_TRUE.equalsIgnoreCase(removeElements))
					removeEmptyElements(rootElement);
			
			
			if (IrisAdminConstants.MEDIA_FILE.equals(mediumType) || IrisAdminConstants.MEDIA_FTP.equals(mediumType))
			{
				filePath = jobData.getMediaDetails();
				outFile = new File(filePath, currentFileName);
				fullFile = outFile.getAbsolutePath();
				if (jobData.isSplitFile())
					jobData.addSplitFile(outFile.getAbsolutePath());
				else
					jobData.addSplitFile(outFile.getAbsolutePath());
				
				outStream = new FileOutputStream(outFile);
				fileWriter = new OutputStreamWriter(outStream, jobData.getCharSet());
				xmlForfmat = OutputFormat.createPrettyPrint();
				xmlForfmat.setNewLineAfterDeclaration(false);
				xmlForfmat.setEncoding(jobData.getCharSet());
				xmlForfmat.setIndentSize(2);
				xmlForfmat.setNewlines(true);
				xmlForfmat.setTrimText(false);
				xmlForfmat.setExpandEmptyElements(true);
				writer = new XMLWriter(fileWriter, xmlForfmat);
				writer.write(document);
				writer.flush();
			}
			else if (IrisAdminConstants.MEDIA_MQ.equals(mediumType))
			{
				
				inputParms = new HashMap<String, Object>();
				contextManager = ContextManager.getInstance();
				senderServiceName = jobData.getFilterParameter(IrisAdminConstants.JMS_SESSION_NAME);
				if (senderServiceName == null )
				{
					errorMsg = "MQ Queue details not configured ";
					eExp = new ExecutionException("error.iris.admin.NoQdetails", new Object[] {IrisAdminConstants.JMS_SESSION_NAME},null);
					logger.error(IRISLogger.getText(eExp));
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					throw eExp;
				}
				jobData.setMessageData(document.asXML());
				inputParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				senderServiceSession = (IRequestReceiver) contextManager.getBeanObject(senderServiceName);
				senderServiceSession.sendMessage(inputParms);
				
			}
			else if (IrisAdminConstants.MEDIA_WEBSERVICE.equals(mediumType))
			{
				
				inputParms = new HashMap<String, Object>();
				contextManager = ContextManager.getInstance();
				senderServiceName = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_SESSION_NAME);
				if (senderServiceName == null )
				{
					errorMsg = "webService details not configured ";
					eExp = new ExecutionException("error.iris.admin.NoServicedetails", new Object[] {IrisAdminConstants.WEBSERVICE_SESSION_NAME},null);
					logger.error(IRISLogger.getText(eExp));
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					throw eExp;
				}
				logger.debug("Sending XML:-{}", document.asXML());
				jobData.setDataObject(document);
				inputParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				senderServiceSession = (IRequestReceiver) contextManager.getBeanObject(senderServiceName);
				senderServiceSession.sendMessage(inputParms);
				
			}
			else if ( IrisAdminConstants.MEDIA_HTTP_REQUEST.equals(mediumType) &&  IrisAdminConstants.MODEL_SUB_TYPE_REQUEST.equals(modelSubType))
			{
				String xmlData = null;
				
				inputParms = new HashMap<String, Object>();
				contextManager = ContextManager.getInstance();
				senderServiceName = jobData.getFilterParameter(IrisAdminConstants.HTTP_SESSION_NAME);
				if (senderServiceName == null )
				{
					errorMsg = "http details not configured ";
					eExp = new ExecutionException("error.iris.admin.NoHTTPdetails", new Object[] {IrisAdminConstants.HTTP_SESSION_NAME},null);
					logger.error(IRISLogger.getText(eExp));
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					throw eExp;
				}
				xmlData = document.asXML();
				logger.debug("Sending XML:-{}", xmlData);
				jobData.setDataObject(xmlData);
				inputParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				senderServiceSession = (IRequestReceiver) contextManager.getBeanObject(senderServiceName);
				senderServiceSession.sendMessage(inputParms);
			}
			else if ( IrisAdminConstants.MEDIA_HTTP_CW.equals(mediumType) )
			{
				jobData.setDataObject(document.asXML());
			}
		}
		catch(ExecutionException exp)
		{
			throw exp;
		}
		catch ( BeanConfigException exp)
		{
			errorMsg = "Error While accessing Bean Object" + senderServiceName;
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]	{errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (FileNotFoundException exp)
		{
			errorMsg = " File not found" + fullFile;
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]	{errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (UnsupportedEncodingException exp)
		{
			errorMsg = " Unsupported Encoding:" + jobData.getCharSet();
			eExp = new ExecutionException("error.iris.admin.unsupported", new Object[]	{ errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (IOException exp)
		{
			errorMsg = " File not able to read"  + fullFile;
			eExp = new ExecutionException("error.iris.admin.ioerror", new Object[]{errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.unknown", new Object[]	{errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		finally
		{
			document = null;
			CleanUpUtils.doClose(writer);
			xmlForfmat = null;
			HelperUtils.doClose(fileWriter);
			HelperUtils.doClose(outStream);
			CleanUpUtils.doClean(inputParms);
		}
	}
	
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param rootElement
	 * </pre></p>
	 */
	private void setNameSpaces (Element node) throws ExecutionException
	{
		DefaultElement element = null;
		Map<String, List<NameSpaceElements>> nameSpaceMap = null;
		List<NameSpaceElements> nameSpaceList = null;
		XPath xpath = null;
		Map<String, String> uris = null;
		String prefix = null;
		String uri = null;
		String relativeXpath = null;
		List<Node> nodelsList = null;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisError irisError = null;
		boolean isDefaultExits = false;
	    
		try
		{
			
			nameSpaceMap = interfaceDef.getNameSpaceElements();
			uris = new HashMap<String, String>();
			for ( Map.Entry<String, List<NameSpaceElements>> entry : nameSpaceMap.entrySet())
			{
				nameSpaceList = entry.getValue();
				isDefaultExits = checkDefaultNameSpace(nameSpaceList);
				for ( NameSpaceElements elements : nameSpaceList)
				{
					prefix = elements.getPrefix();
					uri = elements.getNameSpaceURI();
					uris.put(prefix, uri);
					relativeXpath = elements.getRelativeXPath();
					xpath = DocumentHelper.createXPath(relativeXpath);
					xpath.setNamespaceContext(new SimpleNamespaceContext( uris));
					xpath.setNamespaceURIs(uris);
					nodelsList = (List<Node>)xpath.selectNodes(node);
					for (Node mynode : nodelsList)
					{
						element = (DefaultElement)mynode;
						if ( (isDefaultExits && !"".equals(prefix)) || ( ! isDefaultExits &&  !"".equals(element.getNamespace().getURI())))
								element.add(new Namespace(prefix,uri));
						else
								element.setNamespace(new Namespace(prefix,uri));
					}
					
					// set default name space for all elements. This is must other wise child elements comes with empty xmlns 
					if ( "".equals(prefix))
						addNameSpace(node);
					
				}
			}
		}
		catch ( Exception exp)
		{
			errorMsg = "Error Wile creating Namespace for " + relativeXpath + " with URI" + uri;
			eExp = new ExecutionException("error.iris.admin.nameSpace", new Object[] { errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param nameSpaceList
	 * @return
	 * </pre></p>
	 */
	private boolean checkDefaultNameSpace (List<NameSpaceElements> nameSpaceList)
	{
		String prefix = null;
		boolean isexits = false;
		
		for ( NameSpaceElements elements : nameSpaceList)
		{
			prefix = elements.getPrefix();
			if ("".equals(prefix))
			{
				isexits = true;
				break;
			}
				
		}
		return isexits;
	}

	/**
	 * 
	 * <p>This helper method removes empty elements if there is no data
	 * <p> <i> this helper method trims the value and checks its empty of not</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param Element
	 * </pre></p>
	 */
	@SuppressWarnings("rawtypes")
	private void removeEmptyElements(Element node) 
	{
		Iterator elementIterator = null;
		Element element = null;
	    
		elementIterator = node.elementIterator();
	    while(elementIterator.hasNext())
	    {
	      element = (Element)elementIterator.next();
	      removeEmptyElements(element);
	    }
	    if ( node.elements().size() == 0 && node.getStringValue().trim().isEmpty())
	    	node.getParent().remove(node);
	}
	
	private void addNameSpace(Element node)
	{
		Iterator elementIterator = null;
		Element element = null;
	    
		elementIterator = node.elementIterator();
		while(elementIterator.hasNext())
	    {
	      element = (Element)elementIterator.next();
	      
	      if ( "".equals(element.getNamespace().getURI()))
	    	  	((DefaultElement)element).setNamespace(node.getNamespace());
	      
	      addNameSpace(element);
	    }
	}
}
