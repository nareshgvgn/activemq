/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : InterfaceDataReader.java
 * CREATED: Jul 8, 2013 10:49:14 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceBandsDef;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.interfaces.SplitParameter;
import com.fundtech.iris.admin.model.ModelBandDef;
import com.fundtech.iris.admin.model.ModelDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.fundtech.iris.admin.util.StringUtils;

/**
 * This helper class reads the data from interface table and makes Process level bands
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceDataReader.java,v 1.33 2016/03/16 13:48:24 ramap Exp $
 * @since 1.0.0
 */
public class InterfaceDataReader
{
	private static Logger logger = LoggerFactory.getLogger(InterfaceDataReader.class);
	private InterfaceDef interfaceDef = null;
	private ModelDef modelDef = null;
	private ExecutionJobData jobData = null;
	private Connection dbConnection = null;
	
	@SuppressWarnings("unused")
	private InterfaceDataReader()
	{
		// DO not allow to use this
	}
	
	/**
	 * @param interfaceDef
	 * @param modelDef
	 * @param jobData
	 * @param dbConnection
	 */
	public InterfaceDataReader(InterfaceDef interfaceDef, ModelDef modelDef, ExecutionJobData jobData, Connection dbConnection)
	{
		this.modelDef = modelDef;
		this.jobData = jobData;
		this.interfaceDef = interfaceDef;
		this.dbConnection = dbConnection;
	}
	
	
	/**
	 * @return
	 * @throws ExecutionException
	 * @throws FormatException
	 */
	public RootBand loadInterfaceData () throws ExecutionException, FormatException
	{
		Map<String, ModelBandDef> iBandDefs = null;
		Map<String, InterfaceBandDef> pBandDefs = null;
		long totalCount = 0;
		RootBand rootBand = null;
		Map<String, BatchBand> dataBBand = null;
		ExecutionException eExp = null;
		List<BatchBand> bands = null;
		BatchBand trilarBand = null;
		String errorMsg = null;
		
		try
		{
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "Before loading download Data");
			iBandDefs = modelDef.getBandsDefinition().getBandDefinitions();
			rootBand = new RootBand();
			for (ModelBandDef iDef : iBandDefs.values())
			{
				pBandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
				totalCount = getTotalRecords(iDef);
				
				for (InterfaceBandDef pDef : pBandDefs.values())
				{
					
					dataBBand = getBandData(pDef, iDef, totalCount, rootBand);
					
					if (rootBand.getBatches().isEmpty())
					{
						for (BatchBand band : dataBBand.values())
						{
							rootBand.addBatches(band);
						}
					}
					else
					{
						bands = rootBand.getBatches();
						for (BatchBand batchBand : bands)
						{
							trilarBand = dataBBand.get(batchBand.getMinMaxKey());
							if (trilarBand == null)
							{
								errorMsg = "Key:" + batchBand.getMinMaxKey() + " not available in data band for Band:" + pDef.getBandName()
										+ " Process Defined Wrongly";
								eExp = new ExecutionException("err.imadmin.executionsql", new Object[]
								{ errorMsg }, null);
								logger.error(IRISLogger.getText(eExp));
								jobData.setStatus("E");
								throw eExp;
							}
							for (Band trilar : trilarBand.getBatchBands())
								batchBand.addBatchBands(trilar);
						}
					}
					
				}
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[] { "Interface Code:" + interfaceDef.getModelName(), "Process Code:" + interfaceDef.getModelName() }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "After loading download Data");
		}
		return rootBand;
	}
	
	
	
/*-------------------------------------------------------------------------------------------------*
 * HELPER METHODS
 *------------------------------------------------------------------------------------------------*/
	
	/**
	 * This helper method creates the Parent Data Band and calls child data band
	 * 
	 * @param pDef
	 * @param modelDef
	 * @param totalRecordCount
	 * @param rootBand
	 * @return
	 * @throws ExecutionException
	 */
	private Map<String, BatchBand> getBandData (InterfaceBandDef pDef, ModelBandDef modelDef, long totalRecordCount, RootBand rootBand)
			throws ExecutionException
	{
		long factor = 0;
		StringBuilder topBandSql = null;
		Map<String, String> sqls = null;
		PreparedStatement parentSt = null;
		String groupBySql = null;
		String finalSql = null;
		ResultSet parentRs = null;
		ResultSetMetaData metadata = null;
		String colName = null;
		String colValue = null;
		Band dataBand = null;
		InterfaceBandsDef childBandsDef = null;
		Map<String, BatchBand> parentData = null;
		Map<String, BatchBand> childData = null;
		ExecutionException eExp = null;
		int level = 0;
		String dataKey = null;
		String fieldName = null;
		BatchBand batchBand = null;
		DataField dataField = null;
		String executionId = null;
		
		try
		{
			level = getMaxLevel(interfaceDef.getModelName(), interfaceDef.getInterfaceName());
			factor = getFactor(level, totalRecordCount);
			executionId = jobData.getExecutionId();
			topBandSql = new StringBuilder();
			sqls = format(pDef, modelDef, factor, 0, rootBand.getGroupSql());
			topBandSql.append(sqls.get("SELECT"));
			topBandSql.append(" GROUP BY ");
			groupBySql = sqls.get("GROUPBY");
			topBandSql.append(groupBySql);
			if (sqls.containsKey("ORDERBY"))
				topBandSql.append(sqls.get("ORDERBY"));
			
			finalSql = topBandSql.toString();
			CleanUpUtils.doClean(topBandSql);
			
			if (logger.isDebugEnabled())
				logger.debug("Sql to be executed for Band:" + pDef.getBandName() + "  SQL: " + finalSql);
			
			parentSt = dbConnection.prepareStatement(finalSql);
			parentSt.clearParameters();
			parentSt.setString(1, executionId);
			parentRs = parentSt.executeQuery();
			metadata = parentRs.getMetaData();
			parentData = new LinkedHashMap<String, BatchBand>();
			
			while (parentRs.next())
			{
				
				dataBand = new Band();
				dataBand.setId(pDef.getBandId());
				dataBand.setSequenceNumber(pDef.getSequenceNumber());
				dataBand.setName(pDef.getBandName());
				dataBand.setLineSeparator(jobData.getLinSeparator());
				for (int i = 1; i <= metadata.getColumnCount(); i++)
				{
					colName = metadata.getColumnName(i);
					colValue = parentRs.getString(i);
					
					if (logger.isTraceEnabled())
						logger.trace("COLUMN NAME:" + colName + "  COLUMN VALUE:" + colValue);
					
					if (colName.equals("MIN_ROW_NMBR") || colName.equals("MAX_ROW_NMBR"))
					{
						if (dataKey != null)
							dataKey = dataKey + "," + colValue;
						else
							dataKey = colValue;
					}
					
					fieldName = modelDef.getFieldName(colName);
					if (fieldName != null)
					{
						dataField = new DataField();
						dataField.setValue(colValue);
						dataBand.setFieldValue(fieldName, dataField);
					}
				}
				dataBand.setMinMaxKey(dataKey);
				if (parentData.containsKey(dataKey))
					batchBand = parentData.get(dataKey);
				else
				{
					batchBand = new BatchBand();
					batchBand.setSequenceNumber(pDef.getSequenceNumber());
					batchBand.setBatchName(pDef.getBandName());
					batchBand.setMinMaxKey(dataKey);
				}
				
				batchBand.addBatchBands(dataBand);
				parentData.put(dataKey, batchBand);
				dataKey = null;
			}
			logger.debug("Finished Loading:" + pDef.getBandName() + " Size of the records:" + parentData.size());
			rootBand.setGroupSql(groupBySql);
			childBandsDef = pDef.getChildDefinitions();
			Map<String, InterfaceBandDef> entry = childBandsDef.getBandDefinitions();
			for (InterfaceBandDef childDef : entry.values())
			{
				childData = new LinkedHashMap<String, BatchBand>();
				getChildData(childDef, modelDef, level - 1, totalRecordCount, factor, groupBySql, childData);
				logger.debug("Arranging Batched For" + childDef.getBandName() + " And parenrBand:" + pDef.getBandName() + "parentData Size:"
						+ parentData.size() + " childData size:" + childData.size());
				parentData = arrangeBatches(parentData, childData);
				logger.debug("Completed Batched For" + childDef.getBandName() + " And parenrBand:" + pDef.getBandName());
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (SQLException exp)
		{
			logger.error("Error While Executing SQL:" + finalSql);
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[]
			{ finalSql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			logger.error("Error While creating Band Data:" + finalSql);
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[]
			{ finalSql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(parentRs);
			HelperUtils.doClose(parentSt);
			CleanUpUtils.doClean(topBandSql);
			topBandSql = null;
		}
		return parentData;
	}
	
	/**
	 * This helper method creates child data band for the parent
	 * 
	 * @param pDef
	 * @param modelDef
	 * @param bandLevel
	 * @param totalRecordCount
	 * @param parentFactor
	 * @param parentGroupSql
	 * @return
	 * @throws ExecutionException
	 */
	private void getChildData (InterfaceBandDef pDef, ModelBandDef modelDef, int bandLevel, long totalRecordCount, long parentFactor,
			String parentGroupSql, Map<String, BatchBand> parentData) throws ExecutionException
	{
		long factor = 0;
		StringBuilder topBandSql = null;
		Map<String, String> sqls = null;
		PreparedStatement parentSt = null;
		String groupBySql = null;
		String finalSql = null;
		ResultSet parentRs = null;
		ResultSetMetaData metadata = null;
		String colName = null;
		String colValue = null;
		Band dataBand = null;
		InterfaceBandsDef childBandsDef = null;
		ExecutionException eExp = null;
		Map<String, BatchBand> childData = null;
		String dataKey = null;
		long childFactor = 0;
		String fieldName = null;
		BatchBand batchBand = null;
		DataField dataField = null;
		String executionId = null;
		try
		{
			factor = getFactor(bandLevel, totalRecordCount);
			topBandSql = new StringBuilder();
			sqls = format(pDef, modelDef, factor, parentFactor, parentGroupSql);
			childFactor = factor + parentFactor;
			topBandSql.append(sqls.get("SELECT"));
			topBandSql.append(" GROUP BY ");
			groupBySql = sqls.get("GROUPBY");
			topBandSql.append(groupBySql);
			if (sqls.containsKey("ORDERBY"))
				topBandSql.append(sqls.get("ORDERBY"));
			
			finalSql = topBandSql.toString();
			CleanUpUtils.doClean(topBandSql);
			
			if (logger.isDebugEnabled())
				logger.debug("Sql to be executed for Band:" + pDef.getBandName() + "  SQL: " + finalSql);
			executionId = jobData.getExecutionId();
			parentSt = dbConnection.prepareStatement(finalSql);
			parentSt.clearParameters();
			parentSt.setString(1, executionId);
			parentRs = parentSt.executeQuery();
			metadata = parentRs.getMetaData();
			while (parentRs.next())
			{
				dataBand = new Band();
				dataBand.setId(pDef.getBandId());
				dataBand.setSequenceNumber(pDef.getSequenceNumber());
				dataBand.setName(pDef.getBandName());
				dataBand.setLineSeparator(jobData.getLinSeparator());
				for (int i = 1; i <= metadata.getColumnCount(); i++)
				{
					colName = metadata.getColumnName(i);
					colValue = parentRs.getString(i);
					if (logger.isTraceEnabled())
						logger.trace("COLUMN NAME:" + colName + "  COLUMN VALUE:" + colValue);
					if (colName.equals("MIN_ROW_NMBR") || colName.equals("MAX_ROW_NMBR"))
					{
						if (dataKey != null)
							dataKey = dataKey + "," + colValue;
						else
							dataKey = colValue;
						
					}
					fieldName = modelDef.getFieldName(colName);
					if (fieldName != null)
					{
						dataField = new DataField();
						dataField.setValue(colValue);
						dataBand.setFieldValue(fieldName, dataField);
					}
				}
				dataBand.setMinMaxKey(dataKey);
				if (parentData.containsKey(dataKey))
					batchBand = parentData.get(dataKey);
				else
				{
					batchBand = new BatchBand();
					batchBand.setSequenceNumber(pDef.getSequenceNumber());
					batchBand.setBatchName(pDef.getBandName());
					batchBand.setMinMaxKey(dataKey);
				}
				
				batchBand.addBatchBands(dataBand);
				parentData.put(dataKey, batchBand);
				dataKey = null;
			}
			childBandsDef = pDef.getChildDefinitions();
			Map<String, InterfaceBandDef> entry = childBandsDef.getBandDefinitions();
			
			for (InterfaceBandDef childDef : entry.values())
			{
				childData = new LinkedHashMap<String, BatchBand>();
				getChildData(childDef, modelDef, bandLevel - 1, totalRecordCount, childFactor, groupBySql, childData);
				parentData = arrangeBatches(parentData, childData);
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (SQLException exp)
		{
			logger.error("Error While Executing SQL:" + finalSql);
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[]
			{ finalSql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			logger.error("Error While creating Band Data:" + finalSql);
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[]
			{ finalSql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(parentRs);
			HelperUtils.doClose(parentSt);
			CleanUpUtils.doClean(topBandSql);
			topBandSql = null;
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param keysList
	 * @param childData
	 * </pre>
	 * 
	 * </p>
	 */
	private Map<String, BatchBand> removeMached (List<String> keysList, Map<String, BatchBand> childData)
	{
		
		for (String key : keysList)
			childData.remove(key);
		
		return childData;
	}
	
	/**
	 * TODO
	 * 
	 * @param batchData
	 * @param parentData
	 */
	private Map<String, BatchBand> arrangeBatches (Map<String, BatchBand> batchData, Map<String, BatchBand> childData)
	{
		String parentKey = null;
		String childKey = null;
		String[] parentKeyTokens = null;
		String[] childKeyTokens = null;
		BigInteger parentMinValue = null;
		BigInteger parentMaxValue = null;
		BigInteger childMinValue = null;
		BigInteger childMaxValue = null;
		BatchBand parentBatchBand = null;
		BatchBand childBatchBand = null;
		int maxCompare = 0;
		int minCompare = 0;
		List<String> keysList = null;
		
		if (batchData.isEmpty())
		{
			logger.debug("Parent data is empty so making child as parent");
			return childData;
		}
		
		try
		{
			for (Map.Entry<String, BatchBand> parentEntry : batchData.entrySet())
			{
				parentKey = parentEntry.getKey();
				parentKeyTokens = parentKey.split(",");
				parentMinValue = new BigInteger(parentKeyTokens[0]);
				parentMaxValue = new BigInteger(parentKeyTokens[1]);
				parentBatchBand = parentEntry.getValue();
				keysList = new LinkedList<String>();
				for (Map.Entry<String, BatchBand> childEntry : childData.entrySet())
				{
					childKey = childEntry.getKey();
					childKeyTokens = childKey.split(",");
					childMinValue = new BigInteger(childKeyTokens[0]);
					childMaxValue = new BigInteger(childKeyTokens[1]);
					minCompare = parentMinValue.compareTo(childMinValue);
					maxCompare = parentMaxValue.compareTo(childMaxValue);
					if (minCompare < 1 && maxCompare > -1)
					{
						childBatchBand = childEntry.getValue();
						for (Band parent : parentBatchBand.getBatchBands())
						{
							for (Band band : childBatchBand.getBatchBands())
							{
								band.setParentBand(parent);
								
							}
							parent.addChildBatche(childBatchBand);
							childBatchBand.setParentBand(parent);
							childBatchBand.setParentBatchBand(parentBatchBand);
						}
						keysList.add(childKey); // matched keys Storing in a list, so that matched keys will be removed from map and left with
												// unmatched.
					}
					else
						// if Child keys not falling between parent keys, break the loop, so that next parent will key will be verified
						break;
					
					childMinValue = null;
					childMaxValue = null;
					childKeyTokens = null;
				}
				childData = removeMached(keysList, childData);
				
				parentMinValue = null;
				parentMaxValue = null;
				parentKeyTokens = null;
			}
		}
		finally
		{
			CleanUpUtils.doClean(keysList);
			keysList = null;
			parentKey = null;
			childKey = null;
			parentKeyTokens = null;
			childKeyTokens = null;
			parentMinValue = null;
			parentMaxValue = null;
			childMinValue = null;
			childMaxValue = null;
			parentBatchBand = null;
			childBatchBand = null;
		}
		return batchData;
	}
	
	/**
	 * This method creates the factor
	 * 
	 * @param maxLavel
	 * @param totalRecordsCount
	 * @return
	 */
	private long getFactor (int maxLavel, long totalRecordsCount)
	{
		long factor = 0;
		int length = 0;
		int temp = 0;
		
		length = (Long.toString(totalRecordsCount + 1)).length();
		temp = (length * maxLavel) + 1;
		factor = Long.parseLong(StringUtils.padRight("1", "0", temp));
		return factor;
	}
	
	/**
	 * This helper method creates total record count for that session
	 * 
	 * @param modelDef
	 * @return
	 */
	private long getTotalRecords (ModelBandDef iBandDef) throws ExecutionException
	{
		PreparedStatement totalSt = null;
		ResultSet totalRs = null;
		long totalCount = 0;
		String sql = "SELECT COUNT(*) AS COUNT FROM ";
		ExecutionException eExp = null;
		String tableName = null;
		String joinCondition = null;
		String executionId = null;
		try
		{
			tableName = iBandDef.getMappedTable();
			joinCondition = iBandDef.getJoinCondition();
			executionId = jobData.getExecutionId();
			if (joinCondition == null)
				sql = sql + tableName + " WHERE EXECUTION_ID =?";
			else
				sql = sql + tableName + " WHERE EXECUTION_ID = ? AND " + joinCondition;
				
			totalSt = dbConnection.prepareStatement(sql);
			totalSt.clearParameters();
			totalSt.setString(1, executionId);
			totalRs = totalSt.executeQuery();
			if (totalRs.next())
				totalCount = totalRs.getLong("COUNT");
		}
		catch (SQLException exp)
		{
			logger.error("Error While Executing SQL:" + sql);
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[]	{ "Table Name:" + tableName, sql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			logger.error("Error While Executing SQL:" + sql);
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[]{ "Table Name:" + tableName, sql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(totalRs);
			HelperUtils.doClose(totalSt);
		}
		return totalCount;
	}
	
	/**
	 * This Helper method creates SQLS for all bands
	 * 
	 * @param pDef
	 * @param iDef
	 * @param factor
	 * @param parentFactor
	 * @param parentGroup
	 * @return
	 */
	private Map<String, String> format (InterfaceBandDef pDef, ModelBandDef iDef, long factor, long parentFactor, String parentGroup)
	{
		StringBuilder selectSql = null;
		Map<String, String> sqls = null;
		String tableSql = null;
		StringBuilder groupSql = null;
		StringBuilder orderBySql = null;
		String colName = null;
		String colAlias = null;
		
		String fieldName = null;
		boolean isfirst = true;
		Map<Integer, String> orderbyData = null;
		String substr1 = "SUBSTRC(";
		String substr2 = ",";
		String substr3 = ")";
		long subfactor = 0;
		long totalFactor = 0;
		
		try
		{
			sqls = new HashMap<String, String>();
			selectSql = new StringBuilder();
			groupSql = new StringBuilder();
			orderBySql = new StringBuilder();
			subfactor = factor - 1;
			totalFactor = parentFactor + factor;
			selectSql.append("SELECT ");
			selectSql.append("(min(SR_NMBR) * ");
			selectSql.append(totalFactor);
			selectSql.append(") AS MIN_ROW_NMBR, ");
			
			selectSql.append("((max(SR_NMBR) * ");
			selectSql.append(totalFactor);
			selectSql.append(") + ");
			selectSql.append(subfactor);
			selectSql.append(") AS MAX_ROW_NMBR, ");
			
			tableSql = getFromClause(iDef, jobData); 
			orderBySql.append(" ORDER BY ");
			
			orderbyData = getSplitFields(iDef, pDef);
			if (parentGroup != null)
			{
				groupSql.append(parentGroup);
				groupSql.append(",");
			}
			for (MappingField field : pDef.getMappingFields())
			{
				// select only INT and INT MANDATORY
				// FIELD_TYPE_INT -0
				// FIELD_TYPE_INT_MANDATORY -1 so used less than
				// do not refer ref code map and ignore from fetching 
				if (IrisAdminConstants.FIELD_TYPE_INT_MANDATORY >= field.getFieldType() && (IrisAdminConstants.MAPPING_TYPE_REFCODEMAP != field.getMappingType()) )
				{
					if (!isfirst)
					{
						selectSql.append(",");
						groupSql.append(",");
					}
					fieldName = field.getFieldName();
					colName = iDef.getColumnNameWithAlias(fieldName);
					
					if (field.getDataType().equals(IrisAdminConstants.DATA_TYPE_STRING)
							&& !(IrisAdminConstants.MAPPING_TYPE_CODEMAP == field.getMappingType()) )
					{
						colAlias = colName;
						colName = substr1 + colName + substr2 + 1 + substr2 + field.getFieldLength() + substr3;
						colAlias = colName + " AS " + iDef.getColNameWithoutAlias(fieldName);
					}
					if (colAlias != null)
						selectSql.append(colAlias);
					else
						selectSql.append(colName);
					colAlias = null;
					groupSql.append(colName);
					isfirst = false;
					if (field.getorderBy() != null)
					{
						orderbyData.put(field.getorderSequenceNmbr(), colName + " " + field.getorderBy());
					}
				}
			}
			isfirst = true;
			orderBySql.append("MIN_ROW_NMBR");
			for (int i = 1; i == orderbyData.size(); i++)
			{
				orderBySql.append(",");
				orderBySql.append(orderbyData.get(i));
				isfirst = false;
			}
			
			selectSql.append(tableSql);
			sqls.put("SELECT", selectSql.toString());
			sqls.put("GROUPBY", groupSql.toString());
			sqls.put("ORDERBY", orderBySql.toString());
			
			orderbyData.clear();
		}
		finally
		{
			CleanUpUtils.doClean(selectSql);
			CleanUpUtils.doClean(groupSql);
			CleanUpUtils.doClean(orderBySql);
			selectSql = null;
			groupSql = null;
			orderBySql = null;
			orderbyData = null;
		}
		return sqls;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param iDef
	 * @param jobData2
	 * @return
	 * </pre></p>
	 */
	private String getFromClause (ModelBandDef iDef, ExecutionJobData jobData2)
	{
		String returnString = null;
		String tableString = null;
		String joinCondition = null;
		
		
		tableString = iDef.getMappedTable();
		joinCondition = iDef.getJoinCondition();
		
		
		if ( joinCondition == null )
			returnString = " FROM " + tableString + " WHERE EXECUTION_ID = ?";
		else
			returnString = " FROM " + tableString + " WHERE EXECUTION_ID = ? AND " + joinCondition;
		
		return returnString;
	}

	/**
	 * TODO
	 * 
	 * @param def
	 * @return
	 */
	private Map<Integer, String> getSplitFields (ModelBandDef iDef, InterfaceBandDef pDef)
	{
		Map<Integer, String> orderby = null;
		List<SplitParameter> splitList = null;
		String fieldName = null;
		String colName = null;
		int length = 0;
		String substr1 = "SUBSTRC(";
		String substr2 = ",";
		String substr3 = ")";
		
		orderby = new HashMap<Integer, String>();
		
		splitList = interfaceDef.getSplitParameters();
		for (SplitParameter parm : splitList)
		{
			if (!pDef.getBandName().equals(parm.getBandName()))
				break;
			fieldName = parm.getFieldName();
			length = getFiledLength(fieldName, pDef);
			colName = iDef.getColumnNameWithAlias(fieldName);
			colName = substr1 + colName + substr2 + 1 + substr2 + length + substr3;
			orderby.put(parm.getSeqNumber(), colName);
		}
		return orderby;
	}
	
	
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param fieldName
	 * @param pDef
	 * @return
	 * </pre></p>
	 */
	private int getFiledLength (String fieldName, InterfaceBandDef pDef)
	{
		int length = 0; 
		List<MappingField> lstFields = null;
		lstFields = pDef.getMappingFields();
		for (MappingField field : lstFields)
		{
			if ( field.getFieldName().equals(fieldName))
			{
				length = field.getIFieldLength();
					break;
			}
		}
		
		return length;
	}

	/**
	 * This helper method gets the maximum levels of the bands
	 * 
	 * @param modelName
	 * @param interfaceName
	 * @return max level
	 * @throws ExecutionException
	 */
	private int getMaxLevel (String modelName, String interfaceName) throws ExecutionException
	{
		PreparedStatement totalSt = null;
		ResultSet totalRs = null;
		int maxLevel = 0;
		String sql = "SELECT MAX(M.BAND_LEVEL) AS MAXLEVEL FROM IRIS_INT_BAND_DTL M WHERE M.MODEL_NAME = ? AND M.INTERFACE_NAME=?";
		
		ExecutionException eExp = null;
		try
		{
			totalSt = dbConnection.prepareStatement(sql);
			totalSt.clearParameters();
			totalSt.setString(1,modelName);
			totalSt.setString(2,interfaceName);
			totalRs = totalSt.executeQuery();
			if (totalRs.next())
				maxLevel = totalRs.getInt("MAXLEVEL");
		}
		catch (SQLException exp)
		{
			logger.error("Error While Executing Max level SQL:" + sql);
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[]
			{ "Model Name:" + modelName, "Interface Name:" + interfaceName, sql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			logger.error("Error While Executing Max level SQL:" + sql);
			eExp = new ExecutionException("err.imadmin.executionsql", new Object[]
			{ "Model Name:" + modelName, "Interface Name:" + interfaceName, sql }, exp);
			logger.error(IRISLogger.getText(eExp));
		}
		finally
		{
			HelperUtils.doClose(totalRs);
			HelperUtils.doClose(totalSt);
		}
		return maxLevel;
	}
	
}
