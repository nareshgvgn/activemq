/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : InterfaceDataMapper.java
 * CREATED: May 3, 2013 12:56:10 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.DateUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.ModelBand;
import com.fundtech.iris.admin.data.ModelRootBand;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.model.ModelBandDef;
import com.fundtech.iris.admin.model.ModelBandsDef;
import com.fundtech.iris.admin.model.ModelDef;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceDataMapper.java,v 1.21 2016/06/29 11:05:53 ramap Exp $
 * @since 1.0.0
 */
public class InterfaceDataMapper
{
	private static Logger logger = LoggerFactory.getLogger(InterfaceDataMapper.class);
	private ModelDef definition = null;
	private RootBand rootBand = null;
	private ExecutionJobData jobData = null;
	
	@SuppressWarnings("unused")
	private InterfaceDataMapper()
	{
		// Do not allow
	}
	
	public InterfaceDataMapper(ModelDef definition, RootBand rootBand, ExecutionJobData jobData)
	{
		this.definition = definition;
		this.rootBand = rootBand;
		this.jobData = jobData;
	}
	
	/**
	 * This method creates the interface data band
	 * 
	 * @return
	 * @throws Exception
	 */
	public ModelRootBand createModelBands () throws Exception
	{
		ModelBandsDef modelBandsDef = null;
		Map<String, ModelBandDef> modelBandDefs = null;
		ModelRootBand iRootBand = null;
		ModelBand iBatchBand = null;
		ModelBand iPreviousParentBand = null;
		List<Band> bands = null;
		Map<String, ModelBand> parentBands = null;
		String iBandType = null;
		try
		{
			
			modelBandsDef = definition.getBandsDefinition();
			modelBandDefs = modelBandsDef.getBandDefinitions();
			iRootBand = new ModelRootBand();
			parentBands = new HashMap<String, ModelBand>();
			for (Band pDataBand : rootBand.getBatchBands())
			{
				for (String key : pDataBand.getAllBands())
				{
					bands = pDataBand.getChildBands(key);
					for (Band pParentBand : bands)
					{
						iBatchBand = createBandData(pParentBand, modelBandDefs, jobData, iRootBand);
						iBandType = iBatchBand.getBandType();
						// Store Parent bad, so that if parallel band have same BandType we can merge
						if (parentBands.containsKey(iBandType))
						{
							iPreviousParentBand = parentBands.get(iBandType);
							if (iPreviousParentBand.getProcessBandName().equals(iBatchBand.getProcessBandName()))
							{
								parentBands.put(iBatchBand.getBandType(), iBatchBand);
								iRootBand.addBatchBands(iBatchBand);
							}
							else
							{
								mergeBand(iBatchBand, iPreviousParentBand);
								
							}
						}
						else
						{
							parentBands.put(iBatchBand.getBandType(), iBatchBand);
							iRootBand.addBatchBands(iBatchBand);
						}
					}
				}
				CleanUpUtils.doClean(parentBands);
				CleanUpUtils.doClose(pDataBand);
			}
		}
		finally
		{
			CleanUpUtils.doClose(rootBand);
		}
		return iRootBand;
	}
	
	/*-------------------------------------------------------------------------------------------------------------------------------------------------------------------*
	 * 																				HELPER METHODS
	 *------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	/**
	 * This helper method merges the bad
	 * 
	 * @param fromBand
	 * @param toBand
	 * @return
	 */
	private ModelBand mergeBand (ModelBand fromBand, ModelBand toBand)
	{
		
		if (toBand.getRows().isEmpty())
		{
			addData(fromBand, toBand);
			fromBand.getFieldRow().clear();
		}
		else
		{
			if (!toBand.getRows().isEmpty())
			{
				for (ModelBand dataBand : toBand.getRows())
				{
					addData(fromBand, dataBand);
				}
				fromBand.getFieldRow().clear();
			}
		}
		return toBand;
	}
	
	/**
	 * This helper method add the data from one band to another band
	 * 
	 * @param fromBand
	 * @param toBand
	 */
	private void addData (ModelBand fromBand, ModelBand toBand)
	{
		String key = null;
		String fldVal = null;
		Map<String, String> fieldRow = null;
		
		fieldRow = fromBand.getFieldRow();
		for (Map.Entry<String, String> entry : fieldRow.entrySet())
		{
			key = entry.getKey();
			fldVal = entry.getValue();
			toBand.setFieldValue(key, fldVal);
		}
		for (String bandName : fromBand.getAllBands())
		{
			for (ModelBand band : fromBand.getChildBands(bandName))
				toBand.addChildBand(band);
		}
	}
	
	/**
	 * This helper method creates the Band Data
	 * 
	 * @param pDataBand
	 * @param modelBandDefs
	 * @param jobData
	 * @return
	 * @throws Exception
	 */
	private ModelBand createBandData (Band pDataBand, Map<String, ModelBandDef> modelBandDefs, ExecutionJobData jobData,ModelRootBand iRootBand) throws Exception
	{
		String pBandType = null;
		String iBandType = null;
		ModelBand iBatchBand = null;
		Map<String, ModelBandDef> childBandDefs = null;
		
		pBandType = pDataBand.getBandType();
		for (ModelBandDef bandDef : modelBandDefs.values())
		{
			iBandType = bandDef.getBandType();
			
			if (pBandType.equals(iBandType))
			{
				iBatchBand = createModelBand(pDataBand, bandDef, jobData, iRootBand);
				break;
			}
			else
			{
				childBandDefs = bandDef.getChildBandDefs();
				if (!childBandDefs.isEmpty())
				{
					iBatchBand = createBandData(pDataBand, childBandDefs, jobData, iRootBand);
					if (iBatchBand != null)
						break;
				}
			}
		}
		return iBatchBand;
	}
	
	/**
	 * This helper method creates the interface Band
	 * 
	 * @param pDataBand
	 * @param iBandDef
	 * @param jobData
	 * @return
	 * @throws Exception
	 */
	private ModelBand createModelBand (Band pDataBand, ModelBandDef iBandDef, ExecutionJobData jobData,ModelRootBand iRootBand) throws Exception
	{
		String pBandType = null;
		String iParentBandType = null;
		ModelBand iParentDataBand = null;
		
		pBandType = pDataBand.getBandType();
		iParentBandType = iBandDef.getBandType();
		if (pBandType.equals(iParentBandType))
		{
			iParentDataBand = setIBandValues(iBandDef, pDataBand);
		}
		
		getChildBands(pDataBand, iBandDef, iParentDataBand, iRootBand);
		
		return iParentDataBand;
		
	}
	
	private void getChildBands (Band pDataBand, ModelBandDef iBandDef, ModelBand iParentDataBand,ModelRootBand iRootBand) throws Exception
	{
		Set<String> pBandNames = null;
		List<Band> pChildDataBands = null;
		String iParentBandType = null;
		ModelBand iDataBand = null;
		ModelBand iChildBand = null;
		ModelBandDef iChildDef = null;
		
		iParentBandType = iBandDef.getBandType();
		pBandNames = pDataBand.getAllBands();
		for (String bandName : pBandNames)
		{
			pChildDataBands = pDataBand.getChildBands(bandName);
			
			for (Band pChildDataBand : pChildDataBands)
			{
				if (pChildDataBand.getBandType().equals(iParentBandType))
				{
					/*
					 * If pChildDataBand.getBandType() and iParentBandType is same means interface band type is same for parent and child so we should
					 * add child data to parent. and we should not create new interface band. commented code working like if parent and child are same
					 * type, then copy parent data in to child band and create a band. it should not be like that, coz it creates many transactions
					 * and it should create 1 trans only. so now code correacted such a way that. child band data will be moved to parent band so that
					 * always we read parent band only.
					 * 
					 * 
					 * iDataBand = copyIBandValues(iBandDef, pChildDataBand, iParentDataBand); iParentDataBand.addRow(iDataBand);
					 */
					iDataBand = createModelBand(pChildDataBand, iBandDef, jobData, iRootBand);
					mergeBand(iDataBand, iParentDataBand);
					getChildBands(pChildDataBand, iBandDef, iParentDataBand, iRootBand);
				}
				else
				{
					
					iChildDef = getBandDefinition(pChildDataBand.getBandType(), iBandDef);
					iChildBand = createModelBand(pChildDataBand, iChildDef, jobData, iRootBand);
					if ( iBandDef.getParentBandType() == null)
					{
						if (iChildDef.getBandLevel() == iBandDef.getBandLevel())
						{
							// This logger we need to remove after testing 
							logger.trace("Parent Band parent is null and band levels are samee");
							iRootBand.addBatchBands(iChildBand);
						}
						else
						{
							// This logger we need to remove after testing 
							logger.trace("Parent Band parent is null and band levels are NOT samee");
							iChildBand.setParentBand(iParentDataBand);
							iParentDataBand.addChildBand(iChildBand);
							iChildBand.setParentBand(iParentDataBand);
						}
					}
					else
					{
						if (iChildDef.getBandLevel() == iBandDef.getBandLevel())
						{
							// This logger we need to remove after testing 
							logger.trace("Parent Band parent is avl and band levels are samee");
							ModelBand superBand = iParentDataBand.getParentBand();
							iChildBand.setParentBand(superBand);
							superBand.addChildBand(iChildBand);
							iChildBand.setParentBand(superBand);
						}
						else
						{
							// This logger we need to remove after testing 
							logger.trace("Parent Band parent is avl and band levels are NOT samee");
							iChildBand.setParentBand(iParentDataBand);
							iParentDataBand.addChildBand(iChildBand);
							iChildBand.setParentBand(iParentDataBand);
						}
					}
				}
			}
		}
	}
	
	/**
	 * This helper method sets the values in interface band
	 * 
	 * @param iBandDef
	 * @param pdataBand
	 * @return
	 */
	private ModelBand setIBandValues (ModelBandDef iBandDef, Band pdataBand) throws ExecutionException
	{
		Map<String, DataField> fields = null;
		String fldVal = null;
		ModelBand idataBand = null;
		String key = null;
		DataField dataField = null;
		
		idataBand = new ModelBand();
		idataBand.setBandPath(iBandDef.getBandPath());
		idataBand.setBandType(iBandDef.getBandType());
		idataBand.setName(iBandDef.getMappedTable());
		idataBand.setProcessBandName(pdataBand.getName());
		idataBand.setCurrentSessionId(jobData.getExecutionId());
		fields = pdataBand.getFieldRow();
		
		for (Map.Entry<String, DataField> entry : fields.entrySet())
		{
			key = entry.getKey();
			if (iBandDef.getInterfaceFields().containsKey(key))
			{
				dataField = entry.getValue();
				fldVal = getValueAsString(dataField);
				idataBand.setFieldValue(iBandDef.getColumnNameWithAlias(key), fldVal);
			}
		}
		pdataBand.getFieldRow().clear();
		return idataBand;
		
	}
	
	/**
	 * This helper method updates the Interface Band TODO
	 * 
	 * @param iBandDef
	 * @param pdataBand
	 * @param idataBand
	 * @return
	 * @throws ExecutionException
	 */
	@SuppressWarnings("unused")
	private ModelBand copyIBandValues (ModelBandDef iBandDef, Band pdataBand, ModelBand idataBand) throws ExecutionException
	{
		Map<String, DataField> fields = null;
		String fldVal = null;
		ModelBand iCopydataBand = null;
		String dbColumnName = null;
		ExecutionException eExp = null;
		String key = null;
		DataField dataField = null;
		
		try
		{
			fields = pdataBand.getFieldRow();
			iCopydataBand = (ModelBand) idataBand.clone();
			
			for (Map.Entry<String, DataField> entry : fields.entrySet())
			{
				key = entry.getKey();
				if (iBandDef.getInterfaceFields().containsKey(key))
				{
					dataField = entry.getValue();
					fldVal = dataField.getValue();
					dbColumnName = iBandDef.getColumnNameWithAlias(key);
					if (dbColumnName != null)
						iCopydataBand.setFieldValue(dbColumnName, fldVal);
					else
					{
						eExp = new ExecutionException("error.iris.admin.interfacesetp", new Object[]
						{ "In Band:" + pdataBand.getName() + " and for key:" + key + " db column not configured" }, null);
						logger.error(IRISLogger.getText(eExp));
						throw eExp;
					}
					
				}
			}
			pdataBand.getFieldRow().clear();
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			eExp = new ExecutionException("error.iris.admin.interfacesetp", new Object[]
			{ "UnKnown error while configuring for band :" + pdataBand.getName() }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		return iCopydataBand;
	}
	
	/**
	 * This helper method get the Band Definition for given band Type
	 * 
	 * @param pBandType
	 * @param iParentDef
	 * @return
	 */
	private ModelBandDef getBandDefinition (String pBandType, ModelBandDef iParentDef)
	{
		ModelBandDef iChildDef = null;
		
		for (ModelBandDef iDef : iParentDef.getChildBands())
		{
			if (pBandType.equals(iDef.getBandType()))
			{
				iChildDef = iDef;
				break;
			}
			else
			{
				iChildDef = getBandDefinition(pBandType, iDef);
			}
		}
		if ( iChildDef == null)
			iChildDef = iParentDef.getParallelDefinition(pBandType);
		
		return iChildDef;
	}
	
	/**
	 * <p>
	 * This helper method in upload reads the field value and converts to {@link DateUtils.ISO_DATEFORMAT}.
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param field
	 * @param fldVal
	 * @return
	 * @throws FormatException
	 * </pre>
	 * 
	 * </p>
	 */
	public String getValueAsString (DataField field) throws ExecutionException
	{
		SimpleDateFormat dateFormat = null;
		SimpleDateFormat isoDateFormat = null;
		ExecutionException eExp = null;
		String dataType = null;
		String fldVal = null;
		
		
		try
		{
			
			dataType = field.getDataType();
			fldVal = field.getValue();
			if (fldVal == null || "".equals(fldVal.trim()) )
				return fldVal;
			
			if ( IrisAdminConstants.DATA_TYPE_DATE.equals(dataType) ||  IrisAdminConstants.DATA_TYPE_DATETIME.equals(dataType))
			{
				dateFormat = new SimpleDateFormat(field.getFormat());
				
				/*
				 * if lenient is true & input date is like 2005-13-06 [yyyy-MM-dd] this date will get converted as like 2006-01-06 i.e. if month is
				 * more that 12 it will increase year by 1 instead of throwing parsing error, so set lenient to false
				 */
				dateFormat.setLenient(false);
				isoDateFormat = new SimpleDateFormat(DateUtils.ISO_DATEFORMAT);
				fldVal = isoDateFormat.format(new Date(dateFormat.parse(fldVal).getTime()));
			}
			
			
		}
		catch (ParseException exp)
		{
			
			eExp = new ExecutionException("err.irisadmin.format", new Object[]{ field.toString() }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
			
		}
		catch (Exception exp)
		{
			eExp = new ExecutionException("err.irisadmin.format", new Object[]{ field.toString() }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			dateFormat = null;
			isoDateFormat = null;
		}
		return fldVal;
	}
}
