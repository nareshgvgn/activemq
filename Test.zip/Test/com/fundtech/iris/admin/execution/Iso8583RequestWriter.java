/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : Iso8583RequestWriter.java
 * CREATED: Jun 21, 2015 11:39:08 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.IRequestReceiver;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: Iso8583RequestWriter.java,v 1.6 2015/12/21 04:43:52 ramap Exp $
 */
public class Iso8583RequestWriter extends AbstractDataWriter
{
	private static Logger logger = LoggerFactory.getLogger(Iso8583RequestWriter.class);
	private Writer fileWriter = null;
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public Iso8583RequestWriter()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.IWriter#writeData()
	 */
	@Override
	public Object writeData () throws ExecutionException
	{
		Map<String, InterfaceBandDef> pBandDefs = null;
		OutputStreamWriter writer = null;
		OutputStream outStream = null;
		ExecutionException eExp = null;
		
		try
		{
			pBandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			if (rootBand.getBatches().isEmpty())
			{
				
				jobData.setNoData(true);
				logger.warn("No Data Present!!!");
				jobData.setErrorCode("EMPTYNOGEN");
				return null;
			}
			
			convertToOutput(pBandDefs);
		}
		catch ( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.formatter", new Object[]
			{ "Un Known error" }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(writer);
			HelperUtils.doClose(outStream);
			cleanup();
		}
		return null;
	}
	
	/**
	 * This helper method creates a file from Process Data Bands
	 * @param writer
	 * @param pBandDefs
	 * @throws ExecutionException
	 */
	private void convertToOutput (Map<String, InterfaceBandDef> pBandDefs) throws ExecutionException
	{
		ExecutionException eExp = null;
		ContextManager contextManager = null;
		IRequestReceiver iRequestReceiver = null;
		Map<String, Object> sendParms = null;
		try
		{
			contextManager = ContextManager.getInstance();
			iRequestReceiver = (IRequestReceiver) contextManager.getBeanObject(jobData.getFilterParameter(IrisAdminConstants.ISO_SESSION_NAME));
			sendParms = new HashMap<String, Object>();
			sendParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
			sendParms.put(IrisAdminConstants.DATA_ROOT_BAND, rootBand);
			iRequestReceiver.sendMessage(sendParms);
		}
		
		
		catch (Exception exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("err.irisadmin.unknownError", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(fileWriter);
			CleanUpUtils.doClean(sendParms);
			fileWriter = null;
		}
	}
}
