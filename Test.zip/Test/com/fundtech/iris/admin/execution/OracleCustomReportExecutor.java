/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : OracleCustomReportExecutor.java
 * CREATED: Feb 24, 2015 3:54:08 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom2.Document;
import org.jdom2.output.XMLOutputter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.channel.IFileSender;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.report.ReportParameterDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.CustomReportUtilities;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: OracleCustomReportExecutor.java,v 1.9 2015/12/23 04:22:55 ramap Exp $
 */
public class OracleCustomReportExecutor extends OracleReportExecutor
{
	private static Logger logger = LoggerFactory.getLogger(OracleCustomReportExecutor.class);
	private static final String repColumnsSql =" select upper(preload_code) as preload_code,preload_value from gen_preload_mst gpm where "
			 +" gpm.preload_type= ? and applicable_flag='Y'";
	private String reportXmlFile = null;
	
	public OracleCustomReportExecutor()
	{
		super();
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.AbstractReportExecutor#checkPrerequisite(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Boolean checkPrerequisite (Connection dbConnection, Map<String, Object> parms) throws ExecutionException
	{
		RMJobData jobData = null;
		String colSelectjsonStr = null;
		ReportParameterDef selectDef = null;
		JSONObject tempJson = null;
		JSONObject colSelectJson = null;
		File rdfFile = null;
		Document  document = null;
		String parentReportCode = null;
		OutputStream outStream = null;
		XMLOutputter xmlOutput = null;
		IFileSender fileSender = null;
		List<String> filesList = null;
		ExecutionException eExp = null;
		Map<String, String> dynamicProperties = null;
		String staticReportsPath = null;
		
		try
		{
			jobData = (RMJobData) parms.get(IReportExecutor.EXECUTION_DATA);
			dynamicProperties = (Map<String, String>) parms.get(IReportExecutor.EXECUTION_STATIC_PROPS);
			staticReportsPath = dynamicProperties.get("REPORT_XMLS_PATH");
			selectDef = jobData.getReportParamDef("REPCOLS");
			colSelectjsonStr = selectDef.getColumnJson();
			tempJson = JSONObject.fromObject(colSelectjsonStr);
			parentReportCode = jobData.getParentSrcName();
			
			JSONArray jarray = (JSONArray) tempJson.get("lstBoxdata");
			
			if (jarray != null) 
				colSelectJson = JSONObject.fromObject(jarray.getString(1));
			else
				colSelectJson = tempJson;
			
			document = CustomReportUtilities.prepareCustomReportXML(colSelectJson, staticReportsPath + parentReportCode + ".xml");
			rdfFile = File.createTempFile(jobData.getExecutionId(), ".xml");
			outStream = new FileOutputStream(rdfFile);
			xmlOutput = new XMLOutputter();
			xmlOutput.output(document, outStream);
			filesList = new ArrayList<String>();
			reportXmlFile = rdfFile.getName();
			filesList.add(rdfFile.getAbsolutePath());
			fileSender = getFileSender(jobData);
			fileSender.sendFiles(filesList);
			return true;
		}
		catch (IOException exp)
		{
			eExp = new ExecutionException("iris.admin.report.custFtp", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			eExp = new ExecutionException("iris.admin.report.custFtp", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			if ( rdfFile != null)
				rdfFile.delete();
			CleanUpUtils.doClean(filesList);
			filesList = null;
			document = null;
			xmlOutput = null;
			HelperUtils.doClose(outStream);
			rdfFile = null;
		}
	}


	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.AbstractReportExecutor#getAdditionalParms(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Map<String, String> getAdditionalParms (Connection dbConnection, Map<String, Object> parms) throws ExecutionException
	{
		Map<String, String> returnMap = null;
		String sortColumns = null;
		String colOrderjsonStr = null;
		RMJobData jobData = null;
		String parentReportCode = null;
		String reportCode = null;
		ReportParameterDef sortDef = null;
		Map<String, String> paramColumns = null;
		String makerLocale = null;
		String parmCode = null;
		
		returnMap =  new HashMap<String, String>();
		returnMap.put("REPORT", reportXmlFile);
		
		jobData = (RMJobData) parms.get(IReportExecutor.EXECUTION_DATA);
		parentReportCode = jobData.getParentSrcName();
		makerLocale = jobData.getSysParameter("MAKER_LOCALE");
		makerLocale = IrisAdminUtils.getCorrectLocale(makerLocale);
		parmCode = "CUSTOMIZE";
		makerLocale = parentReportCode + "_"+ makerLocale + ".xml";
		returnMap.put(parmCode, makerLocale);
		
		reportCode = jobData.getSrcId();
		sortDef = jobData.getReportParamDef("REPORDER");
		colOrderjsonStr = sortDef.getColumnJson();
		try
		{
			paramColumns = getSortColumns(dbConnection, parentReportCode);
			sortColumns = CustomReportUtilities.prepareSortColumnParameter(parentReportCode, reportCode, colOrderjsonStr, paramColumns);
			if (sortColumns != null )
				returnMap.put("P_SORT", sortColumns);
		}
		finally
		{
			CleanUpUtils.doClean(paramColumns);
			paramColumns = null;
		}
		
		return returnMap;
	}
	
    
    /**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param parentReportCode
	 * @param colOrderjsonStr
	 * @return
	 * </pre></p>
	 */
	private Map<String, String> getSortColumns (Connection dbConnection, String parentReportCode)
	{
		PreparedStatement psParmColumns = null;
		ResultSet rsParmColumns = null;
		Map<String, String> returnMap = null;
		
		returnMap = new HashMap<String, String>();
		try
		{
			psParmColumns = dbConnection.prepareStatement(repColumnsSql);
			psParmColumns.clearParameters();
			psParmColumns.setString(1, parentReportCode);
			rsParmColumns = psParmColumns.executeQuery();
			while ( rsParmColumns.next())
			{
				returnMap.put(rsParmColumns.getString("preload_code"), rsParmColumns.getString("preload_value"));
			}
		}
		catch (SQLException exp)
		{
			logger.error("Error:", exp);
			// Not doing any thing coz sort will not appiede so that ereport generates 
			logger.warn("not able to execute sql{} and value is{} and error Message is{}", repColumnsSql, parentReportCode, exp.getMessage());
		}
		catch ( Exception exp)
		{
			logger.error("Error:", exp);
			// Not doing any thing coz sort will not appiede so that ereport generates 
			logger.warn("not able to execute sql{} and value is{} and error Message is{}", repColumnsSql, parentReportCode, exp.getMessage());
		}
		finally
		{
			HelperUtils.doClose(rsParmColumns);
			rsParmColumns = null;
			HelperUtils.doClose(psParmColumns);
			psParmColumns = null;
		}
		
		return returnMap;
	}

    private IFileSender getFileSender(RMJobData jobData) throws FileNotFoundException, BeanConfigException
    {
    	IFileSender fileSender = null;
    	
    	fileSender = (IFileSender) ContextManager.getInstance().getBeanObject(jobData.getFileSenderName());
    	return fileSender;
    }
}
