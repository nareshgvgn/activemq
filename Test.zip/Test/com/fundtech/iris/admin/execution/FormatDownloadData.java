/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : FormatDownloadData.java
 * CREATED: Jun 10, 2013 11:14:31 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceDef;

/**
 * This helper class checks the validation of the data and creates the file
 * 
 * @author Babu Paluri
 * @version $Id: FormatDownloadData.java,v 1.6 2014/07/20 04:58:21 ramap Exp $
 * @since 1.0.0
 */
public class FormatDownloadData
{
	private static Logger logger = LoggerFactory.getLogger(FormatDownloadData.class);
	private ApplicationContext appContext = null;
	private InterfaceDef interfaceDef = null;
	private ExecutionJobData jobData = null;
	private RootBand rootBand = null;
	
	@SuppressWarnings("unused")
	private FormatDownloadData()
	{
		// Do not allow
	}
	
	public FormatDownloadData(ApplicationContext appContext, InterfaceDef interfaceDef, ExecutionJobData jobData, RootBand rootBand)
	{
		this.appContext = appContext;
		this.interfaceDef = interfaceDef;
		this.jobData = jobData;
		this.rootBand = rootBand;
	}
	
	/**
	 * This helper method controls the all helper methods
	 * 
	 * @return
	 * @throws FormatException
	 */
	public Object formatData () throws FormatException
	{
		FormatException fExp = null;
		Map<String, InterfaceBandDef> pBandDefs = null;
		IFormatter iFormatter = null;
		String formatterClass = null;
		Class<?> clazz = null;
		
		try
		{
			formatterClass = interfaceDef.getFormatterClass();
			clazz = Class.forName(formatterClass);
			iFormatter = (IFormatter) clazz.newInstance();
			iFormatter.initialize(appContext, interfaceDef, jobData, null);
			pBandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			
			for (BatchBand batchBand : rootBand.getBatches())
			{
				applyValidations(pBandDefs, batchBand, iFormatter);
			}
			
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			fExp = new FormatException("error.iris.admin.formatter", new Object[]
			{ "Un Known error" }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			iFormatter.cleanup();
		}
		
		return null;// TODO need to work on this
	}
	
	/**
	 * TODO
	 * 
	 * @param bandDef
	 * @param batchBand
	 * @param formatter
	 */
	private void applyValidations (Map<String, InterfaceBandDef> pBandDefs, BatchBand batchBand, IFormatter iFormatter) throws FormatException
	{
		FormatException fExp = null;
		InterfaceBandDef bandDef = null;
		String bandName = null;
		try
		{
			for (Band dataBand : batchBand.getBatchBands())
			{
				
				bandName = dataBand.getName();
				bandDef = pBandDefs.get(bandName);
				iFormatter.downloadFormat(batchBand, bandDef, dataBand);
			}
		}
		
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			fExp = new FormatException("error.iris.admin.formatter", new Object[]
			{ "Un Known error", bandName }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
	}
}
