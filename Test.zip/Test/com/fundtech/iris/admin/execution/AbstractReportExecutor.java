/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : AbstractReportExecutor.java
 * CREATED: Jul 5, 2015 6:10:12 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.report.ReportParameterDef;
import com.fundtech.iris.admin.report.plugins.SysReportPasswordPlugin;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.fundtech.iris.admin.util.ReportParameterUtils;
import com.fundtech.iris.admin.util.StringUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AbstractReportExecutor.java,v 1.8 2016/10/06 07:34:42 ramap Exp $
 */
public abstract class AbstractReportExecutor implements IReportExecutor
{
	private static Logger logger = LoggerFactory.getLogger(AbstractReportExecutor.class);
	private String passwordBeanName = null;
	
	public abstract Object executeReport (Connection dbConnection, Map<String, Object> parms) throws ExecutionException;
	public abstract Object checkPrerequisite(Connection dbConnection, Map<String, Object> parms) throws ExecutionException;
	public abstract Map<String, String> getAdditionalParms(Connection dbConnection, Map<String, Object> parms) throws ExecutionException;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public AbstractReportExecutor()
	{
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.IReportExecutor#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> parms) throws ExecutionException
	{
		
		if ( (Boolean) checkPrerequisite(dbConnection, parms))
			return executeReport (dbConnection, parms);
		
			return null;
	}
	
	protected String formatURL (Connection dbConnection, Map<String, Object> parms) throws ExecutionException
	{
		StringBuffer sBuffer = null;
		Iterator<String> keyItr = null;
		StringTokenizer tokenizer = null;
		Map<String, String> reportParameters = null;
		String objConnectString = null;
		String opString = null;
		String pdfPass = null;
		ExecutionException eExp = null;
		String reportURL = null;
		RMJobData jobData = null;
		Map<String, String> dynamicProperties = null;
		String repServerName = null;
		String outType = null;
		
		try
		{
			jobData = (RMJobData) parms.get(IReportExecutor.EXECUTION_DATA);
			outType = jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE);
			dynamicProperties = (Map<String, String>) parms.get(IReportExecutor.EXECUTION_STATIC_PROPS);
			passwordBeanName = dynamicProperties.get("REPORT_PWD_BEAN_NAME");
			repServerName = dynamicProperties.get("REPORT_SERVER_NAME");
			reportURL = dynamicProperties.get("ORACLE_REPORT_URL");
			sBuffer = new StringBuffer(reportURL + "?");
			opString = getOracleCommand(jobData, getOracleFormat(jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE)));
			if (opString != null)
			{
				tokenizer = new StringTokenizer(opString, " ");
				while (tokenizer.hasMoreTokens())
				{
					sBuffer.append(tokenizer.nextToken().trim() + "&");
				}
			}
			pdfPass = getPassword(dbConnection, parms);
			
			if (!StringUtils.isEmpty(pdfPass) && "PDF".equals(outType))
			{
				if (logger.isInfoEnabled())
					logger.info("User password is supplied, will password protect the PDF!");
				sBuffer.append("PDFUSER");
				sBuffer.append("=");
				sBuffer.append(pdfPass);
				sBuffer.append("&");
			}
			objConnectString = getDbConnectionString(jobData);
			
			sBuffer.append(objConnectString);
			if ( repServerName != null)
				sBuffer.append("&server=" + repServerName);
			
			reportParameters = setOracleParams(dbConnection, parms);
			
			if (reportParameters != null && !reportParameters.isEmpty())
			{
				keyItr = reportParameters.keySet().iterator();
				while (keyItr.hasNext())
				{
					String paramName = keyItr.next();
					String paramValue = reportParameters.get(paramName);
					sBuffer.append("&");
					sBuffer.append(paramName);
					sBuffer.append("=");
					sBuffer.append(getParamEncodeString(paramValue));
				}
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.formattingURL", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			keyItr = null;
			tokenizer = null;
			reportParameters = null;
		}
		return sBuffer.toString();
	}
	
	protected String getDbConnectionString (RMJobData jobData)
	{
		String userId = null;
		String dbPass = null;
		String serverName = null;
		String connectionString = null;
		
		userId = jobData.getDbUser();
		dbPass = jobData.getDbPass();
		serverName = jobData.getRepDdUrl();
		if (serverName == null)
			serverName = jobData.getDbUrl();
		
		connectionString = "userid=" + getParamEncodeString(userId) + "/" + getParamEncodeString(dbPass) + "@" + getParamEncodeString(serverName);
		return connectionString;
	}
	
	protected String getOracleFormat (String outType)
	{
		
		if ("PDF".equals(outType))
			return outType;
		else if ("XLS".equals(outType))
			return "delimitedDATA&mimetype=application/vnd.ms-excel";
		else if ("HTML".equals(outType))
			return "HTML";
		else if ("CSV".equals(outType))
			return "DELIMITEDDATA DELIMITER=,";
		else if ("REPRUN".equals(outType))
			return "SCREEN";
		else if ("PRINT".equals(outType))
			return "PDF";
		else if ("RTF".equals(outType))
			return "RTF";
		else
			return "DELIMITED DELIMITER=none";
	}
	
	protected String getOracleCommand (RMJobData jobData, String format) throws ExecutionException
	{
		String command = null;
		String outType = null;
		
		outType = jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE);
		if (!format.equals("SCREEN"))
		{
			if (outType.trim().equalsIgnoreCase("PRINT"))
				command = "desformat=PDF&destype=cache";
			else
				command = "desformat=" + format + "&destype=cache";
		}
		getReportFileName(jobData);
		jobData.setParamString(command);
		
		return command;
	}
	
	/**
	 * The purpose of this method is to form the report file name.
	 * 
	 * @param dataObject
	 * @return
	 * @throws NodeProcessingException
	 */
	protected String getReportFileName (RMJobData jobData) throws ExecutionException
	{
		String fileName = null;
		String entityCode = null;
		String reportCode = null;
		String fileNameExtn = null;
		String executionId = null;
		String tempDir = null;
		File file = null;
		ExecutionException eExp = null;
		
		try
		{
			executionId = jobData.getExecutionId();
			entityCode = jobData.getEntityCode();
			reportCode = jobData.getSrcId();
			fileNameExtn = jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE);
			
			// Replace Spaces and brackets from EntityCode
			if (entityCode != null)
			{
				entityCode = entityCode.replace('(', '_');
				entityCode = entityCode.replace(')', '_');
				entityCode = entityCode.replaceAll(" ", "");
			}
			else
			{
				entityCode = "";
			}
			
			fileName = entityCode + "_" + reportCode  + "_" + executionId + "." + fileNameExtn;
			tempDir = jobData.getFtpPath();
			file = new File(tempDir, fileName);
			jobData.setOutFileName(file.getAbsolutePath());
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.genFileName", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			reportCode = null;
		}
		return fileName;
	}
	
	protected Map<String, String> setOracleParams (Connection dbConnection, Map<String, Object> parms) throws ExecutionException
	{
		StringBuilder paramString = null;
		String parmCode = null;
		HashMap<String, String> parameterList = null;
		ExecutionException nodeExp = null;
		Map<String, ReportParameterDef> reportParmDefs = null;
		ReportParameterDef parmDef = null;
		String parmValue = null;
		Map<String, String> additionalParms = null;
		RMJobData jobData = null;
		
		try
		{
			jobData = (RMJobData) parms.get(IReportExecutor.EXECUTION_DATA);
			paramString = new StringBuilder();
			parameterList = new HashMap<String, String>();
			reportParmDefs = jobData.getReportParmDefs();
			for (Map.Entry<String, ReportParameterDef> entry : reportParmDefs.entrySet())
			{
				parmCode = entry.getKey();
				parmDef = entry.getValue();
				
				if ( parmDef.getDataType().equals("DATE"))
					parmValue = ReportParameterUtils.getDateValueString(parmCode, jobData, parmDef);
				else if ( parmDef.getDataType().equals("TEXT"))
					parmValue = ReportParameterUtils.getTextValueString(parmCode, jobData, parmDef);
				else if ( parmDef.getDataType().equals("DECIMAL"))
					parmValue = ReportParameterUtils.getDecimalValueString(parmCode, jobData, parmDef);
				else if ( parmDef.getDataType().equals("NUMBER"))
					parmValue = ReportParameterUtils.getNumberValueString(parmCode, jobData, parmDef);
				else if ( parmDef.getDataType().equals("JSON"))
					continue;// Ignore, no need to do anny thing
				
				if ( parmValue != null && ! "".equals(parmValue) && ! "null".equals(parmValue))
				{
					paramString.append(" " + parmCode + "=\"" + parmValue + "\"");
					parameterList.put(parmCode, parmValue);
				}
				else
					logger.trace(" Parameter Code: {}  ignored as there is no value polulated", parmCode);
			}
			
			additionalParms = getAdditionalParms(dbConnection, parms);
			if ( additionalParms != null)
			{
				for (Map.Entry<String, String> entry : additionalParms.entrySet())
				{
					parmCode = entry.getKey();
					parmValue = entry.getValue();
					paramString.append(" " + parmCode + "=\"" + parmValue + "\"");
					parameterList.put(parmCode, parmValue);
				}
			}
			
			parmValue = jobData.getSysParameter("MAKER_LOCALE");
			parmValue =  IrisAdminUtils.getCorrectLocale(parmValue);
			parmCode = "ENVID";
			paramString.append(" " + parmCode + "=\"" + parmValue + "\"");
			parameterList.put(parmCode, parmValue);
			return parameterList;
			
		}
		catch (Exception e)
		{
			nodeExp = new ExecutionException("error.rm.CreateReportParameters", new Object[]{  }, e);
			logger.error(IRISLogger.getText(nodeExp));
			throw nodeExp;
		}
		finally
		{
			CleanUpUtils.doClean(paramString);
		}
	}
	
	/**
	 * Helper function to URLEncode a given string.
	 * 
	 * @param pstrToEncode
	 *            the string to be URLEncoded.
	 * @return the URLEncoded string.
	 */
	protected String getParamEncodeString (String pstrToEncode)
	{
		String strTemp = null;
		
		try
		{
			strTemp = URLEncoder.encode(pstrToEncode, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
			if (logger.isWarnEnabled())
				logger.warn("Unexpected error has occurred while encoding the string " + pstrToEncode, ex);
			strTemp = pstrToEncode;
		}
		return strTemp;
	}
	
	private String getPassword(Connection dbConnection, Map<String, Object> parms)
	{
		String password = null;
		IPlugin passwordBean = null;
		
		try
		{
			if ( passwordBeanName == null)
				passwordBean = new SysReportPasswordPlugin();
			else
				passwordBean = ( IPlugin) ContextManager.getInstance().getBeanObject(passwordBeanName);
			
			password = (String) passwordBean.execute(dbConnection, parms);
		}
		catch (BeanConfigException e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		catch (FileNotFoundException e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		catch (FormatException e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		catch (ExecutionException e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		catch ( Exception e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		
		return password;
	}
}
