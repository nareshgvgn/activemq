/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : AbstractDataReader.java
 * CREATED: Aug 8, 2013 10:50:34 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: AbstractDataReader.java,v 1.14 2016/08/04 05:35:42 ramap Exp $
 * @since 1.0.0
 */
public abstract class AbstractDataReader implements IReader
{
	private static Logger logger = LoggerFactory.getLogger(AbstractDataReader.class);
	protected ApplicationContext appContext = null;
	protected InterfaceDef interfaceDef = null;
	protected ExecutionJobData jobData = null;
	protected ZeroProofings zeroProofings = null;
	private Map<String, IFormatter> formatterMap = new HashMap<String, IFormatter>();
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IReader#initialize(com.cashtech.iris.contexts.ApplicationContext,
	 * com.fundtech.iris.admin.interfaces.InterfaceDef, com.fundtech.iris.admin.data.ExecutionJobData, com.fundtech.iris.admin.data.ZeroProofings)
	 */
	public void initialize (ApplicationContext appContext, InterfaceDef interfaceDef, ExecutionJobData jobData, ZeroProofings zeroProofings)
	{
		this.appContext = appContext;
		this.interfaceDef = interfaceDef;
		this.jobData = jobData;
		this.zeroProofings = zeroProofings;
	}
	
	public RootBand readData () throws FormatException
	{
		RootBand rootBand = null;
		FormatException fExp = null;
		
		try
		{
			rootBand = formatData();
			
			// throws errors if reader and formatters completed their tasks and accumulated erros
			if (!jobData.getErrors().isEmpty())
			{
				jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
				fExp = new FormatException("fileprocessingerrors", new Object[] {}, null);
				throw fExp;
			}
		}
		catch (FormatException exp)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
			throw exp;
		}
		finally
		{
			cleanupFormatter();
		}
		
		return rootBand;
	}
	
	public abstract RootBand formatData () throws FormatException;
	
	public IFormatter getFormatterInstance (InterfaceBandDef bandDef) throws FormatException
	{
		String formatterClass = null;
		Class<?> clazz = null;
		IFormatter iFormatter = null;
		String dataStoreName = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		try
		{
			dataStoreName = bandDef.getMediumName();
			if (formatterMap.containsKey(dataStoreName))
				iFormatter = formatterMap.get(dataStoreName);
			else
			{
				formatterClass = bandDef.getFormatterClass();
				clazz = Class.forName(formatterClass);
				iFormatter = (IFormatter) clazz.newInstance();
				iFormatter.initialize(appContext, interfaceDef, jobData, zeroProofings);
				formatterMap.put(dataStoreName, iFormatter);
				
			}
		}
		catch (ClassNotFoundException exp)
		{
			errorMsg = "FormatterClass:" + formatterClass + " not found";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString() }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, bandDef.toString(), null);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (InstantiationException exp)
		{
			errorMsg = "FormatterClass:" + formatterClass + " not able to Instantiation";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString() }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, bandDef.toString(), null);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (IllegalAccessException exp)
		{
			errorMsg = "FormatterClass:" + formatterClass + " not able to access";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg, bandDef.toString() }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, bandDef.toString(), null);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error While getting FormatterClass:" + formatterClass;
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg, bandDef.toString() }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, bandDef.toString(), null);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		return iFormatter;
	}
	
	public void cleanupFormatter ()
	{
		for (IFormatter formatter : formatterMap.values())
		{
			formatter.cleanup();
		}
	}
	
	/**
	 * This helper method creates the file stream
	 * 
	 * @param fileSource
	 * @return
	 * @throws FileNotFoundException
	 * @throws UnsupportedEncodingException
	 */
	public Object identifyFile (String fileSource) throws FileNotFoundException, UnsupportedEncodingException
	{
		Reader reader = null;
		InputStream in = null;
		String mediaType = null;
		
		mediaType = jobData.getMediumType();
		if (IrisAdminConstants.MEDIA_FILE.equals(mediaType))
		{
			logger.debug("Processing File:{}", fileSource);
			if (isFile(fileSource))
			{
				in = new FileInputStream((String) fileSource);
				reader = new InputStreamReader(in, jobData.getCharSet());
				jobData.setMessageData(null);
				return reader;
			}
			else
				throw new FileNotFoundException(fileSource + " Not found!");
		}
		else if (IrisAdminConstants.MEDIA_MQ.equals(mediaType))
		{
			in = new ByteArrayInputStream(fileSource.getBytes(jobData.getCharSet()));
			reader = new InputStreamReader(in, jobData.getCharSet());
			jobData.setMessageData(null);
			return reader;
		}
		else if (IrisAdminConstants.MEDIA_WEBSERVICE.equals(mediaType))
		{
			in = new ByteArrayInputStream(fileSource.getBytes(jobData.getCharSet()));
			reader = new InputStreamReader(in, jobData.getCharSet());
			jobData.setMessageData(null);
			return reader;
		}
		else if (IrisAdminConstants.MEDIA_HTTP_RESPONSE.equals(mediaType))
		{
			in = new ByteArrayInputStream(fileSource.getBytes(jobData.getCharSet()));
			reader = new InputStreamReader(in, jobData.getCharSet());
			jobData.setMessageData(null);
			return reader;
		}
		else if (IrisAdminConstants.MEDIA_ISO.equals(mediaType))
		{
			return null; //do nothing..
		}
			
		else
			throw new FileNotFoundException(fileSource + " Not found!");
		
	}
	
	/**
	 * This helper method checks the input is a file or not
	 * 
	 * @param str
	 * @return
	 */
	public boolean isFile (final String str)
	{
		return new File(str).isFile();
	}
}
