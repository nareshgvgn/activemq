/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : FileWriter.java
 * CREATED: Oct 14, 2013 12:42:12 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.IRequestReceiver;
import com.fundtech.iris.admin.channel.sftp.SFTPFilesSender;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.hooks.IProcessHook;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: FileWriter.java,v 1.39 2017/01/30 04:50:14 ramap Exp $
 * @since 1.0.0
 */
public class FileWriter extends AbstractDataWriter
{
	private static Logger logger = LoggerFactory.getLogger(FileWriter.class);
	private String previousFileName = null;
	private boolean isGenerated = false;
	private IProcessHook fileGenHook = null;
	private Map<String, Object> hookData = new HashMap<String, Object>();
	private Connection hookDBConnection = null;
	private Writer fileWriter = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IWriter#writeData()
	 */
	public Object writeData () throws ExecutionException
	{
		Map<String, InterfaceBandDef> pBandDefs = null;
		OutputStreamWriter writer = null;
		OutputStream outStream = null;
		ExecutionException eExp = null;
		String fileNameClass = null;
		String fileName = null;
		String filePath = null;
		File outFile = null;
		String emptyFile = null;
		String errorMsg = null;
		IrisError irisError = null;
		
		try
		{
			pBandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			
			hookDBConnection = getDBConnection();
			hookData.put(IProcessHook.EXECUTION_DATA, jobData);
			hookData.put(IProcessHook.DATA_ROOT_BAND, rootBand);
			hookData.put(IProcessHook.FILE_GEN_FILTER_PARMS, getFileGenFilterParms());
			hookData.put(IProcessHook.FILE_GEN_INT_FIELDS, getFileGenInternalParms());
			emptyFile = jobData.getFilterParameter(IrisAdminConstants.FILTER_EMPTY_FILE);
			
			if (rootBand.getBatches().isEmpty())
			{
				
				if (IrisAdminConstants.CONSTANT_Y.equals(emptyFile))
				{
					if (IrisAdminConstants.EMPTYFILENAMEGEN_FLAG_YES == interfaceDef.isEmptyFileRequired())
						fileNameClass = interfaceDef.getEmptyFileNameClass();
					else
						fileNameClass = jobData.getParm(IrisAdminConstants.CUST_GEN_EMPTY_FILE);
					
					fileGenHook = getFileNameGenerator(fileNameClass);
					fileName = (String) fileGenHook.execute(hookDBConnection, hookData);
					filePath = jobData.getMediaDetails();
					outFile = new File(filePath, fileName);
					jobData.addSplitFile(outFile.getAbsolutePath());
					outStream = new FileOutputStream(outFile);
					writer = new OutputStreamWriter(outStream, jobData.getCharSet());
					if (logger.isDebugEnabled())
						logger.error("Empty file generated:" + outFile.getAbsolutePath());
					jobData.setErrorCode("EMPTYGEN");
					jobData.setMediaDetails(outFile.getAbsolutePath());
				}
				else
				{
					jobData.setNoData(true);
					logger.warn("No Data Present!!!");
					jobData.setErrorCode("EMPTYNOGEN");
				}
				return null;
			}
			
			if (IrisAdminConstants.FILENAMEGEN_FLAG_YES == interfaceDef.isGenFileNameRequired())
				fileNameClass = interfaceDef.getFileNameClass();
			else
				fileNameClass = jobData.getParm(IrisAdminConstants.CUST_GEN_DATA_FILE);
			
			if (interfaceDef.isSplitRequired())
				hookData.put(IProcessHook.SPLIT_FILE_PARMS, getSplitParms());
			
			fileGenHook = getFileNameGenerator(fileNameClass);
			convertToOutput(pBandDefs);
		}
		catch ( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (SystemException exp)
		{
			jobData.setStatus("E");
			logger.error("Error While getting database connection");
			eExp = new ExecutionException("err.irisadmin.dbConnection", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("err.irisadmin.unknownError", new Object[] {errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(writer);
			HelperUtils.doClose(outStream);
			cleanup();
		}
		return null;
	}
	
	/**
	 * This helper method creates a file from Process Data Bands
	 * @param writer
	 * @param pBandDefs
	 * @throws ExecutionException
	 */
	private void convertToOutput (Map<String, InterfaceBandDef> pBandDefs) throws ExecutionException
	{
		String delimiter = null;
		String qualifier = null;
		ExecutionException eExp = null;
		boolean isFirst = false;
		ContextManager contextManager = null;
		IRequestReceiver jmsSender = null;
		SFTPFilesSender sftpSender = null;
		String mediumType = null;
		Map<String, Object> inputParms = null;
		String errorMsg = null;
		IrisError irisError = null;
		String beanName = null;
		
		try
		{
			delimiter = interfaceDef.getDelimiter();
			qualifier = interfaceDef.getQualifier();
			mediumType = interfaceDef.getMediumType();
			
			for (BatchBand batchBand : rootBand.getBatches())
			{
				hookData.put(IProcessHook.EXECUTION_BATCH, batchBand);
				isFirst = writeToStream();
				batchBand.doWriteText(fileWriter, delimiter, qualifier, pBandDefs, isFirst);
				fileWriter.flush();
			}
			
			if (IrisAdminConstants.MEDIA_MQ.equals(mediumType))
			{
				inputParms = new HashMap<String, Object>();
				contextManager = ContextManager.getInstance();
				beanName = jobData.getFilterParameter(IrisAdminConstants.JMS_SESSION_NAME);
				if (beanName == null )
				{
					errorMsg = "MQ Queue details not configured ";
					eExp = new ExecutionException("error.iris.admin.NoQdetails", new Object[] {IrisAdminConstants.JMS_SESSION_NAME},null);
					logger.error(IRISLogger.getText(eExp));
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					throw eExp;
				}
				
				jmsSender = (IRequestReceiver) contextManager.getBeanObject(beanName);
				jobData.setMessageData(fileWriter.toString());
				inputParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				jmsSender.sendMessage(inputParms);
			}
			
			if (IrisAdminConstants.MEDIA_WEBSERVICE.equals(mediumType))
			{
				inputParms = new HashMap<String, Object>();
				contextManager = ContextManager.getInstance();
				beanName = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_SESSION_NAME);
				if (beanName == null )
				{
					errorMsg = "WebService details not configured ";
					eExp = new ExecutionException("error.iris.admin.NoQdetails", new Object[] {IrisAdminConstants.WEBSERVICE_SESSION_NAME},null);
					logger.error(IRISLogger.getText(eExp));
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					throw eExp;
				}
				
				jmsSender = (IRequestReceiver) contextManager.getBeanObject(beanName);
				jobData.setMessageData(fileWriter.toString());
				inputParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				jmsSender.sendMessage(inputParms);
			}
			else if ( IrisAdminConstants.MEDIA_FTP.equals(mediumType))
			{
				beanName = jobData.getFilterParameter(IrisAdminConstants.FTP_RESOURCE_NAME);
				if (beanName.isEmpty() && "CLIENT".equals(jobData.getEntityType()))
				{
					//Client 
				}
				else
				{
					contextManager = ContextManager.getInstance();
					sftpSender = (SFTPFilesSender) contextManager.getBeanObject(beanName);
					sftpSender.sendFiles(jobData.getSplitFileList());
				}
			}
			else if ( IrisAdminConstants.MEDIA_HTTP_CW.equals(mediumType))
			{
				jobData.setMessageData(fileWriter.toString());
			}
		}
		
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch ( BeanConfigException exp)
		{
			errorMsg = "Error While accessing Bean Object" + beanName;
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]	{errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("err.irisadmin.unknownError", new Object[] {errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(fileWriter);
			fileWriter = null;
			CleanUpUtils.doClean(inputParms);
		}
	}
	
	/**
	 * <p>This helper method create a Stream either file outStream or String Writer stream for MQ
	 * <p> <i> In this method, we check the same file returns if split file enabled</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @return
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private boolean writeToStream () throws ExecutionException
	{
		String fileName = null;
		String filePath = null;
		File outFile = null;
		OutputStream outStream = null;
		boolean isFirst = false;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisError irisError = null;
		String fullFile = null;
		
		try
		{
			isFirst = true;
			if (interfaceDef.isSplitRequired())
			{
				fileName = (String) fileGenHook.execute(hookDBConnection, hookData);
				if (!fileName.equals(previousFileName))
				{
					if (previousFileName != null)
						isFirst = false;
					HelperUtils.doClose(fileWriter);
					fileWriter = null;
					previousFileName = fileName;
					isFirst = false; 
				}
				else
					isFirst = true;
			}
			else if (!isGenerated)
			{
				fileName = (String) fileGenHook.execute(hookDBConnection, hookData);
				isGenerated = true;
				isFirst = true;
			}
			if (fileWriter == null)
			{
				isFirst = false;
				if (IrisAdminConstants.MEDIA_FILE.equals(interfaceDef.getMediumType()) || IrisAdminConstants.MEDIA_FTP.equals(interfaceDef.getMediumType()))
				{
					filePath = jobData.getMediaDetails();
					outFile = new File(filePath, fileName);
					fullFile = outFile.getAbsolutePath();
					if (jobData.isSplitFile())
						jobData.addSplitFile(outFile.getAbsolutePath());
					else
						jobData.addSplitFile(outFile.getAbsolutePath());
					
					outStream = new FileOutputStream(outFile);
					fileWriter = new OutputStreamWriter(outStream, jobData.getCharSet());
					if (logger.isDebugEnabled())
						logger.error("File generated:" + outFile.getAbsolutePath());
					
				}
				else if (IrisAdminConstants.MEDIA_MQ.equals(interfaceDef.getMediumType()) || 
						IrisAdminConstants.MEDIA_WEBSERVICE.equals(interfaceDef.getMediumType()) || IrisAdminConstants.MEDIA_HTTP_CW.equals(interfaceDef.getMediumType()))
					fileWriter = new StringWriter();
			}
		}
		catch (FileNotFoundException exp)
		{
			errorMsg = " File not found" + fullFile;
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]	{errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (UnsupportedEncodingException exp)
		{
			errorMsg = " Unsupported Encoding:" + jobData.getCharSet();
			eExp = new ExecutionException("error.iris.admin.unsupported", new Object[]	{ errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.unknown", new Object[]	{errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		return isFirst;
	}
}
