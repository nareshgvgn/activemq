/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : Iso8583ResponseReader.java
 * CREATED: Jun 24, 2015 6:27:35 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.data.ZeroProofing;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: Iso8583ResponseReader.java,v 1.4 2016/04/07 05:34:44 ramap Exp $
 */
public class Iso8583ResponseReader extends AbstractDataReader
{
	private static Logger logger = LoggerFactory.getLogger(Iso8583ResponseReader.class);
	
	/**
	 * This method is a controller for file reading and creating process data bands
	 * 
	 * @return
	 * @throws FormatException
	 * @throws ExecutionException
	 */
	public RootBand formatData () throws FormatException
	{
		long lineNum = 0;
		Deque<InterfaceBandDef> defStack = null;
		Deque<Band> dataStack = null;
		RootBand rootBand = null;
		FormatException fExp = null;
		ZeroProofing zeroProofing = null;
		Map<String, ZeroProofing> zProofings = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		Object inputData = null;
		
		try
		{
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "Before loading file Data");
			defStack = new ArrayDeque<InterfaceBandDef>();
			dataStack = new ArrayDeque<Band>();
			rootBand = new RootBand();
			inputData = jobData.getDataObject();
			
			
			format(lineNum, inputData, defStack, dataStack, rootBand);
			zProofings = zeroProofings.getZeroProofings();
			// Zero Proofing check
			for (Map.Entry<String, ZeroProofing> entry : zProofings.entrySet())
			{
				zeroProofing = entry.getValue();
				if (null != zeroProofing)
				{
					if (zeroProofing.checkProof())
					{
						if (logger.isDebugEnabled())
							logger.debug("Zero Proofing matched for Band:" + zeroProofing.getPrimeBandName() + " & Field:"
									+ zeroProofing.getPrimeFieldName());
					}
					else
					{
						errorMsg = "Zero proofing failed for " + "Prime Field:" + zeroProofing.getPrimeFieldName() + " Prime Value:"
								+ zeroProofing.getPrimeValue() + " Source Field Name:" + zeroProofing.getSourceFieldName() + " Source Value:"
								+ zeroProofing.getSourceValue();
						fExp = new FormatException("err.irisadmin.zeroproofing", new Object[] { errorMsg }, fExp);
						error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_FORMAT, errorMsg, null, null);
						irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						logger.error(IRISLogger.getText(fExp));
						if (!jobData.isAccumulateErros())
							throw fExp;
					}
				}
			}
			
			getLastbatchBand(dataStack, rootBand);
			validateRootBands(rootBand);
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		
		catch (Exception exp)
		{
			errorMsg = "Error while reading file" + jobData.getMediaDetails();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			
			if (dataStack != null)
				dataStack.clear();
			if (defStack != null)
				defStack.clear();
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "After loading file Data");
		}
		
		return rootBand;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param rootBand
	 * </pre>
	 * 
	 * </p>
	 */
	private void validateRootBands (RootBand rootBand) throws FormatException
	{
		Map<String, InterfaceBandDef> bandDefs = null;
		String errorMsg = null;
		IrisAdminError error = null;
		FormatException fExp = null;
		IrisError irisError = null;
		
		bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
		for (InterfaceBandDef parentBandDef : bandDefs.values())
		{
			if (parentBandDef.isMandatory())
			{
				for (Band dataBand : rootBand.getBatchBands())
				{
					if (dataBand.getChildBands(parentBandDef.getBandName()) == null)
					{
						errorMsg = "Mandatory Band:" + parentBandDef.getBandName() + " ID:" + parentBandDef.getBandId() + " is not present.";
						fExp = new FormatException("err.irisadmin.format", new Object[]
						{ errorMsg, parentBandDef.toString() }, null);
						error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, parentBandDef.toString(), null);
						irisError = IrisAdminUtils.createIrisError(parentBandDef.getBandType(), parentBandDef.getBandName(), errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						logger.error(IRISLogger.getText(fExp));
						throw fExp;
					}
				}
			}
		}
	}
	
	private boolean format (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack, RootBand rootBand)
			throws FormatException, ExecutionException
	{
		Map<String, InterfaceBandDef> bandDefs = null;
		IFormatter iFormatter = null;
		boolean isProcessed = false;
		InterfaceBandDef bandDef = null;
		Band dataBand = null;
		FormatException fExp = null;
		boolean isRightBandFound = true;
		String bandValue = null;
		Map<String, InterfaceBandDef> childBandDefs = null;
		String bandDefId = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		try
		{
			while (isRightBandFound)
			{
				if (defStack.isEmpty())
				{
					bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
					for (InterfaceBandDef parentBandDef : bandDefs.values())
					{
						iFormatter = getFormatterInstance(parentBandDef);
						if (iFormatter.isBandExits(obj, parentBandDef))
						{
							defStack.addFirst(parentBandDef);
							isProcessed = (Boolean) iFormatter.uploadFormat(lineNumber, obj, defStack, dataStack);
							break;
						}
						else if (parentBandDef.isMandatory())
						{
							if (!dataStack.isEmpty())
							{
								dataBand = dataStack.peekFirst();
								if (dataBand.getChildBands(parentBandDef.getBandName()) == null)
								{
									errorMsg = "Mandatory Band:" + parentBandDef.getBandName() + " ID:" + parentBandDef.getBandId()
											+ " is not present.";
									fExp = new FormatException("err.irisadmin.format", new Object[]
									{ errorMsg }, null);
									error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, obj);
									jobData.addError(error);
									irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
									jobData.addIrisError(irisError);
									logger.error(IRISLogger.getText(fExp));
									throw fExp;
								}
							}
							else
							{
								errorMsg = "Mandatory Band:" + parentBandDef.getBandName() + " ID:" + parentBandDef.getBandId() + " is not present.";
								fExp = new FormatException("err.irisadmin.format", new Object[]
								{ errorMsg }, null);
								error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null,  obj);
								irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
								jobData.addIrisError(irisError);
								jobData.addError(error);
								logger.error(IRISLogger.getText(fExp));
								throw fExp;
							}
						}
						continue;
					}
					if (!isProcessed)
					{
						errorMsg = "Given Band not found. Please check.";
						fExp = new FormatException("err.irisadmin.format", new Object[]
						{ errorMsg }, null);
						error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null,  obj);
						irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						logger.error(IRISLogger.getText(fExp));
						throw fExp;
					}
				}
				else
				{
					bandDef = defStack.removeFirst();
					dataBand = dataStack.removeFirst();
					iFormatter = getFormatterInstance(bandDef);
					bandValue = iFormatter.getBandId(obj, bandDef);
					bandDefId = bandDef.getBandId();
					if (bandDefId != null && bandDefId.equals(bandValue))
					{
						if (isValidBand(bandDef, dataBand, lineNumber, (String) obj))
						{
							defStack.addFirst(bandDef);
							dataStack.addFirst(dataBand);
							isProcessed = (Boolean) iFormatter.uploadFormat(lineNumber, obj, defStack, dataStack);
						}
					}
					else
					{
						childBandDefs = bandDef.getChildDefinitions().getBandDefinitions();
						for (InterfaceBandDef childBandDef : childBandDefs.values())
						{
							iFormatter = getFormatterInstance(childBandDef);
							if (iFormatter.isBandExits(obj, childBandDef))
							{
								defStack.addFirst(bandDef);
								dataStack.addFirst(dataBand);
								defStack.addFirst(childBandDef);
								isProcessed = (Boolean) iFormatter.uploadFormat(lineNumber, obj, defStack, dataStack);
								break;
							}
							else if (childBandDef.isMandatory())
							{
								if (dataBand.getChildBands(childBandDef.getBandName()) == null)
								{
									errorMsg = "Mandatory Band:" + childBandDef.getBandName() + " ID:" + childBandDef.getBandId()
											+ " is not present.";
									fExp = new FormatException("err.irisadmin.format", new Object[]
									{ errorMsg }, null);
									error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg,
											childBandDef.toString(),  obj);
									irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
									jobData.addIrisError(irisError);
									jobData.addError(error);
									logger.error(IRISLogger.getText(fExp));
									throw fExp;
								}
							}
							else
								continue;
						}
						if (!isProcessed)
							format(lineNumber, obj, defStack, dataStack, rootBand);
					}
				}
				isRightBandFound = false;
			}
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		
		return isProcessed;
	}
	
	/*-------------------------------------------------------------------------------------------------*
	 * HELPER METHODS
	 *------------------------------------------------------------------------------------------------*/
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandDef
	 * @param dataBand
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private boolean isValidBand (InterfaceBandDef bandDef, Band dataBand, long lineNumber, String obj) throws FormatException
	{
		Map<String, InterfaceBandDef> childBandDefs = null;
		String errorMsg = null;
		FormatException fExp = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		try
		{
			
			childBandDefs = bandDef.getChildDefinitions().getBandDefinitions();
			for (InterfaceBandDef childBandDef : childBandDefs.values())
			{
				if (childBandDef.isMandatory())
					if (dataBand.getChildBands(childBandDef.getBandName()) == null)
					{
						errorMsg = "Mandatory Band:" + childBandDef.getBandName() + " ID:" + childBandDef.getBandId() + " is not present.";
						fExp = new FormatException("err.irisadmin.format", new Object[]
						{ errorMsg }, null);
						error = IrisAdminUtils.createError(lineNumber, IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, childBandDef.toString(),
								 obj);
						irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						logger.error(IRISLogger.getText(fExp));
						throw fExp;
					}
				
			}
		}
		finally
		{
			obj = null;
		}
		
		return true;
	}
	
	/**
	 * This helper method adds last band to its parent
	 * 
	 * @param dataStack
	 * @param rootBand
	 */
	private void getLastbatchBand (Deque<Band> dataStack, RootBand rootBand)
	{
		Band batchBand = null;
		boolean isRoot = true;
		while (isRoot)
		{
			batchBand = dataStack.removeFirst();
			if (dataStack.isEmpty())
				isRoot = false;
		}
		if (batchBand.getParentBand() == null)
			rootBand.addBatchBands(batchBand);
	}
	
	/**
	 * This helper method removed first few chars of BOM-UTF notation
	 * 
	 * @param readLine
	 * @return
	 */
	private String escapeSplChars (String readLine)
	{
		String var = "\ufeff";
		readLine = readLine.replace(var, "");
		return readLine;
	}
	
}
