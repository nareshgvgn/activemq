/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : AbstractReportExecutor.java
 * CREATED: Jun 12, 2014 2:50:51 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.report.ReportParameterDef;
import com.fundtech.iris.admin.report.plugins.SysReportPasswordPlugin;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: OracleReportExecutorOld.java,v 1.15 2016/12/08 11:25:39 ramap Exp $
 */
@Deprecated
public class OracleReportExecutorOld implements IReportExecutor
{
	private static Logger logger = LoggerFactory.getLogger(OracleReportExecutorOld.class);
	private String passwordBeanName = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IReportExecutor#execute(java.sql.Connection, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> parms) throws ExecutionException
	{
		String servletURL = null;
		String reportURL = null;
		URL url = null;
		HttpURLConnection httpConnection = null;
		int responseCode = 0;
		RMJobData jobData = null;
		Map<String, String> dynamicProperties = null;
		ExecutionException eExp = null;
		String cType = null;
		int cntLen = -1;
		boolean isHtml = false;
		String outType = null;
		
		try
		{
			jobData = (RMJobData) parms.get(IReportExecutor.EXECUTION_DATA);
			dynamicProperties = (Map<String, String>) parms.get(IReportExecutor.EXECUTION_STATIC_PROPS);
			passwordBeanName = dynamicProperties.get("REPORT_PWD_BEAN_NAME");
			servletURL = dynamicProperties.get("ORACLE_REPORT_URL");
			
			if (servletURL != null)
			{
				reportURL = formatURL(servletURL, jobData, dbConnection, parms);
				logger.debug("Report URL{}", reportURL);
				url = new URL(reportURL);
				httpConnection = getHttpConnection(url);
				responseCode = httpConnection.getResponseCode();
				logger.info("ResponseCode:{}", responseCode);
				logger.info("Response Message:{}", httpConnection.getResponseMessage());
				if (responseCode != HttpURLConnection.HTTP_OK)
				{
					logger.error("Report Execution Failed. For more details check " + "report Server logs" + responseCode);
					throw new Exception("err.app.ReportExecutionFailed with responseCode:" + responseCode);
				}
				else
				{
					cType = httpConnection.getContentType();
					cntLen = httpConnection.getContentLength();
					outType = jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE);
					
					if ("HTML".equals(outType))
						isHtml = true;
					
					if (cntLen > 0)
						logger.info("Expecting {} bytes in response!", Integer.valueOf(cntLen));
					
					if ((!isHtml && (cType != null && cType.startsWith("text/html")) || null == cType))
					{
						writeFile(httpConnection, jobData, true);
						logger.error("Error while generatinng report. Please check:" + jobData.getOutFileName() + ".html");
						eExp = new ExecutionException("error.iris.admin.errorreport", new Object[]{ jobData.getOutFileName() }, null);
						logger.error(IRISLogger.getText(eExp));
						throw eExp;
					}
					else
						writeFile(httpConnection, jobData, false);
					
				}
				
			}
		}
		catch (ExecutionException ex)
		{
			throw ex;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.oracleReportExecute", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			if (httpConnection != null)
				httpConnection.disconnect();
		}
		return null;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private String getDbConnectionString (RMJobData jobData)
	{
		String userId = null;
		String dbPass = null;
		String serverName = null;
		String connectionString = null;
		
		userId = jobData.getDbUser();
		dbPass = jobData.getDbPass();
		serverName = jobData.getRepDdUrl();
		if (serverName == null)
			serverName = jobData.getDbUrl();
		
		connectionString = "userid=" + userId + "/" + dbPass + "@" + serverName;
		return connectionString;
	}
	
	private String getOracleFormat (String outType)
	{
		
		if ("PDF".equals(outType))
			return outType;
		else if ("XLS".equals(outType))
			return "delimitedDATA&mimetype=application/vnd.ms-excel";
		else if ("HTML".equals(outType))
			return "HTML";
		else if ("CSV".equals(outType))
			return "DELIMITEDDATA DELIMITER=,";
		else if ("REPRUN".equals(outType))
			return "SCREEN";
		else if ("PRINT".equals(outType))
			return "PDF";
		else if ("RTF".equals(outType))
			return "RTF";
		else
			return "DELIMITED DELIMITER=none";
	}
	
	private String getOracleCommand (RMJobData jobData, String format) throws ExecutionException
	{
		String command = null;
		String outType = null;
		String fileName = null;
		
		outType = jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE);
		if (!format.equals("SCREEN"))
		{
			if (outType.trim().equalsIgnoreCase("PRINT"))
				command = "desformat=PDF&destype=FILE";
			else
				command = "desformat=" + format + "&destype=FILE";
		}
		else if (format.equals("SCREEN"))
		{
			command = "desformat=" + format + "&destype=PREVIEW";
		}
		
		if (format.equals("SCREEN"))
			command = command + "&desname= SCREEN";
		else if (!format.equals("SCREEN"))
		{
			fileName = getReportFileName(jobData);
			command = command + "&desname=" + fileName;
		}
		jobData.setParamString(command);
		
		return command;
	}
	
	private Map<String, String> setOracleParams (RMJobData jobData) throws ExecutionException
	{
		StringBuilder paramString = null;
		String defaultValue = null;
		HashMap<String, String> parameterList = null;
		ExecutionException nodeExp = null;
		Map<String, String> reportParms = null;
		Map<String, ReportParameterDef> reportParmDefs = null;
		String parmCode = null;
		String parmOperator = null;
		ReportParameterDef def = null;
		String[] splitData = null;
		String inputValue = null;
		
		try
		{
			paramString = new StringBuilder();
			reportParmDefs = jobData.getReportParmDefs();
			parameterList = new HashMap<String, String>();
			reportParms = jobData.getReportParameters();
			
			for (Map.Entry<String, ReportParameterDef> entry : reportParmDefs.entrySet())
			{
				parmCode = entry.getKey();
				def  = entry.getValue();
				
				// This condition to handle if Parameter code and LHS name not same
				if ("USER".equalsIgnoreCase(parmCode) || "SELLER".equalsIgnoreCase(parmCode) || "CORPORATION".equalsIgnoreCase(parmCode) || "CLIENT".equalsIgnoreCase(parmCode))
				{
					parmCode = def.getReportColumnName();
				}
				
				inputValue = reportParms.get(parmCode);
				if ( inputValue == null)
					continue;
				splitData = StringUtils.split(inputValue, "|");
				parmOperator = splitData[0];
				
				if (IrisAdminConstants.EQUAL.equals(parmOperator))
				{
					defaultValue = splitData[1];
				}
				else
					defaultValue = parmOperator;
				
				if (defaultValue != null)
				{
					if (defaultValue.trim().equalsIgnoreCase("(ALL)"))
					{
						defaultValue = null;
					}
					else if (defaultValue.equals("LAST_GEN_DATE"))
					{
						defaultValue = jobData.getSysParameter(IrisAdminConstants.SYS_PREV_GEN_DATE);
						
					}
					else if (defaultValue.trim().equalsIgnoreCase("NEXT_GEN_DATE"))
					{
						defaultValue = jobData.getSysParameter(IrisAdminConstants.SYS_NEXT_GEN_DATE);
					}
					else if (defaultValue.trim().equalsIgnoreCase("FUT_GEN_DATE"))
					{
						defaultValue = jobData.getSysParameter(IrisAdminConstants.SYS_FUT_GEN_DATE);
					}
					else if (defaultValue.trim().equalsIgnoreCase("PREV_APPL_DATE"))
					{
						defaultValue = getFormatedDateTime("dd/MM/yyyy", getDate(jobData.getReportParameter(IrisAdminConstants.SYS_PREV_APP_DATE)));
					}
					else if (defaultValue.trim().equalsIgnoreCase("SYS_APPL_DATE"))
					{
						defaultValue = getFormatedDateTime("dd/MM/yyyy", getDate(jobData.getReportParameter(IrisAdminConstants.SYS_APP_DATE)));
					}
					
					if (defaultValue != null)
					{
						paramString.append(" " + parmCode + "=\"" + defaultValue + "\"");
						parameterList.put(parmCode, defaultValue);
					}
					
				}
			}
			
			defaultValue = jobData.getSysParameter("MAKER_LOCALE");
			defaultValue = IrisAdminUtils.getCorrectLocale(defaultValue);
			parmCode = "ENVID";
			paramString.append(" " + parmCode + "=\"" + defaultValue + "\"");
			parameterList.put(parmCode, defaultValue);
			
			parmCode = "CUSTOMIZE";
			defaultValue = jobData.getSrcId() + "_"+ defaultValue + ".xml";
			paramString.append(" " + parmCode + "=\"" + defaultValue + "\"");
			parameterList.put(parmCode, defaultValue);
			
			jobData.setParamString(paramString.toString());
			return parameterList;
		}
		catch (Exception e)
		{
			nodeExp = new ExecutionException("error.rm.CreateReportParameters", new Object[]
			{ "process_hooks", }, e);
			logger.error(IRISLogger.getText(nodeExp));
			throw nodeExp;
		}
		finally
		{
		}
	}
	
	/**
	 * The purpose of this method is to form the report file name.
	 * 
	 * @param dataObject
	 * @return
	 * @throws NodeProcessingException
	 */
	private String getReportFileName (RMJobData jobData) throws ExecutionException
	{
		String time = null;
		String sysDate = null;
		String fileName = null;
		String entityCode = null;
		String reportCode = null;
		String fileNameExtn = null;
		String executionId = null;
		String tempDir = null;
		File file = null;
		ExecutionException eExp = null;
		
		try
		{
			
			// sysDate = getFormatedDateTime("yyMMdd", getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE)));
			sysDate = getFormatedDateTime("yyMMdd", Calendar.getInstance().getTime());
			time = getFormatedDateTime("hhmmss", new Date(System.currentTimeMillis()));
			executionId = jobData.getExecutionId();
			entityCode = jobData.getEntityCode();
			reportCode = jobData.getSrcId();
			fileNameExtn = jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE);
			
			// Replace Spaces and brackets from EntityCode
			if (entityCode != null)
			{
				entityCode = entityCode.replace('(', '_');
				entityCode = entityCode.replace(')', '_');
				entityCode = entityCode.replaceAll(" ", "");
			}
			else
			{
				entityCode = "";
			}
			
			fileName = entityCode + reportCode + sysDate + time + "_" + executionId + "." + fileNameExtn;
			tempDir = jobData.getFtpPath();
			file = new File(tempDir, fileName);
			jobData.setOutFileName(file.getAbsolutePath());
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.genFileName", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			time = null;
			sysDate = null;
			reportCode = null;
		}
		return fileName;
	}
	
	private String getFormatedDateTime (String format, java.util.Date date)
	{
		SimpleDateFormat dateformatter = new SimpleDateFormat(format);
		return dateformatter.format(date);
		
	}
	
	private Date getDate (String value) throws ParseException
	{
		Date date = null;
		SimpleDateFormat sdf = null;
		
		if (value.trim().length() > 10)
		{
			sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		}
		else
		{
			sdf = new SimpleDateFormat("dd/MM/yyyy");
		}
		date = sdf.parse(value);
		return date;
	}
	
	private String formatURL (String reportURL, RMJobData jobData, Connection dbConnection, Map<String, Object> parms) throws ExecutionException
	{
		StringBuffer sBuffer = null;
		Iterator<String> keyItr = null;
		StringTokenizer tokenizer = null;
		Map<String, String> reportParameters = null;
		String objConnectString = null;
		String opString = null;
		String pdfPass = null;
		ExecutionException eExp = null;
		String outType = null;
		
		try
		{
			outType = jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE);
			sBuffer = new StringBuffer(reportURL + "?");
			sBuffer.append("cmdkey=");
			
			sBuffer.append(jobData.getSrcId() + "&");
			opString = getOracleCommand(jobData, getOracleFormat(jobData.getJobParameter(IrisAdminConstants.JOB_OUTPUT_TYPE)));
			if (opString != null)
			{
				tokenizer = new StringTokenizer(opString, " ");
				while (tokenizer.hasMoreTokens())
				{
					sBuffer.append(tokenizer.nextToken().trim() + "&");
				}
			}
			pdfPass = getPassword(dbConnection, parms);
			if (!StringUtils.isEmpty(pdfPass) && "PDF".equals(outType))
			{
				if (logger.isInfoEnabled())
					logger.info("User password is supplied, will password protect the PDF!");
				sBuffer.append("PDFUSER");
				sBuffer.append("=");
				sBuffer.append(pdfPass);
				sBuffer.append("&");
			}
			objConnectString = getDbConnectionString(jobData);
			
			sBuffer.append(objConnectString);
			reportParameters = setOracleParams(jobData);
			
			if (reportParameters != null && !reportParameters.isEmpty())
			{
				keyItr = reportParameters.keySet().iterator();
				while (keyItr.hasNext())
				{
					String paramName = keyItr.next();
					String paramValue = reportParameters.get(paramName);
					sBuffer.append("&");
					sBuffer.append(paramName);
					sBuffer.append("=");
					sBuffer.append(getParamEncodeString(paramValue));
				}
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.formattingURL", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			keyItr = null;
			tokenizer = null;
			reportParameters = null;
		}
		return sBuffer.toString();
	}
	
	private HttpURLConnection getHttpConnection (URL url) throws ExecutionException
	{
		HttpURLConnection httpConnection = null;
		ExecutionException eExp = null;
		try
		{
			httpConnection = (HttpURLConnection) url.openConnection();
			httpConnection.setRequestMethod("GET");
			httpConnection.setDoOutput(true);
			httpConnection.setConnectTimeout(10000);
			httpConnection.setReadTimeout(1000000);
			httpConnection.connect();
		}
		catch (SocketTimeoutException ex)
		{
			eExp = new ExecutionException("error.iris.admin.report.HTTPConnectionTimeout", new Object[] {}, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IOException ex)
		{
			eExp = new ExecutionException("error.iris.admin.report.createHTTPConnection", new Object[] {}, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.report.unknown", new Object[] {}, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		return httpConnection;
	}
	
	private void writeFile (HttpURLConnection httpConnection, RMJobData jobData, boolean isError) throws ExecutionException
	{
		FileOutputStream outStream = null;
		BufferedOutputStream out = null;
		InputStream in = null;
		ExecutionException eExp = null;
		String fileName = null;
		try
		{
			in = httpConnection.getInputStream();
			fileName = jobData.getOutFileName();
			if ( isError)
				fileName = fileName + ".html";
			
			outStream = new FileOutputStream(fileName);
			out = new BufferedOutputStream(outStream);
			int i = 0;
			while ((i = in.read()) != -1)
			{
				out.write(i);
				out.flush();
			}
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.writetoFile", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(in);
			HelperUtils.doClose(out);
			HelperUtils.doClose(outStream);
		}
	}
	
	/**
	 * Helper function to URLEncode a given string.
	 * 
	 * @param pstrToEncode
	 *            the string to be URLEncoded.
	 * @return the URLEncoded string.
	 */
	private String getParamEncodeString (String pstrToEncode)
	{
		String strTemp = null;
		
		try
		{
			strTemp = URLEncoder.encode(pstrToEncode, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
			if (logger.isWarnEnabled())
				logger.warn("Unexpected error has occurred while encoding the string " + pstrToEncode, ex);
			strTemp = pstrToEncode;
		}
		return strTemp;
	}
	
	private String getPassword(Connection dbConnection, Map<String, Object> parms)
	{
		String password = null;
		IPlugin passwordBean = null;
		
		try
		{
			if ( passwordBeanName == null)
				passwordBean = new SysReportPasswordPlugin();
			else
				passwordBean = ( IPlugin) ContextManager.getInstance().getBeanObject(passwordBeanName);
			
			password = (String) passwordBean.execute(dbConnection, parms);
		}
		catch (BeanConfigException e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		catch (FileNotFoundException e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		catch (FormatException e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		catch (ExecutionException e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		catch ( Exception e)
		{
			logger.error("Bean not configured, ignoring exception", e);
		}
		
		return password;
	}
}
