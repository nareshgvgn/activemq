/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : AbstractDataWriter.java
 * CREATED: Oct 14, 2013 12:38:01 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.hooks.IProcessHook;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.interfaces.RoutineParameter;
import com.fundtech.iris.admin.interfaces.SplitParameter;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: AbstractDataWriter.java,v 1.14 2015/11/02 12:23:02 ramap Exp $
 * @since 1.0.0
 */
public abstract class AbstractDataWriter implements IWriter
{
	private static Logger logger = LoggerFactory.getLogger(AbstractDataWriter.class);
	protected ApplicationContext appContext = null;
	protected InterfaceDef interfaceDef = null;
	protected ExecutionJobData jobData = null;
	protected RootBand rootBand = null;
	private Connection dbConnection = null;
	private ConnectionProvider conProvider = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IWriter#initialize(com.cashtech.iris.contexts.ApplicationContext,
	 * com.fundtech.iris.admin.interfaces.InterfaceDef, com.fundtech.iris.admin.data.ExecutionJobData, com.fundtech.iris.admin.data.ZeroProofings)
	 */
	public void initialize (ApplicationContext appContext, InterfaceDef interfaceDef, ExecutionJobData jobData, RootBand rootBand)
	{
		this.appContext = appContext;
		this.interfaceDef = interfaceDef;
		this.jobData = jobData;
		this.rootBand = rootBand;
		
	}
	
	/**
	 * TODO
	 */
	public List<String> getSplitParms ()
	{
		List<SplitParameter> splitList = null;
		String fldVal = null;
		String bandName = null;
		String fieldName = null;
		List<String> output = null;
		output = new ArrayList<String>();
		jobData.setSplitFile(true);
		splitList = interfaceDef.getSplitParameters();
		for (SplitParameter splitparm : splitList)
		{
			bandName = splitparm.getBandName();
			fieldName = splitparm.getFieldName();
			fldVal = bandName + "." + fieldName;
			output.add(fldVal);
			fldVal = null;
		}
		return output;
	}
	
	/**
	 * TODO
	 * 
	 * @return
	 */
	public List<String> getFileGenInternalParms ()
	{
		List<String> filterParms = null;
		List<RoutineParameter> routineParms = null;
		String fldName = null;
		String bandName = null;
		
		routineParms = interfaceDef.getRoutineParameters(IrisAdminConstants.FILENAME_GEN_ROUTINE);
		if (routineParms == null)
			return null;
		
		filterParms = new ArrayList<String>();
		for (RoutineParameter parms : routineParms)
		{
			if ("I".equals(parms.getParameterType()))
			{
				fldName = parms.getFieldRef();
				bandName = parms.getBandRef();
				fldName = bandName + "." + fldName;
				filterParms.add(fldName);
				fldName = null;
			}
		}
		
		return filterParms;
	}
	
	/**
	 * TODO
	 * 
	 * @return
	 */
	public List<String> getFileGenFilterParms ()
	{
		List<String> filterParms = null;
		List<RoutineParameter> routineParms = null;
		String fldName = null;
		
		routineParms = interfaceDef.getRoutineParameters(IrisAdminConstants.FILENAME_GEN_ROUTINE);
		if (routineParms == null)
			return null;
		
		filterParms = new ArrayList<String>();
		for (RoutineParameter parms : routineParms)
		{
			
			if ("F".equals(parms.getParameterType()))
			{
				
				fldName = parms.getFieldRef();
				filterParms.add(fldName);
			}
		}
		return filterParms;
	}
	
	public IProcessHook getFileNameGenerator (String fileNameGenClass) throws ExecutionException
	{
		Class<?> clazz = null;
		IProcessHook fileGenHook = null;
		ExecutionException eExp = null;
		
		try
		{
			clazz = Class.forName(fileNameGenClass);
			fileGenHook = (IProcessHook) clazz.newInstance();
			fileGenHook.initialize();
		}
		catch (ClassNotFoundException exp)
		{
			logger.error("Error While assigning Ref Value");
			eExp = new ExecutionException("err.irisadmin.filegen", new Object[]	{ "Class:" + fileNameGenClass }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (InstantiationException exp)
		{
			logger.error("Error While assigning Ref Value");
			eExp = new ExecutionException("err.irisadmin.filegen", new Object[]	{ "Class:" + fileNameGenClass }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IllegalAccessException exp)
		{
			logger.error("Error While assigning Ref Value");
			eExp = new ExecutionException("err.irisadmin.filegen", new Object[]	{ "Class:" + fileNameGenClass }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (FormatException exp)
		{
			logger.error("Error While assigning Ref Value");
			eExp = new ExecutionException("err.irisadmin.filegen", new Object[]	{ "Class:" + fileNameGenClass }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
			// TODO do what?
		}
		
		return fileGenHook;
	}
	
	public void cleanup ()
	{
		close(conProvider, dbConnection);
		
	}
	
	public Connection getDBConnection () throws SystemException
	{
		conProvider = getDBProvider();
		dbConnection = conProvider.getConnection();
		
		return dbConnection;
	}
	
	/**
	 * TODO
	 * 
	 * @param provider
	 * @param tmpConnection
	 */
	private void close (ConnectionProvider provider, Connection tmpConnection)
	{
		try
		{
			if (tmpConnection != null)
				provider.releaseConnection(tmpConnection);
			
		}
		catch (Exception exp)
		{
			logger.error("Error:",exp);
			// DO NOTHING
		}
		finally
		{
			provider = null;
		}
	}
	
	/**
	 * TODO
	 * 
	 * @return
	 * @throws SystemException
	 */
	private ConnectionProvider getDBProvider () throws SystemException
	{
		if (conProvider == null)
			conProvider = new ConnectionProviderAdapter(appContext.getResourceFinder(), ResourceTypeEnum.DB_CONN, ResourceTypeEnum.IRIS_DATABASE);
		
		return conProvider;
	}
}
