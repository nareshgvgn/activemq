/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : IReader.java
 * CREATED: Aug 8, 2013 10:35:45 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import com.cashtech.iris.contexts.ApplicationContext;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceDef;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: IReader.java,v 1.4 2014/07/20 04:58:21 ramap Exp $
 * @since 1.0.0
 */
public interface IReader
{
	public void initialize (ApplicationContext appContext, InterfaceDef interfaceDef, ExecutionJobData jobData, ZeroProofings zeroProofings);
	
	public RootBand readData () throws FormatException;
	
}
