/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : SwiftReader.java
 * CREATED: Feb 13, 2014 2:35:58 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.Reader;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.data.ZeroProofing;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: SwiftReader.java,v 1.6 2016/04/07 05:34:44 ramap Exp $
 */
public class SwiftReader extends AbstractDataReader
{
	private static Logger logger = LoggerFactory.getLogger(SwiftReader.class);
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public SwiftReader()
	{
	}
	
	/**
	 * This method is a controller for file reading and creating process data bands
	 * 
	 * @return
	 * @throws FormatException
	 * @throws ExecutionException
	 */
	public RootBand formatData () throws FormatException
	{
		Reader reader = null;
		BufferedReader buffReader = null;
		Scanner fileScanner = null;
		String line = null;
		long lineNum = 0;
		Deque<InterfaceBandDef> defStack = null;
		Deque<Band> dataStack = null;
		RootBand rootBand = null;
		FormatException fExp = null;
		ZeroProofing zeroProofing = null;
		String error = null;
		Map<String, ZeroProofing> zProofings = null;
		Map<String, String> bandTags = null;
		
		try
		{
			reader = (Reader) identifyFile(jobData.getMediaDetails());
			buffReader = new BufferedReader(reader);
			fileScanner = new Scanner(buffReader);
			fileScanner.useDelimiter("\\{1:");
			defStack = new ArrayDeque<InterfaceBandDef>();
			dataStack = new ArrayDeque<Band>();
			rootBand = new RootBand();
			while (fileScanner.hasNext())
			{
				line = fileScanner.next();
				line = "{1:" + line;
				lineNum++;
				if (logger.isTraceEnabled())
					logger.trace(line);
				
				bandTags = checkBandValues(line);
				format(lineNum, bandTags, defStack, dataStack, rootBand);
			}
			zProofings = zeroProofings.getZeroProofings();
			// Zero Proofing check
			for (Map.Entry<String, ZeroProofing> entry : zProofings.entrySet())
			{
				zeroProofing = entry.getValue();
				if (null != zeroProofing)
				{
					if (zeroProofing.checkProof() == false)
					{
						fExp = new FormatException("err.irisadmin.zeroproofing", new Object[]
						{ "Prime Field:" + zeroProofing.getPrimeFieldName(), "Prime Value:" + zeroProofing.getPrimeValue(),
								"Source Field Name:" + zeroProofing.getSourceFieldName(), "Source Vale:" + zeroProofing.getSourceValue() }, fExp);
						
						throw fExp;
					}
				}
			}
			
			getLastbatchBand(dataStack, rootBand);
		}
		catch (FormatException exp)
		{
			// error = jobData.getErrorMsg();
			// jobData.setErrorMsg(error + "  at line number:" + lineNum);
			throw exp;
		}
		
		catch (FileNotFoundException exp)
		{
			// jobData.setErrorMsg("File:" + jobData.getMediaDetails() + " not found");
			fExp = new FormatException("error.iris.admin.format", new Object[]
			{ "File:" + jobData.getMediaDetails() + " not found" }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			// error = jobData.getErrorMsg();
			// jobData.setErrorMsg(error + "  at line number:" + lineNum);
			fExp = new FormatException("error.iris.admin.format", new Object[]
			{ "Error At line Number:" + lineNum }, exp);
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			
			HelperUtils.doClose(buffReader);
			HelperUtils.doClose(reader);
			if (dataStack != null)
				dataStack.clear();
			if (defStack != null)
				defStack.clear();
			line = null;
		}
		
		return rootBand;
	}
	
	private boolean format (long lineNumber, Object obj, Deque<InterfaceBandDef> defStack, Deque<Band> dataStack, RootBand rootBand)
			throws FormatException, ExecutionException
	{
		Map<String, InterfaceBandDef> bandDefs = null;
		IFormatter iFormatter = null;
		boolean isProcessed = false;
		InterfaceBandDef bandDef = null;
		Band dataBand = null;
		FormatException fExp = null;
		boolean isRightBandFound = true;
		String bandValue = null;
		Map<String, InterfaceBandDef> childBandDefs = null;
		String bandDefId = null;
		
		try
		{
			while (isRightBandFound)
			{
				if (defStack.size() < 1)
				{
					bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
					for (InterfaceBandDef parentBandDef : bandDefs.values())
					{
						iFormatter = getFormatterInstance(parentBandDef);
						if (iFormatter.isBandExits(obj, parentBandDef))
						{
							defStack.addFirst(parentBandDef);
							isProcessed = (Boolean) iFormatter.uploadFormat(lineNumber, obj, defStack, dataStack);
							break;
						}
						else
							continue;
					}
					if (!isProcessed)
					{
						// jobData.setErrorMsg("Given Band not found. Please check. Band Value");
						logger.error("Given Band not found. Please check. Band Value");
						fExp = new FormatException("error.iris.admin.format", new Object[]
						{ "DATA:" + (String) obj }, null);
						logger.error(IRISLogger.getText(fExp));
						throw fExp;
					}
				}
				else
				{
					bandDef = defStack.removeFirst();
					dataBand = dataStack.removeFirst();
					iFormatter = getFormatterInstance(bandDef);
					bandValue = iFormatter.getBandId(obj, bandDef);
					bandDefId = bandDef.getBandId();
					if (bandDefId != null && bandDefId.equals(bandValue))
					{
						defStack.addFirst(bandDef);
						dataStack.addFirst(dataBand);
						isProcessed = (Boolean) iFormatter.uploadFormat(lineNumber, obj, defStack, dataStack);
					}
					else
					{
						childBandDefs = bandDef.getChildDefinitions().getBandDefinitions();
						for (InterfaceBandDef childBandDef : childBandDefs.values())
						{
							iFormatter = getFormatterInstance(childBandDef);
							if (iFormatter.isBandExits(obj, childBandDef))
							{
								defStack.addFirst(bandDef);
								dataStack.addFirst(dataBand);
								defStack.addFirst(childBandDef);
								isProcessed = (Boolean) iFormatter.uploadFormat(lineNumber, obj, defStack, dataStack);
								break;
							}
							else
								continue;
						}
						if (!isProcessed)
							format(lineNumber, obj, defStack, dataStack, rootBand);
					}
				}
				isRightBandFound = false;
			}
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		
		return isProcessed;
	}
	
	/*-------------------------------------------------------------------------------------------------*
	 * HELPER METHODS
	 *------------------------------------------------------------------------------------------------*/
	
	/**
	 * This helper method adds last band to its parent
	 * 
	 * @param dataStack
	 * @param rootBand
	 */
	private void getLastbatchBand (Deque<Band> dataStack, RootBand rootBand)
	{
		Band batchBand = null;
		boolean isRoot = true;
		while (isRoot)
		{
			batchBand = dataStack.removeFirst();
			if (dataStack.size() < 1)
				isRoot = false;
		}
		if (batchBand.getParentBand() == null)
			rootBand.addBatchBands(batchBand);
	}
	
	private Map<String, String> checkBandValues (String line)
	{
		Pattern pattern = null;
		Matcher matcher = null;
		String tempVal = null;
		String value = null;
		String key = null;
		Map<String, String> bandTagValues = null;
		
		pattern = Pattern.compile("\\{[12345]:.*?\\}\\}?");
		matcher = pattern.matcher(line);
		bandTagValues = new HashMap<String, String>();
		while (matcher.find())
		{
			tempVal = matcher.group(0);
			key = tempVal.substring(0, 3);
			value = tempVal.substring(3, tempVal.length() - 1);
			bandTagValues.put(key, value);
		}
		return bandTagValues;
	}
}
