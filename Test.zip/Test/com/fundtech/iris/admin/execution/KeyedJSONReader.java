/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : KeyedJSONReader.java
 * CREATED: Dec 14, 2016 1:06:29 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.Reader;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;

/**
 * <p>
 * This Class reads the {@code}{@link JSONObject} String by using KeyedJSONReader. Large files can be read by using this class
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into medium_mst (MEDIUM_TYPE, MODEL_TYPE, FORMAT_TYPE, MEDIUM_NAME, DESCRIPTION, LINE_SEPARATOR, EXECUTION_CLASS, FORMATTER_CLASS, VALID_FLAG)
 * values ('REST_RES', 'U', 'JSON', 'JSON', 'JSON Format', null, 'com.fundtech.iris.admin.execution.KeyedJSONReader', 'com.fundtech.iris.admin.execution.formatter.KeyedJSONFormatter', 'Y');
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: KeyedJSONReader.java,v 1.1 2017/01/30 04:50:14 ramap Exp $
 */
public class KeyedJSONReader  extends AbstractDataReader
{
	
	private Logger logger = LoggerFactory.getLogger(KeyedJSONReader.class);

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.execution.AbstractDataReader#formatData()
	 */
	@Override
	public RootBand formatData () throws FormatException
	{
		Map<String, InterfaceBandDef> bandDefs = null;
		String bandName = null;
		JSONArray jsonArray = null;
		Object obj = null;
		FormatException fExp = null;
		Deque<InterfaceBandDef> defStack = null;
		Deque<Band> dataStack = null;
		Band batchBand = null;
		RootBand rootBand = null;
		IFormatter iFormatter = null;
		String formatterClass = null;
		Class<?> clazz = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		Reader reader = null;
		JSONObject  parentJson = null;
		JSONObject  jsonObj = null;
		long countLines = 1;
		String recivedMessage = null;
		
		try
		{
			recivedMessage = (String) jobData.getMessageData();
			parentJson = (JSONObject) JSONValue.parseWithException(recivedMessage);
			bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			defStack = new ArrayDeque<InterfaceBandDef>();
			dataStack = new ArrayDeque<Band>();
			formatterClass = interfaceDef.getFormatterClass();
			clazz = Class.forName(formatterClass);
			iFormatter = (IFormatter) clazz.newInstance();
			iFormatter.initialize(appContext, interfaceDef, jobData, zeroProofings);
			rootBand = new RootBand();
			batchBand = new Band();
			dataStack.addFirst(batchBand);
			for (InterfaceBandDef bandDef : bandDefs.values())
			{
				bandName = bandDef.getBandName();
				defStack.addFirst(bandDef);
				obj = parentJson.get(bandName);
				if (obj instanceof JSONObject)
				{
					jsonArray = new JSONArray();
					jsonArray.add((JSONObject) obj);
				}
				else if (obj instanceof JSONArray)
				{
					jsonArray = (JSONArray) obj;
				}
				
				if (jsonArray == null)
				{
					errorMsg = bandDef.getBandName() + " or " + bandName + " Doersn't have any data in xml";
					fExp = new FormatException("err.irisadmin.format", new Object[] { errorMsg, bandDef.toString() }, null);
					error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, bandDef.toString(), null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					logger.error(IRISLogger.getText(fExp));
					throw fExp;
				}
				
				for (int index = 0; null != jsonArray && index < jsonArray.size(); index++)
				{
					jsonObj = (JSONObject)jsonArray.get(index);
					iFormatter.uploadFormat(countLines, jsonObj, defStack, dataStack);
					countLines ++;
				}
			}
			batchBand = dataStack.removeFirst();
			rootBand.addBatchBands(batchBand);
			iFormatter.cleanup();
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error while reading file" + jobData.getMediaDetails();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			HelperUtils.doClose(reader);
			
			if (dataStack != null)
				dataStack.clear();
			if (defStack != null)
				defStack.clear();
			
			if (iFormatter != null)
				iFormatter.cleanup();
			
			iFormatter = null;
		}
		return rootBand;
	}
	
	public final IrisAdminError createError (String errCode, String errMsg, String info1, String errLine)
	{
		IrisAdminError error = null;
		
		error = new IrisAdminError(0, IrisAdminConstants.ERR_TYPE_ERROR, errCode, errMsg, info1, errLine);
		return error;
	}
}
