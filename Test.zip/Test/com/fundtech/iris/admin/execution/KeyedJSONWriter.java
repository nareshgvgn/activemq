/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : KeyedJSONWriter.java
 * CREATED: Dec 14, 2016 4:43:03 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.MappingField;
import com.fundtech.iris.admin.channel.IRequestReceiver;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.DataField;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;

/**
 * <p>
 * This Class reads the {@code}{@link JSONObject} String by using KeyedJSONReader. Large files can be read by using this class
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into medium_mst (MEDIUM_TYPE, MODEL_TYPE, FORMAT_TYPE, MEDIUM_NAME, DESCRIPTION, LINE_SEPARATOR, EXECUTION_CLASS, FORMATTER_CLASS, VALID_FLAG)
 * values ('REST_REQ', 'D', 'JSON', 'JSON', 'JSON Format', null, 'com.fundtech.iris.admin.execution.KeyedJSONWriter', 'com.fundtech.iris.admin.execution.formatter.DelimiterDownloadFormatter', 'Y');
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: KeyedJSONWriter.java,v 1.1 2017/01/30 04:50:14 ramap Exp $
 */
public class KeyedJSONWriter extends AbstractDataWriter
{
	
	private static Logger logger = LoggerFactory.getLogger(KeyedJSONWriter.class);
	private boolean emptytagsRequired = false;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public KeyedJSONWriter()
	{
		// BABU Auto-generated constructor stub
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IWriter#writeData()
	 */
	public Object writeData () throws ExecutionException
	{
		Map<String, InterfaceBandDef> pBandDefs = null;
		OutputStreamWriter writer = null;
		OutputStream outStream = null;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisError irisError = null;
		String removeEmptyTags = "FALSE";
		
		try
		{
			if (jobData.getFilterParameters().containsKey(IrisAdminConstants.REMOVE_EMPTY_ELEMENTS) )
				removeEmptyTags = jobData.getFilterParameter(IrisAdminConstants.REMOVE_EMPTY_ELEMENTS);
			if ( IrisAdminConstants.CONSTANT_YES.equalsIgnoreCase(removeEmptyTags) || IrisAdminConstants.CONSTANT_TRUE.equalsIgnoreCase(removeEmptyTags))
					emptytagsRequired = true;
			
			pBandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			if (rootBand.getBatches().isEmpty())
			{
				jobData.setNoData(true);
				logger.warn("No Data Present!!!");
				jobData.setErrorCode("EMPTYNOGEN");
				return null;
			}
			convertToOutput(pBandDefs);
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("err.irisadmin.unknownError", new Object[]
			{ errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(writer);
			HelperUtils.doClose(outStream);
			cleanup();
		}
		return null;
	}
	
	/**
	 * This helper method creates a file from Process Data Bands
	 * @param writer
	 * @param pBandDefs
	 * @throws ExecutionException
	 */
	private void convertToOutput (Map<String, InterfaceBandDef> pBandDefs) throws ExecutionException
	{
		ExecutionException eExp = null;
		JSONObject rootJsonObject = null;
		String mediumType = null;
		String modelSubType = null;
		Map<String, Object> inputParms = null;
		String errorMsg = null;
		IrisError irisError = null;
		ContextManager contextManager = null;
		IRequestReceiver senderServiceSession = null;
		String senderServiceName = null;
		
		try
		{
			rootJsonObject = new JSONObject();
			createJsonObjects(jobData, pBandDefs, rootBand.getBatches(), rootJsonObject);
			mediumType = interfaceDef.getMediumType();
			modelSubType = interfaceDef.getMosdelDef().getModelSubType();
			
			if (IrisAdminConstants.MEDIA_MQ.equals(mediumType))
			{
				
				inputParms = new HashMap<String, Object>();
				contextManager = ContextManager.getInstance();
				senderServiceName = jobData.getFilterParameter(IrisAdminConstants.JMS_SESSION_NAME);
				if (senderServiceName == null )
				{
					errorMsg = "MQ Queue details not configured ";
					eExp = new ExecutionException("error.iris.admin.NoQdetails", new Object[] {IrisAdminConstants.JMS_SESSION_NAME},null);
					logger.error(IRISLogger.getText(eExp));
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					throw eExp;
				}
				jobData.setMessageData(rootJsonObject.toJSONString());
				inputParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				senderServiceSession = (IRequestReceiver) contextManager.getBeanObject(senderServiceName);
				senderServiceSession.sendMessage(inputParms);
				
			}
			else if (IrisAdminConstants.MEDIA_REST_WEBSERVICE.equals(mediumType))
			{
				
				inputParms = new HashMap<String, Object>();
				contextManager = ContextManager.getInstance();
				senderServiceName = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_SESSION_NAME);
				senderServiceName = "restServiceSession";
				if (senderServiceName == null )
				{
					errorMsg = "webService details not configured ";
					eExp = new ExecutionException("error.iris.admin.NoServicedetails", new Object[] {IrisAdminConstants.WEBSERVICE_SESSION_NAME},null);
					logger.error(IRISLogger.getText(eExp));
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					throw eExp;
				}
				logger.debug("Sending JSON:-{}", rootJsonObject.toJSONString());
				jobData.setDataObject(rootJsonObject);
				inputParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				senderServiceSession = (IRequestReceiver) contextManager.getBeanObject(senderServiceName);
				senderServiceSession.sendMessage(inputParms);
				
			}
			else if ( IrisAdminConstants.MEDIA_HTTP_REQUEST.equals(mediumType) &&  IrisAdminConstants.MODEL_SUB_TYPE_REQUEST.equals(modelSubType))
			{
				inputParms = new HashMap<String, Object>();
				contextManager = ContextManager.getInstance();
				senderServiceName = jobData.getFilterParameter(IrisAdminConstants.HTTP_SESSION_NAME);
				if (senderServiceName == null )
				{
					errorMsg = "http details not configured ";
					eExp = new ExecutionException("error.iris.admin.NoHTTPdetails", new Object[] {IrisAdminConstants.HTTP_SESSION_NAME},null);
					logger.error(IRISLogger.getText(eExp));
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					throw eExp;
				}
				logger.debug("Sending XML:-{}", rootJsonObject.toJSONString());
				jobData.setDataObject(rootJsonObject);
				inputParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				senderServiceSession = (IRequestReceiver) contextManager.getBeanObject(senderServiceName);
				senderServiceSession.sendMessage(inputParms);
			}
			else if ( IrisAdminConstants.MEDIA_HTTP_CW.equals(mediumType) )
			{
				jobData.setDataObject(rootJsonObject.toJSONString());
			}
		}
		catch(ExecutionException exp)
		{
			throw exp;
		}
		catch ( BeanConfigException exp)
		{
			errorMsg = "Error While accessing Bean Object" + senderServiceName;
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]	{errorMsg}, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Un known Error:" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.unknown", new Object[]	{errorMsg }, exp);
			logger.error(IRISLogger.getText(eExp));
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			throw eExp;
		}
		finally
		{
			rootJsonObject = null;
			CleanUpUtils.doClean(inputParms);
		}
	}
	
	private void createJsonObjects (ExecutionJobData jobData, Map<String, InterfaceBandDef> pBandDefs, List<BatchBand> batchBands,JSONObject parentJsonObj) throws ExecutionException
	{
		InterfaceBandDef childDef = null;
		String bandName = null;
		String fldVal = null;
		ExecutionException eExp = null;
		List<MappingField> listFields = null;
		DataField dataField = null;
		Map<String, DataField> fieldsList = null;
		List<BatchBand> childBatchBands = null;
		String errorMsg = null;
		IrisAdminError error = null;
		String jsonName = null;
		IrisError irisError = null;
		JSONObject jsonElementsObject = null;
		JSONArray jsonArray = null;
		String jsonFieldName = null;
		int bandLevel = -1;
		
		try
		{
			for (BatchBand batchBand : batchBands)
			{
				for (Band band : batchBand.getBatchBands())
				{
					bandName = band.getName();
					childDef = pBandDefs.get(bandName);
					bandLevel = childDef.getBandLevel();
					listFields = childDef.getMappingFields();
					fieldsList = band.getFieldRow();
					jsonName = childDef.getBandName();
					if (parentJsonObj.containsKey(jsonName))
					{
						if ( bandLevel > -1)
						{
							jsonArray = (JSONArray)parentJsonObj.get(jsonName);
							jsonElementsObject = new JSONObject();
						}
						else // else case will not come 
							jsonElementsObject = (JSONObject)parentJsonObj.get(jsonName);
					}
					else
					{
						if ( bandLevel > -1)
						{
							jsonArray = new JSONArray();
							parentJsonObj.put(jsonName, jsonArray);
							jsonElementsObject = new JSONObject();
						}
						else
						{
							jsonElementsObject = new JSONObject();
							parentJsonObj.put(jsonName, jsonElementsObject);
						}
						
					}
					
					
					for (MappingField field : listFields)
					{
						if (IrisAdminConstants.MAPPING_TYPE_INTERNAL != field.getMappingType())
						{
							if (logger.isTraceEnabled())
								logger.trace("BandName:{}, FieldName:{} ", childDef.getBandName(), field.getFieldName());
							
							dataField = fieldsList.get(field.getFieldName());
							fldVal = dataField.getValue();
							jsonFieldName = field.getRemarks();
							
							if (null == jsonFieldName)
								continue;
							
							if ( StringUtils.isEmpty(fldVal) && ! emptytagsRequired)
								continue;
							
							jsonElementsObject.put(jsonFieldName, fldVal);
						}
					}
					if ( bandLevel > -1)
						jsonArray.add(jsonElementsObject);
					
					childBatchBands = band.getChildBatches();
					if (childBatchBands.size() > 0)
					{
						createJsonObjects(jobData, childDef.getChildDefinitions().getBandDefinitions(), childBatchBands, jsonElementsObject);
					}
				}
			}
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("E");
			errorMsg = "Not able to process-" + exp.getMessage();
			eExp = new ExecutionException("error.iris.admin.fillingpreparedstmt", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError("999", errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
		}
	}
}
