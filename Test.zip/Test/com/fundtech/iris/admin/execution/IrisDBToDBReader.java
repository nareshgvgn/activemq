/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : IrisDBToDBReader.java
 * CREATED: Aug 6, 2015 6:10:15 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisDBToDBReader.java,v 1.3 2016/02/09 05:33:41 ramap Exp $
 */
public class IrisDBToDBReader  extends AbstractDataReader
{
	
	private static Logger logger = LoggerFactory.getLogger(FileReader.class);
	
	/**
	 * This method is a controller for file reading and creating process data bands
	 * 
	 * @return
	 * @throws FormatException
	 * @throws ExecutionException
	 */
	public RootBand formatData () throws FormatException
	{
		Deque<InterfaceBandDef> defStack = null;
		Deque<Band> dataStack = null;
		RootBand rootBand = null;
		FormatException fExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		IFormatter iFormatter = null;
		String formatterClass = null;
		Class<?> clazz = null;
		Band batchBand = null;
		IrisError irisError = null;
		
		try
		{
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "Before loading file Data");
			bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			defStack = new ArrayDeque<InterfaceBandDef>();
			dataStack = new ArrayDeque<Band>();
			formatterClass = interfaceDef.getFormatterClass();
			clazz = Class.forName(formatterClass);
			iFormatter = (IFormatter) clazz.newInstance();
			iFormatter.initialize(appContext, interfaceDef, jobData, zeroProofings);
			rootBand = new RootBand();
			batchBand = new Band();
			dataStack.addFirst(batchBand);
			for (InterfaceBandDef bandDef : bandDefs.values())
			{
				
				defStack.addFirst(bandDef);
				iFormatter.uploadFormat(0, bandDef.getAbsoluteXPath1(), defStack, dataStack);
			}
			
			batchBand = dataStack.removeFirst();
			rootBand.addBatchBands(batchBand);
			iFormatter.cleanup();
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error while reading file" + jobData.getMediaDetails();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			if (dataStack != null)
				dataStack.clear();
			if (defStack != null)
				defStack.clear();
			
			if (iFormatter != null)
				iFormatter.cleanup();
			
			iFormatter = null;
		}
		return rootBand;
	}
	
	
	
	
	
}