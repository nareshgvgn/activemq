/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : XMLDOMReader.java
 * CREATED: Aug 8, 2013 11:37:20 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: XMLDOMReader.java,v 1.9 2015/08/30 10:19:38 ramap Exp $
 * @since 1.0.0
 */
public class XMLDOMReader extends AbstractDataReader
{
	private static Logger logger = LoggerFactory.getLogger(XMLDOMReader.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IReader#readData()
	 */
	public RootBand formatData () throws FormatException
	{
		
		XPath xPath = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		String expression = null;
		NodeList rootList = null;
		Node parentNode = null;
		Document xmlDocument = null;
		Deque<InterfaceBandDef> defStack = null;
		Deque<Band> dataStack = null;
		Band batchBand = null;
		RootBand rootBand = null;
		FileInputStream fileStream = null;
		DocumentBuilderFactory builderFactory = null;
		DocumentBuilder builder = null;
		IFormatter iFormatter = null;
		String formatterClass = null;
		Class<?> clazz = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		FormatException fExp = null;
		
		try
		{
			
			fileStream = new FileInputStream(new File(jobData.getMediaDetails()));
			builderFactory = DocumentBuilderFactory.newInstance();
			builder = builderFactory.newDocumentBuilder();
			xmlDocument = builder.parse(fileStream);
			
			bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			defStack = new ArrayDeque<InterfaceBandDef>();
			dataStack = new ArrayDeque<Band>();
			formatterClass = interfaceDef.getFormatterClass();
			clazz = Class.forName(formatterClass);
			iFormatter = (IFormatter) clazz.newInstance();
			iFormatter.initialize(appContext, interfaceDef, jobData, zeroProofings);
			rootBand = new RootBand();
			batchBand = new Band();
			dataStack.addFirst(batchBand);
			for (InterfaceBandDef bandDef : bandDefs.values())
			{
				expression = bandDef.getRelativeXPath();
				xPath = XPathFactory.newInstance().newXPath();
				defStack.addFirst(bandDef);
				rootList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODESET);
				for (int index = 0; null != rootList && index < rootList.getLength(); index++)
				{
					parentNode = rootList.item(index);
					iFormatter.uploadFormat(0, parentNode, defStack, dataStack);
				}
			}
			batchBand = dataStack.removeFirst();
			rootBand.addBatchBands(batchBand);
			iFormatter.cleanup();
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (FileNotFoundException exp)
		{
			errorMsg = "File:" + jobData.getMediaDetails() + " not found";
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error while reading file" + jobData.getMediaDetails();
			fExp = new FormatException("err.irisadmin.format", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			HelperUtils.doClose(fileStream);
			xmlDocument = null;
			builderFactory = null;
			
			if (dataStack != null)
				dataStack.clear();
			if (defStack != null)
				defStack.clear();
			
			if (iFormatter != null)
				iFormatter.cleanup();
			
			iFormatter = null;
			
		}
		return rootBand;
	}
}
