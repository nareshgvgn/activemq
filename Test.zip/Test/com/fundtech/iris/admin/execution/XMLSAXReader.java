/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.execution
 * FILE   : XMLSAXReader.java
 * CREATED: Aug 8, 2013 11:37:20 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.execution;

import java.io.FileNotFoundException;
import java.io.Reader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.execution.formatter.IFormatter;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * 
 * <p>
 * This Class reads the file by using SAXreader. Large files can be read by using this class
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into Datastore_Mst (DATASTORE_TYPE, INTERFACE_TYPE, DATASTORE_NAME, DESCRIPTION, DATASTORE_VALUE, EXECUTION_CLASS, FORMATTER_CLASS, RECORD_KEY_NMBR, AUDIT_NMBR, VALID_FLAG, OPERATION_FLAG, CHECKER_ACTION, PREV_AUDIT_NMBR)
 * values ('F', 'U', 'X', 'XML File  Format', '', 'com.fundtech.iris.admin.execution.XMLSAXReader', 'com.fundtech.iris.admin.execution.formatter.XMLSAXFormatter', '', '', 'Y', '', '', '');
 * </pre>
 * 
 * </p>
 * <p>
 * 
 * @author Babu Paluri
 * @version $Id: XMLSAXReader.java,v 1.17 2016/06/20 04:53:20 ramap Exp $
 */
public class XMLSAXReader extends AbstractDataReader
{
	private Logger logger = LoggerFactory.getLogger(XMLSAXReader.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.execution.IReader#readData()
	 */
	public RootBand formatData () throws FormatException
	{
		
		Map<String, InterfaceBandDef> bandDefs = null;
		String expression = null;
		List<Node> rootList = null;
		Object obj = null;
		Node parentNode = null;
		FormatException fExp = null;
		Document xmlDocument = null;
		Deque<InterfaceBandDef> defStack = null;
		Deque<Band> dataStack = null;
		Band batchBand = null;
		RootBand rootBand = null;
		IFormatter iFormatter = null;
		String formatterClass = null;
		Class<?> clazz = null;
		SAXReader saxReader = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		String mediaType = null;
		Reader reader = null;
		
		try
		{
			
			mediaType = jobData.getMediumType();
			if (IrisAdminConstants.MEDIA_FILE.equals(mediaType))
				reader = (Reader) identifyFile(jobData.getMediaDetails());
			else if (IrisAdminConstants.MEDIA_MQ.equals(mediaType) || IrisAdminConstants.MEDIA_WEBSERVICE.equals(mediaType) ||  IrisAdminConstants.MEDIA_HTTP_RESPONSE.equals(mediaType) )
				reader = (Reader) identifyFile(jobData.getMessageData());
			
			saxReader = new SAXReader();
			// reader.setValidation(false);
			// reader.setFeature(IrisAdminConstants.XML_SAX_VALIDATION, true);
			// reader.setFeature(IrisAdminConstants.XML_SAX_SCHEMA, true);
			// reader.setFeature(IrisAdminConstants.XML_SAX_FULL_CHECK,false);
			// reader.setFeature(IrisAdminConstants.XML_SAX_NAME_SPACE, true);
			// reader.setProperty(IrisAdminConstants.XML_SAX_NAME_SPACE_LOCATION, uri + " " + xsdName +".xsd" );
			xmlDocument = saxReader.read(reader);
			xmlDocument.accept(new RemoveNamespace());
			bandDefs = interfaceDef.getBandsDefinition().getBandDefinitions();
			defStack = new ArrayDeque<InterfaceBandDef>();
			dataStack = new ArrayDeque<Band>();
			formatterClass = interfaceDef.getFormatterClass();
			clazz = Class.forName(formatterClass);
			iFormatter = (IFormatter) clazz.newInstance();
			iFormatter.initialize(appContext, interfaceDef, jobData, zeroProofings);
			rootBand = new RootBand();
			batchBand = new Band();
			dataStack.addFirst(batchBand);
			for (InterfaceBandDef bandDef : bandDefs.values())
			{
				expression = bandDef.getRelativeXPath();
				defStack.addFirst(bandDef);
				obj = xmlDocument.selectObject(expression);
				if (obj instanceof Node)
				{
					rootList = new ArrayList<Node>();
					rootList.add((Node) obj);
				}
				else if (obj instanceof List)
				{
					rootList = (List<Node>) obj;
				}
				
				if (rootList == null)
				{
					errorMsg = bandDef.getBandName() + " or " + expression + " Doersn't have any data in xml";
					fExp = new FormatException("err.irisadmin.format", new Object[] { errorMsg, bandDef.toString() }, null);
					error = createError(IrisAdminConstants.ERR_CODE_CREATE_BAND, errorMsg, bandDef.toString(), null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, bandDef.getBandName(), errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					logger.error(IRISLogger.getText(fExp));
					throw fExp;
				}
				
				for (int index = 0; null != rootList && index < rootList.size(); index++)
				{
					parentNode = rootList.get(index);
					iFormatter.uploadFormat(0, parentNode, defStack, dataStack);
				}
			}
			batchBand = dataStack.removeFirst();
			rootBand.addBatchBands(batchBand);
			iFormatter.cleanup();
		}
		catch (FormatException exp)
		{
			throw exp;
		}
		catch (FileNotFoundException exp)
		{
			errorMsg = "File:" + jobData.getMediaDetails() + " not found";
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error while reading file" + jobData.getMediaDetails();
			fExp = new FormatException("err.irisadmin.format", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			// DO not accumulate error as this is serious error
			logger.error(IRISLogger.getText(fExp));
			throw fExp;
		}
		finally
		{
			HelperUtils.doClose(reader);
			xmlDocument = null;
			
			if (dataStack != null)
				dataStack.clear();
			if (defStack != null)
				defStack.clear();
			
			if (iFormatter != null)
				iFormatter.cleanup();
			
			iFormatter = null;
			saxReader = null;
		}
		return rootBand;
	}
	
	public final IrisAdminError createError (String errCode, String errMsg, String info1, String errLine)
	{
		IrisAdminError error = null;
		
		error = new IrisAdminError(0, IrisAdminConstants.ERR_TYPE_ERROR, errCode, errMsg, info1, errLine);
		return error;
	}
}
