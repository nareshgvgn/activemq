/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.model
 * FILE   : LoadModelDef.java
 * CREATED: Mar 18, 2013 7:03:31 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: LoadModelDef.java,v 1.13 2016/12/08 11:25:40 ramap Exp $
 * @since 1.0.0
 */
public class LoadModelDef
{
	private String mandatory = "MANDATORY";
	private static Logger logger = LoggerFactory.getLogger(LoadModelDef.class);
	private static final String modelMstSQL = "SELECT MODEL_TYPE,SELLER_CODE,UPLOAD_ROUTINE,CATEGORY,MODEL_SUBTYPE,gcp_version FROM IRIS_MODEL_MST WHERE MODEL_NAME = ? AND VALID_FLAG = 'Y'";
	private static final String modelBandSQL = "SELECT * FROM IRIS_MODEL_BAND_MST B where B.MODEL_NAME =? ORDER BY B.BAND_LEVEL, B.PARENT_BAND_TYPE";
	private static final String modelFieldsSQL = "SELECT * FROM IRIS_MODEL_BAND_DTL  WHERE MODEL_NAME = ? AND BAND_TYPE = ? ORDER BY 1, 2, SEQUENCE_NMBR";
	
	public ModelDef loadDefinition (Connection dbConnection, String modelName) throws LoadingException
	{
		ModelDef definition = null;
		PreparedStatement interfaceStmt = null;
		ResultSet interfaceRs = null;
		ModelBandsDef modelBandsDef = null;
		LoadingException intExp = null;
		
		try
		{
			interfaceStmt = dbConnection.prepareStatement(modelMstSQL);
			interfaceStmt.clearParameters();
			interfaceStmt.setString(1, modelName);
			interfaceRs = interfaceStmt.executeQuery();
			if (interfaceRs.next())
			{
				definition = new ModelDef();
				definition.setModelName(modelName);
				definition.setModelType(interfaceRs.getString("MODEL_TYPE"));
				definition.setSellerCode(interfaceRs.getString("SELLER_CODE"));
				definition.setUploadRoutine(interfaceRs.getString("UPLOAD_ROUTINE"));
				definition.setCategory(interfaceRs.getString("CATEGORY"));
				definition.setGcpVersion(interfaceRs.getString("gcp_version"));
				definition.setModelSubType(interfaceRs.getString("MODEL_SUBTYPE"));
			}
			else
			{
				// TODO throw Exception
			}
			HelperUtils.doClose(interfaceRs);
			HelperUtils.doClose(interfaceStmt);
			
			modelBandsDef = loadBandDefination(dbConnection, modelName);
			definition.setBandsDefinition(modelBandsDef);
		}
		catch (LoadingException loadExp)
		{
			throw loadExp;
		}
		catch (Exception ex)
		{
			intExp = new LoadingException("error.irisdb.model.def", new Object[]{ modelMstSQL }, ex);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(interfaceRs);
			HelperUtils.doClose(interfaceStmt);
		}
		return definition;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param modelName
	 * @return
	 * @throws LoadingException
	 * </pre></p>
	 */
	private ModelBandsDef loadBandDefination (Connection dbConnection, String modelName) throws LoadingException
	{
		ModelBandsDef modelBandsDef = null;
		PreparedStatement bandStmt = null;
		ResultSet bandRs = null;
		ModelBandDef modelBandDef = null;
		String currentBandType = null;
		Map<String, ModelField> modelFields = null;
		PreparedStatement fieldStmt = null;
		String currentParentType = null;
		Map<String, ModelBandDef> bandDefs = null;
		List<String> parents = null;
		ModelBandDef parentDef = null;
		LoadingException intExp = null;
		
		try
		{
			bandDefs = new HashMap<String, ModelBandDef>();
			parents = new ArrayList<String>();
			
			bandStmt = dbConnection.prepareStatement(modelBandSQL);
			bandStmt.clearParameters();
			bandStmt.setString(1, modelName);
			bandRs = bandStmt.executeQuery();
			fieldStmt = dbConnection.prepareStatement(modelFieldsSQL);
			modelBandsDef = new ModelBandsDef();
			while (bandRs.next())
			{
				modelBandDef = setBandDefinition(bandRs);
				currentBandType = modelBandDef.getBandType();
				modelFields = getFileds(fieldStmt, currentBandType, modelName);
				modelBandDef.setInterfaceFields(modelFields);
				currentParentType = modelBandDef.getParentBandType();
				
				if (currentParentType == null)
				{
					for (String parentType : parents)
					{
						parentDef = bandDefs.get(parentType);
						parentDef.addParallelDefinition(modelBandDef);
						modelBandDef.addParallelDefinition(parentDef);
					}
					parents.add(currentBandType);
					bandDefs.put(currentBandType, modelBandDef);
				}
				else
				{
					parentDef = bandDefs.get(currentParentType);
					modelBandDef.setParentDefinition(parentDef);
					parentDef.addChildDefinition(modelBandDef);
					bandDefs.put(currentBandType, modelBandDef);
				}
			}
			
			for (String s : parents)
			{
				ModelBandDef bandDef = bandDefs.get(s);
				modelBandsDef.addBandDefination(bandDef);
			}
		}
		catch ( NullPointerException exp)
		{
			intExp = new LoadingException("error.irisdb.model.band", new Object[]{ modelBandSQL, modelFieldsSQL, "Current Band:" + currentBandType , 
																															"Parent Band:" + currentParentType }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (SQLException sqlExp)
		{
			intExp = new LoadingException("error.irisdb.model.band", new Object[]{ modelBandSQL, modelFieldsSQL }, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch (Exception exp)
		{
			intExp = new LoadingException("error.irisdb.model.band", new Object[]{ modelMstSQL }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			bandDefs.clear();
			bandDefs = null;
			parents.clear();
			parents = null;
			HelperUtils.doClose(fieldStmt);
			HelperUtils.doClose(bandRs);
			HelperUtils.doClose(bandStmt);
		}
		return modelBandsDef;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param bandRs
	 * @return
	 * @throws SQLException
	 * </pre></p>
	 */
	private ModelBandDef setBandDefinition (ResultSet bandRs) throws SQLException
	{
		ModelBandDef modelBandDef = null;
		int bandLevel = 0;
		String bandType = null;
		String booleanValue = null;
		
		modelBandDef = new ModelBandDef();
		bandLevel = bandRs.getInt("BAND_LEVEL");
		modelBandDef.setBandLevel(bandLevel);
		bandType = bandRs.getString("BAND_TYPE");
		modelBandDef.setBandType(bandType);
		modelBandDef.setModelName(bandRs.getString("MODEL_NAME"));
		booleanValue = bandRs.getString(mandatory);
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(booleanValue))
			modelBandDef.setMandatory(true);
		
		modelBandDef.setJoinCondition(bandRs.getString("JOIN_CONDITION"));
		modelBandDef.setMappedTable(bandRs.getString("MAPPED_TABLE"));
		modelBandDef.setParentBandType(bandRs.getString("PARENT_BAND_TYPE"));
		return modelBandDef;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param fieldStmt
	 * @param bandType
	 * @param modelName
	 * @return
	 * @throws LoadingException
	 * </pre></p>
	 */
	private Map<String, ModelField> getFileds (PreparedStatement fieldStmt, String bandType, String modelName) throws LoadingException
	{
		Map<String, ModelField> modelFields = null;
		ResultSet fieldRs = null;
		ModelField field = null;
		String booleanValue = null;
		LoadingException intExp = null;
		String fieldName = null;
		
		
		try
		{
			modelFields = new HashMap<String, ModelField>();
			fieldStmt.clearParameters();
			fieldStmt.setString(1, modelName);
			fieldStmt.setString(2, bandType);
			fieldRs = fieldStmt.executeQuery();
			while (fieldRs.next())
			{
				field = new ModelField();
				field.setBandType(bandType);
				field.setFieldDataType(fieldRs.getString("FIELD_DATA_TYPE"));
				field.setFieldLength(fieldRs.getInt("FIELD_LENGTH"));
				fieldName = fieldRs.getString("FIELD_NAME");
				field.setFieldName(fieldName);
				field.setFilterParmFlag(fieldRs.getString("FILTER_PARAM_FLAG"));
				booleanValue = fieldRs.getString(mandatory);
				if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(booleanValue))
					field.setMandatory(true);
				booleanValue = fieldRs.getString("REF_KEY_FLAG");
				if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(booleanValue))
					field.setKeyField(true);
				field.setMappedColoumn(fieldRs.getString("COLUMN_ALIAS"));
				field.setSequenceNumber(fieldRs.getInt("SEQUENCE_NMBR"));
				modelFields.put(fieldName, field);
			}
		}
		catch (SQLException sqlExp)
		{
			logger.error("Error While loading Model for {} and band type {} and for field {}", modelName, bandType,fieldName);
			intExp = new LoadingException("error.irisdb.model.fields", new Object[]{ modelFieldsSQL,modelName, bandType}, sqlExp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		catch ( Exception exp)
		{
			logger.error("Error While loading Model for {} and band type {} and for field {}", modelName, bandType,fieldName);
			intExp = new LoadingException("error.irisdb.model.fields", new Object[]{ modelFieldsSQL,modelName, bandType }, exp);
			logger.error(IRISLogger.getText(intExp));
			throw intExp;
		}
		finally
		{
			HelperUtils.doClose(fieldRs);
		}
		
		return modelFields;
	}
	
}
