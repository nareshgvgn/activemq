/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.model
 * FILE   : InterfaceBandDef.java
 * CREATED: Mar 18, 2013 5:39:37 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ModelBandDef.java,v 1.3 2015/06/24 14:00:08 ramap Exp $
 * @since 1.0.0
 */
public class ModelBandDef
{
	private String modelName = null;
	private String bandType = null;
	private int bandLevel = Integer.MIN_VALUE;
	private String parentBandType = null;
	private boolean mandatory = false;
	private String mappedTable = null;
	private String joinCondition = null;
	private Map<String, ModelField> modelFields = new HashMap<String, ModelField>();
	private Map<String, String> interfaceFiledNames = new HashMap<String, String>();
	private String bandPath = null;
	private ModelBandsDef childDefinitions = new ModelBandsDef();
	private ModelBandDef parentDefinition = null;
	private ModelBandsDef parallelDefinitions = new ModelBandsDef();
	
	/**
	 * @return the modelName
	 */
	public String getModelName ()
	{
		return modelName;
	}
	
	/**
	 * @param modelName
	 *            the modelName to set
	 */
	public void setModelName (String interfaceCode)
	{
		this.modelName = interfaceCode;
	}
	
	/**
	 * @return the bandType
	 */
	public String getBandType ()
	{
		return bandType;
	}
	
	/**
	 * @param bandType
	 *            the bandType to set
	 */
	public void setBandType (String bandType)
	{
		this.bandType = bandType;
	}
	
	/**
	 * @return the bandLevel
	 */
	public int getBandLevel ()
	{
		return bandLevel;
	}
	
	/**
	 * @param bandLevel
	 *            the bandLevel to set
	 */
	public void setBandLevel (int bandLevel)
	{
		this.bandLevel = bandLevel;
	}
	
	/**
	 * @return the parentBandType
	 */
	public String getParentBandType ()
	{
		return parentBandType;
	}
	
	/**
	 * @param parentBandType
	 *            the parentBandType to set
	 */
	public void setParentBandType (String parentBandType)
	{
		this.parentBandType = parentBandType;
	}
	
	/**
	 * @return the mandatory
	 */
	public boolean isMandatory ()
	{
		return mandatory;
	}
	
	/**
	 * @param mandatory
	 *            the mandatory to set
	 */
	public void setMandatory (boolean mandatory)
	{
		this.mandatory = mandatory;
	}
	
	/**
	 * @return the mappedTable
	 */
	public String getMappedTable ()
	{
		return mappedTable;
	}
	
	/**
	 * @param mappedTable
	 *            the mappedTable to set
	 */
	public void setMappedTable (String mappedTable)
	{
		this.mappedTable = mappedTable;
	}
	
	/**
	 * @return the modelFields
	 */
	public Map<String, ModelField> getInterfaceFields ()
	{
		return modelFields;
	}
	
	/**
	 * @param modelFields
	 *            the modelFields to set
	 */
	public void setInterfaceFields (Map<String, ModelField> modelFields)
	{
		String key = null;
		ModelField field = null;
		
		this.modelFields = modelFields;
		for (Map.Entry<String, ModelField> entry : modelFields.entrySet())
		{
			key = entry.getKey();
			field = entry.getValue();
			interfaceFiledNames.put(field.getColNameWithOutAlias(), key);
		}
	}
	
	public String getColumnNameWithAlias(String key)
	{
		ModelField field = null;
		
		field = modelFields.get(key);
		
		if (field == null)
			return null;
		return field.getMappedColoumn();
	}
	
	public String getColNameWithoutAlias(String key)
	{
		ModelField field = null;
		
		field = modelFields.get(key);
		
		if (field == null)
			return null;
		return field.getColNameWithOutAlias();
	}
	public String getFieldName (String columnName)
	{
		return interfaceFiledNames.get(columnName);
	}
	
	/**
	 * @return the bandPath
	 */
	public String getBandPath ()
	{
		return bandPath;
	}
	
	/**
	 * @param bandPath
	 *            the bandPath to set
	 */
	public void setBandPath (String bandPath)
	{
		this.bandPath = bandPath;
	}
	
	public void addChildDefinition (ModelBandDef modelBandDef)
	{
		childDefinitions.addBandDefination(modelBandDef);
	}
	
	public ModelBandDef getChildBand (String bandType)
	{
		for (ModelBandDef band : childDefinitions.getBandDefinitions().values())
		{
			if (band.getBandType().equals(bandType))
				return band;
		}
		return null;
	}
	
	public Collection<ModelBandDef> getChildBands ()
	{
		return childDefinitions.getBandDefinitions().values();
	}
	
	public Map<String, ModelBandDef> getChildBandDefs ()
	{
		return childDefinitions.getBandDefinitions();
	}
	
	public void addParallelDefinition (ModelBandDef modelBandDef)
	{
		parallelDefinitions.addBandDefination(modelBandDef);
	}
	
	public ModelBandDef getParallelDefinition (String bandType)
	{
		for (ModelBandDef band : parallelDefinitions.getBandDefinitions().values())
		{
			if (band.getBandType().equals(bandType))
				return band;
		}
		return null;
	}
	
	public Collection<ModelBandDef> getParallelDefinitions ()
	{
		return parallelDefinitions.getBandDefinitions().values();
	}
	
	/**
	 * @return the parentDefinition
	 */
	public ModelBandDef getParentDefinition ()
	{
		return parentDefinition;
	}
	
	/**
	 * @param parentDefinition
	 *            the parentDefinition to set
	 */
	public void setParentDefinition (ModelBandDef parentDefinition)
	{
		this.parentDefinition = parentDefinition;
	}

	/**
	 * @return the joinCondition
	 */
	public String getJoinCondition ()
	{
		return joinCondition;
	}

	/**
	 * @param joinCondition the joinCondition to set
	 */
	public void setJoinCondition (String joinCondition)
	{
		this.joinCondition = joinCondition;
	}
	
}
