/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.interfaces
 * FILE   : ModelDef.java
 * CREATED: Mar 18, 2013 5:05:45 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.model;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ModelDef.java,v 1.5 2016/12/08 11:25:40 ramap Exp $
 * @since 1.0.0
 */
public class ModelDef
{
	private String modelName = null;
	private String modelType = null;
	private String uploadRoutine = null;
	private String sellerCode = null;
	private String category = null;
	private ModelBandsDef modelBandsDef = null;
	private String modelSubType = null;
	private String gcpVersion = "4.3";
	
	/**
	 * @return the modelName
	 */
	public String getModelName ()
	{
		return modelName;
	}
	
	/**
	 * @param modelName
	 *            the modelName to set
	 */
	public void setModelName (String interfaceCode)
	{
		this.modelName = interfaceCode;
	}
	
	/**
	 * @return the modelType
	 */
	public String getModelType ()
	{
		return modelType;
	}
	
	/**
	 * @param modelType
	 *            the modelType to set
	 */
	public void setModelType (String interfaceType)
	{
		this.modelType = interfaceType;
	}
	
	
	/**
	 * @return the uploadRoutine
	 */
	public String getUploadRoutine ()
	{
		return uploadRoutine;
	}
	
	/**
	 * @param uploadRoutine
	 *            the uploadRoutine to set
	 */
	public void setUploadRoutine (String uploadRoutine)
	{
		this.uploadRoutine = uploadRoutine;
	}
	
	/**
	 * @return the sellerCode
	 */
	public String getSellerCode ()
	{
		return sellerCode;
	}
	
	/**
	 * @param sellerCode
	 *            the sellerCode to set
	 */
	public void setSellerCode (String sellerCode)
	{
		this.sellerCode = sellerCode;
	}
	
	/**
	 * @return the modelBandsDef
	 */
	public ModelBandsDef getBandsDefinition ()
	{
		return modelBandsDef;
	}
	
	/**
	 * @param modelBandsDef
	 *            the modelBandsDef to set
	 */
	public void setBandsDefinition (ModelBandsDef modelBandsDef)
	{
		this.modelBandsDef = modelBandsDef;
	}

	/**
	 * @return the category
	 */
	public String getCategory ()
	{
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory (String category)
	{
		this.category = category;
	}

	/**
	 * @return the modelSubType
	 */
	public String getModelSubType ()
	{
		return modelSubType;
	}

	/**
	 * @param modelSubType the modelSubType to set
	 */
	public void setModelSubType (String modelSubType)
	{
		this.modelSubType = modelSubType;
	}

	/**
	 * @return the gcpVersion
	 */
	public String getGcpVersion ()
	{
		return gcpVersion;
	}

	/**
	 * @param gcpVersion the gcpVersion to set
	 */
	public void setGcpVersion (String gcpVersion)
	{
		if ( gcpVersion == null)
			gcpVersion = "4.3";
		this.gcpVersion = gcpVersion;
	}
	
}
