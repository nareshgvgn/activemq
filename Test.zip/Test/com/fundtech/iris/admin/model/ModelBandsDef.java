/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.model
 * FILE   : InterfaceBandsDef.java
 * CREATED: Mar 18, 2013 5:38:20 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.model;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ModelBandsDef.java,v 1.2 2014/07/20 04:58:19 ramap Exp $
 * @since 1.0.0
 */
public class ModelBandsDef
{
	private Map<String, ModelBandDef> modelBandDefs = new LinkedHashMap<String, ModelBandDef>();
	
	/**
	 * Add Band Definition to list of definitions
	 * 
	 * @param modelBandDef
	 */
	public void addBandDefination (ModelBandDef modelBandDef)
	{
		modelBandDefs.put(modelBandDef.getBandType(), modelBandDef);
	}
	
	@SuppressWarnings("unused")
	private ModelBandDef getBandDefiniation (String key)
	{
		return modelBandDefs.get(key);
	}
	
	/**
	 * @return the modelBandDefs
	 */
	public Map<String, ModelBandDef> getBandDefinitions ()
	{
		return modelBandDefs;
	}
	
	/**
	 * @param modelBandDefs
	 *            the modelBandDefs to set
	 */
	public void setBandDefinitions (Map<String, ModelBandDef> modelBandDefs)
	{
		this.modelBandDefs = modelBandDefs;
	}
	
	public boolean containsBandDefinition (String key)
	{
		return modelBandDefs.containsKey(key);
	}
}
