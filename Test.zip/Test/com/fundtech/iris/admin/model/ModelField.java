/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.model
 * FILE   : ModelField.java
 * CREATED: Mar 18, 2013 6:35:03 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.model;

import com.fundtech.iris.admin.IrisAdminConstants;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: ModelField.java,v 1.5 2016/10/19 14:04:55 ramap Exp $
 * @since 1.0.0
 */
public class ModelField
{
	private String bandType = null;
	private String fieldName = null;
	private String colNameWithOutAlias = null;
	private String fieldDataType = null;
	private int fieldLength = Integer.MIN_VALUE;
	private boolean mandatory = false;
	private String filterParmFlag = IrisAdminConstants.CONSTANT_N;
	private String mappedColoumn = null;
	private int sequenceNumber = Integer.MIN_VALUE;
	private boolean isKeyField = false;
	
	/**
	 * @return the bandType
	 */
	public String getBandType ()
	{
		return bandType;
	}
	
	/**
	 * @param bandType
	 *            the bandType to set
	 */
	public void setBandType (String bandType)
	{
		this.bandType = bandType;
	}
	
	/**
	 * @return the fieldName
	 */
	public String getFieldName()
	{
		return fieldName;
	}
	
	/**
	 * @param fieldName
	 *            the fieldName to set
	 */
	public void setFieldName (String fieldName)
	{
		this.fieldName = fieldName;
	}
	
	/**
	 * @return the fieldDataType
	 */
	public String getFieldDataType ()
	{
		return fieldDataType;
	}
	
	/**
	 * @param fieldDataType
	 *            the fieldDataType to set
	 */
	public void setFieldDataType (String fieldDataType)
	{
		this.fieldDataType = fieldDataType;
	}
	
	/**
	 * @return the fieldLength
	 */
	public int getFieldLength ()
	{
		return fieldLength;
	}
	
	/**
	 * @param fieldLength
	 *            the fieldLength to set
	 */
	public void setFieldLength (int fieldLength)
	{
		this.fieldLength = fieldLength;
	}
	
	/**
	 * @return the mandatory
	 */
	public boolean isMandatory ()
	{
		return mandatory;
	}
	
	/**
	 * @param mandatory
	 *            the mandatory to set
	 */
	public void setMandatory (boolean mandatory)
	{
		this.mandatory = mandatory;
	}
	
	/**
	 * @return the filterParmFlag
	 */
	public String getFilterParmFlag ()
	{
		return filterParmFlag;
	}
	
	/**
	 * @param filterParmFlag
	 *            the filterParmFlag to set
	 */
	public void setFilterParmFlag (String filterParmFlag)
	{
		this.filterParmFlag = filterParmFlag;
	}
	
	
	/**
	 * @return the mappedColoumn
	 */
	public String getMappedColoumn ()
	{
		return mappedColoumn;
	}
	
	/**
	 * @param mappedColoumn
	 *            the mappedColoumn to set
	 */
	public void setMappedColoumn (String mappedColoumn)
	{
		this.mappedColoumn = mappedColoumn;
		this.colNameWithOutAlias = mappedColoumn.substring(mappedColoumn.indexOf(".") + 1 , mappedColoumn.length());
	}
	
	/**
	 * @return the sequenceNumber
	 */
	public int getSequenceNumber ()
	{
		return sequenceNumber;
	}
	
	/**
	 * @param sequenceNumber
	 *            the sequenceNumber to set
	 */
	public void setSequenceNumber (int sequenceNumber)
	{
		this.sequenceNumber = sequenceNumber;
	}

	/**
	 * @return the colNameWithOuutAlias
	 */
	public String getColNameWithOutAlias ()
	{
		return colNameWithOutAlias;
	}

	/**
	 * @return the isKeyField
	 */
	public boolean isKeyField ()
	{
		return isKeyField;
	}

	/**
	 * @param isKeyField the isKeyField to set
	 */
	public void setKeyField (boolean isKeyField)
	{
		this.isKeyField = isKeyField;
	}
}
