/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.hooks
 * FILE   : UnZipFile.java
 * CREATED: Mar 11, 2014 12:17:44 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.hooks;

import java.io.File;
import java.sql.Connection;
import java.util.Map;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.FileUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * This helper class Unzip's the uploaded file
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into iris_routine_mst (ROUTINE_TYPE, ROUTINE_NAME, ROUTINE_DESC, ROUTINE_SUBTYPE, MAPPED_CLASS, VALID_FLAG)
 * values ('PRE_PROCESSING_ROUTINE', 'Un-Zip File', 'This routine is to unzip the file', 'J', 'com.fundtech.iris.admin.hooks.UnZipFile', 'Y');
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: UnZipFile.java,v 1.6 2015/10/19 12:04:09 ramap Exp $
 */
public class UnZipFile extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(UnZipFile.class);
	
	public UnZipFile()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		String inputFileName = null;
		ZipFile zipFile = null;
		String zipPassword = null;
		String clientCode = null;
		ExecutionException eExp = null;
		ExecutionJobData jobData = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		String destPath = null;
		String zipFileName = null;
		String outFileName = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IProcessHook.EXECUTION_DATA);
			clientCode = jobData.getEntityCode();
			;
			inputFileName = jobData.getMediaDetails();
			if (null == inputFileName)
			{
				
				errorMsg = "File Name is Null";
				eExp = new ExecutionException("error.iris.admin.batch", new Object[]
				{ errorMsg }, null);
				error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
				irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
				jobData.addIrisError(irisError);
				jobData.addError(error);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			
			zipFile = new ZipFile(inputFileName);
			if (zipFile.isValidZipFile())
			{
				if (zipFile.isEncrypted())
				{
					zipPassword = jobData.getFilterParameter("P_ZIP_PASSWORD");
					if (zipPassword == null)
					{
						errorMsg = "File:" + inputFileName + " is protected and given password is null";
						eExp = new ExecutionException("error.iris.admin.batch", new Object[]
						{ errorMsg }, null);
						error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
						irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
						jobData.addIrisError(irisError);
						jobData.addError(error);
						logger.error(IRISLogger.getText(eExp));
						throw eExp;
					}
					zipFile.setPassword(zipPassword);
				}
				zipFileName = FileUtils.getBaseName(inputFileName);
				destPath = zipFile.getFile().getParent() + File.separator + clientCode + File.separator + zipFileName;
				zipFile.extractAll(destPath);
				outFileName = destPath + File.separator + zipFileName;
				jobData.setMediaDetails(outFileName);
				jobData.setOrgMediaDetails(inputFileName);
			}
		}
		
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (ZipException exp)
		{
			errorMsg = "File:" + inputFileName + " not able to unzip ";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[] { errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "File:" + inputFileName + " not able to unzip ";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			clientCode = null;
			zipFile = null;
			inputFileName = null;
		}
		return null;
	}
}
