/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.hooks
 * FILE   : SysGenFileNameHook.java
 * CREATED: Jul 12, 2013 3:34:05 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.hooks;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.BatchBand;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

/**
 * <p>
 * This Helper class generates the file name. This class will be used if user not defined file name generation logic.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * Once new logic for file name generation is ready, create a Routine preload. Example:
 * <b>
 * insert into IRIS_ROUTINE_MST (ROUTINE_TYPE, ROUTINE_NAME, ROUTINE_DESC, ROUTINE_SUBTYPE, MAPPED_CLASS, VALID_FLAG)
 * values ('FILENAME_GEN_ROUTINE', 'CUSTOMGENNAME', 'Custom Generate File Name', 'J', 'com.fundtech.iris.irisadmin.hooks.FileNameGenerationHook', 'Y');
 * </b>
 * Add your jar to integrator class path.
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">IRIS Admin</td>
 * </tr>
 * <tr>
 * <td>
 * if user wants to get Execution Job details:- Example ExecutionJobData jobData = ExecutionJobData) data.get(IProcessHook.EXECUTION_DATA); if
 * java.sql.Connection used, commit/Rollback should be taken care by hook only.( No need to close the connection)</td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: SysGenFileNameHook.java,v 1.10 2014/07/20 04:58:27 ramap Exp $
 * @since 1.0.0
 */
public class SysGenFileNameHook extends IrisAdminPlugin
{
	
	private Map<String, String> splitValues = new HashMap<String, String>();
	private int count = 0;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public Object execute (Connection dbConnection, Map<String, Object> data) throws ExecutionException, FormatException
	{
		String clientCode = null;
		String executionId = null;
		String mapName = null;
		ExecutionJobData jobData = null;
		List<String> splitParms = null;
		BatchBand batchBand = null;
		String parmVal = null;
		String oldParmval = null;
		int firstIndex = -1;
		String bandRef = null;
		Band dataBand = null;
		boolean isDataChanged = false;
		
		jobData = (ExecutionJobData) data.get(IProcessHook.EXECUTION_DATA);
		batchBand = (BatchBand) data.get(IProcessHook.EXECUTION_BATCH);
		
		if (jobData.isSplitFile())
		{
			splitParms = (List<String>) data.get(IProcessHook.SPLIT_FILE_PARMS);
			for (String parmName : splitParms)
			{
				parmName = parmName.trim();
				firstIndex = parmName.indexOf(".");
				bandRef = parmName.substring(0, firstIndex);
				dataBand = getDataBand(batchBand, bandRef);
				parmVal = getRefValue(parmName, dataBand, batchBand);
				if (splitValues.containsKey(parmName))
				{
					oldParmval = splitValues.get(parmName);
					if (!oldParmval.equals(parmVal))
					{
						isDataChanged = true;
						splitValues.put(parmName, parmVal);
					}
				}
				else
				{
					isDataChanged = true;
					splitValues.put(parmName, parmVal);
				}
			}
			if (isDataChanged)
				count = count + 1;
			
			clientCode = jobData.getEntityCode();
			mapName = jobData.getMapName();
			executionId = jobData.getExecutionId();
			if ("XML".equals(jobData.getFormatterType()))
				return clientCode + mapName + executionId + count + ".xml";
			else
				return clientCode + mapName + executionId + count + ".txt";
		}
		else
		{
			clientCode = jobData.getEntityCode();
			mapName = jobData.getMapName();
			executionId = jobData.getExecutionId();
			if ("XML".equals(jobData.getFormatterType()))
				return clientCode + mapName + executionId + ".xml";
			else
				return clientCode + mapName + executionId + ".txt";
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param batchBand
	 * @param bandRef
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private Band getDataBand (BatchBand batchBand, String bandRef)
	{
		Band returnBand = null;
		
		for (Band band : batchBand.getBatchBands())
		{
			if (band.getName().equals(bandRef))
			{
				returnBand = band;
				break;
			}
		}
		return returnBand;
	}
	
}