/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.mapping
 * FILE   : IProcessHook.java
 * CREATED: Jun 25, 2013 9:25:28 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.hooks;

import java.sql.Connection;
import java.util.Map;

import com.fundtech.iris.admin.data.Band;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.SplitParameter;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: IProcessHook.java,v 1.6 2014/07/20 04:58:27 ramap Exp $
 * @since 1.0.0
 */
public interface IProcessHook
{
	public String EXECUTION_DATA = "EXECUTION_DATA";
	public String EXECUTION_BAND = "EXECUTION_BAND";
	public String EXECUTION_BATCH = "EXECUTION_BATCH";
	public String DATA_ROOT_BAND = "DATA_ROOT_BAND";
	
	/**
	 * This key gives (,) separated parameters of interface fields which are configured to validate split.
	 */
	public String SPLIT_FILE_PARMS = "SPLIT_FILE_PARMS";
	
	/**
	 * This key gives (,) separated parameters which taken from Filter Parameters to generate file name. This fields can be accessed by using
	 * EXECUTION_DATA
	 */
	public String FILE_GEN_FILTER_PARMS = "FILE_GEN_FILTER_PARMS";
	
	/**
	 * This key gives (,) separated field names of interface fields which are configured to generate file name.
	 */
	public String FILE_GEN_INT_FIELDS = "FILE_GEN_INT_FIELDS";
	
	/**
	 * 
	 * This method helps you initialize the hook. This could be reading a proprty file..etc
	 * 
	 * @throws ExecutionException
	 */
	public void initialize () throws FormatException, ExecutionException;
	
	/**
	 * 
	 * This
	 * 
	 * @param dbConnection
	 * @param dataBand
	 *            -- This Data contains several Objects like {@link ExecutionJobData} {@link SplitParameter} {@link Band} etc
	 * @return Object.. future purpose
	 * @throws ExecutionException
	 */
	public Object execute (Connection dbConnection, Map<String, Object> data) throws FormatException, ExecutionException;
}
