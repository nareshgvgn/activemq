/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.hooks
 * FILE   : SysGenEmptyFileNameHook.java
 * CREATED: Jul 16, 2013 12:49:07 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.hooks;

import java.sql.Connection;
import java.util.Map;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: SysGenEmptyFileNameHook.java,v 1.5 2014/07/20 04:58:27 ramap Exp $
 * @since 1.0.0
 */
public class SysGenEmptyFileNameHook extends IrisAdminPlugin
{
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.hooks.IProcessHook#execute(java.sql.Connection, com.fundtech.iris.admin.data.ExecutionJobData, java.util.List,
	 * com.fundtech.iris.admin.data.RootBand)
	 */
	public Object execute (Connection dbConnection, Map<String, Object> data) throws ExecutionException
	{
		String clientCode = null;
		String executionId = null;
		String mapName = null;
		ExecutionJobData jobData = null;
		
		jobData = (ExecutionJobData) data.get(IProcessHook.EXECUTION_DATA);
		clientCode = jobData.getEntityCode();
		mapName = jobData.getMapName();
		executionId = jobData.getExecutionId();
		return "Empty" + clientCode + mapName + executionId + ".txt";
	}
	
}
