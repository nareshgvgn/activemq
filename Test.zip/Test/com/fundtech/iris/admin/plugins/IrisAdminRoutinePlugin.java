/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : IrisAdminRoutinePlugin.java
 * CREATED: Mar 9, 2014 12:13:24 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.RootBand;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.hooks.IProcessHook;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IrisAdminRoutinePlugin.java,v 1.8 2015/10/04 06:06:58 ramap Exp $
 */
public class IrisAdminRoutinePlugin extends IrisAdminPlugin
{
	
	private static Logger logger = LoggerFactory.getLogger(IrisAdminRoutinePlugin.class);
	private String routineType = null;
	private final String logRoutineClass = "RoutineClass:";
	
	public IrisAdminRoutinePlugin()
	{
		// BABU Auto-generated constructor stub
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		ExecutionJobData jobData = null;
		Map<String, String> props = null;
		InterfaceDef interfaceDef = null;
		IProcessHook processHook = null;
		String routineClass = null;
		RootBand rootBand = null;
		Class<?> clazz = null;
		Map<String, Object> hookData = null;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		Object retObject = null;
		String strInterfaceDef = null;
		Map<String, String> routineClasses = null;
		IrisError irisError = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			
			props = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			routineClasses = (Map<String, String>) params.get(IrisAdminConstants.ROUTINE_CLASSES);
			interfaceDef = jobData.getInterfaceDef();
			rootBand = (RootBand) params.get(IrisAdminConstants.PROCESS_DATA);
			if (props.containsKey("RoutineType"))
			{
				routineType = props.get("RoutineType");
				if (IrisAdminConstants.PRE_PROCESSING_ROUTINE.equals(routineType))
				{
					routineClass = interfaceDef.getPreProcessingRoutine();
				}
				
				else if (IrisAdminConstants.POST_PROCESSING_ROUTINE.equals(routineType))
				{
					routineClass = interfaceDef.getPostProcessingRoutine();
				}
				
				else if (IrisAdminConstants.POST_UPDATION_ROUTINE.equals(routineType))
				{
					routineClass = interfaceDef.getPostUpdationRoutine();
					if (IrisAdminConstants.JOB_STATUS_SUCESS.equals(jobData.getStatus()))
						jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE);
				}
				
				else if (IrisAdminConstants.REVERSE_UPDATE_ROUTINE.equals(routineType))
				{
					routineClass = interfaceDef.getReverseUpdateRoutine();
					jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE);
				}
				
				if (routineClass == null || "".equals(routineClass))
					return null;
				
				/*
				 * Populate the additional requried Job Data from Process Defination.
				 */
				hookData = new HashMap<String, Object>();
				hookData.put(IProcessHook.DATA_ROOT_BAND, rootBand);
				hookData.put(IProcessHook.EXECUTION_DATA, jobData);
				clazz = Class.forName(routineClasses.get(routineClass));
				processHook = (IProcessHook) clazz.newInstance();
				processHook.initialize();
				retObject = processHook.execute(dbConnection, hookData);
				if (!jobData.getErrors().isEmpty())
				{
					throw new ExecutionException("fileprocessingerrors", new Object[] {}, null);
				}
			}
		}
		catch (ExecutionException exp)
		{
			setStatus(jobData);
			errorMsg = logRoutineClass + routineClass + " Failed its execution.";
			if (interfaceDef != null)
				strInterfaceDef = interfaceDef.toString();
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, strInterfaceDef, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(exp));
			throw exp;
		}
		catch (ClassNotFoundException exp)
		{
			setStatus(jobData);
			errorMsg = logRoutineClass + routineClass + " not found";
			
			if (interfaceDef != null)
				strInterfaceDef = interfaceDef.toString();
			eExp = new ExecutionException("error.iris.admin.routinecall", new Object[]{ errorMsg, strInterfaceDef }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, strInterfaceDef, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (InstantiationException exp)
		{
			setStatus(jobData);
			errorMsg = logRoutineClass + routineClass + " not able to Instantiation";
			if (interfaceDef != null)
				strInterfaceDef = interfaceDef.toString();
			eExp = new ExecutionException("error.iris.admin.routinecall", new Object[]	{ errorMsg, strInterfaceDef }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, strInterfaceDef, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			throw eExp;
		}
		catch (IllegalAccessException exp)
		{
			setStatus(jobData);
			errorMsg = logRoutineClass + routineClass + " not able to access";
			if (interfaceDef != null)
				strInterfaceDef = interfaceDef.toString();
			eExp = new ExecutionException("error.iris.admin.routinecall", new Object[]{ errorMsg, strInterfaceDef }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, strInterfaceDef, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			throw eExp;
		}
		catch (Exception exp)
		{
			setStatus(jobData);
			errorMsg = logRoutineClass + routineClass + " failed";
			if (interfaceDef != null)
				strInterfaceDef = interfaceDef.toString();
			eExp = new ExecutionException("error.iris.admin.routinecall", new Object[]{ errorMsg, strInterfaceDef }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, strInterfaceDef, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			throw eExp;
		}
		return retObject;
	}
	
	/**
	 * This helper method
	 * 
	 * @param jobData
	 */
	private void setStatus (ExecutionJobData jobData)
	{
		if (IrisAdminConstants.PRE_PROCESSING_ROUTINE.equals(routineType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
		else if (IrisAdminConstants.POST_PROCESSING_ROUTINE.equals(routineType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT);
		
		else if (IrisAdminConstants.POST_UPDATION_ROUTINE.equals(routineType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
		
		else if (IrisAdminConstants.REVERSE_UPDATE_ROUTINE.equals(routineType))
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
	}
}
