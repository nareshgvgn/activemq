/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : InterfaceFTPPlugin.java
 * CREATED: Jun 13, 2014 7:01:39 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.FTPHelper;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceFTPPlugin.java,v 1.4 2017/02/27 13:21:08 ramap Exp $
 */
public class InterfaceFTPPlugin extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(InterfaceFTPPlugin.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		
		ExecutionJobData jobData = null;
		SecurityProfile secProfile = null;
		String channelType = null;
		ExecutionException eExp = null;
		InterfaceMap interfaceMap = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			interfaceMap = jobData.getInterfaceMap();
			secProfile = interfaceMap.getSecurityProfile();
			if (secProfile != null)
			{
				channelType = secProfile.getChannelType();
				if (channelType == null)
					return null;
				doFTP(params);
			}
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE);
		}
		catch (ExecutionException ex)
		{
			throw ex;
		}
		catch (Exception ex)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			eExp = new ExecutionException("error.iris.admin.interface.FTP", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		return null;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param secProfile
	 * @param jobData
	 * </pre>
	 * 
	 * </p>
	 */
	@SuppressWarnings("unchecked")
	private void doFTP (Map<String, Object> params) throws ExecutionException
	{
		ExecutionJobData jobData = null;
		SecurityProfile secProfile = null;
		Map<String, String> staticProps = null;
		InterfaceMap interfaceMap = null;
		List<String> fileList = null;
		String destDir = null;
		String channelIp = null;
		int channelPort = 0;
		String channelType = null;
		String channelUser = null;
		String channelPass = null;
		String proxyHost = null;
		String proxyPort = null;
		String proxyUser = null;
		String proxyPass = null;
		FTPHelper ftpHelper = null;
		ExecutionException eExp = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			interfaceMap = jobData.getInterfaceMap();
			secProfile = interfaceMap.getSecurityProfile();
			fileList = jobData.getSplitFileList();
			destDir = secProfile.getChannelBasePath();
			channelIp = secProfile.getChannelIPAddress();
			channelPass = secProfile.getChannelPassword();
			channelPort = secProfile.getChannelPort();
			channelUser = secProfile.getChannelUser();
			channelType = secProfile.getChannelType();
			staticProps = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			proxyHost = staticProps.get("ProxyHost");
			proxyPort = staticProps.get("ProxyPort");
			proxyPort = staticProps.get("ProxyUser");
			proxyPort = staticProps.get("ProxyPassword");
			ftpHelper = new FTPHelper(channelIp, channelPort, channelUser, channelPass, channelType);
			ftpHelper.setProtocol(channelType);
			ftpHelper.setProxyDetails(proxyHost, proxyPort, proxyUser, proxyPass);
			ftpHelper.uploadFiles(fileList, destDir);
			
		}
		catch (IOException ex)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			eExp = new ExecutionException("error.iris.admin.interface.FTP", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (GeneralSecurityException ex)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			eExp = new ExecutionException("error.iris.admin.interface.FTP", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception ex)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			eExp = new ExecutionException("error.iris.admin.interface.FTP", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			ftpHelper = null;
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param params
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	private List<String> getFromFTP (Map<String, Object> params) throws ExecutionException
	{
		ExecutionJobData jobData = null;
		SecurityProfile secProfile = null;
		Map<String, String> staticProps = null;
		InterfaceMap interfaceMap = null;
		List<String> fileList = null;
		String destDir = null;
		String channelIp = null;
		int channelPort = 0;
		String channelType = null;
		String channelUser = null;
		String channelPass = null;
		String proxyHost = null;
		String proxyPort = null;
		String proxyUser = null;
		String proxyPass = null;
		FTPHelper ftpHelper = null;
		ExecutionException eExp = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			interfaceMap = jobData.getInterfaceMap();
			secProfile = interfaceMap.getSecurityProfile();
			fileList = jobData.getSplitFileList();
			destDir = secProfile.getChannelBasePath();
			channelIp = secProfile.getChannelIPAddress();
			channelPass = secProfile.getChannelPassword();
			channelPort = secProfile.getChannelPort();
			channelUser = secProfile.getChannelUser();
			channelType = secProfile.getChannelType();
			staticProps = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			proxyHost = staticProps.get("ProxyHost");
			proxyPort = staticProps.get("ProxyPort");
			proxyPort = staticProps.get("ProxyUser");
			proxyPort = staticProps.get("ProxyPassword");
			ftpHelper = new FTPHelper(channelIp, channelPort, channelUser, channelPass, channelIp);
			ftpHelper.setProtocol(channelType);
			ftpHelper.setProxyDetails(proxyHost, proxyPort, proxyUser, proxyPass);
			fileList = ftpHelper.downloadFiles(jobData.getMediaDetails(), destDir, true, "Backup");
			
		}
		catch (IOException ex)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			eExp = new ExecutionException("error.iris.admin.interface.FTP", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (GeneralSecurityException ex)
		{
			jobData.setStatus(IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE);
			eExp = new ExecutionException("error.iris.admin.interface.FTP", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			ftpHelper = null;
		}
		
		return fileList;
	}
}
