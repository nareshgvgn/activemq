/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : SymmetricEncryptionPlugin.java
 * CREATED: Oct 17, 2013 11:21:51 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.exceptions.NotSupportedException;
import com.fundtech.iris.admin.exceptions.SecurityException;
import com.fundtech.iris.admin.security.ISymmetricSecurityProvider;
import com.fundtech.iris.admin.security.SecurityProviderFactory;
import com.fundtech.iris.admin.security.SymmetricSigning;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: SymmetricEncryptionPlugin.java,v 1.16 2017/03/27 12:06:52 ramap Exp $
 * @since 1.0.0
 */
public class SymmetricEncryptionPlugin extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(SymmetricEncryptionPlugin.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		String algorithm = null;
		InterfaceMap interfaceMap = null;
		int keySize = 0;
		String downloadFileName = null;
		ExecutionException eExp = null;
		ExecutionJobData jobData = null;
		List<String> spList = null;
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			interfaceMap = jobData.getInterfaceMap();
			spList = jobData.getSplitFileList();
			for (String fileName : spList)
			{
				downloadFileName = fileName;
				jobData.setMediaDetails(downloadFileName);
				executeCrypto(jobData, interfaceMap);
			}
		}
		catch (NotSupportedException exp)
		{
			// jobData.setErrorMsg("Not Supported,Algorithm:" + algorithm + "keySize:" + keySize);
			eExp = new ExecutionException("error.iris.admin.decryptionnotsupported", new Object[]
			{ "Algorithm:" + algorithm, "keySize:" + keySize }, exp);
			throw eExp;
		}
		catch (FileNotFoundException exp)
		{
			// jobData.setErrorMsg("File not found FileName:" + downloadFileName);
			eExp = new ExecutionException("error.iris.admin.decryptionfilenotfound", new Object[]
			{ "FileName:" + downloadFileName }, exp);
			throw eExp;
		}
		catch (SecurityException exp)
		{
			// jobData.setErrorMsg("Encryption failed FileName:" + downloadFileName + "Algorithm:" + algorithm + "keySize:" + keySize);
			eExp = new ExecutionException("error.iris.admin.decryptionnotdone", new Object[]
			{ "Algorithm:" + algorithm, "keySize:" + keySize, "FileName:" + downloadFileName }, exp);
			throw eExp;
		}
		catch (IOException exp)
		{
			// jobData.setErrorMsg("Encryption failed FileName:" + downloadFileName + "Algorithm:" + algorithm + "keySize:" + keySize);
			eExp = new ExecutionException("error.iris.admin.decryptionnotdone", new Object[]
			{ "Algorithm:" + algorithm, "keySize:" + keySize, "FileName:" + downloadFileName }, exp);
			throw eExp;
		}
		
		return null;
	}
	
	private void executeCrypto (ExecutionJobData jobData, InterfaceMap interfaceMap) throws NotSupportedException, IOException, SecurityException,
			ExecutionException
	{
		
		String algorithm = null;
		String encryptionKey = null;
		ISymmetricSecurityProvider securityProvider = null;
		int keySize = 0;
		String downloadFileName = null;
		InputStream inputStream = null;
		OutputStream outStream = null;
		File tempFile = null;
		File downloadFile = null;
		SymmetricSigning sigining = null;
		SecurityProfile secProfile = null;
		
		try
		{
			secProfile = interfaceMap.getSecurityProfile();
			if (secProfile.isSiginingRequired())
			{
				sigining = getSymmetricSigning();
				sigining.executeDownload(jobData);
			}
			if (secProfile.isEncryptionRequired())
			{
				downloadFileName = jobData.getMediaDetails();
				algorithm = secProfile.getEncryptionAlgo();
				encryptionKey = secProfile.getEncryptionKey();
				keySize = secProfile.getEncryptionKeyLength();
				securityProvider = getSecurityProvider().getSymmetricInstance(algorithm);
				downloadFile = new File(downloadFileName);
				inputStream = new FileInputStream(downloadFile);
				tempFile = File.createTempFile("enc_", ".dat");
				outStream = new FileOutputStream(tempFile);
				securityProvider.encrypt(encryptionKey, keySize, inputStream, outStream);
				HelperUtils.doClose(inputStream);
				HelperUtils.doClose(outStream);
				copyFile(tempFile, downloadFile);
			}
		}
		finally
		{
			HelperUtils.doClose(inputStream);
			HelperUtils.doClose(outStream);
		}
		
	}
	
	/**
	 * To copy a file.
	 * 
	 * @param sourceFile
	 *            - Source file
	 * @param destFile
	 *            - Destination file
	 */
	private void copyFile (File sourceFile, File destFile)
	{
		FileChannel sourceChannel = null;
		FileChannel destChannel = null;
		FileInputStream inStream = null;
		FileOutputStream outStream = null;
		
		try
		{
			inStream = new FileInputStream(sourceFile);
			outStream = new FileOutputStream(destFile);
			sourceChannel = inStream.getChannel();
			destChannel = outStream.getChannel();
			
			if (logger.isDebugEnabled())
				logger.debug("File ::" + sourceFile.getName() + " To Be copied From : " + sourceFile.getParent() + " To : " + destFile.getParent());
			
			destChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
			outStream.flush();
		}
		catch (Exception e)
		{
			logger.error("Exception : ", e);
		}
		finally
		{
			HelperUtils.doClose(sourceChannel);
			HelperUtils.doClose(destChannel);
			HelperUtils.doClose(inStream);
			HelperUtils.doClose(outStream);
		}
	}
	
	private SecurityProviderFactory getSecurityProvider()
	{
		SecurityProviderFactory factory = null;
		
		try
		{
			factory = (SecurityProviderFactory) ContextManager.getInstance().getBeanObject(SecurityProviderFactory.class);
		}
		catch ( Exception exp)
		{
			logger.warn("Error:",exp);
			factory = new SecurityProviderFactory();
		}
		
	return factory;
	}
	
	private SymmetricSigning getSymmetricSigning()
	{
		SymmetricSigning factory = null;
		
		try
		{
			factory = (SymmetricSigning) ContextManager.getInstance().getBeanObject("symmetricSigningHelper");
		}
		catch ( Exception exp)
		{
			logger.warn("Error:",exp);
			factory = new SymmetricSigning();
		}
		
		return factory;
	}
}
