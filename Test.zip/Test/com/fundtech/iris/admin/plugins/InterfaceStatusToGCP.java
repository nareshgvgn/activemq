/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : InterfaceStatusToGCP.java
 * CREATED: Feb 5, 2014 1:01:20 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.FileUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * This plug in class updated the GCP Status to screens.
 * <h3>Configuration for IRIS</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * 
 * &lt;NodeDefinition id="StatusToGCP" nodeClass="com.fundtech.iris.admin.execution.nodes.InterfacePluginNode"&gt;
 * 		&lt;References&gt;
 * 			&lt;Reference name="uploadType" type="INPUT_TYPE"/&gt;
 * 			&lt;Reference name="uploadType" type="OUTPUT_TYPE"/&gt;
 * 		&lt;/References&gt;
 * 		&lt;Parameter name="HelperClass" value="com.fundtech.iris.admin.plugins.InterfaceStatusToGCP"/&gt;
 * 	&lt;/NodeDefinition&gt;
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceStatusToGCP.java,v 1.21 2016/10/19 14:04:55 ramap Exp $
 */
public class InterfaceStatusToGCP extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(InterfaceStatusToGCP.class);
	
	public InterfaceStatusToGCP()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		ExecutionJobData jobData = null;
		String procCall = "{CALL pkg_integrate_gcp.update_gcp_status(?, ?, ?, ?)}";
		CallableStatement cStmt = null;
		ExecutionException eExp = null;
		String executionId = null;
		String errorMsg = null;
		String errorCode = null;
		IrisAdminError error = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		IrisError irisError = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			if (!jobData.getErrors().isEmpty() || "E".equals(jobData.getStatus()) || "R".equals(jobData.getStatus()))
			{
				errorCode = "Error";
				errorMsg = " Error: Please check the report";
			}
			else if ("EMPTYGEN".equals(jobData.getErrorCode()))
			{
				errorCode = "Sucess";
				errorMsg = "No Data For Download";
			}
			else if ("EMPTYNOGEN".equals(jobData.getErrorCode()))
			{
				errorCode = "Sucess";
				errorMsg = "No Data For Download";
			}
			else
			{
				errorCode = "Sucess";
				errorMsg = " Data Downloaded Successfully";
			}
			
			startTime = System.currentTimeMillis();
			// If its download then only execute & If Pregen flag Y then only insert
			if (IrisAdminConstants.DEFINITION_TYPE_DOWNLOAD.equals(jobData.getMapType())
					&& IrisAdminConstants.MEDIA_FILE.equals(jobData.getMediumType()) 
					&& ! IrisAdminConstants.CONSTANT_N.equals(jobData.getFilterParameter(IrisAdminConstants.PRE_GEN_FLAG)))
				createPreGenerated(dbConnection, jobData, errorMsg);
			
			cStmt = dbConnection.prepareCall(procCall);
			executionId = jobData.getExecutionId();
			cStmt.setString(1, executionId);
			cStmt.setString(2, jobData.getRefId());
			cStmt.setString(3, errorCode);
			cStmt.setString(4, errorMsg);
			
			cStmt.executeUpdate();
			dbConnection.commit();
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing pkg_integrate_gcp.update_gcp_status  StoredProcedure: {}" , delta);
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_STATUS, errorMsg, procCall, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
		return null;
	}
	
	private void createPreGenerated (Connection dbConnection, ExecutionJobData jobData, String message) throws ExecutionException
	{
		PreparedStatement pregenPs = null;
		String errorMsg = null;
		IrisAdminError error = null;
		ExecutionException eExp = null;
		String ftpPath = null;
		File outFile = null;
		double bytes = 0;
		double kilobytes = 0;
		IrisError irisError = null;
		
		String pregenSql = "INSERT INTO IRIS_PRE_GEN_TXN (ENTITY_TYPE,ENTITY_CODE,SRC_TYPE,SRC_NAME,SRC_DESCRIPTION,SCHEDULE_ID,"
				+ "EXECUTION_ID,APP_DATE,CREATED_DATE ,FILE_NAME,FILE_SIZE,del_output,SELLER_CODE,ADDITIONAL_INFO,STATUS,pre_gen_id,CHANNEL_NAME) "
				+ "VALUES (?,?,?,?,?,?,?,generic.get_date(?),SYSDATE ,?,?,?,?,?,?," + "generic.f_generate_sequence_id('IRIS_PREGEN_ID'),?)";
		try
		{
			pregenPs = dbConnection.prepareStatement(pregenSql);
			if (jobData.isNoData())
			{
				/*
				 * The bellow lines commented coz if No data we no need to insert in pre gen. This was coded coz of anz requirement but now we have job monitoring screen 
				 * which should show no data found. 
				 */
				
//				pregenPs.clearParameters();
//				
//				pregenPs.setString(1, jobData.getEntityType());
//				pregenPs.setString(2, jobData.getEntityCode());
//				pregenPs.setString(3, jobData.getMapType());
//				pregenPs.setString(4, jobData.getMapName());
//				pregenPs.setString(5, null); // src description
//				pregenPs.setString(6, jobData.getRefId());
//				pregenPs.setString(7, jobData.getExecutionId());
//				pregenPs.setString(8, jobData.getSellerCode());// ADD DATE
//				// CREATED_DATE is SYSDATE
//				pregenPs.setString(9, null); // coz its empty file
//				pregenPs.setInt(10, 0);
//				pregenPs.setString(11, null); // GET FILE EXTN
//				pregenPs.setString(12, jobData.getSellerCode());
//				pregenPs.setString(13, message);
//				pregenPs.setString(14, jobData.getStatus());
//				// Recordkey Number used oracle sequence
//				if ( jobData.getRefId() ==  null)
//					pregenPs.setString(15, "SUB");
//				else 
//					pregenPs.setString(15, "SCH");
//				pregenPs.executeUpdate();
				
			}
			else
			{
				ftpPath = jobData.getFtpPath();
				for (String file : jobData.getSplitFileList())
				{
					pregenPs.clearParameters();
					
					pregenPs.setString(1, jobData.getEntityType());
					pregenPs.setString(2, jobData.getEntityCode());
					pregenPs.setString(3, jobData.getMapType());
					pregenPs.setString(4, jobData.getMapName());
					pregenPs.setString(5, null); // src description
					pregenPs.setString(6, jobData.getRefId());
					pregenPs.setString(7, jobData.getExecutionId());
					pregenPs.setString(8, jobData.getSellerCode());// ADD DATE
					// CREATED_DATE is SYSDATE
					outFile = new File(file);
					bytes = outFile.length();
					kilobytes = Math.round(bytes / 1024 * 100.0)/100.0;
					file = file.replace(ftpPath, "");
					file = "." + file;
					pregenPs.setString(9, file); // coz its empty file
					pregenPs.setString(10, kilobytes + "KB");
					pregenPs.setString(11, FileUtils.getExtension(file).toUpperCase()); // GET FILE EXTN
					pregenPs.setString(12, jobData.getSellerCode());
					pregenPs.setString(13, message);
					pregenPs.setString(14, jobData.getStatus());
					// Recordkey Number used oracle sequence
					if ( jobData.getRefId() ==  null)
						pregenPs.setString(15, "SUB");
					else 
						pregenPs.setString(15, "SCH");
					pregenPs.addBatch();
				}
				pregenPs.executeBatch();
			}
			
			
			dbConnection.commit();
		}
		catch (SQLException e)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]
			{ errorMsg }, e);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_STATUS, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(pregenPs);
		}
		
	}
	
}
