/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : InterfaceStatusUpdate.java
 * CREATED: Mar 10, 2014 10:35:48 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.interfaces.InterfaceBandDef;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.DBToDBUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: InterfaceStatusUpdate.java,v 1.19 2017/01/30 04:50:14 ramap Exp $
 */
public class InterfaceStatusUpdate extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(InterfaceStatusUpdate.class);
	private static final String updateSql = "UPDATE IRIS_JOB_QUEUE T SET T.STATUS = ?, T.SYS_END_DATE = SYSDATE , END_DATE = pk_timezone.get_seller_time(?), "
			+ "ERROR_CODE=?, ERROR_MSG=?, MEDIA_DTLS= ? WHERE T.EXECUTION_ID = ?";
	
	public InterfaceStatusUpdate()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		ExecutionJobData jobData = null;
		String jobStatus = null;
		InterfaceDef iDef = null;
		Map<String, InterfaceBandDef> bandDefs = null;
		Connection hostDbConnection = null;
		String mediaType = null;
		
		try
		{
			
			jobData = (ExecutionJobData) params.get(IrisAdminConstants.EXECUTION_DATA);
			jobStatus = jobData.getStatus();
			mediaType = jobData.getMediumType();
			
			/*
			 * E and S are ERROR and Sucess. S status comes after completion of Interface procedure call E Status comes if any error before interface
			 * procedure call
			 */
			
			if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus) || IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE.equals(jobStatus)
					|| IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
			{
				iDef = jobData.getInterfaceDef();
				if ( IrisAdminConstants.MEDIA_DATABASE.equals(iDef.getMediumType()))
				{
					hostDbConnection = getHostDBSession(jobData);
					bandDefs = iDef.getBandsDefinition().getBandDefinitions();
					for ( Map.Entry<String, InterfaceBandDef> entry : bandDefs.entrySet())
					{
						finishHostJob(entry.getValue(),jobData, hostDbConnection);
					}
					CleanUpUtils.doClean(hostDbConnection);
				}
				if ( IrisAdminConstants.MEDIA_FILE.equals(mediaType) )
				{
					getOriginalFile(jobData);
					moveFiles(jobData);
				}
				updateJobStatus(dbConnection, jobData);
				finishJob(dbConnection, jobData);
			}
			else
				updateJobStatus(dbConnection, jobData);
			
			return null;
		}
		finally
		{
			CleanUpUtils.doClean(hostDbConnection);
		}
	}
	
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * </pre></p>
	 */
	private void getOriginalFile (ExecutionJobData jobData)
	{
		File tempFile = null;
		String originalFileName = null;
		String tempFileName = null;
		
		originalFileName = jobData.getOrgMediaDetails();
		tempFileName = jobData.getMediaDetails();
		if ( originalFileName != null &&  ! tempFileName.equals(originalFileName))
		{
			tempFile = new File(tempFileName);
			if ( tempFile.exists())
				tempFile.delete();
			
			jobData.setMediaDetails(originalFileName);
			jobData.setOrgMediaDetails(null);
		}
		
	}

	private void updateJobStatus (Connection dbConnection, ExecutionJobData jobData) throws ExecutionException
	{
		PreparedStatement updateSt = null;
		int status = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String jobStatus = null;
		String errorCode = "Sucess";
		String errorMsg = "Sucess";
		IrisAdminError error = null;
		List<IrisAdminError> errors = null;
		IrisError irisError = null;
//		String sellerDate = "pk_timezone.get_seller_time";
		try
		{
			errors = jobData.getErrors();
			if ( "E".equals(jobData.getStatus()) || "R".equals(jobData.getStatus()))
			{
				if ( errors.size() > 0 )
				{
					error = errors.get(0);
					errorMsg = error.getErrorMessage();
				}
				else
				errorMsg = "Error";
				errorCode = "Error";
			}
			executionId = jobData.getExecutionId();
			jobStatus = jobData.getStatus();
			
			
			updateSt = dbConnection.prepareStatement(updateSql);
			updateSt.clearParameters();
			updateSt.setString(1, jobStatus);
			updateSt.setString(2, jobData.getSellerCode());
			updateSt.setString(3, errorCode);
			updateSt.setString(4, errorMsg);
			updateSt.setString(5, jobData.getMediaDetails());
			updateSt.setString(6, executionId);
			status = updateSt.executeUpdate();
			
			if (status < 0)
				logger.warn("Job:" + executionId + " record not available for status update");
			else if (logger.isTraceEnabled())
				logger.debug("Job:" + executionId + " Record status updated");
			dbConnection.commit();
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]
			{ errorMsg, updateSql }, exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_STATUS, errorMsg, updateSql, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg, updateSql },exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_STATUS, errorMsg, updateSql, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(updateSt);
		}
		
	}
	
	private void finishJob (Connection dbConnection, ExecutionJobData jobData) throws ExecutionException
	{
		CallableStatement cStmt = null;
		String sql = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String errorCode = "Sucess";
		String errorMsg = "Sucess";
		IrisAdminError error = null;
		List<IrisAdminError> errors = null;
		String refId = null;
		IrisError irisError = null;
		try
		{
			
			errors = jobData.getErrors();
			if ( "E".equals(jobData.getStatus()) || "R".equals(jobData.getStatus()))
			{
				if ( errors.size() > 0 )
				{
					error = errors.get(0);
					errorMsg = error.getErrorMessage();
				}
				else
				errorMsg = "Error";
				errorCode = "Error";
			}
			
			startTime = System.currentTimeMillis();
			sql = "{CALL pkg_iris_admin.finish_iris_job (?, ?, ?, ?,?)}";
			cStmt = dbConnection.prepareCall(sql);
			executionId = jobData.getExecutionId();
			cStmt.setString(1, executionId);
			if (! IrisAdminConstants.SCH_SEGMENTED.equals(jobData.getSrcSubType()) && ! IrisAdminConstants.SCH_PROFILE.equals(jobData.getSrcSubType()))
				refId = jobData.getRefId();
			
			cStmt.setString(2, refId);
			cStmt.setString(3, jobData.getStatus());
			cStmt.setString(4, errorCode);
			cStmt.setString(5, errorMsg);
			
			cStmt.executeUpdate();
			dbConnection.commit();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing pkg_iris_admin.finish_iris_job " + " StoredProcedure: " + delta);
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]
			{ errorMsg, sql }, exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_STATUS, errorMsg, sql, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
	}
	
	/**
	 * TODO
	 * 
	 * @param jobData
	 */
	private void moveFiles (ExecutionJobData jobData)
	{
		String interfaceType = null;
		String destPath = null;
		String jobStatus = null;
		String srcFileName = null;
		List<String> spList = null;
		List<String> outList = null;
		String destFileName = null;
		
		jobStatus = jobData.getStatus();
		interfaceType = jobData.getMapType();
		
		if (IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(interfaceType))
		{
			if (IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE.equals(jobStatus))
				destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_DESTINATION_DIRECTORY);
			else if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus))
				destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
			else if (IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
				destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
			else
				destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
			
		}
		else
		{
			if (IrisAdminConstants.JOB_STATUS_SUCESS_COMPLETE.equals(jobStatus))
				destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_DESTINATION_DIRECTORY);
			else if (IrisAdminConstants.JOB_STATUS_REJECT_COMPLETE.equals(jobStatus))
				destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
			else if (IrisAdminConstants.JOB_STATUS_OUTRIGHT_REJECT.equals(jobStatus))
				destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_ERROR_DIRECTORY);
			else if (IrisAdminConstants.JOB_STATUS_SUCESS.equals(jobStatus))
				destPath = jobData.getFilterParameter(IrisAdminConstants.FILE_DESTINATION_DIRECTORY);
		}
		if (destPath == null)
			return;
		
		if (IrisAdminConstants.DEFINITION_TYPE_DOWNLOAD.equals(interfaceType))
		{
			if (jobData.isSplitFile())
			{
				spList = jobData.getSplitFileList();
				outList = new ArrayList<String>();
				for (String fileName : spList)
				{
					srcFileName = fileName;
					destFileName = move(srcFileName, destPath, jobData);
					outList.add(destFileName);
				}
				jobData.setSplitFile(outList);
				return;
			}
		}
		
		srcFileName = jobData.getMediaDetails();
		move(srcFileName, destPath, jobData);
	}
	
	private String move (String sourceFileName, String destFolder, ExecutionJobData jobData)
	{
		File sourceFile = null;
		File destFile = null;
		File finalDest = null;
		
		try
		{
			sourceFile = new File(sourceFileName);
			destFile = new File(jobData.getFtpPath(), destFolder);
			
			if (!sourceFile.exists() && sourceFile.isDirectory())
				return sourceFileName;
			if (!destFile.exists())
			{
				if (destFile.mkdirs())
				{
				}
				else
				{
					logger.error("Couldn't make folder creation:" + destFile.getAbsolutePath());
					return sourceFileName;
				}
			}
			
			if (!sourceFile.getParent().equals(destFile.getAbsolutePath()))
			{
				finalDest = new File(destFile, sourceFile.getName());
				if (logger.isTraceEnabled())
					logger.trace("File Moved from :" + sourceFile.getAbsolutePath() + " to:" + finalDest.getAbsolutePath());
				
				sourceFile.renameTo(finalDest);
				if (!jobData.isSplitFile())
					jobData.setMediaDetails(finalDest.getAbsolutePath());
				return finalDest.getAbsolutePath();
			}
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
			logger.error("Couldn't move file from:" + sourceFileName + " to:" + destFolder);
		}
		
		return sourceFileName;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * @return
	 * </pre></p>
	 */
	private Connection getHostDBSession (ExecutionJobData jobData)
	{
		DataSource dataSource = null;
		ContextManager manager = null;
		Connection hostDbConnection = null;
		
		try
		{
			manager = ContextManager.getInstance();
			dataSource = (DataSource)manager.getBeanObject(jobData.getFilterParameter(IrisAdminConstants.DB_SESSION_NAME));
			hostDbConnection = dataSource.getConnection();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (BeanConfigException e)
		{
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return hostDbConnection;
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * </pre></p>
	 */
	private void finishHostJob (InterfaceBandDef bandDef , ExecutionJobData jobData, Connection hostDbConnection)
	{
		Map<String, InterfaceBandDef> childBandDefs = null;
		
		DBToDBUtils.callHostUpdate(bandDef, jobData, hostDbConnection);
		
		childBandDefs = bandDef.getChildDefinitions().getBandDefinitions();
		for ( Map.Entry<String , InterfaceBandDef> entry : childBandDefs.entrySet())
		{
			finishHostJob(entry.getValue(), jobData, hostDbConnection);
		}
	}

	
}
