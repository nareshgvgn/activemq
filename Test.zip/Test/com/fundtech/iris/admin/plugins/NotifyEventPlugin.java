/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : NotifyEventPlugin.java
 * CREATED: Feb 5, 2014 3:47:35 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * This plugin will create event based on status and type of interface
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * &lt;NodeDefinition id="Notify" nodeClass="com.fundtech.iris.admin.execution.nodes.InterfacePluginNode"&gt;
 * 		&lt;References&gt;
 * 			&lt;Reference name="uploadType" type="INPUT_TYPE"/&gt;
 * 			&lt;Reference name="uploadType" type="OUTPUT_TYPE"/&gt;
 * 		&lt;/References&gt;
 * 		&lt;Parameter name="HelperClass" value="com.fundtech.iris.admin.plugins.NotifyEventPlugin"/&gt;
 * 	&lt;/NodeDefinition&gt;
 * </pre>
 * 
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: NotifyEventPlugin.java,v 1.11 2015/10/19 12:03:52 ramap Exp $
 */
public class NotifyEventPlugin extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(NotifyEventPlugin.class);
	
	public NotifyEventPlugin()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		ExecutionJobData jobData = null;
		String procCall = "{CALL pkg_integrate_gcp.notify_gcp_event (?, ?, ?)}";
		CallableStatement cStmt = null;
		ExecutionException eExp = null;
		String executionId = null;
		InterfaceMap interfaceMap = null;
		String errorMsg = null;
		IrisAdminError error = null;
		SecurityProfile secProfile = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		IrisError irisError = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			interfaceMap = jobData.getInterfaceMap();
			secProfile = interfaceMap.getSecurityProfile();
			if ("E".equals(jobData.getStatus()) || "R".equals(jobData.getStatus()))
			{
				if (!secProfile.isNotifyFailure())
					return null;
				
			}
			else
			{
				if (!secProfile.isNotifySucess())
					return null;
			}
			startTime = System.currentTimeMillis();
			cStmt = dbConnection.prepareCall(procCall);
			executionId = jobData.getExecutionId();
			cStmt.setString(1, executionId);
			cStmt.setString(2, jobData.getMapType());
			cStmt.setString(3, jobData.getStatus());
			cStmt.executeUpdate();
			dbConnection.commit();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing pkg_integrate_gcp.notify_gcp_event " + " StoredProcedure: " + delta);
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_NOTIFY, errorMsg, procCall, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
			
		}
		finally
		{
			HelperUtils.doClose(cStmt);
		}
		return null;
	}
	
}
