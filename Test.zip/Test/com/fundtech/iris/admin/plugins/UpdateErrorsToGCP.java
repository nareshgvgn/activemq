/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : UpdateErrorsToGCP.java
 * CREATED: Mar 10, 2014 1:25:04 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: UpdateErrorsToGCP.java,v 1.12 2016/02/08 05:36:04 ramap Exp $
 */
public class UpdateErrorsToGCP extends GenerateErrorLog
{
	private static Logger logger = LoggerFactory.getLogger(UpdateErrorsToGCP.class);
	
	public UpdateErrorsToGCP()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		Object retunObject = null;
		ExecutionJobData jobData = null;
		Queue<IrisError> irisErrors = null;
		String executionId = null;
		int count = 1;
		int batchSize = 1000;
		List<IrisAdminError> errors = null;
		PreparedStatement erroStmt = null;
		PreparedStatement irisErrorStmt = null;
		String irisErrorsql = "INSERT INTO INT_MONITORING_ERRORS(execution_id, sr_nmbr,record_level, record_nmbr, reference_key, reject_reason) values(?,?,?,?,?,?)";
		String sql = "insert into IRIS_INT_ERRORS (EXECUTION_ID, APPL_DATE, MASTER_TABLE_NAME, FIELD_NAME,"
				+ " REJECT_CODE, ROW_NMBR, ROW_DATA, REJECT_REASON)" + " values (?,generic.get_date(?),?,?,?,?,?,?)";
		
		try
		{
			// Call super method so that it creates the error file
			retunObject = super.execute(dbConnection, params);
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			irisErrors = jobData.getIrisErrors();
			executionId = jobData.getExecutionId();
			if ( irisErrors.size() > 0)
			{
				irisErrorStmt = dbConnection.prepareStatement(irisErrorsql);
				logger.debug("Executing SQL:{} for errors{}", irisErrorsql, irisErrors.size());
				for ( IrisError error : irisErrors)
				{
					irisErrorStmt.clearParameters();
					irisErrorStmt.setString(1, executionId);
					irisErrorStmt.setInt(2, count);
					count ++;
					irisErrorStmt.setString(3, error.getBandName());
					irisErrorStmt.setLong(4, error.getLineNumber());
					irisErrorStmt.setString(5, error.getErrorCode());
					irisErrorStmt.setString(6, error.getErrorDesc());
					irisErrorStmt.addBatch();
					
					if (count == batchSize)
					{
						irisErrorStmt.executeBatch();
						irisErrorStmt.clearBatch();
						batchSize = batchSize + count;
					}
				}
				irisErrorStmt.executeBatch();
				irisErrorStmt.clearBatch();
				dbConnection.commit();
			}
			errors = jobData.getErrors();
			
			if ( errors.size() > 0)
			{
				erroStmt = dbConnection.prepareStatement(sql);
				
				for (IrisAdminError error : errors)
				{
					createInsert(error, jobData, erroStmt);
				}
				erroStmt.executeBatch();
				dbConnection.commit();
			}
		}
		catch (SQLException e)
		{
			// Do not throw Exception
			logger.error("Error Wile insert into t_upload_errors", e);
			
		}
		finally
		{
			HelperUtils.doClose(irisErrorStmt);
			HelperUtils.doClose(erroStmt);
			CleanUpUtils.doClean(jobData.getIrisErrors());
		}
		
		return retunObject;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param error
	 * @param jobData
	 * @param erroStmt
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @throws SQLException
	 */
	private void createInsert (IrisAdminError error, ExecutionJobData jobData, PreparedStatement errorStmt) throws SQLException
	{
		String errorLine = null;
		
		errorStmt.clearParameters();
		errorLine = error.getErrorLine();
		if (errorLine != null && errorLine.length() > 4000)
			errorLine = errorLine.substring(0, 3999);
		
		errorStmt.setString(1, jobData.getExecutionId());
		errorStmt.setString(2, jobData.getSellerCode());
		errorStmt.setString(3, " ");// mater table name
		errorStmt.setString(4, " "); // field name
		errorStmt.setString(5, error.getErrorCode());
		errorStmt.setInt(6, Integer.parseInt("" + error.getLineNumber()));
		errorStmt.setString(7, errorLine);
		errorStmt.setString(8, error.getErrorMessage());
		errorStmt.addBatch();
	}
}
