/*
 * ==================================================================== Licensed to the Apache Software Foundation (ASF) under one or more contributor
 * license agreements. See the NOTICE file distributed with this work for additional information regarding copyright ownership. The ASF licenses this
 * file to You under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations
 * under the License. ====================================================================
 */

package com.fundtech.iris.admin.plugins;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.interfaces.InterfaceDef;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * 
 * This class taken from POI sample and modified
 * 
 * @author Babu Paluri
 * @version $Id: XLSToDelimiterPlugin.java,v 1.17 2016/08/04 12:14:26 ramap Exp $
 * @since 1.0.0
 */
public class XLSToDelimiterPlugin extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(XLSToDelimiterPlugin.class);
	private Workbook workbook = null;
	private ArrayList<ArrayList<String>> csvData = null;
	private int maxRowWidth = 0;
	private DataFormatter formatter = null;
	private FormulaEvaluator evaluator = null;
	private String delimiter = null;
	private String qualifier = null;
	
	public void convert (String srcFileName, String destFileName, String separator, String qualifier) throws FileNotFoundException, IOException,
			InvalidFormatException
	{
		File source = new File(srcFileName);
		File destination = new File(destFileName);
		
		this.delimiter = separator;
		this.qualifier = qualifier;
		openWorkbook(source);
		convertToCSV();
		saveCSVFile(destination);
	}
	
	/**
	 * Open an Excel workbook ready for conversion.
	 * 
	 * @param file
	 *            An instance of the File class that encapsulates a handle to a valid Excel workbook. Note that the workbook can be in either binary
	 *            (.xls) or SpreadsheetML (.xlsx) format.
	 * @throws java.io.FileNotFoundException
	 *             Thrown if the file cannot be located.
	 * @throws java.io.IOException
	 *             Thrown if a problem occurs in the file system.
	 * @throws org.apache.poi.openxml4j.exceptions.InvalidFormatException
	 *             Thrown if invalid xml is found whilst parsing an input SpreadsheetML file.
	 */
	private void openWorkbook (File file) throws FileNotFoundException, IOException, InvalidFormatException
	{
		FileInputStream fis = null;
		try
		{
			if (logger.isTraceEnabled())
				logger.trace("Opening workbook [" + file.getName() + "]");
			
			fis = new FileInputStream(file);
			
			// Open the workbook and then create the FormulaEvaluator and
			// DataFormatter instances that will be needed to, respectively,
			// force evaluation of forumlae found in cells and create a
			// formatted String encapsulating the cells contents.
			this.workbook = WorkbookFactory.create(fis);
			this.evaluator = this.workbook.getCreationHelper().createFormulaEvaluator();
			this.formatter = new DataFormatter(true);
		}
		finally
		{
			if (fis != null)
			{
				fis.close();
			}
		}
	}
	
	/**
	 * Called to convert the contents of the currently opened workbook into a CSV file.
	 */
	private void convertToCSV ()
	{
		Sheet sheet = null;
		Row row = null;
		int lastRowNum = 0;
		
		this.csvData = new ArrayList<ArrayList<String>>();
		
		if (logger.isTraceEnabled())
			logger.trace("Converting files contents to CSV format.");
		
		// Discover how many sheets there are in the workbook....
		int numSheets = this.workbook.getNumberOfSheets();
		
		// and then iterate through them.
		for (int i = 0; i < numSheets; i++)
		{
			
			// Get a reference to a sheet and check to see if it contains
			// any rows.
			sheet = this.workbook.getSheetAt(i);
			if (sheet.getPhysicalNumberOfRows() > 0)
			{
				
				// Note down the index number of the bottom-most row and
				// then iterate through all of the rows on the sheet starting
				// from the very first row - number 1 - even if it is missing.
				// Recover a reference to the row and then call another method
				// which will strip the data from the cells and build lines
				// for inclusion in the resylting CSV file.
				lastRowNum = sheet.getLastRowNum();
				for (int j = 0; j <= lastRowNum; j++)
				{
					row = sheet.getRow(j);
					this.rowToCSV(row);
				}
			}
		}
	}
	
	/**
	 * Called to actually save the data recovered from the Excel workbook as a CSV file.
	 * 
	 * @param file
	 *            An instance of the File class that encapsulates a handle referring to the CSV file.
	 * @throws java.io.FileNotFoundException
	 *             Thrown if the file cannot be found.
	 * @throws java.io.IOException
	 *             Thrown to indicate and error occurred in the underylying file system.
	 */
	private void saveCSVFile (File file) throws FileNotFoundException, IOException
	{
		FileWriter fw = null;
		BufferedWriter bw = null;
		ArrayList<String> line = null;
		StringBuffer buffer = null;
		String csvLineElement = null;
		try
		{
			
			if (logger.isTraceEnabled())
				logger.trace("Saving the CSV file [" + file.getName() + "]");
			
			// Open a writer onto the CSV file.
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);
			
			// Step through the elements of the ArrayList that was used to hold
			// all of the data recovered from the Excel workbooks' sheets, rows
			// and cells.
			for (int i = 0; i < this.csvData.size(); i++)
			{
				buffer = new StringBuffer();
				
				// Get an element from the ArrayList that contains the data for
				// the workbook. This element will itself be an ArrayList
				// containing Strings and each String will hold the data recovered
				// from a single cell. The for() loop is used to recover elements
				// from this 'row' ArrayList one at a time and to write the Strings
				// away to a StringBuffer thus assembling a single line for inclusion
				// in the CSV file. If a row was empty or if it was short, then
				// the ArrayList that contains it's data will also be shorter than
				// some of the others. Therefore, it is necessary to check within
				// the for loop to ensure that the ArrayList contains data to be
				// processed. If it does, then an element will be recovered and
				// appended to the StringBuffer.
				line = this.csvData.get(i);
				for (int j = 0; j < this.maxRowWidth; j++)
				{
					if (line.size() > j)
					{
						csvLineElement = line.get(j);
						if (csvLineElement != null && qualifier != null)
						{
							buffer.append(this.escapeEmbeddedCharacters(csvLineElement));
						}
					}
					if (j < (this.maxRowWidth - 1))
						buffer.append(this.delimiter);
				}
				
				// Once the line is built, write it away to the CSV file.
				bw.write(buffer.toString().trim());
				
				// Condition the inclusion of new line characters so as to
				// avoid an additional, superfluous, new line at the end of
				// the file.
				if (i < (this.csvData.size() - 1))
					bw.newLine();
			}
		}
		finally
		{
			if (bw != null)
			{
				bw.flush();
				bw.close();
			}
		}
	}
	
	/**
	 * Called to convert a row of cells into a line of data that can later be output to the CSV file.
	 * 
	 * @param row
	 *            An instance of either the HSSFRow or XSSFRow classes that encapsulates information about a row of cells recovered from an Excel
	 *            workbook.
	 */
	private void rowToCSV (Row row)
	{
		Cell cell = null;
		int lastCellNum = 0;
		ArrayList<String> csvLine = null;
		// This row commented by babu to remove empty rows from xls and moved down this line
		// csvLine = new ArrayList<String>();
		
		try
		{
			// Check to ensure that a row was recovered from the sheet as it is
			// possible that one or more rows between other populated rows could be
			// missing - blank. If the row does contain cells then...
			if (row != null)
			{
				csvLine = new ArrayList<String>();
				// Get the index for the right most cell on the row and then
				// step along the row from left to right recovering the contents
				// of each cell, converting that into a formatted String and
				// then storing the String into the csvLine ArrayList.
				lastCellNum = row.getLastCellNum();
				for (int i = 0; i <= lastCellNum; i++)
				{
					cell = row.getCell(i);
					if (cell == null)
						csvLine.add("");
					else
					{
						if (cell.getCellType() != Cell.CELL_TYPE_FORMULA)
							csvLine.add(this.formatter.formatCellValue(cell));
						else
							csvLine.add(this.formatter.formatCellValue(cell, this.evaluator));
					}
				}
				// Make a note of the index number of the right most cell. This value
				// will later be used to ensure that the matrix of data in the CSV file
				// is square.
				if (lastCellNum > this.maxRowWidth)
					this.maxRowWidth = lastCellNum;
				this.csvData.add(csvLine);
				
			}
			// This row commented by babu to remove empty rows from xls and moved up this line
			// this.csvData.add(csvLine);
		}
		finally
		{
			// if ( csvLine != null)
			// {
			// csvLine.clear();
			// csvLine = null;
			// }
		}
	}
	
	/**
	 * Checks to see whether the field - which consists of the formatted contents of an Excel worksheet cell encapsulated within a String - contains
	 * any embedded characters that must be escaped. The method is able to comply with either Excel's or UNIX formatting conventions in the following
	 * manner;
	 * 
	 * With regard to UNIX conventions, if the field contains any embedded field delimiter or EOL characters they will each be escaped by prefixing a
	 * leading backspace character. These are the only changes that have yet emerged following some research as being required.
	 * 
	 * Excel has other embedded character escaping requirements, some that emerged from empirical testing, other through research. Firstly, with
	 * regards to any embedded speech marks ("), each occurrence should be escaped with another speech mark and the whole field then surrounded with
	 * speech marks. Thus if a field holds <em>"Hello" he said</em> then it should be modified to appear as <em>"""Hello"" he said"</em>. Furthermore,
	 * if the field contains either embedded delimiter or EOL characters, it should also be surrounded with speech marks. As a result <em>1,400</em>
	 * would become <em>"1,400"</em> assuming that the comma is the required field delimiter. This has one consequence in, if a field contains
	 * embedded speech marks and embedded delimiter characters, checks for both are not required as the additional set of speech marks that should be
	 * placed around ay field containing embedded speech marks will also account for the embedded delimiter.
	 * 
	 * It is worth making one further note with regard to embedded EOL characters. If the data in a worksheet is exported as a CSV file using Excel
	 * itself, then the field will be surounded with speech marks. If the resulting CSV file is then re-imports into another worksheet, the EOL
	 * character will result in the original simgle field occupying more than one cell. This same 'feature' is replicated in this classes behaviour.
	 * 
	 * @param field
	 *            An instance of the String class encapsulating the formatted contents of a cell on an Excel worksheet.
	 * @return A String that encapsulates the formatted contents of that Excel worksheet cell but with any embedded delimiter, EOL or speech mark
	 *         characters correctly escaped.
	 */
	private String escapeEmbeddedCharacters (String field)
	{
		StringBuffer buffer = null;
		
		// Firstly, check if there are any speech marks (") in the field;
		// each occurrence must be escaped with another set of spech marks
		// and then the entire field should be enclosed within another
		// set of speech marks. Thus, "Yes" he said would become
		// """Yes"" he said"
		if (field.contains(qualifier))
		{
			buffer = new StringBuffer(field.replaceAll(qualifier, "\\" + qualifier + "\\" + qualifier));
			buffer.insert(0, qualifier);
			buffer.append(qualifier);
		}
		else
		{
			// If the field contains either embedded delimiter or EOL
			// characters, then escape the whole field by surrounding it
			// with speech marks.
			buffer = new StringBuffer(field);
			if ((buffer.indexOf(this.delimiter)) > -1 || (buffer.indexOf("\n")) > -1)
			{
				buffer.insert(0, qualifier);
				buffer.append(qualifier);
			}
		}
		return (buffer.toString().trim());
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.plugins.IPlugin#execute(java.util.Map)
	 */
	public Object execute (Connection dbConnection, Map<String, Object> data) throws ExecutionException
	{
		String destFileName = null;
		String sourceFileName = null;
		ExecutionJobData jobData = null;
		String delimiter = null;
		String qualifier = null;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		InterfaceDef intDef = null;
		
		try
		{
			jobData = (ExecutionJobData) data.get(IPlugin.EXECUTION_DATA);
			intDef = jobData.getInterfaceDef();
			if ( "XLSX".equals(intDef.getFormatterType()) && "EXCEL".equals(intDef.getMediumName()))
				return null;
			
			if (IrisAdminConstants.MEDIA_MQ.equals(jobData.getMediumType()) || IrisAdminConstants.MEDIA_WEBSERVICE.equals(jobData.getMediumType()))
				return null;
			
			sourceFileName = jobData.getMediaDetails();
			if (sourceFileName == null)
				return null;
			
			if (!sourceFileName.endsWith(".xls") && !sourceFileName.endsWith(".xlsx"))
			{
				if (logger.isTraceEnabled())
					logger.trace("File:" + sourceFileName + " not an Excel file");
				return null;
			}
			
			destFileName = sourceFileName.substring(0, sourceFileName.lastIndexOf(".")) + ".csv";
			delimiter = jobData.getInterfaceDef().getDelimiter();
			qualifier = jobData.getInterfaceDef().getQualifier();
			if (qualifier == null)
				qualifier = "\"";
			convert(sourceFileName, destFileName, delimiter, qualifier);
			jobData.setMediaDetails(destFileName);
			jobData.setOrgMediaDetails(sourceFileName);
		}
		catch (FileNotFoundException exp)
		{
			errorMsg = "File:" + sourceFileName + " not found";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg, "Dest file:" + destFileName }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, "Dest file:" + destFileName, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (InvalidFormatException exp)
		{
			errorMsg = "File:" + sourceFileName + " is not correct format";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg, "Dest file:" + destFileName }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, "Dest file:" + destFileName, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IOException exp)
		{
			errorMsg = "File:" + sourceFileName + " Dest file:" + destFileName + " not able to convert";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		return null;
	}
	
	public static void main (String[] args) throws Exception
	{
		XLSToDelimiterPlugin test = new XLSToDelimiterPlugin();
		test.convert("c:/upload/UBANOMNG 31 12 13 13.xls", "c:/upload/PAY1_UPLD_Babu_1.csv", ",", "\"");
	}
}
