/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : DuplicateDataCheck.java
 * CREATED: Mar 10, 2014 7:56:03 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.security.HashProviderFactory;
import com.fundtech.iris.admin.security.IHashProvider;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * This Class computes Checksum Using MD5 or CRC32 or Adler32 Algorithm for a given
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * &lt;NodeDefinition id="InsertDataNode" nodeClass="com.fundtech.iris.admin.execution.nodes.InterfacePluginNode"&gt;
 * 	&lt;References&gt;
 * 		&lt;Reference name="IRIS_DB" type="DB_CONN"/&gt;
 * 		&lt;Reference name="uploadType" type="INPUT_TYPE"/&gt;
 * 		&lt;Reference name="uploadType" type="OUTPUT_TYPE"/&gt;
 * 	&lt;/References&gt;
 * 	&lt;Parameter name="HelperClass" value="com.fundtech.iris.admin.plugins.DuplicateDataCheck"/&gt;
 * 	&lt;Parameter name="StaticParameters"&gt;
 * 		&lt;Parameter name="BatchSize"  value="10000"/&gt;
 * 	&lt;/Parameter&gt;
 * &lt;/NodeDefinition&gt;
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">Iris Admin</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>IrisAdminUpload.xml</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: DuplicateDataCheck.java,v 1.16 2017/03/17 11:34:20 ramap Exp $
 */
public class DuplicateDataCheck extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(DuplicateDataCheck.class);
	
	public DuplicateDataCheck()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		ExecutionJobData jobData = null;
		String uploadFileName = null;
		InputStream inStream = null;
		String checkSumValue = null;
		IHashProvider hashProvider = null;
		InterfaceMap interfaceMap = null;
		String interfaceType = null;
		String algorithm = null;
		String errorMsg = null;
		IrisAdminError error = null;
		ExecutionException eExp = null;
		SecurityProfile secProfile = null;
		IrisError irisError = null;
		String mqData = null;
		try
		{
			jobData = (ExecutionJobData) params.get(IrisAdminConstants.EXECUTION_DATA);
			
			/*if (IrisAdminConstants.MEDIA_MQ.equals(jobData.getMediumType()) || IrisAdminConstants.MEDIA_WEBSERVICE.equals(jobData.getMediumType()))
				return null;*/
			
			interfaceMap = jobData.getInterfaceMap();
			secProfile = interfaceMap.getSecurityProfile();
			interfaceType = jobData.getMapType();
			if (secProfile.isIntegrityCheckRequired() && IrisAdminConstants.DEFINITION_TYPE_UPLOAD.equals(interfaceType))
			{
				algorithm = secProfile.getIntegrityAlgo();
				if (IrisAdminConstants.MEDIA_MQ.equals(jobData.getMediumType()) || IrisAdminConstants.MEDIA_WEBSERVICE.equals(jobData.getMediumType()))
				{
					mqData = jobData.getMessageData();
					uploadFileName = jobData.getExecutionId();
		    	    inStream = new ByteArrayInputStream(mqData.getBytes("UTF-8"));
		    	}
				else
				{
					uploadFileName = jobData.getMediaDetails();
					inStream = new FileInputStream(uploadFileName);
				}
				hashProvider = getHashFactory().getHashFactoryProvider(algorithm);
				checkSumValue = hashProvider.calculate(inStream);
				if ( jobData.isReUpload())
					deleteOldData(dbConnection, jobData.getExecutionId());
				checkDuplicate(checkSumValue, jobData, dbConnection);
				
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (FileNotFoundException exp)
		{
			jobData.setStatus("R");
			errorMsg = "File:" + uploadFileName + " not found";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, "Check sum:" + checkSumValue, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("R");
			errorMsg = "Error While updating duplicate file.";
			eExp = new ExecutionException("error.iris.admin.batch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, "Check sum:" + checkSumValue, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(inStream);
		}
		
		return null;
	}
	
	/*--------------------------------------------------------------------------------------------------
	 * HELPER METHODS
	 *------------------------------------------------------------------------------------------------*/
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param executionId
	 * </pre></p>
	 */
	private void deleteOldData (Connection dbConnection, String executionId)
	{
		PreparedStatement deleteSt = null;
		String sql = "delete from IRIS_DATA_CHECKSUM t where t.execution_id=?";
		
		try
		{
			deleteSt = dbConnection.prepareStatement(sql);
			deleteSt.setString(1, executionId);
			deleteSt.executeUpdate();
			dbConnection.commit();
		}
		catch ( Exception exp)
		{
			logger.error("Errro Wile deleting decord" , exp);
		}
		finally
		{
			CleanUpUtils.doClean(deleteSt);
		}
		
	}

	/**
	 * TODO
	 * 
	 * @param checkSumValue
	 * @param jobData
	 * @param dbConnection
	 * @throws ExecutionException
	 * @throws SQLException
	 */
	private void checkDuplicate (String checkSumValue, ExecutionJobData jobData, Connection dbConnection) throws ExecutionException
	{
		PreparedStatement insertStmt = null;
		String insertSql = null;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		insertSql = "INSERT INTO IRIS_DATA_CHECKSUM(CHECKSUM,EXECUTION_ID,SELLER_CODE,ENTITY_TYPE,ENTITY_CODE,MAP_NAME,"
				+ "FILENAME) VALUES (?,?,?,?,?,?,?)";
		try
		{
			insertStmt = dbConnection.prepareStatement(insertSql);
			insertStmt.clearParameters();
			insertStmt.setString(1, checkSumValue);
			insertStmt.setString(2, jobData.getExecutionId());
			insertStmt.setString(3, jobData.getSellerCode());
			insertStmt.setString(4, jobData.getEntityType());
			insertStmt.setString(5, jobData.getEntityCode());
			insertStmt.setString(6, jobData.getMapName());
			insertStmt.setString(7, jobData.getMediaDetails());
			insertStmt.executeUpdate();
			dbConnection.commit();
		}
		catch (SQLException exp)
		{
			logger.error("SQLException : ", exp);
			
			if (exp.getMessage().contains("ORA-00001"))	// Unique constraint comes then its duplicate
			{
				jobData.setStatus("R");
				errorMsg = "File:" + jobData.getMediaDetails() + " duplicate file and checksumis:" + checkSumValue;
				eExp = new ExecutionException("error.iris.admin.duplicatefile", new Object[]
				{ errorMsg }, exp);
				error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, "Check sum:" + checkSumValue, null);
				irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
				jobData.addIrisError(irisError);
				jobData.addError(error);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
				
			}
			else
			{
				jobData.setStatus("R");
				errorMsg = "Error While updating duplicate file.";
				eExp = new ExecutionException("error.iris.admin.batch", new Object[]
				{ errorMsg }, exp);
				error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_EXE_FAILED, errorMsg, "Check sum:" + checkSumValue, null);
				irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
				jobData.addIrisError(irisError);
				jobData.addError(error);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		finally
		{
			HelperUtils.doClose(insertStmt);
		}
	}
	
	private File createTempFile(String msgData) throws IOException
	{
		File file = new File("test1.txt");
		FileWriter fileWriter = new FileWriter(file);
		fileWriter.write(msgData);
		fileWriter.flush();
		fileWriter.close();
		return file;
	}
	
	private HashProviderFactory getHashFactory()
	{
		HashProviderFactory factory = null;
		
		try
		{
			factory = (HashProviderFactory) ContextManager.getInstance().getBeanObject(HashProviderFactory.class);
		}
		catch ( Exception exp)
		{
			logger.warn("Error:",exp);
			factory = new HashProviderFactory();
		}
		
	return factory;
	}
}
