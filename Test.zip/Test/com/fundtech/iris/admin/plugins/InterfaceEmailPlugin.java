/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : InterfaceEmailPlugin.java
 * CREATED: Feb 8, 2016 10:00:29 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.channel.mail.IrisAdminMailService;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.StringUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: InterfaceEmailPlugin.java,v 1.4 2016/03/02 11:16:23 ramap Exp $
 */
public class InterfaceEmailPlugin  extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(InterfaceEmailPlugin.class);
	
	private static final String  DOWNLOAD_FROM_ADDRESS = "DOWNLOAD_FROM_ADDRESS";
	private static final String DOWNLOAD_SUBJECT_MESSAGE = "DOWNLOAD_SUBJECT_MESSAGE";
	private static final String DOWNLOAD_BODY_MESSAGE = "DOWNLOAD_BODY_MESSAGE";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		
		ExecutionJobData jobData = null;
		ExecutionException eExp = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			doEmail(params);
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.ReportEmail", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		return null;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param secProfile
	 * @param jobData
	 * </pre>
	 * 
	 * </p>
	 */
	@SuppressWarnings("unchecked")
	private void doEmail (Map<String, Object> params) throws ExecutionException
	{
		ExecutionJobData jobData = null;
		List<String> fileList = null;
		String deliveryType = null;
		String fromAddress = null;
		String toAddress = null;
		IrisAdminMailService mailService = null;
		String emailBeanName = null;
		ContextManager contextManager = null;
		Map<String, String> staticParms = null;
		ExecutionException eExp = null;
		String bodyMessagge = null;
		String subjectMessage = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			subjectMessage = jobData.getInterfaceDef().getInterfaceDesc();
			deliveryType = jobData.getFilterParameter("DEL_MEDIUM");
			toAddress = jobData.getFilterParameter("DEL_INFO");
			
			if ((("SMTP".equals(deliveryType) || ("EMAIL".equals(deliveryType)))&& !StringUtils.isEmpty(toAddress)))
			{
				fileList = jobData.getSplitFileList();
				
				staticParms = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
				fromAddress = staticParms.get(DOWNLOAD_FROM_ADDRESS);
				bodyMessagge = staticParms.get(DOWNLOAD_BODY_MESSAGE);
				emailBeanName = staticParms.get(IPlugin.RESOURCE_BEAN_NAME);
				contextManager = ContextManager.getInstance();
				mailService = (IrisAdminMailService) contextManager.getBeanObject(emailBeanName);
				mailService.setFromAddress(fromAddress);
				mailService.setToAddresses(toAddress);
				mailService.setSubject(subjectMessage);
				mailService.setMessageBody(bodyMessagge);
				mailService.sendMail(fileList, false);
				jobData.setStatus("C");
			}
		}
		catch (IOException ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.ReportEmail", new Object[] { jobData.toString(), staticParms }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.ReportEmail", new Object[] { jobData.toString(), staticParms }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
		}
	}
}