/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : IPlugin.java
 * CREATED: Oct 7, 2013 11:21:47 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.sql.Connection;
import java.util.Map;

import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: IPlugin.java,v 1.11 2015/09/28 05:42:15 ramap Exp $
 * @since 1.0.0
 */
public interface IPlugin
{
	
	public String EXECUTION_DATA = "EXECUTION_DATA";
	public String EXECUTION_BATCH = "EXECUTION_BATCH";
	public String EXECUTION_STATIC_PROPS = "STATIC_PROPS";
	public String RESOURCE_BEAN_NAME = "RESOURCE_BEAN_NAME";
	public String PASS_PHRASE = "PASS_PHRASE";
	public String SIGNING_KEY = "SIGNING_KEY";
	
	/**
	 * 
	 * This method helps you initialize the hook. This could be reading a proprty file..etc
	 * 
	 * @throws ExecutionException
	 */
	public void initialize () throws FormatException, ExecutionException;
	
	/**
	 * 
	 * This
	 * 
	 * @param data
	 * @return Object.. future purpose
	 * @throws ExecutionException
	 */
	public Object execute (Connection dbConnection, Map<String, Object> data) throws FormatException, ExecutionException;
}
