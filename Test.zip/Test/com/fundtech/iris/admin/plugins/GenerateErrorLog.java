/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : GenerateErrorLog.java
 * CREATED: Mar 9, 2014 9:28:28 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: GenerateErrorLog.java,v 1.4 2015/07/15 05:32:37 ramap Exp $
 */
public class GenerateErrorLog extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(GenerateErrorLog.class);
	
	public GenerateErrorLog()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		ExecutionJobData jobData = null;
		Map<String, String> props = null;
		List<IrisAdminError> errors = null;
		File errorFile = null;
		String errFileName = null;
		String errFilePath = null;
		FileWriter outStream = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			props = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			errors = jobData.getErrors();
			for (IrisAdminError error : errors)
			{
				if (outStream == null)
				{
					errFileName = getFileName(jobData);
					errFilePath = props.get("ErrorFilePath");
					if (errFilePath == null)
						errFilePath = ".";
					errorFile = new File(errFilePath, errFileName);
					outStream = getWriter(errorFile, false);
					outStream.write(jobData.toString());
					outStream.write(System.getProperty("line.separator"));
					outStream.flush();
				}
				else
					outStream.write(System.getProperty("line.separator"));
				
				outStream.write(error.toString());
				outStream.flush();
			}
		}
		catch (Exception e)
		{
			// do not throw exception
			logger.error("Error while writing logger so ignoring", e);
		}
		finally
		{
			HelperUtils.doClose(outStream);
			outStream = null;
		}
		
		return null;
	}
	
	/**
	 * 
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * @return
	 * </pre>
	 * 
	 * </p>
	 */
	private String getFileName (ExecutionJobData jobData)
	{
		String clientCode = null;
		String mapName = null;
		String executionId = null;
		
		clientCode = jobData.getEntityCode();
		mapName = jobData.getMapName();
		executionId = jobData.getExecutionId();
		
		return clientCode + mapName + executionId + ".err";
	}
	
	private FileWriter getWriter (final File file, final boolean append) throws IOException
	{
		if (file.exists())
		{
			if (file.isDirectory())
			{
				throw new IOException("File '" + file + "' exists but is a directory");
			}
			if (file.canWrite() == false)
			{
				throw new IOException("File '" + file + "' cannot be written to");
			}
		}
		else
		{
			final File parent = file.getParentFile();
			if (parent != null)
			{
				if (!parent.mkdirs() && !parent.isDirectory())
				{
					throw new IOException("Directory '" + parent + "' could not be created");
				}
			}
		}
		return new FileWriter(file, append);
	}
}
