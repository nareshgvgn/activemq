/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : AsymmetricDecryptionPlugin.java
 * CREATED: Sep 16, 2015 9:59:30 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.IOException;
import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.exceptions.NotSupportedException;
import com.fundtech.iris.admin.security.IAsymmetricSecurityProvider;
import com.fundtech.iris.admin.security.SecurityProviderFactory;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AsymmetricDecryptionPlugin.java,v 1.6 2017/03/27 11:45:12 ramap Exp $
 */
public class AsymmetricDecryptionPlugin extends IrisAdminPlugin
{
	
	private static Logger logger = LoggerFactory.getLogger(AsymmetricDecryptionPlugin.class);
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public AsymmetricDecryptionPlugin()
	{
		// BABU Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		String vendor = null;
		String encryptionKey = null;
		InterfaceMap interfaceMap = null;
		IAsymmetricSecurityProvider securityProvider = null;
		String uploadFileName = null;
		ExecutionException eExp = null;
		ExecutionJobData jobData = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		SecurityProfile secProfile = null;
		int intExitCode = 0;
		String passphrase = null;
		String outFileName = null;
		
		
		jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
		interfaceMap = jobData.getInterfaceMap();
		secProfile = interfaceMap.getSecurityProfile();
		
		try
		{
			encryptionKey = secProfile.getEncryptionKey();
			vendor = secProfile.getEncryptionAlgo();
			securityProvider = getSecurityProvider().getAsymmetricInstance(vendor);
			securityProvider.setJobData(jobData);
			passphrase = (String) params.get(IPlugin.PASS_PHRASE);
			uploadFileName = jobData.getMediaDetails();
			outFileName  = uploadFileName + ".dec";
			
			if ( secProfile.isEncryptionRequired() && secProfile.isSiginingRequired())
			{
				intExitCode  = securityProvider.setPassPhrase(passphrase)
						.setSrcFileName(uploadFileName)
						.setDestFileName(outFileName)
						.setSigner(encryptionKey)
						.decrypt();

			}
			else if (secProfile.isEncryptionRequired() )
			{
				intExitCode  = securityProvider.setPassPhrase(passphrase)
						.setSrcFileName(uploadFileName)
						.setDestFileName(outFileName)
						.decrypt();
			}
			else if (secProfile.isSiginingRequired())
			{
				intExitCode  = securityProvider.setPassPhrase(passphrase)
						.setSrcFileName(uploadFileName)
						.setDestFileName(outFileName)
						.setSigner(encryptionKey)
						.verify();
			}
			
			if ( intExitCode != 0)
			{
				errorMsg = " Error While Decrypting :" + uploadFileName + " Error: "  + securityProvider.getOutMessage() + 
						" Message: " + securityProvider.getErrMessage();
				eExp = new ExecutionException("err.iris.admin.hasmatch", new Object[]{ errorMsg }, null);
				error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_SIGNING_FAILED, errorMsg, null, null);
				irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
				jobData.addIrisError(irisError);
				jobData.addError(error);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
				
			jobData.setMediaDetails(outFileName);
			jobData.setOrgMediaDetails(uploadFileName);
			
		}
		catch (NotSupportedException exp)
		{
			errorMsg = "Vendor:" + vendor + " not supported by the system.";
			eExp = new ExecutionException("error.iris.admin.decryptionnotsupported", new Object[]{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_SUPPORTED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IOException exp)
		{
			errorMsg = "FileName:" + jobData.getMediaDetails() + " not found";
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (InterruptedException exp)
		{
			errorMsg = "Interrupted while decrpting FileName:" + jobData.getMediaDetails() ;
			eExp = new ExecutionException("error.iris.admin.interrupted", new Object[]	{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error  while decrpting/verify sigining for:" + jobData.getMediaDetails();
			eExp = new ExecutionException("err.iris.admin.hasmatch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_SIGNING_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		
		return null;
	}
	
	private SecurityProviderFactory getSecurityProvider()
	{
		SecurityProviderFactory factory = null;
		
		try
		{
			factory = (SecurityProviderFactory) ContextManager.getInstance().getBeanObject(SecurityProviderFactory.class);
		}
		catch ( Exception exp)
		{
			logger.error("Error:",exp);
		}
		
	return factory;
	}
	
}
