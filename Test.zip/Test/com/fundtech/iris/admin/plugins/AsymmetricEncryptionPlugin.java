/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : AsymmetricEncryptionPlugin.java
 * CREATED: Sep 24, 2015 3:22:10 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.exceptions.NotSupportedException;
import com.fundtech.iris.admin.security.IAsymmetricSecurityProvider;
import com.fundtech.iris.admin.security.SecurityProviderFactory;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AsymmetricEncryptionPlugin.java,v 1.5 2017/03/27 11:45:12 ramap Exp $
 */
public class AsymmetricEncryptionPlugin extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(AsymmetricEncryptionPlugin.class);
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public AsymmetricEncryptionPlugin()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		InterfaceMap interfaceMap = null;
		IAsymmetricSecurityProvider securityProvider = null;
		String downloadFileName = null;
		ExecutionException eExp = null;
		ExecutionJobData jobData = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		SecurityProfile secProfile = null;
		int intExitCode = 0;
		String vendor = null;
		String outFileName = null;
		List<String> spList = null;
		List<String> outList = null;
		
		jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
		interfaceMap = jobData.getInterfaceMap();
		secProfile = interfaceMap.getSecurityProfile();
		outList = new ArrayList<String>();
		try
		{
			vendor = secProfile.getEncryptionAlgo();
			securityProvider = getSecurityProvider().getAsymmetricInstance(vendor);
			
			securityProvider.setJobData(jobData);
			spList = jobData.getSplitFileList();
			for (String fileName : spList)
			{
				downloadFileName = fileName;
				outFileName  = fileName + ".pgp";
				intExitCode = applySecurity(securityProvider, secProfile, downloadFileName, outFileName, params);
				if ( intExitCode != 0)// break if any one file not able to encrypt
					break;
				outList.add(outFileName);
			}
			
			if ( intExitCode != 0)
			{
				errorMsg = " Error While Decrypting :" + downloadFileName + " Error: "  + securityProvider.getOutMessage() + 
						" Message: " + securityProvider.getErrMessage();
				eExp = new ExecutionException("err.iris.admin.hasmatch", new Object[]{ errorMsg }, null);
				error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_SIGNING_FAILED, errorMsg, null, null);
				irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
				jobData.addIrisError(irisError);
				jobData.addError(error);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			else
			{
				if (!jobData.isSplitFile())
					jobData.setMediaDetails(outFileName);
				else
					jobData.setSplitFile(outList);
			}
		}
		catch (NotSupportedException exp)
		{
			errorMsg = "Vendor:" + vendor + " not supported by the system.";
			eExp = new ExecutionException("error.iris.admin.decryptionnotsupported", new Object[]{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_SUPPORTED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error  while decrpting/verify sigining for:" + downloadFileName;
			eExp = new ExecutionException("err.iris.admin.hasmatch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_SIGNING_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		return null;
	}
	
	private SecurityProviderFactory getSecurityProvider()
	{
		SecurityProviderFactory factory = null;
		
		try
		{
			factory = (SecurityProviderFactory) ContextManager.getInstance().getBeanObject(SecurityProviderFactory.class);
		}
		catch ( Exception exp)
		{
			logger.error("Error:",exp);
		}
		
	return factory;
	}
	
	private int applySecurity(IAsymmetricSecurityProvider securityProvider, SecurityProfile secProfile, String srcName, String destName, Map<String, Object> params)
	{
		String recipientKey = null;
		String signerKey = null;
		String passphrase = null;
		int intExitCode = 0;
		
		recipientKey = secProfile.getEncryptionKey();
		signerKey = (String) params.get(IPlugin.SIGNING_KEY);
		passphrase = (String) params.get(IPlugin.PASS_PHRASE);
		
		if ( secProfile.isEncryptionRequired() && secProfile.isSiginingRequired())
			intExitCode  = signedAndEncrypt(srcName, destName, passphrase, signerKey, recipientKey, securityProvider);
		else if (secProfile.isEncryptionRequired())
			intExitCode = encrypt(srcName, destName, recipientKey, securityProvider);
		else if (secProfile.isSiginingRequired())
			intExitCode = sign(srcName, destName, passphrase, signerKey, securityProvider);
		return intExitCode;
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param sourcefile
	 * @param destFileName
	 * @param passphrase-- to acess bank private key 
	 * @param signer -- in download its bank private key
	 * @param recipient -- in download, its client public key
	 * @param securityProvider
	 * @return
	 * </pre></p>
	 */
	private int signedAndEncrypt(String sourcefile, String destFileName, String passphrase, String signer, String recipient, IAsymmetricSecurityProvider securityProvider)
	{
		int intExitCode = 0;
		ExecutionException eExp = null;
		try
		{
			intExitCode = securityProvider.setPassPhrase(passphrase)
					.setSrcFileName(sourcefile)
					.setDestFileName(destFileName)
					.setRecipient(recipient)
					.setSigner(signer)
					.signAndEncrypt();
					
			return intExitCode;
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.app.PgpCmdSignEncryption", new Object[]{ sourcefile, destFileName, passphrase, signer, recipient }, e);
			logger.error(IRISLogger.getText(eExp));
			intExitCode = -1;
		}
		return intExitCode;
	}
	
	private int encrypt(String sourcefileName, String destFileName, String recipient, IAsymmetricSecurityProvider securityProvider)
	{
		int intExitCode = 0;
		ExecutionException eExp = null;
		try
		{
			intExitCode = securityProvider.setSrcFileName(sourcefileName)
					.setDestFileName(destFileName)
					.setRecipient(recipient)
					.encrypt();
					
			return intExitCode;
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.app.PgpCmdEncryption", new Object[]{ sourcefileName, destFileName, recipient }, e);
			logger.error(IRISLogger.getText(eExp));
			intExitCode = -1;
		}
		return intExitCode;
	}
	
	private int sign (String sourcefile, String destFileName, String passphrase, String signer, IAsymmetricSecurityProvider securityProvider)
	{
		int intExitCode = 0;
		ExecutionException eExp = null;
		try
		{
			intExitCode = securityProvider.setPassPhrase(passphrase)
					.setSrcFileName(sourcefile)
					.setDestFileName(destFileName)
					.setSigner(signer)
					.sign();
					
			return intExitCode;
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.app.PgpCmdsigning", new Object[]{ sourcefile, destFileName, passphrase, signer }, e);
			logger.error(IRISLogger.getText(eExp));
			intExitCode = -1;
		}
		return intExitCode;
	}
}
