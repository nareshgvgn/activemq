/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : SymmetricDecryptionPlugin.java
 * CREATED: Oct 17, 2013 11:26:23 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.plugins;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.InterfaceMap;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.exceptions.NotSupportedException;
import com.fundtech.iris.admin.exceptions.SecurityException;
import com.fundtech.iris.admin.security.ISymmetricSecurityProvider;
import com.fundtech.iris.admin.security.SecurityProviderFactory;
import com.fundtech.iris.admin.security.SymmetricSigning;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: SymmetricDecryptionPlugin.java,v 1.15 2017/03/17 11:34:20 ramap Exp $
 * @since 1.0.0
 */
public class SymmetricDecryptionPlugin extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(SymmetricDecryptionPlugin.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		String algorithm = null;
		String encryptionKey = null;
		InterfaceMap interfaceMap = null;
		ISymmetricSecurityProvider securityProvider = null;
		int keySize = 0;
		String uploadFileName = null;
		InputStream inputStream = null;
		OutputStream outStream = null;
		ExecutionException eExp = null;
		File tempFile = null;
		File uploadFile = null;
		ExecutionJobData jobData = null;
		SymmetricSigning sigining = null;
		boolean hashStatus = false;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		SecurityProfile secProfile = null;
		
		try
		{
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			interfaceMap = jobData.getInterfaceMap();
			secProfile = interfaceMap.getSecurityProfile();
			if (secProfile.isEncryptionRequired())
			{
				uploadFileName = jobData.getMediaDetails();
				algorithm = secProfile.getEncryptionAlgo();
				encryptionKey = secProfile.getEncryptionKey();
				keySize = secProfile.getEncryptionKeyLength();
				securityProvider = getSecurityProvider().getSymmetricInstance(algorithm);
				uploadFile = new File(uploadFileName + ".dec");
				inputStream = new FileInputStream(uploadFile);
				tempFile = File.createTempFile("dec_", ".dat");
				outStream = new FileOutputStream(tempFile);
				securityProvider.decrypt(encryptionKey, keySize, inputStream, outStream);
				HelperUtils.doClose(inputStream);
				HelperUtils.doClose(outStream);
				copyFile(tempFile, uploadFile, jobData);
				jobData.setOrgMediaDetails(uploadFileName);
				jobData.setMediaDetails(uploadFile.getAbsolutePath());
			}
			
			if (secProfile.isSiginingRequired())
			{
				sigining = getSymmetricSigning();
				hashStatus = sigining.executeUpload(jobData);
				if (!hashStatus)
				{
					errorMsg = "File Hash for:" + jobData.getMediaDetails() + " is not matching.";
					eExp = new ExecutionException("err.iris.admin.hasmatch", new Object[]
					{ errorMsg }, null);
					error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_SIGNING_FAILED, errorMsg, null, null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					logger.error(IRISLogger.getText(eExp));
					throw eExp;
				}
			}
		}
		catch (NotSupportedException exp)
		{
			errorMsg = "Algorithm:" + algorithm + " keySize:" + keySize + " not supported by the system.";
			eExp = new ExecutionException("error.iris.admin.decryptionnotsupported", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_SUPPORTED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (FileNotFoundException exp)
		{
			errorMsg = "FileName:" + jobData.getMediaDetails() + " not found";
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (SecurityException exp)
		{
			errorMsg = "Decryption failed for:" + jobData.getMediaDetails();
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_FOUND, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IOException exp)
		{
			errorMsg = "FileName:" + jobData.getMediaDetails() + " not able to read";
			eExp = new ExecutionException("error.iris.admin.filenotfound", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createError(IrisAdminConstants.ERR_CODE_NOT_SUPPORTED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception exp)
		{
			errorMsg = "Error  while decrpting/verify sigining for:" + jobData.getMediaDetails();
			eExp = new ExecutionException("err.iris.admin.hasmatch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_SIGNING_FAILED, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(inputStream);
			HelperUtils.doClose(outStream);
		}
		return null;
	}
	
	/**
	 * To copy a file.
	 * 
	 * @param sourceFile
	 *            - Source file
	 * @param destFile
	 *            - Destination file
	 */
	private void copyFile (File sourceFile, File destFile, ExecutionJobData jobData) throws ExecutionException
	{
		FileChannel sourceChannel = null;
		FileChannel destChannel = null;
		FileInputStream inStream = null;
		FileOutputStream outStream = null;
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		
		try
		{
			inStream = new FileInputStream(sourceFile);
			outStream = new FileOutputStream(destFile);
			sourceChannel = inStream.getChannel();
			destChannel = outStream.getChannel();
			
			if (logger.isDebugEnabled())
				logger.debug("File ::" + sourceFile.getName() + " To Be copied From : " + sourceFile.getParent() + " To : " + destFile.getParent());
			
			destChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
			outStream.flush();
		}
		catch (Exception exp)
		{
			errorMsg = "File not able to move from:" + sourceFile.getAbsolutePath() + " to:" + destFile.getAbsolutePath();
			eExp = new ExecutionException("err.iris.admin.hasmatch", new Object[]
			{ errorMsg }, exp);
			error = IrisAdminUtils.createInterError(IrisAdminConstants.ERR_CODE_FILE_MOVE, errorMsg, null, null);
			irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
			jobData.addIrisError(irisError);
			jobData.addError(error);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(sourceChannel);
			HelperUtils.doClose(destChannel);
			HelperUtils.doClose(inStream);
			HelperUtils.doClose(outStream);
		}
	}
	
	private SecurityProviderFactory getSecurityProvider()
	{
		SecurityProviderFactory factory = null;
		
		try
		{
			factory = (SecurityProviderFactory) ContextManager.getInstance().getBeanObject(SecurityProviderFactory.class);
		}
		catch ( Exception exp)
		{
			logger.error("Error:", exp);
		}
		
	return factory;
	}
	
	private SymmetricSigning getSymmetricSigning()
	{
		SymmetricSigning factory = null;
		
		try
		{
			factory = (SymmetricSigning) ContextManager.getInstance().getBeanObject("symmetricSigningHelper");
		}
		catch ( Exception exp)
		{
			logger.warn("Error:",exp);
			factory = new SymmetricSigning();
		}
		
		return factory;
	}
	
}
