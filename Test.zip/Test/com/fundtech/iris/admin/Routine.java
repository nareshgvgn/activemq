/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : Routine.java
 * CREATED: Mar 10, 2013 6:25:45 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin;

import java.util.List;

import com.fundtech.iris.admin.interfaces.RoutineParameter;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: Routine.java,v 1.3 2014/07/20 04:58:26 ramap Exp $
 * @since 1.0.0
 */
public class Routine
{
	private String type = null;
	private String subType = null;
	private String name = null;
	private List<RoutineParameter> parameterFields = null;
	private String mappingClass = null;
	
	/**
	 * @return the mappingClass
	 */
	public String getMappingClass ()
	{
		return mappingClass;
	}
	
	/**
	 * @param mappingClass
	 *            the mappingClass to set
	 */
	public void setMappingClass (String mappingClass)
	{
		this.mappingClass = mappingClass;
	}
	
	/**
	 * @return the type
	 */
	public String getRoutineType ()
	{
		return type;
	}
	
	/**
	 * @param type
	 *            the type to set
	 */
	public void setRoutineType (String routineType)
	{
		this.type = routineType;
	}
	
	/**
	 * @return the subType
	 */
	public String getRoutineSubType ()
	{
		return subType;
	}
	
	/**
	 * @param subType
	 *            the subType to set
	 */
	public void setRoutineSubType (String routineSubType)
	{
		this.subType = routineSubType;
	}
	
	/**
	 * @return the name
	 */
	public String getRoutineName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setRoutineName (String routineName)
	{
		this.name = routineName;
	}
	
	/**
	 * @return the mappingFields
	 */
	public List<RoutineParameter> getParameters ()
	{
		return parameterFields;
	}
	
	/**
	 * @param mappingFields
	 *            the mappingFields to set
	 */
	public void setMappingFields (List<RoutineParameter> parameters)
	{
		this.parameterFields = parameters;
	}
	
	/**
	 * @param mappingField
	 */
	public void addMappingField (RoutineParameter parameter)
	{
		parameterFields.add(parameter);
	}
}
