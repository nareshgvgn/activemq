/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.sqlparser
 * FILE   : IrisAdminDowloadListener.java
 * CREATED: Nov 11, 2016 2:56:08 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.sqlparser;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DurationFieldType;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.interfaces.FilterParameter;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisAdminDowloadListener.java,v 1.2 2016/12/12 08:28:49 ramap Exp $
 */
public class IrisAdminDowloadListener implements SqlParserEngineListener
{
	private static Logger logger = LoggerFactory.getLogger(IrisAdminDowloadListener.class);
	private static final Map<String, String> stdOperators;
//    static
//    {
//    	stdOperators = new HashMap<String, String>();
//    	stdOperators.put("${BT}", "BETWEEN");
//    	stdOperators.put("${LQ}", "<=");
//    	stdOperators.put("${GQ}", ">=");
//    	stdOperators.put("${LT}", "<");
//    	stdOperators.put("${GT}", ">");
//    	stdOperators.put("${EQ}", "=");
//    	stdOperators.put("${NE}", "<>");
//    	stdOperators.put("${IN}", "IN");
//    	stdOperators.put("${STARTWITH}", "${STARTWITH}");
//    	stdOperators.put("${ENDWITH}", "${ENDWITH}");
//    	stdOperators.put("${CONTAINS}", "${CONTAINS}");
//    }
	 static
	    {
	    	stdOperators = new HashMap<String, String>();
	    	stdOperators.put("BETWEEN", "BETWEEN");
	    	stdOperators.put("<=", "<=");
	    	stdOperators.put(">=", ">=");
	    	stdOperators.put("<", "<");
	    	stdOperators.put(">", ">");
	    	stdOperators.put("=", "=");
	    	stdOperators.put("<>", "<>");
	    	stdOperators.put("IN", "IN");
	    }
	 
	 private static final Map<String, String> operators;
   static
   {
	   operators = new HashMap<String, String>();
	   operators.put("${BT}", "BETWEEN");
	   operators.put("${LQ}", "<=");
	   operators.put("${GQ}", ">=");
	   operators.put("${LT}", "<");
	   operators.put("${GT}", ">");
	   operators.put("${EQ}", "=");
	   operators.put("${NE}", "<>");
	   operators.put("${IN}", "IN");
	   operators.put("${STARTWITH}", "${STARTWITH}");
	   operators.put("${ENDWITH}", "${ENDWITH}");
	   operators.put("${CONTAINS}", "${CONTAINS}");
   }
	
    private static String DATE_FORMAT = "dd/MM/yyyy";
    
	private ExecutionJobData jobData = null;
	private String whereCondition = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisAdminDowloadListener(ExecutionJobData  jobData)
	{
		this.jobData = jobData;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireLeftSideColumn(java.lang.String)
	 */
	@Override
	public String fireLeftSideColumn (String column)
	{
		return column;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireOperator(java.lang.String)
	 */
	@Override
	public String fireOperator (String operator)
	{
		return operator;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireRightSideColumn(java.lang.String)
	 */
	@Override
	public String fireRightSideColumn (String column)
	{
		return column;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireTable(java.lang.String)
	 */
	@Override
	public String fireTable (String tableName)
	{
		return tableName;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireColumn(java.lang.String)
	 */
	@Override
	public String fireColumn (String column)
	{
		return column;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireWhere(java.lang.String)
	 */
	@Override
	public String fireWhere (String where)
	{
		System.out.println("WHERE" + where);
		this.whereCondition = where;
		return where;
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#combineOperatorRight(java.lang.String, java.lang.String)
	 */
	@Override
	public String combineOperatorRight (String leftColumn, String operator, String rightColumn) throws ParseException
	{
		String returnValue = null;
		Map<String, FilterParameter> runTimeParameters = null;
		FilterParameter filterParameter = null;
		String dataType = null;
		
		logger.trace("Processing leftColumn:{} Operator:{} rightColumn:{}", leftColumn, operator, rightColumn);
		returnValue = getBindColumn(leftColumn .trim(), operator.trim(), rightColumn.trim());
		
		if ( returnValue == null)
		{
			runTimeParameters = jobData.getInterfaceDef().getRunTimeParms();
			
			if ( StringUtils.startsWith(rightColumn, ":"))
			{
				rightColumn = StringUtils.removeStart(rightColumn, ":");
			}
			
			filterParameter = runTimeParameters.get(rightColumn.trim());
			if ( filterParameter == null)
			{
				logger.error("Parameter :{} not defined properly", rightColumn);
				throw new ParseException(rightColumn + "  not defined in the system");
			}
			
			dataType = filterParameter.getDataType();
			
			if ( "DATE".equals(dataType))
			{
				returnValue =  " NVL(" + leftColumn + ", SYSDATE) like '%' ";
			}
			else if ( "DECIMAL".equals(dataType))
			{
				returnValue =  " NVL(" + leftColumn + ", 1) like '%' ";
			}
			else if ( "STRING".equals(dataType))
			{
				returnValue =  " NVL(" + leftColumn + ", 1) like '%' ";
				
			}
			else if ("NUMBER".equals(dataType))
				returnValue =  " NVL(" + leftColumn + ", 1) like '%' ";
		}
		else
			returnValue = leftColumn + returnValue;
		return returnValue;
	}
	
	private String getBindColumn(String leftColumn, String operator, String rightColumn)
	{
		Map<String, String> filterparms = null;
		String returnVal = null;
		String[] splitValue = null;
		String value = null;
	
		filterparms = jobData.getFilterParameters();
		
		if ( StringUtils.startsWith(rightColumn, ":"))
		{
			rightColumn = StringUtils.removeStart(rightColumn, ":");
			returnVal = filterparms.get(rightColumn);
			if ( returnVal == null)
				return  null;
			splitValue = StringUtils.split(returnVal, "|");
			
			if ( splitValue.length > 1)
			{
				operator = splitValue[0];
				value = splitValue[1];
			}
			else
			{
				// if operator not specified in parameters ,  operator take from where condition
				value = splitValue[0];
			}
			returnVal = formatValue(rightColumn, value, operator);
		}
		else
			returnVal =	formatValue(rightColumn, null, operator);
		
		return returnVal;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param operator2
	 * @param rightColumn
	 * @return
	 * </pre></p>
	 */
	private String formatValue (String rightColumn, String parmValue, String operator)
	{
		Map<String, FilterParameter> runTimeParameters = null;
		FilterParameter filterParameter = null;
		
		if ( StringUtils.isEmpty(parmValue))
		{
			if ( stdOperators.containsKey(operator))
				operator = stdOperators.get(operator);

			return " "+ operator + " " + rightColumn;
		}
		else
		{
			runTimeParameters = jobData.getInterfaceDef().getRunTimeParms();
			filterParameter = runTimeParameters.get(rightColumn);
			return convertOperatorRightColumn(rightColumn, parmValue, operator,filterParameter);
		}
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param rightColumn
	 * @param parmValue
	 * @param operator
	 * @param filterParameter
	 * @return
	 * </pre></p>
	 */
	private String convertOperatorRightColumn (String rightColumn, String inputValue, String parmOperator, FilterParameter filterParameter)
	{
		String returnValue = null;
		String dataType = null;
		
		dataType = filterParameter.getDataType();
		
		if ( "DATE".equals(dataType))
		{
			returnValue =  getDateValueString(parmOperator, inputValue);
		}
		else if ( "DECIMAL".equals(dataType))
		{
			returnValue =  getDecimalValueString(parmOperator, inputValue);
		}
		else if ( "STRING".equals(dataType))
		{
			returnValue =  getTextValueString(parmOperator, inputValue);
			
		}
		else if ("NUMBER".equals(dataType))
			returnValue =  getNumberValueString(parmOperator, inputValue);
		
		return returnValue;
	}
	
	public static String getDecimalValueString(String parmOperator, String inputValue)
	{
		String returnStr = null;
		String[] splitData = null;
		
		try
		{
			if ( IrisAdminConstants.BETWEEN.equals(parmOperator))
			{
				splitData = StringUtils.splitPreserveAllTokens(inputValue, ",");
				returnStr = " BETWEEN " + splitData[0] + " AND " + splitData[1] ;
			}
			else
				returnStr = " " + operators.get(parmOperator) + " " + inputValue ;
		}
		finally
		{
			parmOperator = null;
			inputValue = null;
			splitData = null;
		}
		
		return returnStr;
	}
	
	
	public static String getNumberValueString (String parmOperator, String inputValue)
	{
		String returnStr = null;
		StringBuilder builder = null;
		int count = 0;
		
		builder = new StringBuilder();
		builder.append(" IN (");
		String[] values = getValues(inputValue);
		for ( String s : values)
		{
			if ( count != 0)
				builder.append("," + s );
			else
				builder.append( s );
		}
		builder.append(")");
		returnStr = builder.toString();
		CleanUpUtils.doClean(builder);	
		return returnStr;
	}

	
	public static String getTextValueString(String parmOperator, String inputValue)
	{
		String returnStr = null;
		StringBuilder builder = null;
		int count = 0;
		
	
		try
		{
			
			if ( IrisAdminConstants.START_WITH.equals(parmOperator))
				returnStr = " LIKE '" + inputValue + "%'" ;
			else if ( IrisAdminConstants.END_WITH.equals(parmOperator))
				returnStr = " LIKE '%" + inputValue + "'" ;
			else if ( IrisAdminConstants.CONTAINS_WITH.equals(parmOperator))
				returnStr = " LIKE '%" + inputValue + "%'" ;
			else if ( IrisAdminConstants.EQUAL.equals(parmOperator) || IrisAdminConstants.IN.equals(parmOperator ) || "=".equals(parmOperator))
			{
				builder = new StringBuilder();
				builder.append(" IN (");
				String[] values = getValues(inputValue);
				for ( String s : values)
				{
					if ( count != 0)
						builder.append(",'" + s + "'");
					else
						builder.append("'" + s + "'");
					count++;
				}
				builder.append(")");
				returnStr = builder.toString();
				CleanUpUtils.doClean(builder);	
			}
			
		}
		finally
		{
			parmOperator = null;
			builder = null;
			count = 0;
			inputValue = null;
		}
		return returnStr;
	}
	
	private static String[] getValues(String value)
	{
		String[] values = null;
		
		values = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(value,",");
		
		return values;
	}
	
	
	public  String getDateValueString(String parmOperator, String inputValue) 
	{
		String returnStr = null;
		String[] splitData = null;
		String paramVal = null;
		DateTime appDate = null;
		DateTime startDate = null;
		DateTime endDate = null;
		int year = 0;
		int month = 0;
		
		try
		{
			
			if (IrisAdminConstants. BETWEEN.equals(parmOperator))
			{
				splitData = StringUtils.splitPreserveAllTokens(inputValue, ",");
				returnStr = " BETWEEN TO_DATE('" + splitData[0] + "','DD/MM/YYYY') AND TO_DATE('" + splitData[1] + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.EQUAL.equals(parmOperator) || IrisAdminConstants.AS_OF_DATE.equals(parmOperator))
				returnStr = " = TO_DATE('" + inputValue + "','DD/MM/YYYY')";
			else if ( IrisAdminConstants.NOT_EQUAL.equals(parmOperator) )
				returnStr = " <> TO_DATE('" + inputValue + "','DD/MM/YYYY')";
			else if ( IrisAdminConstants.LESSTHAN_EQUAL.equals(parmOperator))
				returnStr = " <= TO_DATE('" + inputValue + "','DD/MM/YYYY')";
			else if ( IrisAdminConstants.LESSTHAN.equals(parmOperator))
				returnStr = " < TO_DATE('" + inputValue + "','DD/MM/YYYY')";
			else if ( IrisAdminConstants.GRATERTHAN_EQUAL.equals(parmOperator))
				returnStr = " >= TO_DATE('" + inputValue + "','DD/MM/YYYY')";
			else if ( IrisAdminConstants.GRATERTHAN.equals(parmOperator))
				returnStr = " > TO_DATE('" + inputValue + "','DD/MM/YYYY')";
			else if ( IrisAdminConstants.AS_OF_DATE.equals(parmOperator))
				returnStr = " = TO_DATE('" + inputValue + "','DD/MM/YYYY')";
			else if ( IrisAdminConstants.TODAY.equals(inputValue))
			{
				paramVal = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE)).toString(DATE_FORMAT);
				returnStr = " = TO_DATE('" + paramVal + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.YESTERDAY.equals(inputValue))
			{
				paramVal = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_PREV_APP_DATE)).toString(DATE_FORMAT);
				returnStr = " = TO_DATE('" + paramVal + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.LAST_WEEK.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				DateTime dt2 = appDate.withFieldAdded(DurationFieldType.weeks(), -1);
				startDate = dt2.withDayOfWeek(1);
				endDate = dt2.withDayOfWeek(7);
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + endDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.LAST_WEEK_TODAY.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				DateTime dt2 = appDate.withFieldAdded(DurationFieldType.weeks(), -1);
				startDate = dt2.withDayOfWeek(1);
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + appDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.THIS_WEEK.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				startDate = appDate.withDayOfWeek(1);
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + appDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.LAST_MONTH.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear();
				month = appDate.getMonthOfYear() - 1;
				if ( month < 1)
				{
					year = year - 1;
					month = 12;
				}
				startDate = appDate.withDate(year, month, 1);
				endDate = startDate.dayOfMonth().withMaximumValue();
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + endDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.THIS_MONTH.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear();
				month = appDate.getMonthOfYear();
				startDate = appDate.withDate(year, month, 1);
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + appDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.LAST_MONTH_TODAY.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear();
				month = appDate.getMonthOfYear() - 1;
				
				if ( month < 1)
				{
					year = year - 1;
					month = 12;
				}
				startDate = appDate.withDate(year, month, 1);
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + appDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.LAST_QUATER.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				
				if ( appDate.getMonthOfYear() <= 3)
				{
					year = appDate.getYear() - 1;
					startDate = appDate.withDate(year, 10, 1);
					endDate = appDate.withDate(year , 12, 31);
				}
				else
				{
					startDate = quarterStartFor(appDate);
					endDate = quarterEndFor(appDate);
				}
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + endDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.THIS_QUARTER.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				startDate = quarterStartFor(appDate);
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + appDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.LAST_YEAR_TODAY.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				
				year = appDate.getYear() - 1;
				startDate = appDate.withDate(year, 1, 1);
				
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + appDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.LAST_YEAR.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear() - 1;
				startDate = appDate.withDate(year, 1, 1);
				endDate = appDate.withDate(year, 12, 31);
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + endDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
			else if ( IrisAdminConstants.THIS_YEAR.equals(inputValue))
			{
				appDate = getDate(jobData.getFilterParameter(IrisAdminConstants.SYS_APP_DATE));
				year = appDate.getYear();
				startDate = appDate.withDate(year, 1, 1);
				returnStr = " BETWEEN TO_DATE('" + startDate.toString(DATE_FORMAT) + "','DD/MM/YYYY') AND TO_DATE('" + appDate.toString(DATE_FORMAT) + "','DD/MM/YYYY')";
			}
		}
		finally
		{
			parmOperator = null;
			inputValue = null;
			splitData = null;
			paramVal = null;
			appDate = null;
			startDate = null;
			endDate = null;
			year = 0;
			month = 0;
		}
		return returnStr;
	}
	
	private static DateTime quarterStartFor(DateTime date) 
	{
        return date.withDayOfMonth(1).withMonthOfYear((((date.getMonthOfYear() - 1) / 3) * 3) + 1);
    }

    private  static DateTime quarterEndFor(DateTime date)
    {
        return quarterStartFor(date).plusMonths(3).minusDays(1);
    }
    
    private static DateTime getDate (String value) throws UnsupportedOperationException, IllegalArgumentException
	{
		DateTime date = null;
		DateTimeFormatter fmt = null;
		try
		{
			if (value.trim().length() > 10)
			{
				fmt = DateTimeFormat.forPattern("dd/MM/yyyy HH:mm:ss");
			}
			else
			{
				fmt = DateTimeFormat.forPattern(DATE_FORMAT);
			}
			date = fmt.parseDateTime(value);
		}
		finally
		{
			fmt = null;
		}
		return date;
	}

	/**
	 * @return the whereCondition
	 */
	public String getWhereCondition ()
	{
		return whereCondition;
	}

    
//    private String getRightSideColumn(String leftColumn, String operator, String rightColumn)
//	{
//		String returnVal = null;
//		Map<String, String> filterparms = null;
//		
//		
//		filterparms = jobData.getFilterParameters();
//		rightColumn = getBindColumn(operator,rightColumn);
//		
//		if (filterparms.containsKey(rightColumn))
//		{
//			returnVal = filterparms.get(rightColumn);
//			returnVal = formatValue(operator, rightColumn);
//		}
//		else
//			returnVal = " " + operator + " " + rightColumn;
//		
//		return returnVal;
//	}

	
}
