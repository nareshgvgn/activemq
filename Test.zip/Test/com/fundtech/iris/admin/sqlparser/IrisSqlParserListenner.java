/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.sqlparser
 * FILE   : IrisSqlParserListenner.java
 * CREATED: Jan 14, 2016 12:49:07 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.sqlparser;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * <p>The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisSqlParserListenner.java,v 1.3 2016/12/08 11:23:37 ramap Exp $
 */
public class IrisSqlParserListenner implements SqlParserEngineListener
{
	private ExecutionJobData jobData = null;
	private List<String> whereConditionParms = new LinkedList<String>();
	private List<String> tablesList = new LinkedList<String>();
	private List<String> columnsList = new LinkedList<String>();
	private String whereCondition = null;
	private String leftColumn = null;
	private String operator = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisSqlParserListenner(ExecutionJobData jobData)
	{
		this.jobData = jobData;
	}
	
	/* (non-Javadoc)
	 * @see sqlparser.SqlParserEngineListener#fireLeftSideColumn(java.lang.String)
	 */
	@Override
	public String fireLeftSideColumn (String column)
	{
		System.out.println("LEFT COLUMN:" + column);
		leftColumn = column;
		return column;
	}

	/* (non-Javadoc)
	 * @see sqlparser.SqlParserEngineListener#fireOperator(java.lang.String)
	 */
	@Override
	public String fireOperator (String operator)
	{
		System.out.println("OPRATOR:" + operator);
//		this.operator = operator;
//		if ( ":=".equals(operator.trim()))
//			operator = "=";
		
		return operator;
		
	}

	/* (non-Javadoc)
	 * @see sqlparser.SqlParserEngineListener#fireRightSideColumn(java.lang.String)
	 */
	@Override
	public String fireRightSideColumn (String column)
	{
		
		System.out.println("RIGGHT COLUMN:" + column);
//		String returnVal = null;
//		if ( column == null)
//			return "";
//		
//		if ( column.startsWith("${"))
//		{
//			column = column.substring(2, column.length() - 1);
//			returnVal = "?";
//			whereConditionParms.add(column);
//		}
//		else
//			returnVal = column;
//		
		return column;
		
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireTable(java.lang.String)
	 */
	@Override
	public String fireTable (String tableName)
	{
		tablesList.add(tableName);
		return tableName;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireColumn(java.lang.String)
	 */
	@Override
	public String fireColumn (String column)
	{
		columnsList.add(column);
		return column;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#fireWhere(java.lang.String)
	 */
	@Override
	public String fireWhere (String where)
	{
		this.whereCondition = where;
		return where;
	}

	/**
	 * @return the whereConditionParms
	 */
	public List<String> getWhereConditionParms ()
	{
		return whereConditionParms;
	}

	/**
	 * @return the tablesList
	 */
	public List<String> getTablesList ()
	{
		return tablesList;
	}

	/**
	 * @return the columnsList
	 */
	public List<String> getColumnsList ()
	{
		return columnsList;
	}

	/**
	 * @return the whereCondition
	 */
	public String getWhereCondition ()
	{
		return whereCondition;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.sqlparser.SqlParserEngineListener#combineOperatorRight(java.lang.String, java.lang.String)
	 */
	@Override
	public String combineOperatorRight (String leftColumn, String operator, String rightColumn)
	{
		String returnVal = null;
		
		returnVal =   " " + leftColumn + " " + operator + " " + rightColumn;
		
		System.out.println("returnVal:"+returnVal);
		return returnVal;
	}
	
}
