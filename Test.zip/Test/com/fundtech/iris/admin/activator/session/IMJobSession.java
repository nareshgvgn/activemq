/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator.session
 * FILE   : IMJobSession.java
 * CREATED: Jul 25, 2015 2:25:32 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.activator.session;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.Context;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.ProcessExecution;
import com.cashtech.iris.core.processor.SimpleProcess;
import com.cashtech.iris.core.processor.SimpleProcessExecution;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.util.IRISLogger;
import com.dh.iris.admin.channels.iris.IDataObject;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.ZeroProofings;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IMJobSession.java,v 1.14 2016/09/22 06:23:48 ramap Exp $
 */
public class IMJobSession extends Session 
{
	
	private Logger logger = LoggerFactory.getLogger(IMJobSession.class);
//	private static Logger operator = LoggerFactory.getLogger("com.cashtech.iris.customLogger.Operator");
	private String triggerProcesses = null;
	private ExecutionJobData  jobData = null;
	private String dbResourceName = null;
	private IDataObject dataObjectHelper = null;
	private String id = "SCG";
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run ()
	{
		execute();
	}
	
	/**
	 * TODO Please insert Type's purpose and description.
	 * 
	 * @param triggerProcesses
	 * @param eventProcessJob
	 */
	public IMJobSession(String triggerProcesses, ExecutionJobData jobData, String dbResourceName, IDataObject dataObjectHelper)
	{
		super();
		this.triggerProcesses = triggerProcesses;
		this.jobData = jobData;
		this.dbResourceName = dbResourceName;
		this.dataObjectHelper = dataObjectHelper;
	}
	
	public void execute ()
	{
		Context context = null;
		SimpleProcess simpleProcess = null;
		ProcessExecution simpleProcessExecution = null;
		Packet packet = null;
		String executionName = null;
		String srcSubType = null;
		DataObject inputDo = null;
		Map<String, Object> dataObjectParms = null;
		String processName = null;
		String status = null;
		String errorCode = null;
		String errorMsg = null;
		String executionId = null;
		
		IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "Before Starting Session");
		try
		{
			srcSubType = jobData.getSrcSubType();
			executionId = 	jobData.getExecutionId();
			processName = jobData.getMapName();
//			if ( IrisAdminConstants.SCH_SEGMENTED.equals(srcSubType))
//				operator.info("Start Processing : {}_{}  [{}] [ThreadCount:{}]", id, processName, executionId, ManagementFactory.getThreadMXBean().getThreadCount());
			executionName = setThreadId(processName, jobData.getExecutionId(), srcSubType);
			context = createContext();
			packet = new Packet(null, context);
			packet.setContext(context);
			context.getExecutionContext().put(IrisAdminConstants.EXECUTION_DATA, jobData);
			
			if ( IrisAdminConstants.IRIS.equals(srcSubType) || IrisAdminConstants.SCH_PROFILE_IRIS.equals(srcSubType) ||  IrisAdminConstants.IRIS_EXECUTE.equals(srcSubType))
			{
				triggerProcesses = processName;
				dataObjectParms = new HashMap<String, Object>();
				dataObjectParms.put(IDataObject.MAP_NAME, processName);
				dataObjectParms.put(IDataObject.MEDIA_DETAIL, jobData.getMediaDetails());
				dataObjectParms.put(IDataObject.EXECUTION_ID, executionId);
				dataObjectParms.put(IDataObject.SCHEDULE_ID, jobData.getRefId());
				inputDo = dataObjectHelper.createDataObject(dataObjectParms);
				packet.setDataObject(inputDo);
			}
			
			simpleProcess = getApplicationContext().getProcessDefinition().getProcess(triggerProcesses);
			context.getExecutionContext().put(IrisAdminConstants.ZEROPROOFING_DATA, new ZeroProofings());
			context.getExecutionContext().put(ProcessExecution.PROCESS_NAME, processName);
			context.getExecutionContext().put(ProcessExecution.PROCESS_EXECUTION_ID, executionName);
			simpleProcessExecution = new SimpleProcessExecution(simpleProcess);
			simpleProcessExecution.setPacket(packet);
			simpleProcessExecution.executeProcess();
			
			status = "C";
			errorCode = "Sucess";
			errorMsg = "Sucess";
		}
		catch ( NullPointerException exp)
		{
			status = "E";
			errorCode = "ERROR";
			errorMsg = "Execution Error";
			logger.error(IRISLogger.getNodeProcExText("error.app.errorExecutingProcess", new Object[]{ "Data Object is empty"}, exp));
		}
		catch (Exception e)
		{
			status = "E";
			errorCode = "ERROR";
			errorMsg = "Execution Error";
			logger.error(IRISLogger.getNodeProcExText("error.app.errorExecutingProcess", new Object[]{ getClass().getName() }, e));
		}
		finally
		{
			if (IrisAdminConstants.IRIS.equals(srcSubType) || IrisAdminConstants.IRIS_EXECUTE.equals(srcSubType))
			{
				IrisAdminUtils.finishProcess(status, errorCode, errorMsg, jobData, dbResourceName, getApplicationContext(), true);
			}
			else if (IrisAdminConstants.SCH_PROFILE_IRIS.equals(srcSubType))
			{
				IrisAdminUtils.finishProcess(status, errorCode, errorMsg, jobData, dbResourceName, getApplicationContext(), false);
			}
			jobData.cleanup();
			jobData = null;
			
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "After finishing Session");
//			operator.info("End Processing : {}_{}  [{}] [ThreadCount:{}", id, processName, executionId, ManagementFactory.getThreadMXBean().getThreadCount());
		}
	}
	
	private String setThreadId (String interfaceName, String executionId, String srcSubType)
	{
		String pidRet = null;
		
		if ( IrisAdminConstants.SCH_SEGMENTED.equals(srcSubType))
			pidRet = "SCG_" + interfaceName + "_" + executionId;
		else if ( IrisAdminConstants.SCH_PROFILE.equals(srcSubType))
			pidRet = "PRF_" + interfaceName + "_" + executionId;
			else
		pidRet = "IM_" + interfaceName + "_" + executionId;
		if (logger.isInfoEnabled())
			logger.info("Changing thread name [" + Thread.currentThread().getName() + "] to [" + pidRet + "]");
		
		Thread.currentThread().setName(pidRet);
		return pidRet;
	}
}
