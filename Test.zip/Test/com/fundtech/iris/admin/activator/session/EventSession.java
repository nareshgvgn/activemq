/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator.session
 * FILE   : EventSession.java
 * CREATED: Jul 5, 2014 4:50:40 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.activator.session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.Context;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.ProcessExecution;
import com.cashtech.iris.core.processor.SimpleProcess;
import com.cashtech.iris.core.processor.SimpleProcessExecution;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.EventJob;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: EventSession.java,v 1.8 2016/10/27 09:01:16 ramap Exp $
 */
public class EventSession extends Session implements Runnable
{
	private Logger logger = LoggerFactory.getLogger(EventSession.class);
	private String triggerProcesses = null;
	private EventJob eventJob = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run ()
	{
		execute();
	}
	
	/**
	 * TODO Please insert Type's purpose and description.
	 * 
	 * @param triggerProcesses
	 * @param eventProcessJob
	 */
	public EventSession(String triggerProcesses, EventJob eventJob)
	{
		super();
		this.triggerProcesses = triggerProcesses;
		this.eventJob = eventJob;
	}
	
	public void execute ()
	{
		Context context = null;
		SimpleProcess simpleProcess = null;
		ProcessExecution simpleProcessExecution = null;
		Packet packet = null;
		String executionName = null;
		
		IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "Before Starting Session");
		try
		{
			executionName = setThreadId();
			simpleProcess = getApplicationContext().getProcessDefinition().getProcess(triggerProcesses);
			context = createContext();
			context.getExecutionContext().put(ProcessExecution.PROCESS_NAME, triggerProcesses);
			context.getExecutionContext().put(ProcessExecution.PROCESS_EXECUTION_ID, executionName);
			packet = new Packet(null, context);
			context.getExecutionContext().put(IrisAdminConstants.EXECUTION_DATA, eventJob);
			packet.setContext(context);
			simpleProcessExecution = new SimpleProcessExecution(simpleProcess);
			simpleProcessExecution.setPacket(packet);
			simpleProcessExecution.executeProcess();
		}
		catch (Exception e)
		{
			logger.error(IRISLogger.getNodeProcExText("error.app.errorExecutingProcess", new Object[]{ getClass().getName() }, e));
		}
		finally
		{
			eventJob.cleanup();
			eventJob = null;
			
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "After finishing Session");
		}
	}
	
	private String setThreadId ()
	{
		String pidRet = null;
		
		pidRet = eventJob.getTxnCode()+ "_" + eventJob.getNotificationId() + "_" + eventJob.getEventName() + "_" + eventJob.getJournalNmbr();
		if (logger.isInfoEnabled())
			logger.info("Changing thread name [" + Thread.currentThread().getName() + "] to [" + pidRet + "]");
		
		Thread.currentThread().setName(pidRet);
		return pidRet;
	}
}
