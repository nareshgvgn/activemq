/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator.session
 * FILE   : Session.java
 * CREATED: Jul 5, 2014 4:58:51 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.activator.session;

import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.contexts.Context;
import com.cashtech.iris.contexts.ContextManager;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: Session.java,v 1.3 2015/11/28 08:12:38 ramap Exp $
 */
public abstract class Session implements Runnable
{
	private ApplicationContext applicationContext;
	
	public abstract void execute ();
	
	/**
	 * @return the applicationContext
	 */
	public ApplicationContext getApplicationContext () 
	{
		return applicationContext;
	}
	
	public void setApplicationContext (ApplicationContext applicationContext)
	{
		this.applicationContext = applicationContext;
		
	}
	
	/**
	 * Helper method to create the new named Context
	 * 
	 * @return reference to newly created {@linkplain Context}
	 * @throws Exception
	 */
	protected Context createContext () throws Exception
	{
		
		Context context = null;
		ContextManager contextManager = null;
		
		// Create the context
		contextManager = ContextManager.getInstance();
		context = contextManager.getSimpleContext();
		return context;
	}
	
}
