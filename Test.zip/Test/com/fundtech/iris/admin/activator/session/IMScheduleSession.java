/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator.session
 * FILE   : IMScheduleSession.java
 * CREATED: Jul 29, 2015 11:35:30 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.activator.session;

import java.lang.management.ManagementFactory;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.db.IrisIMScheduleJobActivator;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;
import com.fundtech.iris.admin.util.OracleType;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IMScheduleSession.java,v 1.12 2016/12/08 11:25:41 ramap Exp $
 */
public class IMScheduleSession extends Session implements Runnable
{
	private Logger logger = LoggerFactory.getLogger(IMScheduleSession.class);
	
	/**
	 * custom logger which replaces SOPs to log statements & can be used to
	 * print to console
	 */
	private static Logger operator = LoggerFactory.getLogger("com.cashtech.iris.customLogger.Operator");
	private ExecutionJobData  jobData = null;
	private IrisIMScheduleJobActivator jobActivator = null;
	private String dbResourceName = null;
	private final static String PROC_HOOK = "{CALL pkg_integrate_host.host_handoff_wrapper(?,?,?,?,?)}";
	private String hookToCall = null;
	
	private String id = "SCG";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run ()
	{
		execute();
	}
	
	/**
	 * TODO Please insert Type's purpose and description.
	 * 
	 * @param triggerProcesses
	 * @param eventProcessJob
	 */
	public IMScheduleSession( ExecutionJobData  jobData, IrisIMScheduleJobActivator jobActivator, String dbResourceName)
	{
		super();
		this.jobActivator = jobActivator;
		this.jobData = jobData;
		this.dbResourceName = dbResourceName;
	}
	
	public void execute ()
	{
		String[] status = null;
		String errorCode = null;
		String errorMsg = null;
		String mapName = null;
		String executionId = null;
		
		IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "Before Starting Session");
		try
		{
			mapName = jobData.getMapName();
			executionId = jobData.getExecutionId();
			setThreadId(mapName, executionId);
			operator.info("Start Processing : {}_{}  [{}] [ThreadCount:{}]", id, mapName, executionId, ManagementFactory.getThreadMXBean().getThreadCount());
			status = callModelHook();
			
			if ( "C".equals(status[0]))
				jobActivator.execute();
			
			if ( "C".equals(status[0]))
			{
				errorCode = "Sucess";
				errorMsg = "Sucess";
			}
			else if (IrisAdminConstants.CONSTANT_N.equals(status[0]))
			{
				status[0] = "C";
				errorCode = "Sucess";
				errorMsg = status[1];
			}
			else
			{
				errorCode = "ERROR";
				errorMsg = status[1];
			}
		}
		catch (Exception e)
		{
			status[0] = "E";
			errorCode = "ERROR";
			errorMsg = "Execution Error";
			logger.error(IRISLogger.getNodeProcExText("error.app.errorExecutingProcess", new Object[]{ getClass().getName() }, e));
		}
		finally
		{
			IrisAdminUtils.finishProcess(status[0], errorCode, errorMsg, jobData, dbResourceName, getApplicationContext(), true);
			jobData.cleanup();
			jobData = null;
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.DEBUG, logger, "After finishing Session");
		}
		operator.info("End Processing : {}_{}  [{}] [ThreadCount:{}", id, mapName, executionId, ManagementFactory.getThreadMXBean().getThreadCount());
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * </pre></p>
	 */
	private String[] callModelHook () 
	{
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		ExecutionException eExp = null;
		CallableStatement cStmt = null;
		String executionId = null;
		OracleType runtimeParms = null;
		OracleConnection oraConnection = null;
		ARRAY array = null;
		OracleType[] types = new OracleType[1];
		String errorCode = null;
		String errorMsg = null;
		String action = "commit";
		String[] returnVal = null;
		String whereCondition = null;
		
		try
		{
			whereCondition = jobData.getWhereCondition();
			startTime = System.currentTimeMillis();
			dbProvider = IrisAdminUtils.getDBProvider(dbResourceName, getApplicationContext());
			dbConnection = dbProvider.getConnection();
			returnVal = new String[2];
			runtimeParms = new OracleType(null, null, null);
			types[0] = runtimeParms;
			oraConnection = IrisAdminUtils.getOracleConnection(dbConnection);
			array = HelperUtils.createTypeValue(oraConnection, OracleTypes.ARRAY, "NT_KEY_VALUE_PAIR", types);
			cStmt = dbConnection.prepareCall(getHookToCall());
			executionId = jobData.getExecutionId();
			cStmt.setString(1, executionId);
			cStmt.setObject(2, array, OracleTypes.ARRAY);
			cStmt.setString(3, whereCondition);
			cStmt.registerOutParameter(4, Types.VARCHAR);
			cStmt.registerOutParameter(5, Types.VARCHAR);
			cStmt.executeUpdate();
			errorCode = cStmt.getString(4);
			errorMsg = cStmt.getString(5);
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			logger.debug("Time taken for executing {} StoredProcedure:{} " , PROC_HOOK, delta);			
			if ( errorCode == null)
			{
				returnVal[0] = "C";
				return returnVal;
			}
			else if ( "1000".equals(errorCode))
			{
				logger.warn("##### " + errorMsg + " ####");
				returnVal[0] = "C";
				returnVal[1] = errorMsg;
				return returnVal;
			}
			else
			{
				action = "rollback";
				logger.error("Error while calling {}, Error Code:{}, Error Desc:{}", hookToCall, errorCode, errorMsg);
				eExp = new ExecutionException("error.iris.admin.sch", new Object[] {hookToCall, errorCode, errorMsg}, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch ( ExecutionException exp)
		{
			logger.error("Error:", exp);
			//ignore
		}
		catch (Exception exp)
		{
			logger.error("Ignoring this exceition:{}" , exp.getMessage());
			eExp = new ExecutionException("", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
		}
		finally
		{
			CleanUpUtils.doClean(cStmt);
			dbAction(dbConnection, action);
			CleanUpUtils.doClean(dbProvider, dbConnection);
		}
		returnVal[0] = "E";
		returnVal[1] = errorMsg;
		return returnVal;
	}

	private String setThreadId (String interfaceName, String executionId)
	{
		String pidRet = null;
		
		pidRet = id + "_" + interfaceName + "_" + executionId;
		if (logger.isInfoEnabled())
			logger.info("Changing thread name [" + Thread.currentThread().getName() + "] to [" + pidRet + "]");
		
		Thread.currentThread().setName(pidRet);
		return pidRet;
	}
	
	private void dbAction(Connection dbConnection , String action)
	{
		try
		{
				
			if ( "commit".equals(action))
				dbConnection.commit();
			else
				dbConnection.rollback();
			
		}
		catch (Exception exp)
		{
			logger.error("Error:", exp);
			// DO NOTHING
		}
	}

	/**
	 * @return the hookToCall
	 */
	public String getHookToCall ()
	{
		if ( hookToCall == null)
			hookToCall = PROC_HOOK; 
		return hookToCall;
	}

	/**
	 * @param hookToCall the hookToCall to set
	 */
	public void setHookToCall (String hookToCall)
	{
		
		this.hookToCall = hookToCall;
	}

	/**
	 * @param id the id to set
	 */
	public void setId (String id)
	{
		this.id = id;
	}
	
	
}
