package com.fundtech.iris.admin.activator.session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.contexts.Context;
import com.cashtech.iris.core.processor.Packet;
import com.cashtech.iris.core.processor.ProcessExecution;
import com.cashtech.iris.core.processor.SimpleProcess;
import com.cashtech.iris.core.processor.SimpleProcessExecution;
import com.cashtech.iris.core.processor.activators.Session;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.RMJobData;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * This class will used for getting Session for DBActivator class.
 * 
 * @author
 */
public class RMDbSession extends Session implements Runnable
{
	private static Logger logger = LoggerFactory.getLogger(RMDbSession.class.getName());
	private DataObject dataObject = null;
	private RMJobData jobData = null;
	
	/**
	 * Class constructor
	 * 
	 * @param strId
	 * @param applicationContext
	 * @param activatordataTransferObject
	 */
	public RMDbSession(String strId, ApplicationContext applicationContext, DataObject activatorDataObject, RMJobData jobData)
	{
		this.id = strId;
		this.applicationContext = applicationContext;
		this.dataObject = activatorDataObject;
		this.jobData = jobData;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run ()
	{
		try
		{
			executeProcess();
		}
		catch (Exception e)
		{
			logger.error("IRIS0006:" + IRISLogger.getNodeProcExText("error.app.errorExecutingJob", new Object[]			{ getClass().getName() }, e));
		}
	}
	
	/**
	 * Actual execution of process
	 * 
	 * @throws Exception
	 * @return Packet
	 * @throws Exception
	 */
	private void executeProcess () throws Exception
	{
		String strProcessName = null;
		
		Context context = null;
		SimpleProcess simpleProcess = null;
		ProcessExecution simpleProcessExecution = null;
		Packet packet = null;
		String strExecutionId = null;
		String executionName = null;
		
		IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.TRACE, logger, "Before Starting Session");
		try
		{
			// Check if the process to be triggered has been specified in the metadata
			if (null != triggerProcesses)
			{
				// Loop thru all the processes defined for the activator
				// Trigger their execution
				for (int i = 0; i < triggerProcesses.size(); i++)
				{
					strProcessName = (String) triggerProcesses.get(i);
					executionName = jobData.getSrcId() + "_" + jobData.getExecutionId();
					// Get the process instance
					simpleProcess = applicationContext.getProcessDefinition().getProcess(strProcessName);
					Thread.currentThread().setName(executionName);
					// Create the Context to be passed in the Packet
					// strExecutionId = getExecutionId(strProcessName);
					context = createContext();
					context.getExecutionContext().put(ProcessExecution.PROCESS_NAME, strProcessName);
					context.getExecutionContext().put(ProcessExecution.PROCESS_EXECUTION_ID, executionName);
					context.getExecutionContext().put(IrisAdminConstants.EXECUTION_DATA, this.jobData);
					
					if (this.dataObject.getType().containsProperty("ExecutionId"))
					{
						this.dataObject.setValue("ExecutionId", strExecutionId);
					}
					packet = new Packet(this.dataObject, context);
					simpleProcessExecution = new SimpleProcessExecution(simpleProcess);
					
					// set packet on the process
					simpleProcessExecution.setPacket(packet);
					
					// Execute the process
					simpleProcessExecution.executeProcess();
				}
			}
			else
			{
				executionName = jobData.getSrcId() + "_" + jobData.getExecutionId();
				Thread.currentThread().setName(executionName);
				// ProcessName would be identified runtime based on the data passed to the activator
				// ProcessIdentifier would have been set on this activator
				strProcessName = processIdentifier.identify(jobData);
				
				// Get the process instance
				simpleProcess = applicationContext.getProcessDefinition().getProcess(strProcessName);
				// Assuming new Iris library are used
				// strExecutionId = getExecutionId(strProcessName);
				context = createContext();
				context.getExecutionContext().put(ProcessExecution.PROCESS_NAME, strProcessName);
				context.getExecutionContext().put(ProcessExecution.PROCESS_EXECUTION_ID, executionName);
				
				context.getExecutionContext().put(IrisAdminConstants.EXECUTION_DATA, this.jobData);
				
				// context.getExecutionContext().put("EntityCode", entityCode);
				// packet = new Packet(activatorDataTransferObject, context);
				simpleProcessExecution = new SimpleProcessExecution(simpleProcess);
				
				// set packet on the process
				simpleProcessExecution.setPacket(packet);
				
				// Execute the process
				simpleProcessExecution.executeProcess();
				
			}
		}
		finally
		{
			jobData.cleanup();
			dataObject = null; 
			jobData = null;
			IrisAdminUtils.logMemoryDetails(IrisAdminUtils.Level.TRACE, logger, "After finishing Session");
		}
		
	}// execute Process
}// Class
