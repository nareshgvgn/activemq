/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : MappingField.java
 * CREATED: Jan 6, 2013 11:41:10 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: MappingField.java,v 1.9 2016/10/19 14:04:55 ramap Exp $
 * @since 1.0.0
 */
public class MappingField
{
	/**
	 * This is Interface level band type of field is from Interface or Fixed value CUSTOM if it is Custom field.
	 */
	private String bandType = null;
	private String bandName = null;
	private String fieldName = null;
	private String dataType = null;
	// 0 : Regular field, 1 : Regular field which is mandatory,2 : Custom field,3 : Custom field which is mandatory
	private int fieldType = 0;
	
	private int fieldLength = 0;
	private int iFieldLength = 0;
	private int startPosition = 0;
	private int endPosition = 0;
	// private MappingField previousField = null;
	
	/**
	 * Mapping Type will have values as 0 : Direct 1 : Referenced 2 : Function 3 : Code Map 4 : Complex 5 : Constant 6 : Running no 7 : Batch Total 8
	 * : Internal default is Direct.
	 */
	private int mappingType = 0;
	private boolean mandatory = false;
	private String format = null;
	private int precision = 0;
	private int sequenceNmbr = 0;
	private String defaultValue = null;
	
	/**
	 * L : Left R : Right"
	 */
	private String alignment = null;
	
	/**
	 * Values are : SPACE, ZERO, ASTERIC Value stored in DB should be actual character.
	 */
	
	private String filler = null;
	
	/**
	 * Band Name for Reference Mapping
	 */
	private String bandRef = null;
	/*
	 * TODO need to check may be we need to give another field
	 */
	private String fieldRef = null;
	
	private String bandRefPath = null;
	
	/*
	 * TODO need to check Code Map may be we need to give code map
	 */
	
	private String codeMapRef = null;
	private String constantValue = null;
	
	/*
	 * TODO may be while populating we need to derive which function and fields
	 */
	
	private String derivationLogic1 = null;
	private String derivationLogic2 = null;
	
	private String resetBandName = null;
	
	private String batchRunningNoName = null;
	
	/*
	 * TODO may be we can derive orderby and keep in that seq in list itself
	 */
	private int orderSequenceNmbr = 0;
	
	/**
	 * Values stored as :A : Ascending D : Descending"
	 */
	
	private String orderBy = null;
	
	/**
	 * (Map Type = "Batch Total") Values stored as : S : Sum C : Count"
	 */
	private String batchTotalType = null;
	
	/**
	 * This xPath is used for XML/XSD
	 */
	private String absoluteXPath1 = null;
	
	private String absoluteXPath2 = null;
	
	private String relativeXPath = null;
	
	/**
	 * Whether to do perform incremental download on the basis of this field
	 */
	private boolean downloadIncrementally = false;
	
	private CodeMap codeMap = null;
	
	private int executionOrder = 0;
	
	private String remarks = null;
	
	private boolean restrictToSize = false;
	
	/**
	 * @return the bandType
	 */
	public String getBandType ()
	{
		return bandType;
	}
	
	/**
	 * @param bandType
	 *            the bandType to set
	 */
	public void setBandType (String bandType)
	{
		this.bandType = bandType;
	}
	
	/**
	 * @return the bandName
	 */
	public String getBandName ()
	{
		return bandName;
	}
	
	/**
	 * @param bandName
	 *            the bandName to set
	 */
	public void setBandName (String bandName)
	{
		this.bandName = bandName;
	}
	
	/**
	 * @return the fieldName
	 */
	public String getFieldName ()
	{
		return fieldName;
	}
	
	/**
	 * @param fieldName
	 *            the fieldName to set
	 */
	public void setFieldName (String fieldName)
	{
		this.fieldName = fieldName;
	}
	
	/**
	 * @return the dataType
	 */
	public String getDataType ()
	{
		return dataType;
	}
	
	/**
	 * @param dataType
	 *            the dataType to set
	 */
	public void setDataType (String dataType)
	{
		this.dataType = dataType;
	}
	
	/**
	 * @return the field length
	 */
	public int getFieldLength ()
	{
		return fieldLength;
	}
	
	/**
	 * @param fieldlength
	 *            the field length to set
	 */
	public void setFieldLength (int fieldlength)
	{
		this.fieldLength = fieldlength;
	}
	
	/**
	 * @return the mappingType
	 */
	public int getMappingType ()
	{
		return mappingType;
	}
	
	/**
	 * @param mappingType
	 *            the mappingType to set
	 */
	public void setMappingType (int mappingType)
	{
		this.mappingType = mappingType;
	}
	
	/**
	 * @return the mandatory
	 */
	public boolean isMandatory ()
	{
		return mandatory;
	}
	
	/**
	 * @param mandatory
	 *            the mandatory to set
	 */
	public void setMandatory (String mandatory)
	{
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(mandatory))
			this.mandatory = true;
		else
			this.mandatory = false;
	}
	
	/**
	 * @return the format
	 */
	public String getFormat ()
	{
		return format;
	}
	
	/**
	 * @param format
	 *            the format to set
	 */
	public void setFormat (String format)
	{
		this.format = format;
	}
	
	/**
	 * @return the precision
	 */
	public int getPrecision ()
	{
		return precision;
	}
	
	/**
	 * @param precision
	 *            the precision to set
	 */
	public void setPrecision (int precision)
	{
		this.precision = precision;
	}
	
	/**
	 * @return the sequenceNbr
	 */
	public int getsequenceNmbr ()
	{
		return sequenceNmbr;
	}
	
	/**
	 * @param sequenceNbr
	 *            the sequenceNbr to set
	 */
	public void setsequenceNmbr (int sequenceNmbr)
	{
		this.sequenceNmbr = sequenceNmbr;
	}
	
	/**
	 * @return the defaultValue
	 */
	public String getDefaultValue ()
	{
		return defaultValue;
	}
	
	/**
	 * @param defaultValue
	 *            the defaultValue to set
	 */
	public void setDefaultValue (String defaultValue)
	{
		this.defaultValue = defaultValue;
	}
	
	/**
	 * @return the alignment
	 */
	public String getAlignment ()
	{
		return alignment;
	}
	
	/**
	 * @param alignment
	 *            the alignment to set
	 */
	public void setAlignment (String alignment)
	{
		if (alignment != null)
			this.alignment = alignment;
	}
	
	/**
	 * @return the filler
	 */
	public String getFiller ()
	{
		return filler;
	}
	
	/**
	 * @param filler
	 *            the filler to set
	 */
	public void setFiller (String filler)
	{
		if (filler != null)
			this.filler = filler;
	}
	
	/**
	 * @return the fieldRef
	 */
	public String getFieldRef ()
	{
		return fieldRef;
	}
	
	/**
	 * @param fieldRef
	 *            the fieldRef to set
	 */
	public void setFieldRef (String fieldRef)
	{
		this.fieldRef = fieldRef;
	}
	
	/**
	 * @return the codeMapRef
	 */
	public String getCodeMapRef ()
	{
		return codeMapRef;
	}
	
	/**
	 * @param codeMapRef
	 *            the codeMapRef to set
	 */
	public void setCodeMapRef (String codeMapRef)
	{
		this.codeMapRef = codeMapRef;
	}
	
	/**
	 * @return the constantValue
	 */
	public String getConstantValue ()
	{
		return constantValue;
	}
	
	/**
	 * @param constantValue
	 *            the constantValue to set
	 */
	public void setconstantValue (String constantValue)
	{
		this.constantValue = constantValue;
	}
	
	/**
	 * @return the derivationLogic1
	 */
	public String getDerivationLogic1 ()
	{
		return derivationLogic1;
	}
	
	/**
	 * @param derivationLogic1
	 *            the derivationLogic1 to set
	 */
	public void setDerivationLogic1 (String derivationLogic1)
	{
		this.derivationLogic1 = derivationLogic1;
	}
	
	/**
	 * @return the derivationLogic2
	 */
	public String getDerivationLogic2 ()
	{
		return derivationLogic2;
	}
	
	/**
	 * @param derivationLogic2
	 *            the derivationLogic2 to set
	 */
	public void setDerivationLogic2 (String derivationLogic2)
	{
		this.derivationLogic2 = derivationLogic2;
	}
	
	/**
	 * @return the batchRunningNoName
	 */
	public String getBatchRunningNoName ()
	{
		return batchRunningNoName;
	}
	
	/**
	 * @param batchRunningNoName
	 *            the batchRunningNoName to set
	 */
	public void setBatchRunningNoName (String batchRunningNoName)
	{
		this.batchRunningNoName = batchRunningNoName;
	}
	
	/**
	 * @return the orderSequenceNmbr
	 */
	public int getorderSequenceNmbr ()
	{
		return orderSequenceNmbr;
	}
	
	/**
	 * @param orderSequenceNmbr
	 *            the orderSequenceNmbr to set
	 */
	public void setorderSequenceNmbr (int orderSequenceNmbr)
	{
		this.orderSequenceNmbr = orderSequenceNmbr;
	}
	
	/**
	 * @return the orderBy
	 */
	public String getorderBy ()
	{
		return orderBy;
	}
	
	/**
	 * @param orderBy
	 *            the orderBy to set
	 */
	public void setorderBy (String orderBy)
	{
		this.orderBy = orderBy;
	}
	
	/**
	 * @return the batchTotalType
	 */
	public String getBatchTotalType ()
	{
		return batchTotalType;
	}
	
	/**
	 * @param batchTotalType
	 *            the batchTotalType to set
	 */
	public void setBatchTotalType (String batchTotalType)
	{
		this.batchTotalType = batchTotalType;
	}
	
	/**
	 * @param downloadIncrementally
	 *            To download incrementally on the basis of this field or not
	 */
	public void setDownloadIncrementally (String downloadIncrementally)
	{
		if (IrisAdminConstants.CONSTANT_Y.equalsIgnoreCase(downloadIncrementally))
			this.downloadIncrementally = true;
		else
			this.downloadIncrementally = false;
	}
	
	/**
	 * @return Whether to download incrementally on the basis of this field or not
	 */
	public boolean isDownloadIncrementally ()
	{
		return downloadIncrementally;
	}
	
	public void setBandRef (String bandRef)
	{
		this.bandRef = bandRef;
	}
	
	public String getBandRef ()
	{
		return bandRef;
	}
	
	/**
	 * @return the bandRefPath
	 */
	public String getBandRefPath ()
	{
		return bandRefPath;
	}
	
	/**
	 * @param bandRefPath
	 *            the bandRefPath to set
	 */
	public void setBandRefPath (String bandRefPath)
	{
		this.bandRefPath = bandRefPath;
	}
	
	// /**
	// * @return the previousField
	// */
	// public MappingField getPreviousField()
	// {
	// return previousField;
	// }
	//
	// /**
	// * @param previousField the previousField to set
	// */
	// public void setPreviousField(MappingField previousField)
	// {
	// this.previousField = previousField;
	// }
	
	/**
	 * @return the startPosition
	 */
	public int getStartPosition ()
	{
		return startPosition;
	}
	
	/**
	 * @param startPosition
	 *            the startPosition to set
	 */
	public void setStartPosition (int startPosition)
	{
		this.startPosition = startPosition;
	}
	
	/**
	 * @return the endPosition
	 */
	public int getEndPosition ()
	{
		return endPosition;
	}
	
	/**
	 * @param endPosition
	 *            the endPosition to set
	 */
	public void setEndPosition (int endPosition)
	{
		this.endPosition = endPosition;
	}
	
	/**
	 * @return the fieldType
	 */
	public int getFieldType ()
	{
		return fieldType;
	}
	
	/**
	 * @param fieldType
	 *            the fieldType to set
	 */
	public void setFieldType (int fieldType)
	{
		this.fieldType = fieldType;
	}
	
	/**
	 * @return the iFieldLength
	 */
	public int getIFieldLength ()
	{
		return iFieldLength;
	}
	
	/**
	 * @param fieldLength
	 *            the iFieldLength to set
	 */
	public void setModelFieldLength (int fieldLength)
	{
		iFieldLength = fieldLength;
	}
	
	public String getRelativeXPath ()
	{
		return relativeXPath;
	}
	
	public void setRelativeXPath (String relativeXPath)
	{
		this.relativeXPath = relativeXPath;
	}
	
	public String getAbsoluteXPath1 ()
	{
		return absoluteXPath1;
	}
	
	public void setAbsoluteXPath1 (String absoluteXPath1)
	{
		this.absoluteXPath1 = absoluteXPath1;
	}
	
	public String getAbsoluteXPath2 ()
	{
		return absoluteXPath2;
	}
	
	public void setAbsoluteXPath2 (String absoluteXPath2)
	{
		this.absoluteXPath2 = absoluteXPath2;
	}
	
	public String getResetBandName ()
	{
		return resetBandName;
	}
	
	public void setResetBandName (String resetBandName)
	{
		this.resetBandName = resetBandName;
	}
	
	public void attachCodeMap (CodeMap codeMap)
	{
		this.codeMap = codeMap;
	}
	
	public CodeMap getCodeMap ()
	{
		return codeMap;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString ()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Field Properties: [bandType=");
		builder.append(bandType);
		builder.append(", bandName=");
		builder.append(bandName);
		builder.append(", fieldName=");
		builder.append(fieldName);
		builder.append(", dataType=");
		builder.append(dataType);
		builder.append(", fieldType=");
		builder.append(fieldType);
		builder.append(", fieldLength=");
		builder.append(fieldLength);
		builder.append(", iFieldLength=");
		builder.append(iFieldLength);
		builder.append(", startPosition=");
		builder.append(startPosition);
		builder.append(", endPosition=");
		builder.append(endPosition);
		// builder.append(", previousField=");
		// builder.append(previousField);
		builder.append(", mappingType=");
		builder.append(mappingType);
		builder.append(", mandatory=");
		builder.append(mandatory);
		builder.append(", format=");
		builder.append(format);
		builder.append(", precision=");
		builder.append(precision);
		builder.append(", sequenceNmbr=");
		builder.append(sequenceNmbr);
		builder.append(", defaultValue=");
		builder.append(defaultValue);
		builder.append(", alignment=");
		builder.append(alignment);
		builder.append(", filler=");
		builder.append(filler);
		builder.append(", bandRef=");
		builder.append(bandRef);
		builder.append(", fieldRef=");
		builder.append(fieldRef);
		builder.append(", bandRefPath=");
		builder.append(bandRefPath);
		builder.append(", codeMapRef=");
		builder.append(codeMapRef);
		builder.append(", constantValue=");
		builder.append(constantValue);
		builder.append(", derivationLogic1=");
		builder.append(derivationLogic1);
		builder.append(", derivationLogic2=");
		builder.append(derivationLogic2);
		builder.append(", resetBandName=");
		builder.append(resetBandName);
		builder.append(", batchRunningNoName=");
		builder.append(batchRunningNoName);
		builder.append(", orderSequenceNmbr=");
		builder.append(orderSequenceNmbr);
		builder.append(", orderBy=");
		builder.append(orderBy);
		builder.append(", batchTotalType=");
		builder.append(batchTotalType);
		builder.append(", absoluteXPath1=");
		builder.append(absoluteXPath1);
		builder.append(", absoluteXPath2=");
		builder.append(absoluteXPath2);
		builder.append(", relativeXPath=");
		builder.append(relativeXPath);
		builder.append(", downloadIncrementally=");
		builder.append(downloadIncrementally);
		builder.append("]");
		return builder.toString();
	}
	
	/**
	 * @return the executionOrder
	 */
	public int getExecutionOrder ()
	{
		return executionOrder;
	}
	
	/**
	 * @param executionOrder
	 *            the executionOrder to set
	 */
	public void setExecutionOrder (int executionOrder)
	{
		this.executionOrder = executionOrder;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks ()
	{
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks (String remarks)
	{
		this.remarks = remarks;
	}


	/**
	 * @return the restrictToSize
	 */
	public boolean isRestrictToSize ()
	{
		return restrictToSize;
	}

	/**
	 * @param restrictToSize the restrictToSize to set
	 */
	public void setRestrictToSize (boolean restrictToSize)
	{
		this.restrictToSize = restrictToSize;
	}
	
}
