/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : IrisAdminConstants.java
 * CREATED: Mar 1, 2013 5:01:02 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: IrisAdminConstants.java,v 1.48 2017/01/05 11:56:55 ramap Exp $
 * @since 1.0.0
 */
public final class IrisAdminConstants
{
	
	private IrisAdminConstants()
	{
	}
	
	// public static final String INTERFACE_NAME = "MODEL_NAME";
	// public static final String PROCESS_NAME = "INTERFACE_NAME";
	public static final String ROUTINE_CLASSES = "ROUTINE_CLASSES";
	public static final String CHANNEL_DIR = "DIR";
	public static final String MEDIA_FILE = "File";
	public static final String MEDIA_FTP = "FTP";
	public static final String MEDIA_ISO = "ISO8583";
	public static final String MEDIA_HTTP_CW = "HTTP_CW_RQ";
	public static final String MEDIA_EVENT_RQ = "EVENT_RQ";
	public static final String MEDIA_HTTP_REQUEST = "HTTP_RQ";
	public static final String MEDIA_HTTP_RESPONSE = "HTTP_RS";
	public static final String MODEL_SUB_TYPE_REQUEST = "REQUEST";
//	public static final String MQ_MESSAGE_ID = "MQ_MESSAGE_ID";
	public static final String ISO_SESSION_NAME = "P_ISO_SESSION_NAME";
	public static final String DB_SESSION_NAME = "P_DB_SESSION_NAME";
//	public static final String DIR_SESSION_FILE = "DIR_SESSION_FILE";
	public static final String FTP_RESOURCE_NAME = "P_FTP_RESOURCE_NAME";
	public static final String REMOVE_EMPTY_ELEMENTS = "P_REMOVE_EMPTY_ELEMENTS";
	public static final String ADD_NAME_SPACE = "P_ADD_NAME_SPACE";
	public static final String EVENT_EXECUTION_JOB = "EVENT_EXECUTION_JOB";
	
	public static final String CHANNEL_JMS = "Message";
	public static final String MEDIA_MQ = "Message";
	public static final String CHANNEL_WEBSERVICE = "WebService";
	public static final String MEDIA_WEBSERVICE = "WebService";
	public static final String MEDIA_REST_WEBSERVICE = "REST_REQ";
	public static final String JMS_SESSION_NAME = "P_JMS_SESSION_NAME";
	public static final String WEBSERVICE_SESSION_NAME = "P_WEBSERVICE_SESSION_NAME";
	public static final String HTTP_SESSION_NAME = "P_HTTP_SESSION_NAME";
	public static final String JMS_QUEUE_NAME = "P_JMS_QUEUE_NAME";
	public final static String JMS_RESPONSE_QUEUE_NAME = "P_JMS_RESP_QUEUE_NAME";
	public final static String JMS_DEST_RESOLVER = "JMS_DEST_RESOLVER";
	public static final String JMS_MESSAGE = "JMS_MESSAGE";
	public static final String WEBSERVICE_URI = "P_WEBSERVICE_URI";
	public static final String HTTP_REQUEST_URI = "P_HTTP_REQUEST_URI";
	public static final String WEBSERVICE_SOAP_ACTION = "P_SOAP_ACTION";
	public static final String WEBSERVICE_MESSAGE = "WEBSERVICE_MESSAGE";
	public static final String HTTP_RESPONSE_MESSAGE = "HTTP_RESPONSE_MESSAGE";
	public static final String WEBSERVICE_ACTION_BEAN = "P_REQ_SOAP_HEADER";
	public static final String WEBSERVICE_EXTRACTOR_BEAN = "P_RES_SOAP_HEADER";
	public static final String HTTP_REQUEST_CALLBACK= "P_REQ_CALLBACK";
	public static final String HTTP_RESPONSE_CALLBACK = "P_RES_CALLBACK";
	public static final String PASSWORD_GEN_NAME = "P_PASS_GEN_NAME";
	public static final String JMS_HEADER_DATA = "JMS_HEADER_DATA";
	public static final String FILTER_PARMS = "FILTER_PARMS";
	public static final String LINE_OFFSET_LINE = "L";
	public static final String LINE_OFFSET_POSITION = "P";
	
	public static final String MEDIA_DETAIL = "MEDIA_DETAIL";
	public static final String MEDIA = "MEDIA_TYPE";
	public final static String PARENT_EXECUTION_ID = "PARENT_EXECUTION_ID";
	public final static String PROCESS_IDENTIFIER = "PROCESS_IDENTIFIER";
	public final static String REQUEST_JOB_DATA = "REQUEST_JOB_DATA";
	public static final String MAP_NAME = "MAP_NAME";
	public static final String CHANNEL = "CHANNEL";
	public static final String DATA_ROOT_BAND = "DATA_ROOT_BAND";
	public static final String AUDIT_SOURCE = "AUDIT_SOURCE";
	public static final String DB_CONNECTION = "DB_CONNECTION";
	public static final String DATAOBJECT_HELPER = "DATAOBJECT_HELPER";
	public static final String RESP_MAP_NAME = "P_RESP_INTERFACE_NAME";
	
	/**
	 * Mapping Type will have values as 0 : Direct 1 : Referenced 2 : Function 3 : Code Map 4 : Complex 5 : Constant 6 : Running no 7 : Batch Total 8
	 * : Internal default is Direct. 11 for XML Name SPACE
	 */
	public static final int MAPPING_TYPE_DIRECT = 0;// Direct
	public static final int MAPPING_TYPE_REFERENCED = 1;
	public static final int MAPPING_TYPE_FUNCTION = 2;
	public static final int MAPPING_TYPE_CODEMAP = 3;
	public static final int MAPPING_TYPE_COMPLEX = 4;
	public static final int MAPPING_TYPE_CONSTANT = 5;
	public static final int MAPPING_TYPE_RUNNING_NO = 6;
	public static final int MAPPING_TYPE_BATCH_TOTAL = 7;
	public static final int MAPPING_TYPE_INTERNAL = 8;// Internal
	public static final int MAPPING_TYPE_FILTER = 9;
	public static final int MAPPING_TYPE_ROUTINE = 10;
	public static final int MAPPING_TYPE_NAMESPACE = 11;
	public static final int MAPPING_TYPE_DYNAMIC = 12;
	public static final int MAPPING_TYPE_REFCODEMAP = 13;
	public static final int MAPPING_TYPE_IGNORE = 14;
	public static final int MAPPING_TYPE_ISNULLCODEMAP = 15;
	
	
	public static final int FIELD_TYPE_INT = 0;
	public static final int FIELD_TYPE_INT_MANDATORY = 1;
	public static final int FIELD_TYPE_CUST = 2;
	public static final int FIELD_TYPE_CUST_MANDATORY = 3;
	
	public static final String PRE_PROCESSING_ROUTINE = "PRE_PROCESSING_ROUTINE";
	public static final String POST_PROCESSING_ROUTINE = "POST_PROCESSING_ROUTINE";
	public static final String POST_UPDATION_ROUTINE = "POST_UPDATION_ROUTINE";
	public static final String REVERSE_UPDATE_ROUTINE = "REVERSE_UPDATE_ROUTINE";
	public static final String FILENAME_GEN_ROUTINE = "FILENAME_GEN_ROUTINE";
	public static final String EMPTY_FILENAME_GEN_ROUTINE = "EMPTY_FILENAME_GEN_ROUTINE";
	
	public static final String INTERFACE_PARM_TYPE = "I";
	public static final String FILTER_PARM_TYPE = "F";
	public static final String FILTER_INTERNAL_CHATSET = "P_CHAR_SET";
	public static final String FILTER_EMPTY_FILE = "P_EMPTY_FILE";
//	public static final String FILTER_EMPTY_FILE_FLAG = "Y";
	public static final String SYS_GEN_EMPTY_FILE = "com.fundtech.iris.admin.hooks.SysGenEmptyFileNameHook";
	public static final String SYS_GEN_DATA_FILE = "com.fundtech.iris.admin.hooks.SysGenFileNameHook";
	public static final String CUST_GEN_EMPTY_FILE = "CUST_GEN_EMPTY_FILE";
	public static final String CUST_GEN_DATA_FILE = "CUST_GEN_DATA_FILE";
	public static final String FILTER_INTERNAL_LINESEPARATOR = "P_LINE_SEPARATOR";
	
	public static final String DATA_TYPE_STRING = "STRING";
	public static final String DATA_TYPE_DATE = "DATE";
	public static final String DATA_TYPE_DATETIME = "DATETIME";
	public static final String DATA_TYPE_NUMBER = "NUMBER";
	public static final String DATA_TYPE_DECIMAL = "DECIMAL";
	public static final String DATA_TYPE_BOOLEAN = "BOOLEAN";
	
	public static final String DEFINITION_TYPE_UPLOAD = "U";
	public static final String DEFINITION_TYPE_RE_UPLOAD = "RE_UPLOAD";
	public static final String DEFINITION_TYPE_DOWNLOAD = "D";
	public static final String PRE_GEN_FLAG = "PRE_GEN_FLAG";
	public static final String MAIL_FLAG = "MAIL_FLAG";
	public static final String DEFINITION_TYPE_REPORT = "R";
	public static final String CONSTANT_Y = "Y";
	public static final String CONSTANT_N = "N";
	public static final String CONSTANT_NO = "NO";
	public static final String CONSTANT_YES = "YES";
	public static final String CONSTANT_TRUE = "TRUE";
	
	public static final String SCH_SEGMENTED = "SCH_SEGMENTED";
	public static final String SCH_PROFILE = "SCH_PROFILE";
	public static final String IRIS = "IRIS";
	public static final String SCH_PROFILE_IRIS = "IRIS_PROFILE";
	public static final String IRIS_EXECUTE = "EXECUTE";
	public static final String IRIS_ADMIN = "IRISADMIN";
	
	public static final String CODE_MAP_DEFAULT = "DEFAULT";
	public static final String CODE_MAP_ASIS = "AS-IS";
	public static final String CODE_MAP_REST = "REST";
	public static final String CODE_MAP_UNDEFINED = "UNDEFINED";
	
	// public static final String INTERFACE_DEFINITION = "INTERFACE_DEFINITION";
	// public static final String PROCESS_DEFINITION = "PROCESS_DEFINITION";
	public static final String EXECUTION_DATA = "EXECUTION_DATA";
	public static final String PROCESS_DATA = "PROCESS_DATA";
	public static final String INTERFACE_DATA = "INTERFACE_DATA";
	public static final String ZEROPROOFING_DATA = "ZEROPROOFING_DATA";
	public static final String ISO_MESSAGE = "ISO_MESSAGE";
	public static final String ENTITY_TYPE = "ENTITY_TYPE";
	public static final String ENTITY_CODE = "ENTITY_CODE";
	public static final String EXECUTE_PROCESS = "EXECUTE_PROCESS";
	
	public static final String CRYPTOGRAPHY_TYPE_SY = "S";
	public static final String CRYPTOGRAPHY_TYPE_ASY = "A";
	
	public static final String FORMAT_TYPE_XML = "XML";
	
	public static final String SIGNING_TYPE_SY = "S";
	public static final String SIGNING_TYPE_ASY = "A";
	
	public static final boolean FILENAMEGEN_FLAG_YES = true;
	public static final boolean EMPTYFILENAMEGEN_FLAG_YES = true;
	
	public static final String JOB_STATUS_OUTRIGHT_REJECT = "R";
	public static final String JOB_STATUS_REJECT_COMPLETE = "E";
	public static final String JOB_STATUS_SUCESS = "S";
	public static final String JOB_STATUS_SUCESS_COMPLETE = "C";
	public static final String JOB_STATUS_LOADING_ISSUE = "L";
	
	public static final String SPLIT_BASIS_FIELDS = "F";
	
	public static final String FILE_SOURCE_DIRECTORY = "P_SOURCE_DIRECTORY";
	public static final String FILE_DESTINATION_DIRECTORY = "P_DESTINATION_DIRECTORY";
	public static final String FILE_ERROR_DIRECTORY = "P_ERROR_DIRECTORY";
	public static final String FILE_TEMP_DIRECTORY = "P_TEMP_DIRECTORY";
	public static final String FILE_NAME = "P_FILE_NAME";
	public static final String DELETE_TYPE = "P_DELETE_TYPE";
	public static final String FTP_PATH = "FTP_PATH";
	public static final String FUNCTION_SPLIT_CHARS = "$;";
	public static final int XML_MULTI_LEVEL = 1;
	public static final int XML_SINGLE_LEVEL = 2;
	public static final String XML_XSD_VALIDATION = "P_XSD_VALIDATION";
	
	public static final String XML_SAX_VALIDATION = "http://xml.org/sax/features/validation";
	public static final String XML_SAX_SCHEMA = "http://apache.org/xml/features/validation/schema";
	public static final String XML_SAX_FULL_CHECK = "http://apache.org/xml/features/validation/schema-full-checking";
	public static final String XML_SAX_NAME_SPACE = "http://xml.org/sax/features/namespaces";
	public static final String XML_SAX_NAME_SPACE_LOCATION = "http://apache.org/xml/properties/schema/external-schemaLocation";
	public static final String XML_SAX_NAME_SPACE_PREFIXES = "http://xml.org/sax/features/namespace-prefixes";
	public static final String XML_DOM_IGNORE_WHITESPACE = "http://apache.org/xml/features/dom/include-ignorable-whitespace";
	public static final String XML_SAX_CONTINUE_FATAL = "http://apache.org/xml/features/continue-after-fatal-error";
	public static final String XML_SAX_JAVA_ENCODING = "http://apache.org/xml/features/allow-java-encodings";
	public static final String XML_SAX_WARN_UNDECLARED_ELEMET = "http://apache.org/xml/features/validation/warn-on-undeclared-elemdef";
	
	// ERRORS & TYPES
	
	public static final String ERR_TYPE_ERROR = "ERROR";
	public static final String ERR_TYPE_INTER = "INTER";
	
	// validation errors
	public static final String ERR_CODE_CODEMAP = "IRIS-3001";
	public static final String ERR_CODE_REFVAL = "IRIS-3002";
	public static final String ERR_CODE_FORMAT = "IRIS-3003";
	public static final String ERR_CODE_FUNCT = "IRIS-3004";
	public static final String ERR_CODE_MANDATORY = "IRIS-3005";
	public static final String ERR_CODE_CREATE_BAND = "IRIS-3006";
	public static final String ERR_CODE_VALIDATE = "IRIS-3007";
	public static final String ERR_CODE_NOT_FOUND = "IRIS-3008";
	public static final String ERR_CODE_NOT_SUPPORTED = "IRIS-3009";
	public static final String ERR_CODE_FILE_MOVE = "IRIS-3010";
	public static final String ERR_CODE_NOTIFY = "IRIS-3011";
	public static final String ERR_CODE_STATUS = "IRIS-3012";
	public static final String ERR_CODE_EXE_FAILED = "IRIS-3013";
	
	public static final String ERR_CODE_SIGNING_FAILED = "IRIS-4001";
	
	public static final String ERR_CODE_DB_NULL = "IRIS-2001";
	
	/*--------------------------------------------------------------------------------------------------------------------------------
	 * REPORT MANAGER	
	 *------------------------------------------------------------------------------------------------------------------------------*/
	
	public static final String SECURITY_RECORD_KEY = "SECURITY_RECORD_KEY";
	public static final String JOB_OUTPUT_TYPE = "DEL_OUTPUT_TYPE";
	public static final String SYS_NEXT_GEN_DATE = "NEXT_GEN_DATE";
	public static final String SYS_PREV_GEN_DATE = "PREV_GEN_DATE";
	public static final String SYS_PREV_APP_DATE = "PRV_APPL_DATE";
	public static final String SYS_APP_DATE = "APPL_DATE";
	public static final String SYS_FUT_GEN_DATE = "FUT_GEN_DATE";
	public static final String MEDIA_DATABASE = "Database";
	
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------------------------------------------
	 *  CPON CONSTANTS
	 *------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
	public static final String CPON_PAYMENT_DTL_TBL = "CPON_PRF_FEATURE_PAY_DTL";
	public static final String CPON_COLLECTION_DTL_TBL = "CPON_PRF_FEATURE_PAY_DTL";
	public static final String CPON_ADM_DTL_TBL = "CPON_PRF_ADM_FEATURE_DTL";
	public static final String CPON_BR_DTL_TBL = "CPON_PRF_BR_FEATURE_DTL";
	public static final String CPON_TRADE_DTL_TBL = "CPON_PRF_TRADE_FEATURE_DTL";
	public static final String CPON_LOAN_DTL_TBL = "CPON_PRF_LOAN_FEATURE_DTL";
	//public static final String CPON_INVESTMENT_DTL_TBL = "CPON_PRF_INVEST_FEATURE_DTL";
	public static final String CPON_FORECAST_DTL_TBL = "CPON_PRF_FORECAST_FEATURE_DTL";
	public static final String CPON_POSITIVEPAY_DTL_TBL = "CPON_PRF_PP_FEATURE_DTL";
	public static final String CPON_CHECKS_DTL_TBL = "CPON_PRF_CHK_DTL";
	public static final String CPON_DEPOSIT_VIEW_DTL_TBL = "CPON_PRF_DEPOSIT_FEATURE_DTL";
	public static final String CPON_PORTAL_DTL_TBL = "CPON_PRF_PORTAL_FEATURE_DTL";
	public static final String CPON_LIQUIDITY_DTL_TBL = "CPON_PRF_LMS_FEATURE_DTL";
	public static final String CPON_FSC_DTL_TBL = "CPON_PRF_CF_FEATURE_DTL";
	public static final String CPON_RECORD_KEY_NO  = "CD";
	public static final String CPON_PKG_KEY_NO = "PI";
	public static final String CPON_ACCOUNT_ID = "ACC";
	public static final String MODE_VIEW = "VIEW";
	public static final String MODE_MODIFIEDVIEW = "MODIFIEDVIEW";
	public static final String MODULE_ADMIN ="03";
	public static final String MODULE_BR ="01";
	public static final String MODULE_PAYMENT ="02";
	public static final String MODULE_LIQUIDITY ="04";
	public static final String MODULE_FSC ="06";
	public static final String MODULE_COLLECTION ="05";
	public static final String CANNED_ALERT_PROFILE_TYPE = "CANNED";
	public static final String CUSTOM_ALERT_PROFILE_TYPE = "CUSTOM";
	public static final String CPON_MESSAGE_FEATURE_TYPE = "M";
	public static final String MODULE_INVESTMENTS ="08";
	public static final String MODULE_CHECKS ="14";
	public static final String MODULE_LOAN ="07";
	public static final String MODULE_TRADE = "09";
	public static final String MODULE_FORECAST ="10";
	public static final String MODULE_DEPOSIT_VIEW ="16";
	public static final String MODULE_BANK_REPORTS="15";
	public static final String MODULE_INCOMING_ACH="11";
	public static final String MODULE_POSITIVE_PAY="13";
	public static final String MODULE_COMMON="00";
	public static final String MODULE_LIMITS = "18";
	public static final String MODULE_PORTAL = "19";
	public static final String MODULE_MOBILE = "20";
	
	
	//parameter's Operators
	
	/*
	 * COMMON
	 */
	public static final String EQUAL = "${EQ}";
	public static final String NOT_EQUAL = "${NE}";
	public static final String IN = "${IN}";
	
	
	/*
	 * TEXT
	 */
	public static final String START_WITH = "${STARTWITH}";
	public static final String END_WITH = "${ENDWITH}";
	public static final String CONTAINS_WITH = "${CONTAINS}";
	
	/*
	 * DATE
	 */
	public static final String BETWEEN = "${BT}";
	public static final String AS_OF_DATE = "${AS_OF_DATE}";
	public static final String LESSTHAN_EQUAL = "${LQ}";
	public static final String LESSTHAN = "${LT}";
	public static final String GRATERTHAN_EQUAL = "${GQ}";
	public static final String GRATERTHAN = "${GT}";
	public static final String TODAY = "${TODAY}";
	public static final String YESTERDAY = "${YESTERDAY}";
	public static final String THIS_WEEK = "${THIS_WEEK}";
	public static final String LAST_WEEK = "${LAST_WEEK}";
	public static final String LAST_WEEK_TODAY = "${LAST_WEEK_TODAY}";
	public static final String LAST_MONTH = "${LAST_MONTH}";
	public static final String THIS_MONTH = "${THIS_MONTH}";
	public static final String LAST_MONTH_TODAY = "${LAST_MONTH_TODAY}";
	public static final String THIS_QUARTER = "${THIS_QUARTER}";
	public static final String LAST_QUATER = "${LAST_QUATER}";
	public static final String LAST_QUATER_TODAY = "${LAST_QUATER_TODAY}";
	public static final String THIS_YEAR = "${THIS_YEAR}";
	public static final String LAST_YEAR = "${LAST_YEAR}";
	public static final String LAST_YEAR_TODAY = "${LAST_YEAR_TODAY}";
	
	
	public static final String VERSION_4_3 = "4.3";
}
