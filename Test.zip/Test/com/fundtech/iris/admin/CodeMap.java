/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin
 * FILE   : CodeMap.java
 * CREATED: Mar 8, 2013 12:12:34 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin;

import java.util.HashMap;
import java.util.Map;

/**
 * TODO Please insert Type's purpose and description.
 * 
 * @author Babu Paluri
 * @version $Id: CodeMap.java,v 1.5 2014/08/05 13:40:07 ramap Exp $
 * @since 1.0.0
 */
public class CodeMap
{
	/**
	 * Stores the map code.
	 */
	private Map<String, String> codeMap = new HashMap<String, String>();
	
	private String codeMapId = null;
	
	private String defaultVal = null;
	private String restVal = null;
	
	public String getCodeMap (String oldValue)
	{
		return codeMap.get(oldValue);
	}
	
	public void setCodeMap (String oldValue, String newValue)
	{
		codeMap.put(oldValue, newValue);
	}
	
	public int size ()
	{
		return codeMap.size();
	}
	
	public boolean contains (String key)
	{
		return codeMap.containsKey(key);
	}
	
	/**
	 * @return the codeMapId
	 */
	public String getCodeMapId ()
	{
		return codeMapId;
	}
	
	/**
	 * @param codeMapId
	 *            the codeMapId to set
	 */
	public void setCodeMapId (String codeMapId)
	{
		this.codeMapId = codeMapId;
	}

	/**
	 * @return the defaultVal
	 */
	public String getDefaultVal ()
	{
		return defaultVal;
	}

	/**
	 * @param defaultVal the defaultVal to set
	 */
	public void setDefaultVal (String defaultVal)
	{
		this.defaultVal = defaultVal;
	}

	/**
	 * @return the restVal
	 */
	public String getRestVal ()
	{
		return restVal;
	}

	/**
	 * @param restVal the restVal to set
	 */
	public void setRestVal (String restVal)
	{
		this.restVal = restVal;
	}
}
