/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event
 * FILE   : EventExecutionJob.java
 * CREATED: Oct 13, 2014 3:37:37 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event;

import java.util.HashMap;
import java.util.Map;

import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EventExecutionJob.java,v 1.6 2016/10/27 09:01:16 ramap Exp $
 */
public class EventExecutionJob implements EventJob
{
	private int txnCode = 0;
	private String notificationId = null;
	private String journalNmbr = null;
	private String eventName = null;
	private String eventSource = null;
	private String recipientName = null;
	private String entityCode = null;
	private String clientCode = null;
	private String emailSubject = null;
	private String emailMessage = null;
	private String fromMailId = null;
	private String toEmailId = null;
	private String ccMailId = null;
	private String bccMailId = null;
	private String status = null;
	private String dbUser = null;
	private String dbPass = null;
	private String dbUrl = null;
	private String repDdUrl = null;
	private String dbHost = null;
	private String dbPort = null;
	private String dbSid = null;
	private String outFileName = null;
	private String reportType = null;
	private String paramString = null;
	private String reportCode = null; 
	private String reportLanguage = null;
	
	//for SMS
	private String smsMessage = null;
	private String senderNumber = null;
	private String recipientNumber = null;
	
	//FOR Interface
	private String entityType = null;
	private String mapCode = null;
	private boolean isPDFPasswordRequired = false;
	private boolean isZipRequired = false;
	private String password = null;
	private Map<String, String> filterParameters = new HashMap<String, String>();
	private ExecutionJobData intJobData = null;
	
	/**
	 * @return the notificationId
	 */
	public String getNotificationId ()
	{
		return notificationId;
	}
	/**
	 * @param notificationId the notificationId to set
	 */
	public void setNotificationId (String notificationId)
	{
		this.notificationId = notificationId;
	}
	/**
	 * @return the journalNmbr
	 */
	public String getJournalNmbr ()
	{
		return journalNmbr;
	}
	/**
	 * @param journalNmbr the journalNmbr to set
	 */
	public void setJournalNmbr (String journalNmbr)
	{
		this.journalNmbr = journalNmbr;
	}
	/**
	 * @return the eventName
	 */
	public String getEventName ()
	{
		return eventName;
	}
	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName (String eventName)
	{
		this.eventName = eventName;
	}
	/**
	 * @return the eventSource
	 */
	public String getEventSource ()
	{
		return eventSource;
	}
	/**
	 * @param eventSource the eventSource to set
	 */
	public void setEventSource (String eventSource)
	{
		this.eventSource = eventSource;
	}
	/**
	 * @return the recipientName
	 */
	public String getRecipientName ()
	{
		return recipientName;
	}
	/**
	 * @param recipientName the recipientName to set
	 */
	public void setRecipientName (String recipientName)
	{
		this.recipientName = recipientName;
	}
	/**
	 * @return the entityCode
	 */
	public String getEntityCode ()
	{
		return entityCode;
	}
	/**
	 * @param entityCode the entityCode to set
	 */
	public void setEntityCode (String entityCode)
	{
		this.entityCode = entityCode;
	}
	/**
	 * @return the clientCode
	 */
	public String getClientCode ()
	{
		return clientCode;
	}
	/**
	 * @param clientCode the clientCode to set
	 */
	public void setClientCode (String clientCode)
	{
		this.clientCode = clientCode;
	}
	/**
	 * @return the emailSubject
	 */
	public String getEmailSubject ()
	{
		return emailSubject;
	}
	/**
	 * @param emailSubject the emailSubject to set
	 */
	public void setEmailSubject (String emailSubject)
	{
		this.emailSubject = emailSubject;
	}
	/**
	 * @return the emailMessage
	 */
	public String getEmailMessage ()
	{
		return emailMessage;
	}
	/**
	 * @param emailMessage the emailMessage to set
	 */
	public void setEmailMessage (String emailMessage)
	{
		this.emailMessage = emailMessage;
	}
	/**
	 * @return the fromMailId
	 */
	public String getFromMailId ()
	{
		return fromMailId;
	}
	/**
	 * @param fromMailId the fromMailId to set
	 */
	public void setFromMailId (String fromMailId)
	{
		this.fromMailId = fromMailId;
	}
	/**
	 * @return the toEmailId
	 */
	public String getToEmailId ()
	{
		return toEmailId;
	}
	/**
	 * @param toEmailId the toEmailId to set
	 */
	public void setToEmailId (String toEmailId)
	{
		this.toEmailId = toEmailId;
	}
	/**
	 * @return the ccMailId
	 */
	public String getCcMailId ()
	{
		return ccMailId;
	}
	/**
	 * @param ccMailId the ccMailId to set
	 */
	public void setCcMailId (String ccMailId)
	{
		this.ccMailId = ccMailId;
	}
	/**
	 * @return the bccMailId
	 */
	public String getBccMailId ()
	{
		return bccMailId;
	}
	/**
	 * @param bccMailId the bccMailId to set
	 */
	public void setBccMailId (String bccMailId)
	{
		this.bccMailId = bccMailId;
	}
	/**
	 * @return the status
	 */
	public String getStatus ()
	{
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus (String status)
	{
		this.status = status;
	}
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.event.EventJob#cleanup()
	 */
	@Override
	public void cleanup ()
	{
		notificationId = null;
		journalNmbr = null;
		eventName = null;
		eventSource = null;
		recipientName = null;
		entityCode = null;
		clientCode = null;
		emailSubject = null;
		emailMessage = null;
		fromMailId = null;
		toEmailId = null;
		ccMailId = null;
		bccMailId = null;
		status = null;
		
	}
	/**
	 * @return the outFileName
	 */
	public String getOutFileName ()
	{
		return outFileName;
	}
	/**
	 * @param outFileName the outFileName to set
	 */
	public void setOutFileName (String outFileName)
	{
		this.outFileName = outFileName;
	}
	/**
	 * @return the dbUser
	 */
	public String getDbUser ()
	{
		return dbUser;
	}
	/**
	 * @param dbUser the dbUser to set
	 */
	public void setDbUser (String dbUser)
	{
		this.dbUser = dbUser;
	}
	/**
	 * @return the dbPass
	 */
	public String getDbPass ()
	{
		return dbPass;
	}
	/**
	 * @param dbPass the dbPass to set
	 */
	public void setDbPass (String dbPass)
	{
		this.dbPass = dbPass;
	}
	/**
	 * @return the dbUrl
	 */
	public String getDbUrl ()
	{
		return dbUrl;
	}
	/**
	 * @param dbUrl the dbUrl to set
	 */
	public void setDbUrl (String dbUrl)
	{
		this.dbUrl = dbUrl;
	}
	/**
	 * @return the repDdUrl
	 */
	public String getRepDdUrl ()
	{
		return repDdUrl;
	}
	/**
	 * @param repDdUrl the repDdUrl to set
	 */
	public void setRepDdUrl (String repDdUrl)
	{
		this.repDdUrl = repDdUrl;
	}
	/**
	 * @return the dbHost
	 */
	public String getDbHost ()
	{
		return dbHost;
	}
	/**
	 * @param dbHost the dbHost to set
	 */
	public void setDbHost (String dbHost)
	{
		this.dbHost = dbHost;
	}
	/**
	 * @return the dbPort
	 */
	public String getDbPort ()
	{
		return dbPort;
	}
	/**
	 * @param dbPort the dbPort to set
	 */
	public void setDbPort (String dbPort)
	{
		this.dbPort = dbPort;
	}
	/**
	 * @return the dbSid
	 */
	public String getDbSid ()
	{
		return dbSid;
	}
	/**
	 * @param dbSid the dbSid to set
	 */
	public void setDbSid (String dbSid)
	{
		this.dbSid = dbSid;
	}
	/**
	 * @return the reportType
	 */
	public String getReportType ()
	{
		return reportType;
	}
	/**
	 * @param reportType the reportType to set
	 */
	public void setReportType (String reportType)
	{
		this.reportType = reportType;
	}
	/**
	 * @return the paramString
	 */
	public String getParamString ()
	{
		return paramString;
	}
	/**
	 * @param paramString the paramString to set
	 */
	public void setParamString (String paramString)
	{
		this.paramString = paramString;
	}
	/**
	 * @return the reportCode
	 */
	public String getReportCode ()
	{
		return reportCode;
	}
	/**
	 * @param reportCode the reportCode to set
	 */
	public void setReportCode (String reportCode)
	{
		this.reportCode = reportCode;
	}
	/**
	 * @return the reportLanguage
	 */
	public String getReportLanguage ()
	{
		return reportLanguage;
	}
	/**
	 * @param reportLanguage the reportLanguage to set
	 */
	public void setReportLanguage (String reportLanguage)
	{
		this.reportLanguage = reportLanguage;
	}
	/**
	 * @return the smsMessage
	 */
	public String getSmsMessage ()
	{
		return smsMessage;
	}
	/**
	 * @param smsMessage the smsMessage to set
	 */
	public void setSmsMessage (String smsMessage)
	{
		this.smsMessage = smsMessage;
	}
	/**
	 * @return the senderNumber
	 */
	public String getSenderNumber ()
	{
		return senderNumber;
	}
	/**
	 * @param senderNumber the senderNumber to set
	 */
	public void setSenderNumber (String senderNumber)
	{
		this.senderNumber = senderNumber;
	}
	/**
	 * @return the recipientNumbber
	 */
	public String getRecipientNumber ()
	{
		return recipientNumber;
	}
	/**
	 * @param recipientNumbber the recipientNumbber to set
	 */
	public void setRecipientNumber (String recipientNumber)
	{
		this.recipientNumber = recipientNumber;
	}
	
	/**
	 * @param paramName
	 * @param paramValue
	 */
	public void addFilterParemeter (String paramName, String paramValue)
	{
		filterParameters.put(paramName, paramValue);
	}
	
	public void setFilterParameters (Map<String, String> filterParameters)
	{
		this.filterParameters = filterParameters;
	}
	
	public Map<String, String> getFilterParameters ()
	{
		return filterParameters;
	}
	
	public String getFilterParameter (String paramName)
	{
		return filterParameters.get(paramName);
	}
	/**
	 * @return the entityType
	 */
	public String getEntityType ()
	{
		return entityType;
	}
	/**
	 * @param entityType the entityType to set
	 */
	public void setEntityType (String entityType)
	{
		this.entityType = entityType;
	}
	/**
	 * @return the mapCode
	 */
	public String getMapCode ()
	{
		return mapCode;
	}
	/**
	 * @param mapCode the mapCode to set
	 */
	public void setMapCode (String mapCode)
	{
		this.mapCode = mapCode;
	}
	/**
	 * @return the intJobData
	 */
	public ExecutionJobData getIntJobData ()
	{
		return intJobData;
	}
	/**
	 * @param intJobData the intJobData to set
	 */
	public void setIntJobData (ExecutionJobData intJobData)
	{
		this.intJobData = intJobData;
	}
	
	/**
	 * @return the isZipRequired
	 */
	public boolean isZipRequired ()
	{
		return isZipRequired;
	}
	/**
	 * @param isZipRequired the isZipRequired to set
	 */
	public void setZipRequired (boolean isZipRequired)
	{
		this.isZipRequired = isZipRequired;
	}
	/**
	 * @return the password
	 */
	public String getPassword ()
	{
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword (String password)
	{
		this.password = password;
	}
	/**
	 * @return the isPDFPasswordRequired
	 */
	public boolean isPDFPasswordRequired ()
	{
		return isPDFPasswordRequired;
	}
	/**
	 * @param isPDFPasswordRequired the isPDFPasswordRequired to set
	 */
	public void setPDFPasswordRequired (boolean isPDFPasswordRequired)
	{
		this.isPDFPasswordRequired = isPDFPasswordRequired;
	}
	/**
	 * @return the txnCode
	 */
	public int getTxnCode ()
	{
		return txnCode;
	}
	/**
	 * @param txnCode the txnCode to set
	 */
	public void setTxnCode (int txnCode)
	{
		this.txnCode = txnCode;
	}
	
}
