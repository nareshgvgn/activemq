/*
 * (C) CashTech Solutions India Private Limited Use strictly pursuant to license conditions only
 */
package com.fundtech.iris.admin.event.data;

public class DataAttribute
{
	private String dataKeyColumnName = null;
	private String dataKeyDisplayName = null;
	private String dataType = null;
	private String format = null;
	private String mask = null;
	private boolean forMail = false;
	private boolean forSms = false;
	private boolean forOnScreen = false;
	private String repParameterName = null;
	private String mappingId = null;
	private String defineRule = null;
	private String displayType = null;
	private String derivationClass = null;
	private String intParameterName = null;
	
	/**
	 * @return the dataKeyColumnName
	 */
	public String getDataKeyColumnName ()
	{
		return dataKeyColumnName;
	}
	
	/**
	 * @param dataKeyColumnName
	 *            the dataKeyColumnName to set
	 */
	public void setDataKeyColumnName (String dataKeyColumnName)
	{
		this.dataKeyColumnName = dataKeyColumnName;
	}
	
	/**
	 * @return the dataKeyDisplayName
	 */
	public String getDataKeyDisplayName ()
	{
		return dataKeyDisplayName;
	}
	
	/**
	 * @param dataKeyDisplayName
	 *            the dataKeyDisplayName to set
	 */
	public void setDataKeyDisplayName (String dataKeyDisplayName)
	{
		this.dataKeyDisplayName = dataKeyDisplayName;
	}
	
	/**
	 * @return the dataType
	 */
	public String getDataType ()
	{
		return dataType;
	}
	
	/**
	 * @param dataType
	 *            the dataType to set
	 */
	public void setDataType (String dataType)
	{
		this.dataType = dataType;
	}
	
	/**
	 * @return the format
	 */
	public String getFormat ()
	{
		return format;
	}
	
	/**
	 * @param format
	 *            the format to set
	 */
	public void setFormat (String format)
	{
		this.format = format;
	}
	
	/**
	 * @return the mask
	 */
	public String getMask ()
	{
		return mask;
	}
	
	/**
	 * @param mask
	 *            the mask to set
	 */
	public void setMask (String mask)
	{
		this.mask = mask;
	}
	
	/**
	 * @return the forMail
	 */
	public boolean isForMail ()
	{
		return forMail;
	}
	
	/**
	 * @param forMail
	 *            the forMail to set
	 */
	public void setForMail (boolean forMail)
	{
		this.forMail = forMail;
	}
	
	/**
	 * @return the forSms
	 */
	public boolean isForSms ()
	{
		return forSms;
	}
	
	/**
	 * @param forSms
	 *            the forSms to set
	 */
	public void setForSms (boolean forSms)
	{
		this.forSms = forSms;
	}
	
	/**
	 * @return the forOnScreen
	 */
	public boolean isForOnScreen ()
	{
		return forOnScreen;
	}
	
	/**
	 * @param forOnScreen
	 *            the forOnScreen to set
	 */
	public void setForOnScreen (boolean forOnScreen)
	{
		this.forOnScreen = forOnScreen;
	}
	
	/**
	 * @return the repParameterName
	 */
	public String getRepParameterName ()
	{
		return repParameterName;
	}
	
	/**
	 * @param repParameterName
	 *            the repParameterName to set
	 */
	public void setRepParameterName (String repParameterName)
	{
		this.repParameterName = repParameterName;
	}
	
	/**
	 * @return the mappingId
	 */
	public String getMappingId ()
	{
		return mappingId;
	}
	
	/**
	 * @param mappingId
	 *            the mappingId to set
	 */
	public void setMappingId (String mappingId)
	{
		this.mappingId = mappingId;
	}
	
	/**
	 * @return the defineRule
	 */
	public String getDefineRule ()
	{
		return defineRule;
	}
	
	/**
	 * @param defineRule
	 *            the defineRule to set
	 */
	public void setDefineRule (String defineRule)
	{
		this.defineRule = defineRule;
	}
	
	/**
	 * @return the displayType
	 */
	public String getDisplayType ()
	{
		return displayType;
	}
	
	/**
	 * @param displayType
	 *            the displayType to set
	 */
	public void setDisplayType (String displayType)
	{
		this.displayType = displayType;
	}
	
	/**
	 * @return the derivationClass
	 */
	public String getDerivationClass ()
	{
		return derivationClass;
	}
	
	/**
	 * @param derivationClass
	 *            the derivationClass to set
	 */
	public void setDerivationClass (String derivationClass)
	{
		this.derivationClass = derivationClass;
	}

	/**
	 * @return the intParameterName
	 */
	public String getIntParameterName ()
	{
		return intParameterName;
	}

	/**
	 * @param intParameterName the intParameterName to set
	 */
	public void setIntParameterName (String intParameterName)
	{
		this.intParameterName = intParameterName;
	}
	
}
