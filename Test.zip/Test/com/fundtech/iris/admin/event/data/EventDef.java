/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.event.data
 * FILE   : EventDef.java
 * CREATED: Mar 20, 2014 10:47:03 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: EventDef.java,v 1.2 2014/07/20 04:58:27 ramap Exp $
 */
public class EventDef
{
	private String eventSource = null;
	private String eventName = null;
	private String sellerCode = null;
	private boolean applicable = false;
	private String screenName = null;
	private boolean emailNotify = false;
	private boolean smsNotify = false;
	private boolean onScreenNotify = false;
	private boolean faxNotify = false;
	private boolean attachmentNotify = false;
	private boolean interfaceNotify = false;
	private String module = null;
	private String group = null;
	private String type = null;
	
	private EventDataMapping eventDataMapping = null;
	private Map<String, EventRecipientDef> eventRecipientDefs = new HashMap<String, EventRecipientDef>();
	
	/**
	 * @return the eventSource
	 */
	public String getEventSource ()
	{
		return eventSource;
	}
	
	/**
	 * @param eventSource
	 *            the eventSource to set
	 */
	public void setEventSource (String eventSource)
	{
		this.eventSource = eventSource;
	}
	
	/**
	 * @return the eventName
	 */
	public String getEventName ()
	{
		return eventName;
	}
	
	/**
	 * @param eventName
	 *            the eventName to set
	 */
	public void setEventName (String eventName)
	{
		this.eventName = eventName;
	}
	
	/**
	 * @return the sellerCode
	 */
	public String getSellerCode ()
	{
		return sellerCode;
	}
	
	/**
	 * @param sellerCode
	 *            the sellerCode to set
	 */
	public void setSellerCode (String sellerCode)
	{
		this.sellerCode = sellerCode;
	}
	
	/**
	 * @return the applicable
	 */
	public boolean isApplicable ()
	{
		return applicable;
	}
	
	/**
	 * @param applicable
	 *            the applicable to set
	 */
	public void setApplicable (boolean applicable)
	{
		this.applicable = applicable;
	}
	
	/**
	 * @return the screenName
	 */
	public String getScreenName ()
	{
		return screenName;
	}
	
	/**
	 * @param screenName
	 *            the screenName to set
	 */
	public void setScreenName (String screenCode)
	{
		this.screenName = screenCode;
	}
	
	/**
	 * @return the emailNotify
	 */
	public boolean isEmailNotify ()
	{
		return emailNotify;
	}
	
	/**
	 * @param emailNotify
	 *            the emailNotify to set
	 */
	public void setEmailNotify (boolean emailNotify)
	{
		this.emailNotify = emailNotify;
	}
	
	/**
	 * @return the smsNotify
	 */
	public boolean isSmsNotify ()
	{
		return smsNotify;
	}
	
	/**
	 * @param smsNotify
	 *            the smsNotify to set
	 */
	public void setSmsNotify (boolean smsNotify)
	{
		this.smsNotify = smsNotify;
	}
	
	/**
	 * @return the onScreenNotify
	 */
	public boolean isOnScreenNotify ()
	{
		return onScreenNotify;
	}
	
	/**
	 * @param onScreenNotify
	 *            the onScreenNotify to set
	 */
	public void setOnScreenNotify (boolean onScreenNotify)
	{
		this.onScreenNotify = onScreenNotify;
	}
	
	/**
	 * @return the faxNotify
	 */
	public boolean isFaxNotify ()
	{
		return faxNotify;
	}
	
	/**
	 * @param faxNotify
	 *            the faxNotify to set
	 */
	public void setFaxNotify (boolean faxNotify)
	{
		this.faxNotify = faxNotify;
	}
	
	/**
	 * @return the attachmentNotify
	 */
	public boolean isAttachmentNotify ()
	{
		return attachmentNotify;
	}
	
	/**
	 * @param attachmentNotify
	 *            the attachmentNotify to set
	 */
	public void setAttachmentNotify (boolean attachmentNotify)
	{
		this.attachmentNotify = attachmentNotify;
	}
	
	/**
	 * @return the eventDataMapping
	 */
	public EventDataMapping getEventDataMapping ()
	{
		return eventDataMapping;
	}
	
	/**
	 * @param eventDataMapping
	 *            the eventDataMapping to set
	 */
	public void setEventDataMapping (EventDataMapping eventDataMapping)
	{
		this.eventDataMapping = eventDataMapping;
	}
	
	public void addEventRecipientDef (EventRecipientDef eventRecipientDef)
	{
		
		eventRecipientDefs.put(eventRecipientDef.getCode(), eventRecipientDef);
	}
	
	public EventRecipientDef geteventRecipientDef (String key)
	{
		return eventRecipientDefs.get(key);
	}
	
	public Map<String, EventRecipientDef> geteventRecipientDefs ()
	{
		return eventRecipientDefs;
	}
	
	/**
	 * @return the interfaceNotify
	 */
	public boolean isInterfaceNotify ()
	{
		return interfaceNotify;
	}
	
	/**
	 * @param interfaceNotify
	 *            the interfaceNotify to set
	 */
	public void setInterfaceNotify (boolean interfaceNotify)
	{
		this.interfaceNotify = interfaceNotify;
	}
	
	/**
	 * @return the module
	 */
	public String getModule ()
	{
		return module;
	}
	
	/**
	 * @param module
	 *            the module to set
	 */
	public void setModule (String module)
	{
		this.module = module;
	}
	
	/**
	 * @return the group
	 */
	public String getGroup ()
	{
		return group;
	}
	
	/**
	 * @param group
	 *            the group to set
	 */
	public void setGroup (String group)
	{
		this.group = group;
	}
	
	/**
	 * @return the type
	 */
	public String getType ()
	{
		return type;
	}
	
	/**
	 * @param type
	 *            the type to set
	 */
	public void setType (String type)
	{
		this.type = type;
	}
	
}
