/*------------------------------------------------------------------------------
 * PACKAGE: com.cashtech.iris.event.data
 * FILE   : InRule.java
 * CREATED: Apr 3, 2012 4:30:03 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data.rules;

import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.DataFormatValue;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * This class applies In rule from given multiple date with , separator
 * 
 * @author Babu Paluri
 * @version $Id: InRule.java,v 1.4 2014/10/14 11:44:09 ramap Exp $
 * @since 1.0.0
 */
public class InRule extends AbstractRule
{
	
	private static Logger logger = LoggerFactory.getLogger(InRule.class);
	
	/**
	 * Constructor
	 * 
	 * @param subscriptionCode
	 * @param dataKeyDisplayName
	 * @param dataKeyColumnName
	 * @param dataOperator
	 * @param dataValue
	 * @param datatype
	 */
	public InRule(String subscriptionCode, String dataKeyDisplayName, String dataKeyColumnName, String dataOperator, String dataValue,
			String datatype, String format)
	{
		super(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.event.data.Rule#matches(com.cashtech.iris.event.data.Event)
	 */
	public boolean matches (EventProcessJob jobData) throws ExecutionException
	{
		
		DataFormatValue dataFormatValue = null;
		String value = null;
		StringTokenizer tokens = null;
		ExecutionException nodeExp = null;
		
		try
		{
			dataFormatValue = jobData.getDataFormatValue(dataKeyDisplayName);
			if (dataFormatValue.getValue() == null)
			{
				logger.error("No value recieved  for : " + dataKeyDisplayName);
				return false;
			}
			
			if (this.datatype.equals("String"))
			{
				tokens = new StringTokenizer(dataValue, ",");
				while (tokens.hasMoreTokens())
				{
					value = (String) dataFormatValue.getValue();
					if (value.equals(tokens.nextToken()))
						return true;
				}
			}
		}
		catch (Exception e)
		{
			nodeExp = new ExecutionException("err.app.UnableToData", new Object[]
			{ subscriptionCode, dataKeyDisplayName, dataKeyColumnName }, e);
			logger.error(IRISLogger.getText(nodeExp));
			throw nodeExp;
			
		}
		return false;
	}
}
