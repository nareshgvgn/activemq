/*
 * (C) CashTech Solutions India Private Limited Use strictly pursuant to license conditions only
 */

package com.fundtech.iris.admin.event.data.rules;

/**
 * @author mousamik
 * @version $Id: AbstractRule.java,v 1.0 Dec 20, 2007 8:19:12 PM mousamik
 */
public abstract class AbstractRule implements Rule
{
	/**
	 * SubscriptionCode for this rule
	 */
	protected String subscriptionCode = null;
	/**
	 * 
	 */
	protected String dataKeyDisplayName = null;
	
	/**
	 * ColumnName for which this rule is set
	 */
	protected String dataKeyColumnName = null;
	
	/**
	 * Operator
	 */
	protected String dataOperator = null;
	
	/**
	 * Value to the checked
	 */
	protected String dataValue = null;
	
	/**
	 * Datatype of the column on which rule is set
	 */
	protected String datatype = null;
	
	/**
	 * Format of the column on which rule is set
	 */
	protected String format = null;
	
	/**
	 * Constructor
	 * 
	 * @param subscriptionCode
	 * @param dataKeyDisplayName
	 * @param dataKeyColumnName
	 * @param dataOperator
	 * @param dataValue
	 * @param datatype
	 * @param format
	 */
	public AbstractRule(String subscriptionCode, String dataKeyDisplayName, String dataKeyColumnName, String dataOperator, String dataValue,
			String datatype, String format)
	{
		this.subscriptionCode = subscriptionCode;
		this.dataKeyDisplayName = dataKeyDisplayName;
		this.dataKeyColumnName = dataKeyColumnName;
		this.dataOperator = dataOperator;
		this.dataValue = dataValue;
		this.datatype = datatype;
		this.format = format;
	}
}
