/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.data
 * FILE   : DefaultRecipient.java
 * CREATED: Jul 9, 2014 10:55:42 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: DefaultRecipient.java,v 1.2 2014/07/20 04:58:27 ramap Exp $
 */
public class DefaultRecipient implements IRecipient
{
	private List<Subscription> subscriptions = new ArrayList<Subscription>();
	private String corporation = null;
	private String client = null;
	private String description = null;
	private String mailId = null;
	private String fax = null;
	private String mobile = null;
	private String recipient = null;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#getSubscriptions()
	 */
	@Override
	public List<Subscription> getSubscriptions ()
	{
		return subscriptions;
	}
	
	/**
	 * @param subscriptions
	 *            the subscriptions to set
	 */
	public void setSubscriptions (List<Subscription> subscriptions)
	{
		this.subscriptions = subscriptions;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#getCorporation()
	 */
	@Override
	public String getCorporation ()
	{
		return corporation;
	}
	
	/**
	 * @param corporation
	 *            the corporation to set
	 */
	public void setCorporation (String corporation)
	{
		this.corporation = corporation;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#getClient()
	 */
	@Override
	public String getClient ()
	{
		return client;
	}
	
	/**
	 * @param client
	 *            the client to set
	 */
	public void setClient (String client)
	{
		this.client = client;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#getDescription()
	 */
	@Override
	public String getDescription ()
	{
		return description;
	}
	
	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription (String description)
	{
		this.description = description;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#getMailId()
	 */
	@Override
	public String getMailId ()
	{
		return mailId;
	}
	
	/**
	 * @param mailId
	 *            the mailId to set
	 */
	public void setMailId (String mailId)
	{
		this.mailId = mailId;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#getFax()
	 */
	@Override
	public String getFax ()
	{
		return fax;
	}
	
	/**
	 * @param fax
	 *            the fax to set
	 */
	public void setFax (String fax)
	{
		this.fax = fax;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#getMobile()
	 */
	@Override
	public String getMobile ()
	{
		return mobile;
	}
	
	/**
	 * @param mobile
	 *            the mobile to set
	 */
	public void setMobile (String mobile)
	{
		this.mobile = mobile;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#isEmptySubscriptions()
	 */
	@Override
	public boolean isEmptySubscriptions ()
	{
		return subscriptions.isEmpty();
	}
	
	/**
	 * @param e
	 * @return
	 * @see java.util.List#add(java.lang.Object)
	 */
	public boolean addSubscription (Subscription subscription)
	{
		return subscriptions.add(subscription);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#clearSubscriptions()
	 */
	@Override
	public void clearSubscriptions ()
	{
		subscriptions.clear();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.data.Test#getUserCode()
	 */
	@Override
	public String getRecipient ()
	{
		return recipient;
	}
	
	/**
	 * @param userCode
	 *            the userCode to set
	 */
	public void setRecipient (String recipient)
	{
		this.recipient = recipient;
	}
	
}
