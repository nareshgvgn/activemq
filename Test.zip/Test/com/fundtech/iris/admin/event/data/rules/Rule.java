/*
 * (C) CashTech Solutions India Private Limited Use strictly pursuant to license conditions only
 */
package com.fundtech.iris.admin.event.data.rules;

import com.cashtech.iris.exceptions.NodeProcessingException;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * @author mousamik
 * @version $Id: Rule.java,v 1.0 Dec 25, 2007 11:48:22 AM mousamik
 */
public interface Rule
{
	/**
	 * This method matches the string according to rule defined
	 * 
	 * @param event
	 * @return boolean
	 * @throws NodeProcessingException
	 */
	public boolean matches (EventProcessJob jobData) throws ExecutionException;
}
