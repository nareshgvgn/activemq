/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.data
 * FILE   : ProductAttributeProvider.java
 * CREATED: Jul 20, 2014 6:12:14 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

import java.sql.Connection;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: ProductAttributeProvider.java,v 1.1 2014/07/20 14:09:25 ramap Exp $
 */
public class ProductAttributeProvider implements IAttributeDataProvider
{
	
	private final String productSQL = "s";
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.event.data.IAttributeDataProvider#execute(org.springframework.jdbc.core.JdbcTemplate, java.util.Map)
	 */
	@Override
	public Object execute (JdbcTemplate jdbcTemplate, Map<String, Object> params) throws Exception
	{
		// BABU Auto-generated method stub
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.event.data.IAttributeDataProvider#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws Exception
	{
		
		return null;
	}
	
}
