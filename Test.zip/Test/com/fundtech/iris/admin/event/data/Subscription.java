/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.data
 * FILE   : Subscription.java
 * CREATED: Jul 8, 2014 6:15:28 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.data.rules.Rule;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: Subscription.java,v 1.5 2016/10/19 14:04:55 ramap Exp $
 */
public class Subscription
{
	private String name = null;
	private String type = null;
	private String category = null;
	private String language = null;
	private String parentName = null;
	private Date startDate = null;
	private Date endDate = null;
	private boolean emailNotify = false;
	private String emailTemplateCode = null;
	private String emailMessage = null;
	private String emailSubject = null;
	private boolean smsNotify = false;
	private String smsTemplateCode = null;
	private String smsMessage = null;
	private String smsSubject = null;
	private boolean screenNotify = false;
	private String screenTemplateCode = null;
	private String screenMessage = null;
	private String screenSubject = null;
	private boolean faxNotify = false;
	private String faxTemplateCode = null;
	private String faxMessage = null;
	private String faxSubject = null;
	private String faxReportName = null;
	private boolean attachmentNotify = false;
	private String attachmentTemplateCode = null;
	private String attachmentMessage = null;
	private String attachmentReportName = null;
	private String attachmentSubject = null;
	private String interfaceTemplateCode = null;
	private String interfaceMessage = null;
	private String interfaceSubject = null;
	private boolean interfaceNotify = false;
	private String interfaceRefName = null;
	private String isZipRequired = IrisAdminConstants.CONSTANT_N;
	private String isPDFPassword = IrisAdminConstants.CONSTANT_N;
	private String password = null;
	private List<Rule> rules = null;
	
	/**
	 * @return the name
	 */
	public String getName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName (String name)
	{
		this.name = name;
	}
	
	/**
	 * @return the type
	 */
	public String getType ()
	{
		return type;
	}
	
	/**
	 * @param type
	 *            the type to set
	 */
	public void setType (String type)
	{
		this.type = type;
	}
	
	/**
	 * @return the category
	 */
	public String getCategory ()
	{
		return category;
	}
	
	/**
	 * @param category
	 *            the category to set
	 */
	public void setCategory (String category)
	{
		this.category = category;
	}
	
	/**
	 * @return the language
	 */
	public String getLanguage ()
	{
		return language;
	}
	
	/**
	 * @param language
	 *            the language to set
	 */
	public void setLanguage (String language)
	{
		this.language = language;
	}
	
	/**
	 * @return the parentName
	 */
	public String getParentName ()
	{
		return parentName;
	}
	
	/**
	 * @param parentName
	 *            the parentName to set
	 */
	public void setParentName (String parentName)
	{
		this.parentName = parentName;
	}
	
	/**
	 * @return the startDate
	 */
	public Date getStartDate ()
	{
		return startDate;
	}
	
	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate (Date startDate)
	{
		this.startDate = startDate;
	}
	
	/**
	 * @return the endDate
	 */
	public Date getEndDate ()
	{
		return endDate;
	}
	
	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate (Date endDate)
	{
		this.endDate = endDate;
	}
	
	/**
	 * @return the emailNotify
	 */
	public boolean isEmailNotify ()
	{
		return emailNotify;
	}
	
	/**
	 * @param emailNotify
	 *            the emailNotify to set
	 */
	public void setEmailNotify (boolean emailNotify)
	{
		this.emailNotify = emailNotify;
	}
	
	/**
	 * @return the emailTemplateCode
	 */
	public String getEmailTemplateCode ()
	{
		return emailTemplateCode;
	}
	
	/**
	 * @param emailTemplateCode
	 *            the emailTemplateCode to set
	 */
	public void setEmailTemplateCode (String emailTemplateCode)
	{
		this.emailTemplateCode = emailTemplateCode;
	}
	
	/**
	 * @return the emailMessage
	 */
	public String getEmailMessage ()
	{
		return emailMessage;
	}
	
	/**
	 * @param emailMessage
	 *            the emailMessage to set
	 */
	public void setEmailMessage (String emailMessage)
	{
		this.emailMessage = emailMessage;
	}
	
	/**
	 * @return the smsNotify
	 */
	public boolean isSmsNotify ()
	{
		return smsNotify;
	}
	
	/**
	 * @param smsNotify
	 *            the smsNotify to set
	 */
	public void setSmsNotify (boolean smsNotify)
	{
		this.smsNotify = smsNotify;
	}
	
	/**
	 * @return the smsTemplateCode
	 */
	public String getSmsTemplateCode ()
	{
		return smsTemplateCode;
	}
	
	/**
	 * @param smsTemplateCode
	 *            the smsTemplateCode to set
	 */
	public void setSmsTemplateCode (String smsTemplateCode)
	{
		this.smsTemplateCode = smsTemplateCode;
	}
	
	/**
	 * @return the smsMessage
	 */
	public String getSmsMessage ()
	{
		return smsMessage;
	}
	
	/**
	 * @param smsMessage
	 *            the smsMessage to set
	 */
	public void setSmsMessage (String smsMessage)
	{
		this.smsMessage = smsMessage;
	}
	
	/**
	 * @return the screenNotify
	 */
	public boolean isScreenNotify ()
	{
		return screenNotify;
	}
	
	/**
	 * @param screenNotify
	 *            the screenNotify to set
	 */
	public void setScreenNotify (boolean screenNotify)
	{
		this.screenNotify = screenNotify;
	}
	
	/**
	 * @return the screenTemplateCode
	 */
	public String getScreenTemplateCode ()
	{
		return screenTemplateCode;
	}
	
	/**
	 * @param screenTemplateCode
	 *            the screenTemplateCode to set
	 */
	public void setScreenTemplateCode (String screenTemplateCode)
	{
		this.screenTemplateCode = screenTemplateCode;
	}
	
	/**
	 * @return the screenMessage
	 */
	public String getScreenMessage ()
	{
		return screenMessage;
	}
	
	/**
	 * @param screenMessage
	 *            the screenMessage to set
	 */
	public void setScreenMessage (String screenMessage)
	{
		this.screenMessage = screenMessage;
	}
	
	/**
	 * @return the faxNotify
	 */
	public boolean isFaxNotify ()
	{
		return faxNotify;
	}
	
	/**
	 * @param faxNotify
	 *            the faxNotify to set
	 */
	public void setFaxNotify (boolean faxNotify)
	{
		this.faxNotify = faxNotify;
	}
	
	/**
	 * @return the faxTemplateCode
	 */
	public String getFaxTemplateCode ()
	{
		return faxTemplateCode;
	}
	
	/**
	 * @param faxTemplateCode
	 *            the faxTemplateCode to set
	 */
	public void setFaxTemplateCode (String faxTemplateCode)
	{
		this.faxTemplateCode = faxTemplateCode;
	}
	
	/**
	 * @return the faxMessage
	 */
	public String getFaxMessage ()
	{
		return faxMessage;
	}
	
	/**
	 * @param faxMessage
	 *            the faxMessage to set
	 */
	public void setFaxMessage (String faxMessage)
	{
		this.faxMessage = faxMessage;
	}
	
	/**
	 * @return the faxReportName
	 */
	public String getFaxReportName ()
	{
		return faxReportName;
	}
	
	/**
	 * @param faxReportName
	 *            the faxReportName to set
	 */
	public void setFaxReportName (String faxReportName)
	{
		this.faxReportName = faxReportName;
	}
	
	/**
	 * @return the attachmentNotify
	 */
	public boolean isAttachmentNotify ()
	{
		return attachmentNotify;
	}
	
	/**
	 * @param attachmentNotify
	 *            the attachmentNotify to set
	 */
	public void setAttachmentNotify (boolean attachmentNotify)
	{
		this.attachmentNotify = attachmentNotify;
	}
	
	/**
	 * @return the attachmentTemplateCode
	 */
	public String getAttachmentTemplateCode ()
	{
		return attachmentTemplateCode;
	}
	
	/**
	 * @param attachmentTemplateCode
	 *            the attachmentTemplateCode to set
	 */
	public void setAttachmentTemplateCode (String attachmentTemplateCode)
	{
		this.attachmentTemplateCode = attachmentTemplateCode;
	}
	
	/**
	 * @return the attachmentMessage
	 */
	public String getAttachmentMessage ()
	{
		return attachmentMessage;
	}
	
	/**
	 * @param attachmentMessage
	 *            the attachmentMessage to set
	 */
	public void setAttachmentMessage (String attachmentMessage)
	{
		this.attachmentMessage = attachmentMessage;
	}
	
	/**
	 * @return the attachmentReportName
	 */
	public String getAttachmentReportName ()
	{
		return attachmentReportName;
	}
	
	/**
	 * @param attachmentReportName
	 *            the attachmentReportName to set
	 */
	public void setAttachmentReportName (String attachmentReportName)
	{
		this.attachmentReportName = attachmentReportName;
	}
	
	/**
	 * @return the interfaceNotify
	 */
	public boolean isInterfaceNotify ()
	{
		return interfaceNotify;
	}
	
	/**
	 * @param interfaceNotify
	 *            the interfaceNotify to set
	 */
	public void setInterfaceNotify (boolean interfaceNotify)
	{
		this.interfaceNotify = interfaceNotify;
	}
	
	/**
	 * @return the interfaceRefName
	 */
	public String getInterfaceRefName ()
	{
		return interfaceRefName;
	}
	
	/**
	 * @param interfaceRefName
	 *            the interfaceRefName to set
	 */
	public void setInterfaceRefName (String interfaceRefName)
	{
		this.interfaceRefName = interfaceRefName;
	}
	
	/**
	 * @return the emailSubject
	 */
	public String getEmailSubject ()
	{
		return emailSubject;
	}
	
	/**
	 * @param emailSubject
	 *            the emailSubject to set
	 */
	public void setEmailSubject (String emailSubject)
	{
		this.emailSubject = emailSubject;
	}
	
	/**
	 * @return the rules
	 */
	public List<Rule> getRules ()
	{
		return rules;
	}
	
	/**
	 * @param rules
	 *            the rules to set
	 */
	public void setRules (List<Rule> rules)
	{
		if (rules != null)
			this.rules = rules;
		else
			this.rules = new ArrayList<Rule>();
	}
	
	public void clearRules ()
	{
		CleanUpUtils.doClean(rules);
	}
	
	/**
	 * @return the smsSubject
	 */
	public String getSmsSubject ()
	{
		return smsSubject;
	}
	
	/**
	 * @param smsSubject
	 *            the smsSubject to set
	 */
	public void setSmsSubject (String smsSubject)
	{
		this.smsSubject = smsSubject;
	}
	
	/**
	 * @return the screenSubject
	 */
	public String getScreenSubject ()
	{
		return screenSubject;
	}
	
	/**
	 * @param screenSubject
	 *            the screenSubject to set
	 */
	public void setScreenSubject (String screenSubject)
	{
		this.screenSubject = screenSubject;
	}
	
	/**
	 * @return the faxSubject
	 */
	public String getFaxSubject ()
	{
		return faxSubject;
	}
	
	/**
	 * @param faxSubject
	 *            the faxSubject to set
	 */
	public void setFaxSubject (String faxSubject)
	{
		this.faxSubject = faxSubject;
	}
	
	/**
	 * @return the attachmentSubject
	 */
	public String getAttachmentSubject ()
	{
		return attachmentSubject;
	}
	
	/**
	 * @param attachmentSubject
	 *            the attachmentSubject to set
	 */
	public void setAttachmentSubject (String attachmentSubject)
	{
		this.attachmentSubject = attachmentSubject;
	}

	/**
	 * @return the interfaceTemplateCode
	 */
	public String getInterfaceTemplateCode ()
	{
		return interfaceTemplateCode;
	}

	/**
	 * @param interfaceTemplateCode the interfaceTemplateCode to set
	 */
	public void setInterfaceTemplateCode (String interfaceTemplateCode)
	{
		this.interfaceTemplateCode = interfaceTemplateCode;
	}

	/**
	 * @return the interfaceMessage
	 */
	public String getInterfaceMessage ()
	{
		return interfaceMessage;
	}

	/**
	 * @param interfaceMessage the interfaceMessage to set
	 */
	public void setInterfaceMessage (String interfaceMessage)
	{
		this.interfaceMessage = interfaceMessage;
	}

	/**
	 * @return the interfaceSubject
	 */
	public String getInterfaceSubject ()
	{
		return interfaceSubject;
	}

	/**
	 * @param interfaceSubject the interfaceSubject to set
	 */
	public void setInterfaceSubject (String interfaceSubject)
	{
		this.interfaceSubject = interfaceSubject;
	}

	/**
	 * @return the isZipRequired
	 */
	public String getIsZipRequired ()
	{
		return isZipRequired;
	}

	/**
	 * @param isZipRequired the isZipRequired to set
	 */
	public void setIsZipRequired (String isZipRequired)
	{
		this.isZipRequired = isZipRequired;
	}

	/**
	 * @return the isPDFPassword
	 */
	public String getIsPDFPassword ()
	{
		return isPDFPassword;
	}

	/**
	 * @param isPDFPassword the isPDFPassword to set
	 */
	public void setIsPDFPassword (String isPDFPassword)
	{
		this.isPDFPassword = isPDFPassword;
	}

	/**
	 * @return the password
	 */
	public String getPassword ()
	{
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword (String password)
	{
		this.password = password;
	}
	
}
