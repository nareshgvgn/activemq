/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.data
 * FILE   : MessageTemplate.java
 * CREATED: Jul 11, 2014 5:10:20 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: MessageTemplate.java,v 1.2 2014/07/20 04:58:27 ramap Exp $
 */
public class MessageTemplate
{
	private String message = null;
	private String subject = null;
	
	/**
	 * @return the message
	 */
	public String getMessage ()
	{
		return message;
	}
	
	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage (String message)
	{
		this.message = message;
	}
	
	/**
	 * @return the subject
	 */
	public String getSubject ()
	{
		return subject;
	}
	
	/**
	 * @param subject
	 *            the subject to set
	 */
	public void setSubject (String subject)
	{
		this.subject = subject;
	}
}
