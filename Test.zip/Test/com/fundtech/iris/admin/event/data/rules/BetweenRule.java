/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.data.rules
 * FILE   : BetweenRule.java
 * CREATED: Sep 16, 2014 5:51:59 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data.rules;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.DataFormatValue;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri & BDB team
 * @version $Id: BetweenRule.java,v 1.4 2017/02/27 13:21:08 ramap Exp $
 */
public class BetweenRule extends AbstractRule
{
	
	private static Logger logger = LoggerFactory.getLogger(BetweenRule.class);
	/**
	 * TODO Please insert Type's purpose and description.
	 * @param subscriptionCode
	 * @param dataKeyDisplayName
	 * @param dataKeyColumnName
	 * @param dataOperator
	 * @param dataValue
	 * @param datatype
	 * @param format
	 */
	public BetweenRule(String subscriptionCode, String dataKeyDisplayName, String dataKeyColumnName, String dataOperator, String dataValue,
			String datatype, String format)
	{
		super(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.event.data.rules.Rule#matches(com.fundtech.iris.admin.event.EventProcessJob)
	 */
	@Override
	public boolean matches (EventProcessJob jobData) throws ExecutionException
	{
		
		DataFormatValue dataFormatValue = null;
		SimpleDateFormat dateFormat = null;
		Date startDate = null;
		Date endDate = null;
		Date valueDate = null;
		String[] tokens = null;
		BigDecimal bdValue = null;
		Float fValue = null;
		Long lValue = null;
		Double dValue = null;
		
		ExecutionException nodeExp = null;
		
		try
		{
			dateFormat = new SimpleDateFormat(this.format);
			dataFormatValue = jobData.getDataFormatValue(dataKeyDisplayName);
			if (dataFormatValue.getValue() == null)
			{
				logger.error("No value recieved  for : " + dataKeyDisplayName);
				return false;
			}
			
			 if (this.datatype.equals("Date"))
			{
				 tokens = dataValue.split("[,]");
				 if ( tokens.length < 2)
					 return false;
				
				startDate = dateFormat.parse(tokens[0]);
				endDate = dateFormat.parse(tokens[1]);
				valueDate = dateFormat.parse(dateFormat.format(dataFormatValue.getValue()));
				return valueDate.after(startDate) && valueDate.before(endDate);
			}
			else if (this.datatype.equals("Float"))
			{
				fValue = (Float) dataFormatValue.getValue();
				tokens = dataValue.split("[,]");
			     if ( tokens.length < 2)
				    return false;
				if ((Float.compare(fValue, Float.parseFloat(tokens[0])) >= 0) && (Float.compare(fValue, Float.parseFloat(tokens[1])) <= 0)) 
					return true;
			}
			else if (this.datatype.equals("Long"))
			{
				lValue = (Long) dataFormatValue.getValue();
				tokens = dataValue.split("[,]");
			     if ( tokens.length < 2)
				    return false; 
			     if ((lValue.compareTo(Long.parseLong(tokens[0])) >= 0) && (lValue.compareTo(Long.parseLong(tokens[1])) <= 0))
					return true;
			}
			else if (this.datatype.equals("Double"))
			{
				dValue = (Double) dataFormatValue.getValue();
				tokens = dataValue.split("[,]");
			     if ( tokens.length < 2)
				    return false; 
			     if ((Double.compare(dValue, Double.parseDouble(tokens[0])) >= 0) && (Double.compare(dValue, Double.parseDouble(tokens[1])) <= 0))
					return true;
			}	 
			else if (this.datatype.equals("BigDecimal"))
			{
			     bdValue = (BigDecimal) dataFormatValue.getValue();
			     tokens = dataValue.split("[,]");
			     if ( tokens.length < 2)
				    return false;
			     if ((bdValue.compareTo(new BigDecimal(tokens[0])) >= 0) && (bdValue.compareTo(new BigDecimal(tokens[1])) <= 0))
			    	 return true;				     
			}
			
		}
		catch (Exception e)
		{
			nodeExp = new ExecutionException("err.app.UnableToData", new Object[]
			{ subscriptionCode, dataKeyDisplayName, dataKeyColumnName }, e);
			logger.error(IRISLogger.getText(nodeExp));
			throw nodeExp;
			
		}
		finally
		{
			startDate = null;
			endDate = null;
			valueDate = null;
			dateFormat = null;
			bdValue = null;
			dValue = null;
			lValue = null;
			fValue = null;
		}
		return false;
	}
	
}
