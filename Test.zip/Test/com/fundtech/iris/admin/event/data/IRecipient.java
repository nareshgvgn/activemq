/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.data
 * FILE   : IRecipient.java
 * CREATED: Jul 10, 2014 6:43:31 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

import java.util.List;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IRecipient.java,v 1.3 2014/07/20 04:58:27 ramap Exp $
 */
public interface IRecipient
{
	
	/**
	 * @return the subscriptions
	 */
	public abstract List<Subscription> getSubscriptions ();
	
	public abstract void setSubscriptions (List<Subscription> subscriptions);
	
	/**
	 * @return the corporation
	 */
	public abstract String getCorporation ();
	
	/**
	 * @return the client
	 */
	public abstract String getClient ();
	
	/**
	 * @return the description
	 */
	public abstract String getDescription ();
	
	/**
	 * @return the mailId
	 */
	public abstract String getMailId ();
	
	/**
	 * @return the fax
	 */
	public abstract String getFax ();
	
	/**
	 * @return the mobile
	 */
	public abstract String getMobile ();
	
	/**
	 * @return
	 * @see java.util.List#isEmpty()
	 */
	public abstract boolean isEmptySubscriptions ();
	
	/**
	 * 
	 * @see java.util.List#clear()
	 */
	public abstract void clearSubscriptions ();
	
	/**
	 * @return the userCode
	 */
	public abstract String getRecipient ();
}
