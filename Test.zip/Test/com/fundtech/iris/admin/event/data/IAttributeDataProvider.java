/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.data
 * FILE   : IAttributeDataProvider.java
 * CREATED: Jul 17, 2014 7:09:50 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

import java.sql.Connection;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * <p>
 * This interface is for to get Attribute values. The value could be Map &ltString,Object&gt, List&ltObject&gt, Boolean, BigDecimal, Boolean. This
 * interface can be implemented in 2 ways. One by passing Spring's JdbcTemplate and params( This method is for Cash web). 2nd one is by passing
 * Database connection and params. Params:- Its a Map<String, Object>. If we require to pass any arguments to method to use in implementation.
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * insert into event_data_mapping_mst (MAPPING_ID, EVENT_SOURCE, EVENT_NAME, DATA_KEY_COLUMN_NAME, DATA_KEY_DISPLAY_NAME, DATA_TYPE, DATA_FORMAT, REPORT_PARAMETER_NAME, DEFINE_RULE, MAIL_FLAG, SMS_FLAG, SCREEN_FLAG, SELLER_CODE, DATA_MASK_FORMAT, DISPLAY_TYPE, DERIVATION_CLASS)
 * values ('0149', 'COLLDISBRMS', 'PAY_GL_REJECT', 'event_data_key8', 'Product Code', 'String', null, null, 'B', 'Y', 'N', 'N', 'OWNER', 'CC,0', 'M', 'com.fundtech.iris.admin.event.data.ProductAttributeProvider');
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">IRIS Admin</td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IAttributeDataProvider.java,v 1.2 2014/07/20 04:58:27 ramap Exp $
 */
public interface IAttributeDataProvider
{
	
	public Object execute (JdbcTemplate jdbcTemplate, Map<String, Object> params) throws Exception;
	
	public Object execute (Connection dbConnection, Map<String, Object> params) throws Exception;
}
