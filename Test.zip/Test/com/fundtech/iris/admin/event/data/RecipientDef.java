/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.event.data
 * FILE   : RecipientDef.java
 * CREATED: Mar 20, 2014 10:27:53 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><name>TODO - XML Configuration file name</name></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: RecipientDef.java,v 1.3 2014/08/01 11:59:03 ramap Exp $
 */
public class RecipientDef
{
	
	private String name = null;
	private String providerClass = null;
	private String sellecrCode = null;
	
	/**
	 * @return the name
	 */
	public String getName ()
	{
		return name;
	}
	
	/**
	 * @param name
	 *            the name to set
	 */
	public void setName (String name)
	{
		this.name = name;
	}
	
	
	/**
	 * @return the providerClass
	 */
	public String getProviderClass ()
	{
		return providerClass;
	}
	
	/**
	 * @param providerClass
	 *            the providerClass to set
	 */
	public void setProviderClass (String providerClass)
	{
		this.providerClass = providerClass;
	}
	
	/**
	 * @return the sellecrCode
	 */
	public String getSellecrCode ()
	{
		return sellecrCode;
	}
	
	/**
	 * @param sellecrCode
	 *            the sellecrCode to set
	 */
	public void setSellecrCode (String sellecrCode)
	{
		this.sellecrCode = sellecrCode;
	}
}
