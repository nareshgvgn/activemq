/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.event.data
 * FILE   : EventRecipientDef.java
 * CREATED: Mar 20, 2014 11:24:14 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.data;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: EventRecipientDef.java,v 1.2 2014/07/20 04:58:27 ramap Exp $
 */
public class EventRecipientDef
{
	
	private RecipientDef recipientDef = null;
	private String code = null;
	private String sellerCode = null;
	private String emailId = null;
	private String mobileNumber = null;
	private String faxNumber = null;
	private String userDescription = null;
	private String userCode = null;
	private String subscriptionCode = null;
	private String userType = null;
	
	/**
	 * @return the code
	 */
	public String getCode ()
	{
		return code;
	}
	
	/**
	 * @param code
	 *            the code to set
	 */
	public void setName (String code)
	{
		this.code = code;
	}
	
	/**
	 * @return the sellerCode
	 */
	public String getSellerCode ()
	{
		return sellerCode;
	}
	
	/**
	 * @param sellerCode
	 *            the sellerCode to set
	 */
	public void setSellerCode (String sellerCode)
	{
		this.sellerCode = sellerCode;
	}
	
	/**
	 * @return the emailId
	 */
	public String getEmailId ()
	{
		return emailId;
	}
	
	/**
	 * @param emailId
	 *            the emailId to set
	 */
	public void setEmailId (String emailId)
	{
		this.emailId = emailId;
	}
	
	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber ()
	{
		return mobileNumber;
	}
	
	/**
	 * @param mobileNumber
	 *            the mobileNumber to set
	 */
	public void setMobileNumber (String mobileNumber)
	{
		this.mobileNumber = mobileNumber;
	}
	
	/**
	 * @return the faxNumber
	 */
	public String getFaxNumber ()
	{
		return faxNumber;
	}
	
	/**
	 * @param faxNumber
	 *            the faxNumber to set
	 */
	public void setFaxNumber (String faxNumber)
	{
		this.faxNumber = faxNumber;
	}
	
	/**
	 * @return the userDescription
	 */
	public String getUserDescription ()
	{
		return userDescription;
	}
	
	/**
	 * @param userDescription
	 *            the userDescription to set
	 */
	public void setUserDescription (String userDescription)
	{
		this.userDescription = userDescription;
	}
	
	/**
	 * @return the userCode
	 */
	public String getUserCode ()
	{
		return userCode;
	}
	
	/**
	 * @param userCode
	 *            the userCode to set
	 */
	public void setUserCode (String userCode)
	{
		this.userCode = userCode;
	}
	
	/**
	 * @return the subscriptionCode
	 */
	public String getSubscriptionCode ()
	{
		return subscriptionCode;
	}
	
	/**
	 * @param subscriptionCode
	 *            the subscriptionCode to set
	 */
	public void setSubscriptionCode (String subscriptionCode)
	{
		this.subscriptionCode = subscriptionCode;
	}
	
	/**
	 * @return the userType
	 */
	public String getUserType ()
	{
		return userType;
	}
	
	/**
	 * @param userType
	 *            the userType to set
	 */
	public void setUserType (String userType)
	{
		this.userType = userType;
	}
	
	/**
	 * @return the recipientDef
	 */
	public RecipientDef getRecipientDef ()
	{
		return recipientDef;
	}
	
	/**
	 * @param recipientDef
	 *            the recipientDef to set
	 */
	public void setRecipientDef (RecipientDef recipientDef)
	{
		this.recipientDef = recipientDef;
	}
	
}
