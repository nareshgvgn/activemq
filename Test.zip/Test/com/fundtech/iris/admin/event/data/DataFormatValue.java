package com.fundtech.iris.admin.event.data;

public class DataFormatValue
{
	private String dataKeyDisplayName = null;
	private String dataKeyColumnName = null;
	private String dataType = null;
	private String format = null;
	private String mask = null;
	private Object value = null;
	
	/**
	 * @param dataKeyDisplayName
	 * @param dataKeyColumnName
	 * @param dataType
	 * @param format
	 * @param value
	 */
	public DataFormatValue(String dataKeyDisplayName, String dataKeyColumnName, String dataType, String format, String mask, Object value)
	{
		this.dataKeyDisplayName = dataKeyDisplayName;
		this.dataKeyColumnName = dataKeyColumnName;
		this.dataType = dataType;
		this.format = format;
		this.value = value;
		this.mask = mask;
	}
	
	public String getDataKeyDisplayName ()
	{
		return dataKeyDisplayName;
	}
	
	public String getDataKeyColumnName ()
	{
		return dataKeyColumnName;
	}
	
	public String getDataType ()
	{
		return dataType;
	}
	
	public String getFormat ()
	{
		return format;
	}
	
	public Object getValue ()
	{
		return value;
	}
	
	/**
	 * @return the mask
	 */
	public String getMask ()
	{
		return mask;
	}
}
