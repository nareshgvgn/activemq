/*
 * (C) CashTech Solutions India Private Limited Use strictly pursuant to license conditions only
 */

package com.fundtech.iris.admin.event.data.rules;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.DataFormatValue;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * This class applies Less than Equal ( <= ) rule
 * 
 * @author swatit
 * @version $Id: LessThanOrEqualsRule.java,v 1.4 2014/10/14 11:44:09 ramap Exp $
 * @since 1.0.0
 */

public class LessThanOrEqualsRule extends AbstractRule
{
	private static Logger logger = LoggerFactory.getLogger(LessThanOrEqualsRule.class);
	
	/**
	 * Constructor
	 * 
	 * @param subscriptionCode
	 * @param dataKeyDisplayName
	 * @param dataKeyColumnName
	 * @param dataOperator
	 * @param dataValue
	 * @param datatype
	 * @param format
	 */
	public LessThanOrEqualsRule(String subscriptionCode, String dataKeyDisplayName, String dataKeyColumnName, String dataOperator, String dataValue,
			String datatype, String format)
	{
		super(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cashtech.iris.event.data.Rule#matches(com.cashtech.iris.core.processor.Packet, com.cashtech.iris.event.data.Event)
	 */
	public boolean matches (EventProcessJob jobData) throws ExecutionException
	{
		DataFormatValue dataFormatValue = null;
		SimpleDateFormat dateFormat = null;
		Date date1 = null;
		Date date2 = null;
		Float fValue = null;
		Long lValue = null;
		BigDecimal bdValue = null;
		Double dValue = null;
		ExecutionException nodeExp = null;
		
		try
		{
			dataFormatValue = jobData.getDataFormatValue(dataKeyDisplayName);
			if (dataFormatValue.getValue() == null)
			{
				logger.error("No value recieved  for : " + dataKeyDisplayName);
				return false;
			}
			if (this.datatype.equals("Date"))
			{
				dateFormat = new SimpleDateFormat(this.format);
				date1 = dateFormat.parse(dateFormat.format(dataFormatValue.getValue()));
				date2 = dateFormat.parse(this.dataValue);
				if (date1.equals(date2) || date1.before(date2))
					return true;
			}
			else if (this.datatype.equals("Float"))
			{
				fValue = (Float) dataFormatValue.getValue();
				
				if (Float.compare(fValue, Float.parseFloat(dataValue)) <= 0)
					return true;
			}
			else if (this.datatype.equals("Long"))
			{
				lValue = (Long) dataFormatValue.getValue();
				
				if (lValue.compareTo(Long.parseLong(dataValue)) <= 0)
					return true;
			}
			else if (this.datatype.equals("Double"))
			{
				dValue = (Double) dataFormatValue.getValue();
				
				if (Double.compare(dValue, Double.parseDouble(dataValue)) <= 0)
					return true;
			}
			else if (this.datatype.equals("BigDecimal"))
			{
				bdValue = (BigDecimal) dataFormatValue.getValue();
				if (bdValue.compareTo(new BigDecimal(dataValue)) <= 0)
					return true;
			}
		}
		catch (Exception e)
		{
			nodeExp = new ExecutionException("err.app.UnableToData", new Object[]
			{ subscriptionCode, dataKeyDisplayName, dataKeyColumnName }, e);
			logger.error(IRISLogger.getText(nodeExp));
			throw nodeExp;
		}
		return false;
	}
	
}
