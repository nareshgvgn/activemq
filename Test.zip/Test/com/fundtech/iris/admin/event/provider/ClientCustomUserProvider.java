/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.provider
 * FILE   : ClientCustomUserProvider.java
 * CREATED: Jul 31, 2014 12:50:30 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.provider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.DefaultRecipient;
import com.fundtech.iris.admin.event.data.EventDataMapping;
import com.fundtech.iris.admin.event.data.IRecipient;
import com.fundtech.iris.admin.event.data.RecipientDef;
import com.fundtech.iris.admin.event.data.Subscription;
import com.fundtech.iris.admin.event.data.rules.Rule;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p> This helper class identifies the recipient who subscribes by using Template subscription. To use this class, the recipient type must be CU.
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 *	<u>Recipient Master:</u> insert into RECIPIENT_MST (RECIPIENT_NAME, RECIPIENT_DESC, PROVIDER_CLASS, SELLER_CODE)
 * values ('CLIENT_CUSTOM_USER', 'Client users who is having custom subscriptions', 'com.fundtech.iris.admin.event.provider.ClientCustomUserProvider', 'OWNER');
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">IRIS Admin Event</td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: ClientCustomUserProvider.java,v 1.11 2016/10/12 06:12:25 ramap Exp $
 */
public class ClientCustomUserProvider extends AbstractRecipientProvider
{
private static Logger logger = LoggerFactory.getLogger(ClientCheckersProvider.class);
	
	private final static String subUsrSelectSQL = "WITH msg_temp AS (SELECT msg_template_name, subject, msg_format FROM event_msg_template_mst)"
			+ " SELECT c.usrcode,c.usrcorporation,c.usrclient,c.usrdescription,c.usremailaddr,c.usrfax,c.usrmobileno, b.*, emt.subject MAIL_SUBJECT, "
			+ " emt.msg_format MESSAGE_EMAIL, smt.subject SMS_SUBJECT, smt.msg_format MESSAGE_SMS, omt.subject SCREEN_SUBJECT, omt.msg_format MESSAGE_SCREEN,"
			+ " atc.subject ATTACHMENT_SUBJECT, atc.msg_format MESSAGE_ATTACHHMENT, fax.subject FAX_SUBJECT, fax.msg_format MESSAGE_FAX"
			+ ", int.subject INT_SUBJECT, int.msg_format MESSAGE_INT "
			+ "  FROM event_subscription_mst b, event_template_dtl a,  usermaster c, msg_temp emt, msg_temp smt, msg_temp omt, msg_temp atc, msg_temp fax"
			+ ", msg_temp int ";
	
	private final static String subUsrSelect2SQL = " , userproducts d";
	
	private final static String subUsrWhereSQL = " WHERE b.msg_template_name_email = emt.msg_template_name(+) AND b.msg_template_name_sms = smt.msg_template_name(+)"
			+ " AND b.msg_template_name_screen = omt.msg_template_name(+) AND b.msg_template_name_attachment = atc.msg_template_name(+) AND b.msg_template_name_fax = fax.msg_template_name(+)"
			+ " AND b.MSG_TEMPLATE_NAME_INTERFACE = int.msg_template_name(+) "
			+ " AND a.valid_flag = 'Y' and a.SUBSCRIPTION_NAME = b.SUBSCRIPTION_NAME and a.event_template_name = c.event_template_code and c.usrcorporation=? and "
			+ " c.usrclient=? and c.usrcode <> ? and b.event_name = ? and b.event_source = ? and b.SUBCRIPTION_TYPE in ('C','S') and "
			+ " b.RECIPIENT_NAME=? and a.BANK_VALID_FLAG='Y' and c.valid_flag='Y'";
	
	private final static String subUsrWhere2SQL = " and c.usrcode = d.uspuser and c.usrcorporation = d.uspcorp and c.usrclient = d.uspclient and d.uspproduct =? and d.valid_flag='Y'";
	
	private final static String rulesSelectSQL = "select distinct d.* from event_template_dtl a, event_subscription_mst b, usermaster c, event_subscription_dtls d";
	private final static String rulesWhereSQL = "  where a.valid_flag = 'Y' and a.SUBSCRIPTION_NAME = b.SUBSCRIPTION_NAME and a.subscription_name = d.subscription_name"
			+ " and a.event_template_name = c.event_template_code and b.SUBCRIPTION_TYPE in ('C','S') and c.usrcorporation= ? and c.usrclient=? and c.usrcode <> ? "
			+ " and b.event_name = ? and b.event_source =? and b.RECIPIENT_NAME=? and a.BANK_VALID_FLAG='Y' and c.valid_flag='Y'";
	
	private String myRecipientName = null;
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.IRecipientProvider#getProbableRecipients(java.sql.Connection,
	 * com.fundtech.iris.admin.event.data.EventJob)
	 */
	@Override
	public List<IRecipient> getProbableRecipients (Connection dbConnection, EventProcessJob jobData, RecipientDef recipientDef) throws ExecutionException
	{
		ExecutionException eExp = null;
		List<IRecipient> custUsers = null;
		Map<String, DefaultRecipient> userList = null;
		
		try
		{
			myRecipientName = recipientDef.getName();
			userList = getUserSubcriptions(dbConnection, jobData);
			custUsers = new ArrayList<IRecipient>(userList.values());
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.event.subcriptionloading", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		return custUsers;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @return
	 * @throws SQLException
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private Map<String, DefaultRecipient> getUserSubcriptions (Connection dbConnection, EventProcessJob jobData) throws SQLException, ExecutionException
	{
		ResultSet usrRs = null;
		PreparedStatement usrStmt = null;
		String client = null;
		String corporation = null;
		String fax = null;
		String description = null;
		String mailId = null;
		String mobile = null;
		String makerCode = null;
		String eventName = null;
		String eventSource = null;
		String corpCode = null;
		String clientCode = null;
		String userCode = null;
		Subscription subscription = null;
		List<Rule> rules = null;
		DefaultRecipient defaultRecipient = null;
		String subscriptionSQL = null;
		String rulesSQL = null;
		Map<String, DefaultRecipient> userList = null;
		Map<String, List<Rule>> subscriptionRules = null;
		ExecutionException eExp = null;
		
		try
		{
			rulesSQL = rulesSelectSQL + rulesWhereSQL;
			subscriptionRules = loadSubscriptionRules(dbConnection, jobData, rulesSQL);
			subscriptionSQL = subUsrSelectSQL + subUsrWhereSQL;
			usrStmt = dbConnection.prepareStatement(subscriptionSQL);
			userList = new HashMap<String, DefaultRecipient>();
			corpCode = jobData.getCorpCode();
			clientCode = jobData.getClientCode();
			makerCode = jobData.getMakerCode();
			eventName = jobData.getEventName();
			eventSource = jobData.getEventSource();
			
			usrStmt.clearParameters();
			usrStmt.setString(1, corpCode);
			usrStmt.setString(2, clientCode);
			usrStmt.setString(3, makerCode);
			usrStmt.setString(4, eventName);
			usrStmt.setString(5, eventSource);
			usrStmt.setString(6, myRecipientName);
			usrRs = usrStmt.executeQuery();
			while (usrRs.next())
			{
				userCode = usrRs.getString("usrcode");
				if (userList.containsKey(userCode))
					defaultRecipient = userList.get(userCode);
				else
				{
					corporation = usrRs.getString("USRCORPORATION");
					client = usrRs.getString("USRCLIENT");
					description = usrRs.getString("USRDESCRIPTION");
					fax = usrRs.getString("USRFAX");
					mailId = usrRs.getString("USREMAILADDR");
					mobile = usrRs.getString("USRMOBILENO");
					defaultRecipient = new DefaultRecipient();
					defaultRecipient.setRecipient(userCode);
					defaultRecipient.setClient(client);
					defaultRecipient.setCorporation(corporation);
					defaultRecipient.setDescription(description);
					defaultRecipient.setFax(fax);
					defaultRecipient.setMailId(mailId);
					defaultRecipient.setMobile(mobile);
					userList.put(userCode, defaultRecipient);
				}
				subscription = getSubscription(usrRs);
				rules = subscriptionRules.get(subscription.getName());
				subscription.setRules(rules);
				defaultRecipient.addSubscription(subscription);
			}
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.event.subcriptionloading", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(usrRs);
			HelperUtils.doClose(usrStmt);
		}
		
		return userList;
	}
	
	/**
	 * <p>
	 * This helper method loads the subscription rules for given events and creates the list of rules and keeps in {@link Map} with the key of
	 * SubScription Name
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @return
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	public Map<String, List<Rule>> loadSubscriptionRules (Connection dbConnection, EventProcessJob jobData, String rulesSQL) throws ExecutionException
	{
		PreparedStatement rulesStmt = null;
		ResultSet rulesRs = null;
		String userCode = null;
		String eventName = null;
		String eventSource = null;
		String subscriptionName = null;
		String corpCode = null;
		String clientCode = null;
		Map<String, List<Rule>> rulesMap = null;
		List<Rule> rulesList = null;
		Rule rule = null;
		EventDataMapping dataMapping = null;
		ExecutionException eExp = null;
		
		try
		{
			corpCode = jobData.getCorpCode();
			clientCode = jobData.getClientCode();
			userCode = jobData.getMakerCode();
			eventName = jobData.getEventName();
			eventSource = jobData.getEventSource();
			rulesMap = new HashMap<String, List<Rule>>();
			rulesStmt = dbConnection.prepareStatement(rulesSQL);
			rulesStmt.clearParameters();
			rulesStmt.setString(1, corpCode);
			rulesStmt.setString(2, clientCode);
			rulesStmt.setString(3, userCode);
			rulesStmt.setString(4, eventName);
			rulesStmt.setString(5, eventSource);
			rulesStmt.setString(6, myRecipientName);
			rulesRs = rulesStmt.executeQuery();
			dataMapping = jobData.getEventDef().getEventDataMapping();
			while (rulesRs.next())
			{
				subscriptionName = rulesRs.getString("SUBSCRIPTION_NAME");
				if (rulesMap.containsKey(subscriptionName))
				{
					rulesList = rulesMap.get(subscriptionName);
					
					rule = getSubScriptionRule(rulesRs, dataMapping);
					rulesList.add(rule);
				}
				else
				{
					rulesList = new ArrayList<Rule>();
					rule = getSubScriptionRule(rulesRs, dataMapping);
					rulesList.add(rule);
					rulesMap.put(subscriptionName, rulesList);
				}
			}
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.app.SubscriptionRules", new Object[] { rulesSQL }, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(rulesRs);
			HelperUtils.doClose(rulesStmt);
		}
		return rulesMap;
	}
	
}
