/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.provider
 * FILE   : BankUserProvider.java
 * CREATED: Jul 17, 2014 6:52:26 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.provider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.DefaultRecipient;
import com.fundtech.iris.admin.event.data.EventDataMapping;
import com.fundtech.iris.admin.event.data.IRecipient;
import com.fundtech.iris.admin.event.data.RecipientDef;
import com.fundtech.iris.admin.event.data.Subscription;
import com.fundtech.iris.admin.event.data.rules.Rule;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p> This helper class identifies the recipient who subscribes by using CLIENT_AUTH_USER subscription. To use this class, the recipient type must be CU.
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 *	<u>Recipient Master:</u> insert into RECIPIENT_MST (RECIPIENT_NAME, RECIPIENT_DESC, PROVIDER_CLASS, SELLER_CODE)
 * values ('CLIENT_AUTH_USER', 'Client Transaction/Master Checker User', 'com.fundtech.iris.admin.event.provider.ClientCheckersProvider', 'OWNER');
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">IRIS Admin Event</td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: BankUserProvider.java,v 1.11 2016/10/12 06:12:25 ramap Exp $
 */
public class BankUserProvider extends AbstractRecipientProvider
{
	

	private static Logger logger = LoggerFactory.getLogger(BankUserProvider.class);
	
	private final static String subscriptionSQL = "WITH msg_temp AS (SELECT msg_template_name, subject, msg_format FROM event_msg_template_mst) SELECT b.*,"
			+ " emt.subject MAIL_SUBJECT, emt.msg_format MESSAGE_EMAIL,smt.subject SMS_SUBJECT, smt.msg_format MESSAGE_SMS, omt.subject SCREEN_SUBJECT,"
			+ " omt.msg_format MESSAGE_SCREEN, atc.subject ATTACHMENT_SUBJECT, atc.msg_format MESSAGE_ATTACHHMENT, fax.subject FAX_SUBJECT, fax.msg_format MESSAGE_FAX"
			+ ", int.subject INT_SUBJECT, int.msg_format MESSAGE_INT "
			+ " FROM event_subscription_mst b, event_template_dtl a,  user_mst c, msg_temp emt, msg_temp smt, msg_temp omt, msg_temp atc, msg_temp fax"
			+ ", msg_temp int "
			+ " WHERE b.msg_template_name_email = emt.msg_template_name(+) AND b.msg_template_name_sms = smt.msg_template_name(+) AND b.msg_template_name_screen = "
			+ " omt.msg_template_name(+) AND b.msg_template_name_attachment = atc.msg_template_name(+)  AND b.msg_template_name_fax = fax.msg_template_name(+) "
			+ " AND b.MSG_TEMPLATE_NAME_INTERFACE = int.msg_template_name(+) "
			+ " AND a.valid_flag = 'Y' and a.SUBSCRIPTION_NAME = b.SUBSCRIPTION_NAME and a.event_template_name = c.ENT_TEMPLATE_CODE"
			+ " and c.user_code = ? and b.event_name = ? and b.event_source = ? and c.seller_code =? and b.SUBCRIPTION_TYPE in('S', 'C') and a.BANK_VALID_FLAG='Y'";
	
	private final static String user_mstSQL = "select CATEGORY_CODE,SYS_BRANCH_CODE,USER_DESCRIPTION,EMAIL_ID,FAX,MOBILE from user_mst where user_code=? and seller_code = ?";
	
	private final static String rulesSQL = "select distinct d.*  from event_template_dtl a, event_subscription_mst b,user_mst c, event_subscription_dtls d  where a.valid_flag ='Y' "
			+ " and a.SUBSCRIPTION_NAME = b.SUBSCRIPTION_NAME and b.SUBCRIPTION_TYPE in('S', 'C') and a.subscription_name = d.subscription_name and "
			+ " a.event_template_name = c.ENT_TEMPLATE_CODE and c.user_code = ? and b.event_name = ? and b.event_source = ? and c.seller_code=? and a.BANK_VALID_FLAG='Y'";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.IRecipientProvider#getProbableRecipients(java.sql.Connection,
	 * com.fundtech.iris.admin.event.data.EventJob)
	 */
	@Override
	public List<IRecipient> getProbableRecipients (Connection dbConnection, EventProcessJob jobData,RecipientDef recipientDef) throws ExecutionException
	{
		PreparedStatement subStmt = null;
		ResultSet subRs = null;
		String userCode = null;
		String eventName = null;
		String eventSource = null;
		Subscription subscription = null;
		DefaultRecipient defaultRecipient = null;
		ExecutionException eExp = null;
		List<IRecipient> custUsers = null;
		Map<String, List<Rule>> subscriptionRules = null;
		List<Rule> rules = null;
		String sellerCode = null;
		
		try
		{
			custUsers = new ArrayList<IRecipient>();
			subscriptionRules = loadSubscriptionRules(dbConnection, jobData, rulesSQL);
			userCode = jobData.getMakerCode();
			eventName = jobData.getEventName();
			eventSource = jobData.getEventSource();
			sellerCode = jobData.getSellerCode();
			defaultRecipient = getUserSubcriptions(dbConnection, userCode, sellerCode);
			subStmt = dbConnection.prepareStatement(subscriptionSQL);
			subStmt.setString(1, userCode);
			subStmt.setString(2, eventName);
			subStmt.setString(3, eventSource);
			subStmt.setString(4, sellerCode);
			subRs = subStmt.executeQuery();
			while (subRs.next())
			{
				subscription = getSubscription(subRs);
				rules = subscriptionRules.get(subscription.getName());
				subscription.setRules(rules);
				defaultRecipient.addSubscription(subscription);
			}
			custUsers.add(defaultRecipient);
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.event.subcriptionloading", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(subRs);
			HelperUtils.doClose(subStmt);
		}
		
		return custUsers;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @return
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @throws SQLException
	 */
	private DefaultRecipient getUserSubcriptions (Connection dbConnection, String userCode, String sellerCode) throws SQLException
	{
		ResultSet usrRs = null;
		String client = null;
		String corporation = null;
		String fax = null;
		String description = null;
		String mailId = null;
		String mobile = null;
		DefaultRecipient defaultRecipient = null;
		PreparedStatement usrStmt = null;
		
		try
		{
			defaultRecipient = new DefaultRecipient();
			usrStmt = dbConnection.prepareStatement(user_mstSQL);
			usrStmt.clearParameters();
			usrStmt.setString(1, userCode);
			usrStmt.setString(2, sellerCode);
			usrRs = usrStmt.executeQuery();
			if ( usrRs.next())
			{
				corporation = usrRs.getString("CATEGORY_CODE");
				client = usrRs.getString("SYS_BRANCH_CODE");
				description = usrRs.getString("USER_DESCRIPTION");
				fax = usrRs.getString("FAX");
				mailId = usrRs.getString("EMAIL_ID");
				mobile = usrRs.getString("MOBILE");
				
				defaultRecipient.setRecipient(userCode);
				defaultRecipient.setClient(client);
				defaultRecipient.setCorporation(corporation);
				defaultRecipient.setDescription(description);
				defaultRecipient.setFax(fax);
				defaultRecipient.setMailId(mailId);
				defaultRecipient.setMobile(mobile);
			}
		}
		finally
		{
			HelperUtils.doClose(usrRs);
			HelperUtils.doClose(usrStmt);
		}
		
		return defaultRecipient;
	}
	
	/**
	 * <p>
	 * This helper method loads the subscription rules for given events and creates the list of rules and keeps in {@link Map} with the key of
	 * SubScription Name
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @return
	 * @throws ExecutionException
	 * </pre>
	 * 
	 * </p>
	 */
	public Map<String, List<Rule>> loadSubscriptionRules (Connection dbConnection, EventProcessJob jobData, String rulesSQL) throws ExecutionException
	{
		PreparedStatement rulesStmt = null;
		ResultSet rulesRs = null;
		String userCode = null;
		String eventName = null;
		String eventSource = null;
		String subscriptionName = null;
		Map<String, List<Rule>> rulesMap = null;
		List<Rule> rulesList = null;
		Rule rule = null;
		EventDataMapping dataMapping = null;
		ExecutionException eExp = null;
		String sellerCode = null;
		
		try
		{
			userCode = jobData.getMakerCode();
			eventName = jobData.getEventName();
			eventSource = jobData.getEventSource();
			sellerCode = jobData.getSellerCode();
			rulesMap = new HashMap<String, List<Rule>>();
			rulesStmt = dbConnection.prepareStatement(rulesSQL);
			rulesStmt.clearParameters();
			rulesStmt.setString(1, userCode);
			rulesStmt.setString(2, eventName);
			rulesStmt.setString(3, eventSource);
			rulesStmt.setString(4,sellerCode);
			rulesRs = rulesStmt.executeQuery();
			dataMapping = jobData.getEventDef().getEventDataMapping();
			while (rulesRs.next())
			{
				subscriptionName = rulesRs.getString("SUBSCRIPTION_NAME");
				if (rulesMap.containsKey(subscriptionName))
				{
					rulesList = rulesMap.get(subscriptionName);
					
					rule = getSubScriptionRule(rulesRs, dataMapping);
					rulesList.add(rule);
				}
				else
				{
					rulesList = new ArrayList<Rule>();
					rule = getSubScriptionRule(rulesRs, dataMapping);
					rulesList.add(rule);
					rulesMap.put(subscriptionName, rulesList);
				}
			}
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.app.SubscriptionRules", new Object[]
			{ rulesSQL }, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(rulesRs);
			HelperUtils.doClose(rulesStmt);
		}
		return rulesMap;
	}
}
