/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.execution
 * FILE   : AbstractRecipientProvider.java
 * CREATED: Jul 16, 2014 3:26:04 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.provider;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.IRecipientProvider;
import com.fundtech.iris.admin.event.data.DataAttribute;
import com.fundtech.iris.admin.event.data.EventDataMapping;
import com.fundtech.iris.admin.event.data.Subscription;
import com.fundtech.iris.admin.event.data.rules.BetweenRule;
import com.fundtech.iris.admin.event.data.rules.EqualsRule;
import com.fundtech.iris.admin.event.data.rules.GreaterThanOrEqualsRule;
import com.fundtech.iris.admin.event.data.rules.GreaterThanRule;
import com.fundtech.iris.admin.event.data.rules.InRule;
import com.fundtech.iris.admin.event.data.rules.LessThanOrEqualsRule;
import com.fundtech.iris.admin.event.data.rules.LessThanRule;
import com.fundtech.iris.admin.event.data.rules.NotEqualsRule;
import com.fundtech.iris.admin.event.data.rules.NotInRule;
import com.fundtech.iris.admin.event.data.rules.Rule;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: AbstractRecipientProvider.java,v 1.9 2016/10/19 14:04:55 ramap Exp $
 */
public abstract class AbstractRecipientProvider implements IRecipientProvider
{
	
	public Subscription getSubscription (ResultSet subRs) throws SQLException
	{
		String name = null;
		String type = null;
		String category = null;
		String language = null;
		String parentName = null;
		Date startDate = null;
		Date endDate = null;
		boolean emailNotify = false;
		String emailTemplateCode = null;
		String emailMessage = null;
		boolean smsNotify = false;
		String smsTemplateCode = null;
		String smsMessage = null;
		boolean screenNotify = false;
		String screenTemplateCode = null;
		String screenMessage = null;
		boolean faxNotify = false;
		String faxTemplateCode = null;
		String faxMessage = null;
		String faxReportName = null;
		boolean attachmentNotify = false;
		String attachmentTemplateCode = null;
		String attachmentMessage = null;
		String attachmentReportName = null;
		boolean interfaceNotify = false;
		String interfaceRefName = null;
		String emailSubject = null;
		String smsSubject = null;
		String screenSubject = null;
		String faxSubject = null;
		String attachmentSubject = null;
		String interfaceTemplateCode = null;
		String interfaceMessage = null;
		String interfaceSubject = null;
		String isZipRequired = IrisAdminConstants.CONSTANT_N;
		String isPDFPassword = IrisAdminConstants.CONSTANT_N;
		String password = null;
		Subscription subscription = null;
		
		subscription = new Subscription();
		name = subRs.getString("SUBSCRIPTION_NAME");
		type = subRs.getString("SUBCRIPTION_TYPE");
		category = subRs.getString("SUBCRIPTION_CATEGORY");
		language = subRs.getString("SUBCRIPTION_LANGUAGE");
		parentName = subRs.getString("PARENT_SUBCRIPTION_NAME");
		startDate = subRs.getDate("START_DATE");
		endDate = subRs.getDate("END_DATE");
		
		if (IrisAdminConstants.CONSTANT_Y.equals(subRs.getString("EMAIL_NOTIFY")))
			emailNotify = true;
		
		emailTemplateCode = subRs.getString("MSG_TEMPLATE_NAME_EMAIL");
		emailMessage = subRs.getString("MESSAGE_EMAIL");
		emailSubject = subRs.getString("MAIL_SUBJECT");
		
		if (IrisAdminConstants.CONSTANT_Y.equals(subRs.getString("SMS_NOTIFY")))
			smsNotify = true;
		
		smsTemplateCode = subRs.getString("MSG_TEMPLATE_NAME_SMS");
		smsMessage = subRs.getString("MESSAGE_SMS");
		smsSubject = subRs.getString("SMS_SUBJECT");
		
		if (IrisAdminConstants.CONSTANT_Y.equals(subRs.getString("SCREEN_NOTIFY")))
			screenNotify = true;
		
		screenTemplateCode = subRs.getString("MSG_TEMPLATE_NAME_SCREEN");
		screenMessage = subRs.getString("MESSAGE_SCREEN");
		screenSubject = subRs.getString("SCREEN_SUBJECT");
		
		if (IrisAdminConstants.CONSTANT_Y.equals(subRs.getString("FAX_NOTIFY")))
			faxNotify = true;
		
		faxTemplateCode = subRs.getString("MSG_TEMPLATE_NAME_FAX");
		faxMessage = subRs.getString("MESSAGE_FAX");
		faxSubject = subRs.getString("FAX_SUBJECT");
		faxReportName = subRs.getString("REPORT_NAME_FAX");
		
		if (IrisAdminConstants.CONSTANT_Y.equals(subRs.getString("ATTACHMENT_NOTIFY")))
			attachmentNotify = true;
		
		attachmentTemplateCode = subRs.getString("MSG_TEMPLATE_NAME_ATTACHMENT");
		attachmentMessage = subRs.getString("MESSAGE_ATTACHHMENT");
		attachmentSubject = subRs.getString("ATTACHMENT_SUBJECT");
		attachmentReportName = subRs.getString("REPORT_NAME_ATTACHMENT");
		isPDFPassword = subRs.getString("PDF_PASSWORD_FLAG"); 
		
		if (IrisAdminConstants.CONSTANT_Y.equals(subRs.getString("INTERFACE_NOTIFY")))
			interfaceNotify = true;
		
		
		interfaceRefName = subRs.getString("INTERFACE_REF_NAME");
		interfaceTemplateCode = subRs.getString("MSG_TEMPLATE_NAME_INTERFACE");
		interfaceMessage = subRs.getString("MESSAGE_INT");
		interfaceSubject = subRs.getString("INT_SUBJECT");
		isZipRequired = subRs.getString("ZIP_PASSWORD_FLAG");
		password = subRs.getString("PASSWORD_ATTRIBUTES");
		
		subscription.setName(name);
		subscription.setType(type);
		subscription.setCategory(category);
		subscription.setLanguage(language);
		subscription.setParentName(parentName);
		subscription.setStartDate(startDate);
		subscription.setEndDate(endDate);
		subscription.setEmailNotify(emailNotify);
		subscription.setEmailTemplateCode(emailTemplateCode);
		subscription.setEmailMessage(emailMessage);
		subscription.setEmailSubject(emailSubject);
		subscription.setSmsNotify(smsNotify);
		subscription.setSmsTemplateCode(smsTemplateCode);
		subscription.setSmsMessage(smsMessage);
		subscription.setSmsSubject(smsSubject);
		subscription.setScreenNotify(screenNotify);
		subscription.setScreenTemplateCode(screenTemplateCode);
		subscription.setScreenMessage(screenMessage);
		subscription.setScreenSubject(screenSubject);
		subscription.setFaxNotify(faxNotify);
		subscription.setFaxTemplateCode(faxTemplateCode);
		subscription.setFaxMessage(faxMessage);
		subscription.setFaxReportName(faxReportName);
		subscription.setFaxSubject(faxSubject);
		subscription.setAttachmentNotify(attachmentNotify);
		subscription.setAttachmentTemplateCode(attachmentTemplateCode);
		subscription.setAttachmentMessage(attachmentMessage);
		subscription.setAttachmentReportName(attachmentReportName);
		subscription.setAttachmentSubject(attachmentSubject);
		subscription.setIsPDFPassword(isPDFPassword);
		subscription.setInterfaceTemplateCode(interfaceTemplateCode);
		subscription.setInterfaceMessage(interfaceMessage);
		subscription.setInterfaceSubject(interfaceSubject);
		subscription.setInterfaceNotify(interfaceNotify);
		subscription.setInterfaceRefName(interfaceRefName);
		subscription.setIsZipRequired(isZipRequired);
		subscription.setPassword(password);
		
		return subscription;
	}
	
	
	
	/**
	 * This helper method creates the rule
	 * 
	 * @param rulesRs
	 * @param dataMappingp
	 * @return {@link Rule}
	 * @throws Exception
	 */
	public Rule getSubScriptionRule (ResultSet rulesRs, EventDataMapping dataMappingp) throws Exception
	{
		Rule rule = null;
		
		String dataKeyDisplayName = null;
		String dataKeyColumnName = null;
		String dataOperator = null;
		String dataValue = null;
		String datatype = null;
		String format = null;
		String subscriptionCode = null;
		DataAttribute dataAttribute = null;
		
		subscriptionCode = rulesRs.getString("subscription_name");
		dataKeyDisplayName = rulesRs.getString("data_key_display_name");
		dataKeyColumnName = rulesRs.getString("data_key_column_name");
		dataOperator = rulesRs.getString("data_operator");
		dataValue = rulesRs.getString("data_value");
		dataAttribute = dataMappingp.getDataAttribute(dataKeyColumnName);
		datatype = dataAttribute.getDataType();
		format = dataAttribute.getFormat();
		
		if (dataOperator.equals("="))
			rule = new EqualsRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		else if (dataOperator.equals("<>"))
			rule = new NotEqualsRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		else if (dataOperator.equals(">"))
			rule = new GreaterThanRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		else if (dataOperator.equals("<"))
			rule = new LessThanRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		else if (dataOperator.equals("<="))
			rule = new LessThanOrEqualsRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		else if (dataOperator.equals(">="))
			rule = new GreaterThanOrEqualsRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		else if (dataOperator.equalsIgnoreCase("In"))
			rule = new InRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		else if (dataOperator.equalsIgnoreCase("NotIn"))
			rule = new NotInRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		else if (dataOperator.equalsIgnoreCase("BETWEEN"))
			rule = new BetweenRule(subscriptionCode, dataKeyDisplayName, dataKeyColumnName, dataOperator, dataValue, datatype, format);
		return rule;
	}
}
