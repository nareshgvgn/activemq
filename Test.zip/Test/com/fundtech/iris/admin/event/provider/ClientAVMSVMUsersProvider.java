/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.provider
 * FILE   : ClientAVMSVMUsersProvider.java
 * CREATED: Jul 28, 2014 1:24:25 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.provider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.DefaultRecipient;
import com.fundtech.iris.admin.event.data.EventDataMapping;
import com.fundtech.iris.admin.event.data.IRecipient;
import com.fundtech.iris.admin.event.data.RecipientDef;
import com.fundtech.iris.admin.event.data.Subscription;
import com.fundtech.iris.admin.event.data.rules.Rule;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td> 
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: ClientAVMSVMUsersProvider.java,v 1.12 2017/03/23 07:38:20 ramap Exp $
 */
public class ClientAVMSVMUsersProvider extends AbstractRecipientProvider
{
	private static Logger logger = LoggerFactory.getLogger(ClientAVMSVMUsersProvider.class);
	
	private static final String MYPRODUCT = "mypusrprd";
	private static final String MYPAUTHLEVEL = "mypauthlevel";
	private static final String MYPUSRACCOUNT = "mypusraccount";
	private static final String MYDEBITACCOUNT= "mypdebitaccount";
	
	private final static String genAuthSql = "SELECT user_cat_type, LISTAGG(user_cat_code, ',') WITHIN GROUP (ORDER BY user_cat_type) as user_cat_code FROM gen_auth_detail t"
			+ " WHERE t.auth_nmbr= ? AND t.user_cat_code <> 'ANY' GROUp BY user_cat_type "
			+ " UNION "
			+ " SELECT user_cat_type, LISTAGG(user_cat_code, ',')  WITHIN GROUP (ORDER BY user_cat_type) as user_cat_code FROM gen_auth_detail t"
			+ " WHERE t.auth_nmbr = ? AND t.user_cat_code = 'ANY' GROUp BY user_cat_type";
	
	private final static String subUsrSelectSQL = "WITH msg_temp AS (SELECT msg_template_name, subject, msg_format FROM event_msg_template_mst)"
			+ " SELECT c.usrcode,c.usrcorporation,c.usrclient,c.usrdescription,c.usremailaddr,c.usrfax,c.usrmobileno, b.*, emt.subject MAIL_SUBJECT, "
			+ " emt.msg_format MESSAGE_EMAIL, smt.subject SMS_SUBJECT, smt.msg_format MESSAGE_SMS, omt.subject SCREEN_SUBJECT, omt.msg_format MESSAGE_SCREEN,"
			+ " atc.subject ATTACHMENT_SUBJECT, atc.msg_format MESSAGE_ATTACHHMENT, fax.subject FAX_SUBJECT, fax.msg_format MESSAGE_FAX"
			+ ", int.subject INT_SUBJECT, int.msg_format MESSAGE_INT "
			+ "  FROM event_subscription_mst b, event_template_dtl a,  usermaster c, userclientrights cr, msg_temp emt, msg_temp smt, msg_temp omt, msg_temp atc, msg_temp fax"
			+ ", msg_temp int ";
	
	private final static String subUsrWhereSQL = " WHERE b.msg_template_name_email = emt.msg_template_name(+) AND b.msg_template_name_sms = smt.msg_template_name(+)"
			+ " AND b.msg_template_name_screen = omt.msg_template_name(+) AND b.msg_template_name_attachment = atc.msg_template_name(+) AND b.msg_template_name_fax = fax.msg_template_name(+)"
			+ " AND b.MSG_TEMPLATE_NAME_INTERFACE = int.msg_template_name(+) "			
			+ " AND a.valid_flag = 'Y' and a.SUBSCRIPTION_NAME = b.SUBSCRIPTION_NAME and a.event_template_name = c.event_template_code and c.usrcorporation=? and "
			+ " cr.ucrclient=? AND c.usrcorporation=cr.ucrcorporation and b.event_name = ? and b.event_source = ? and b.SUBCRIPTION_TYPE in ( 'S','C') and c.valid_flag='Y'" 
			+ " and a.BANK_VALID_FLAG='Y' AND cr.valid_flag='Y' and cr.ucruser=c.usrcode and c.usrcode IN ";
	
	private final static String rulesSelectSQL = "select distinct d.* from event_template_dtl a, event_subscription_mst b, usermaster c, event_subscription_dtls d";
	
	private final static String rulesWhereSQL = "  where a.valid_flag = 'Y' and a.SUBSCRIPTION_NAME = b.SUBSCRIPTION_NAME and a.subscription_name = d.subscription_name"
			+ " and a.event_template_name = c.event_template_code and b.SUBCRIPTION_TYPE  in ( 'S','C') and c.usrcorporation= ? and c.usrclient=? "
			+ " and b.event_name = ? and b.event_source =? and a.BANK_VALID_FLAG='Y' and c.valid_flag='Y' and c.usrcode IN ";

	private final static String productSql = "SELECT mypusrprd, mypusraccount, mypauthlevel, mypdebitaccount FROM myproductmaster WHERE mypproduct = ? and mypclient = ?";
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.IRecipientProvider#getProbableRecipients(java.sql.Connection,
	 * com.fundtech.iris.admin.event.data.EventJob)
	 */
	@Override
	public List<IRecipient> getProbableRecipients (Connection dbConnection, EventProcessJob jobData, RecipientDef recipientDef) throws ExecutionException
	{
		ExecutionException eExp = null;
		List<IRecipient> custUsers = null;
		Map<String, DefaultRecipient> userList = null;
		PreparedStatement genAuthStmt = null;
		ResultSet genAuthRs = null;
		String usrCatType = null;
		String usrCatCode = null;
		String authNmbr = null;
		List<String> whereValues = null;
		String eventName = null;
		String eventSource = null;
		String corpCode = null;
		String clientCode = null;
		

		try
		{
			authNmbr = jobData.getRowKeyField();
			genAuthStmt = dbConnection.prepareStatement(genAuthSql);
			genAuthStmt.clearParameters();
			genAuthStmt.setString(1, authNmbr);
			genAuthStmt.setString(2, authNmbr);
			genAuthRs = genAuthStmt.executeQuery();
			custUsers = new ArrayList<IRecipient>();
			while(genAuthRs.next())
			{
				whereValues = new ArrayList<String>();
				
				usrCatType = genAuthRs.getString("user_cat_type");
				usrCatCode = genAuthRs.getString("user_cat_code");
				logger.trace("User category Type:{} and user category code:{}", usrCatType, usrCatCode);
				corpCode = jobData.getCorpCode();
				whereValues.add(corpCode);
				clientCode = jobData.getClientCode();
				whereValues.add(clientCode);
				eventName = jobData.getEventName();
				whereValues.add(eventName);
				eventSource = jobData.getEventSource();
				whereValues.add(eventSource);
				
				userList = getUserSubcriptions(dbConnection, jobData, whereValues, usrCatType, usrCatCode);
				custUsers.addAll(userList.values());
			}
		}
		catch ( ExecutionException exp)
		{
			throw exp;
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.event.subcriptionloading", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		return custUsers;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @param whereValues
	 * @param usrCatType
	 * @param usrCatCode
	 * @return
	 * </pre></p>
	 */
	private Map<String, DefaultRecipient> getUserSubcriptions (Connection dbConnection, EventProcessJob jobData, List<String> whereValues,	String usrCatType, String usrCatCode) 
																																		throws ExecutionException
	{
		String addSql = null;
		Map<String, DefaultRecipient> userList = null;
		
		addSql = getAddSql (dbConnection,jobData, whereValues, usrCatType, usrCatCode);
		userList = getUserSubcriptions(dbConnection, jobData, addSql, whereValues);
		return userList;
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @param whereValues
	 * @param usrCatType
	 * @param usrCatCode
	 * @return
	 * </pre></p>
	 */
	private String getAddSql (Connection dbConnection, EventProcessJob jobData, List<String> whereValues, String usrCatType, String usrCatCode) throws ExecutionException
	{
		String masterSql = null;
		String clientCode = null;
		String userCorp = null;
		String authKey = null;
		String strUserProductLinkage = null;
		String strUserAccountLinkage = null;
		String authLevel = null;
		String strMypdebitaccount = null;
		String userProduct = null;
		Map<String, String> productData = null;
		
		
		if (usrCatType != null && usrCatType.equalsIgnoreCase("U")&& !"ANY".equalsIgnoreCase(usrCatCode))
		{
			
			authKey = jobData.getRowKeyField();
			whereValues.add(authKey);
			masterSql = " (SELECT DISTINCT user_cat_code FROM gen_auth_detail t  WHERE t.user_cat_type = 'U' AND t.auth_nmbr = ? ) ";
		}
		else
		{
			masterSql = " (SELECT ucruser FROM userclientrights  WHERE valid_flag = 'Y' AND ucrclient = ? )";
			productData = getProductData(dbConnection, jobData);
			clientCode = jobData.getClientCode();
			whereValues.add(clientCode);
			
			//Get list of Users for Category in Auth Table
			if ("C".equals(usrCatType))
			{
				masterSql = masterSql + " INTERSECT (SELECT  b.ucruser FROM usermaster a, userclientrights b  WHERE a.valid_flag = 'Y' AND b.valid_flag = 'Y' "
						+ " AND a.usrcode= b.ucruser AND ucrclient = ? AND a.usrcategory IN (SELECT DISTINCT user_cat_code  FROM gen_auth_detail WHERE user_cat_type='C'"
						+ " AND auth_nmbr = ?) AND a.usrcorporation = ?)";
				whereValues.add(clientCode);
				authKey = jobData.getRowKeyField();
				whereValues.add(authKey);
				userCorp = jobData.getCorpCode();
				whereValues.add(userCorp);
			}
			
			//Get list of Users assigned to Product used in transaction
			if ( productData.containsKey(MYPRODUCT))
			{
				strUserProductLinkage = productData.get(MYPRODUCT);
				if (IrisAdminConstants.CONSTANT_Y.equals(strUserProductLinkage))
				{
					masterSql = masterSql + " INTERSECT (SELECT uspuser FROM userproducts WHERE valid_flag = 'Y' AND uspclient = ? AND uspproduct = ? )";
					whereValues.add(clientCode);
					userProduct = (String)jobData.getDataMappingValue("event_data_key4");
					whereValues.add(userProduct);
				}
			}
			
			//Get list of Users assigned to Account used in transaction
			if ( productData.containsKey(MYPUSRACCOUNT))
			{
				strUserAccountLinkage =  productData.get(MYPUSRACCOUNT);
				if (IrisAdminConstants.CONSTANT_Y.equals(strUserAccountLinkage))
				{
					authLevel = productData.get(MYPAUTHLEVEL);
					strMypdebitaccount = productData.get(MYDEBITACCOUNT);
					if ( "1".equals(authLevel) && "B".equals(strMypdebitaccount))
					{
						masterSql = masterSql + " INTERSECT (SELECT usauser  FROM useraccounts  WHERE valid_flag = 'Y' AND usaacctype='DISB_DEBIT' AND usaclient = ? AND"
								+ " usaaccount IN (SELECT phddebitaccount FROM pirheader WHERE record_key_no = (SELECT parent_record_key_no FROM gen_auth_header"
								+ " WHERE auth_nmbr = ?)))";
						whereValues.add(clientCode);
						authKey = jobData.getRowKeyField();
						whereValues.add(authKey);
					}
					else if ("0".equals(authLevel) )
					{
						masterSql = masterSql + " INTERSECT (SELECT usauser FROM useraccounts d WHERE valid_flag = 'Y' AND usaacctype='DISB_DEBIT' AND usaclient = ? AND "
								+ " usaaccount IN (SELECT pdtaccnumber FROM pirdetail WHERE record_key_no = (SELECT detail_record_key_no FROM gen_auth_header "
								+ " WHERE auth_nmbr = ? )))";
						
						whereValues.add(clientCode);
						authKey = jobData.getRowKeyField();
						whereValues.add(authKey);
					}
				}
			}
		}
		return masterSql;
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @return
	 * </pre></p>
	 */
	private Map<String, String> getProductData (Connection dbConnection, EventProcessJob jobData) throws ExecutionException
	{
		PreparedStatement productStmt = null;
		ResultSet productRs = null;
		ExecutionException eExp = null;
		String productKeyColumn = null;
		String clientCode = null;
		Map<String, String> output = null;
		String mydebitAccount = null;
		String myauthlevel = null;
		String myProduct = null;
		String myUserAccount = null;
		
		try
		{
			
			productKeyColumn = (String) jobData.getDataMappingValue("event_data_key4");// We assume always product comes from this field;
			clientCode = jobData.getClientCode();
			productStmt = dbConnection.prepareStatement(productSql);
			productStmt.clearParameters();
			productStmt.setString(1, productKeyColumn);
			productStmt.setString(2, clientCode);
			productRs = productStmt.executeQuery();
			output = new HashMap<String, String>();
			if ( productRs.next())
			{
				mydebitAccount = productRs.getString(MYDEBITACCOUNT);
				myauthlevel = productRs.getString(MYPAUTHLEVEL);
				myProduct = productRs.getString(MYPRODUCT);
				myUserAccount = productRs.getString(MYPUSRACCOUNT);
				
				logger.trace("For Given Product:{} and Client:{} retrived values are {}:{}, {}:{},"
						+ " ", productKeyColumn, clientCode, MYDEBITACCOUNT, mydebitAccount,MYPAUTHLEVEL, myauthlevel);
				output.put(MYDEBITACCOUNT, mydebitAccount);
				output.put(MYPAUTHLEVEL, myauthlevel);
				output.put(MYPRODUCT, myProduct);
				output.put(MYPUSRACCOUNT, myUserAccount);
			}
			
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.event.myproductloading", new Object[] {productSql}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(productRs);
			HelperUtils.doClose(productStmt);
		}
		return output;
	}

	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @return
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private Map<String, DefaultRecipient> getUserSubcriptions (Connection dbConnection, EventProcessJob jobData, String addSql, List<String> whereValues) throws ExecutionException
	{
		ResultSet usrRs = null;
		PreparedStatement usrStmt = null;
		String client = null;
		String corporation = null;
		String fax = null;
		String description = null;
		String mailId = null;
		String mobile = null;
		int count = 1;
		String userCode = null;
		Subscription subscription = null;
		List<Rule> rules = null;
		DefaultRecipient defaultRecipient = null;
		String subscriptionSQL = null;
		String rulesSQL = null;
		Map<String, DefaultRecipient> userList = null;
		Map<String, List<Rule>> subscriptionRules = null;
		ExecutionException eExp = null;
		
		try
		{
			rulesSQL = rulesSelectSQL + rulesWhereSQL + addSql;
			subscriptionRules = loadSubscriptionRules(dbConnection, jobData, rulesSQL, whereValues);
			subscriptionSQL = subUsrSelectSQL + subUsrWhereSQL + addSql;
			usrStmt = dbConnection.prepareStatement(subscriptionSQL);
			userList = new HashMap<String, DefaultRecipient>();
			usrStmt.clearParameters();
			for ( String key : whereValues)
			{
				usrStmt.setString(count, key);
				count++;
			}
			
			usrRs = usrStmt.executeQuery();
			while (usrRs.next())
			{
				userCode = usrRs.getString("usrcode");
				if (userList.containsKey(userCode))
					defaultRecipient = userList.get(userCode);
				else
				{
					corporation = usrRs.getString("USRCORPORATION");
					client = usrRs.getString("USRCLIENT");
					description = usrRs.getString("USRDESCRIPTION");
					fax = usrRs.getString("USRFAX");
					mailId = usrRs.getString("USREMAILADDR");
					mobile = usrRs.getString("USRMOBILENO");
					defaultRecipient = new DefaultRecipient();
					defaultRecipient.setRecipient(userCode);
					defaultRecipient.setClient(client);
					defaultRecipient.setCorporation(corporation);
					defaultRecipient.setDescription(description);
					defaultRecipient.setFax(fax);
					defaultRecipient.setMailId(mailId);
					defaultRecipient.setMobile(mobile);
					userList.put(userCode, defaultRecipient);
				}
				subscription = getSubscription(usrRs);
				rules = subscriptionRules.get(subscription.getName());
				subscription.setRules(rules);
				defaultRecipient.addSubscription(subscription);
			}
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("error.iris.admin.event.subcriptionloading", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(usrRs);
			HelperUtils.doClose(usrStmt);
		}
		
		return userList;
	}
	
	
	/**
	 * <p>
	 * This helper method loads the subscription rules for given events and creates the list of rules and keeps in {@link Map} with the key of
	 * SubScription Name
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @param rulesSQL
	 * @return
	 * @throws ExecutionException
	 * </pre></p>
	 */
	public Map<String, List<Rule>> loadSubscriptionRules (Connection dbConnection, EventProcessJob jobData, String rulesSQL, List<String> whereValues) throws ExecutionException
	{
		int count = 1;
		PreparedStatement rulesStmt = null;
		ResultSet rulesRs = null;
		String subscriptionName = null;
		Map<String, List<Rule>> rulesMap = null;
		List<Rule> rulesList = null;
		Rule rule = null;
		EventDataMapping dataMapping = null;
		ExecutionException eExp = null;
		
		try
		{
			rulesMap = new HashMap<String, List<Rule>>();
			rulesStmt = dbConnection.prepareStatement(rulesSQL);
			rulesStmt.clearParameters();
			for ( String key : whereValues)
			{
				rulesStmt.setString(count, key);
				count++;
			}
			
			rulesRs = rulesStmt.executeQuery();
			dataMapping = jobData.getEventDef().getEventDataMapping();
			while (rulesRs.next())
			{
				subscriptionName = rulesRs.getString("SUBSCRIPTION_NAME");
				if (rulesMap.containsKey(subscriptionName))
				{
					rulesList = rulesMap.get(subscriptionName);
					
					rule = getSubScriptionRule(rulesRs, dataMapping);
					rulesList.add(rule);
				}
				else
				{
					rulesList = new ArrayList<Rule>();
					rule = getSubScriptionRule(rulesRs, dataMapping);
					rulesList.add(rule);
					rulesMap.put(subscriptionName, rulesList);
				}
			}
		}
		catch (Exception e)
		{
			eExp = new ExecutionException("error.app.SubscriptionRules", new Object[] {rulesSQL }, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(rulesRs);
			HelperUtils.doClose(rulesStmt);
		}
		return rulesMap;
	}
}
