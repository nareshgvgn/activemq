/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : EventNotifierPlugin.java
 * CREATED: Jul 12, 2014 4:11:24 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.plugins;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.IRecipient;
import com.fundtech.iris.admin.event.data.Subscription;
import com.fundtech.iris.admin.event.notifier.EmailNotifier;
import com.fundtech.iris.admin.event.notifier.INotifier;
import com.fundtech.iris.admin.event.notifier.InterfaceNotifier;
import com.fundtech.iris.admin.event.notifier.SMSNotifier;
import com.fundtech.iris.admin.event.notifier.ScreenNotifier;
import com.fundtech.iris.admin.event.notifier.WithAttachmentNotifier;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: EventNotifierPlugin.java,v 1.14 2016/10/19 14:04:55 ramap Exp $
 */
public class EventNotifierPlugin extends IrisAdminPlugin
{
	public static final org.slf4j.Logger logger = LoggerFactory.getLogger(EventNotifierPlugin.class);
	private Map<String, INotifier> notifers = new HashMap<String, INotifier>();
	private static final String emailClass = "emailClass";
	private static final String smsClass = "smsClass";
	private static final String attachhmentClass = "attachhmentClass";
	private static final String screenClass = "screenClass";
	private static final String faxClass = "faxClass";
	private static final String interfaceClass = "interfaceClass";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		EventProcessJob jobData = null;
		Map<String, List<IRecipient>> probableRecipients = null;
		String recipientName = null;
		List<IRecipient> recipientList = null;
		List<Subscription> subscriptions = null;
		int countRecords = 1;
		 Map<String, String> staticProperties = null;
		try
		{
			jobData = (EventProcessJob) params.get(IPlugin.EXECUTION_DATA);
			staticProperties = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			probableRecipients = jobData.getProbableRecipients();
			for (Map.Entry<String, List<IRecipient>> entry : probableRecipients.entrySet())
			{
				recipientName = entry.getKey();
				recipientList = entry.getValue();
				if ( recipientList.isEmpty())
					logger.warn("No subscriptions available for Recipient:  {} ",recipientName );
				for (IRecipient recipient : recipientList)
				{
					subscriptions = recipient.getSubscriptions();
					logger.debug("For the recipient: {}, number of subscriptions are {}", recipientName, subscriptions.size());
					for (Subscription subscription : subscriptions)
					{
						insertNotification(countRecords, recipientName, recipient, subscription, jobData, dbConnection, staticProperties);
						countRecords = countRecords + 1;
					}
				}
			}
			
			dbcomplete(dbConnection, "commit");
		}
		finally
		{
			cleanup();
		}
		
		return null;
	}
	
	private void dbcomplete (Connection dbConnection, String operation)
	{
		try
		{
			if ("commit".equals(operation))
				dbConnection.commit();
			else
				dbConnection.rollback();
		}
		catch (Exception e)
		{
			logger.error("Error:", e);
			// ignore
		}
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre>
	 * 
	 * </p>
	 */
	private void cleanup ()
	{
		INotifier notifier = null;
		for (Map.Entry<String, INotifier> entry : notifers.entrySet())
		{
			try
			{
				notifier = entry.getValue();
				notifier.close();
			}
			catch (Exception e)
			{
				logger.error("Error:", e);
				// ignore
			}
		}
		CleanUpUtils.doClean(notifers);
		notifers = null;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param recipientName
	 * @param recipient
	 * @param subscription
	 * @param jobData
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @throws ExecutionException
	 */
	private void insertNotification (int countRecords, String recipientName, IRecipient recipient, Subscription subscription, EventProcessJob jobData,
			Connection dbConnection, Map<String, String> staticProperties) throws ExecutionException
	{
		Map<String, String> hookData = null;
		INotifier notifier = null;
		String tempMessage = null;
		String tempSubject = null;
		String fromMailId = null;
		String senderMobile = null;
		
		fromMailId = staticProperties.get("fromMailId");
		senderMobile = staticProperties.get("senderMobile");
		if (subscription.isEmailNotify())
		{
			if (notifers.containsKey(emailClass))
				notifier = notifers.get(emailClass);
			else
			{
				notifier = new EmailNotifier(dbConnection);
				notifers.put(emailClass, notifier);
			}
			
			hookData = new HashMap<String, String>();
			hookData.put(INotifier.NOTOFICATION_ID, "" + countRecords);
			hookData.put(INotifier.RECIPIENT_NAME, recipientName);
			hookData.put(INotifier.ENTITY_CODE, recipient.getRecipient());
			hookData.put(INotifier.CLIENT_CODE, recipient.getClient());
			hookData.put(INotifier.TO_EMAIL_ID, recipient.getMailId());
			hookData.put(INotifier.FROM_MAIL_ID, fromMailId);
			hookData.put(INotifier.EVENT_JOURNAL_NMBR, jobData.getJournalNmbr());
			hookData.put(INotifier.EVENT_NAME, jobData.getEventName());
			hookData.put(INotifier.EVENT_SOURCE, jobData.getEventSource());
			hookData.put(INotifier.EVENT_DATE, jobData.getEventDate());
			tempMessage = subscription.getEmailMessage();
			tempSubject = subscription.getEmailSubject();
			hookData.put(INotifier.MESSAGE, tempMessage);
			hookData.put(INotifier.SUBJECT, tempSubject);
			hookData.put(INotifier.SUBSCRIPTION_NAME, subscription.getName());
			notifier.notify(hookData, jobData);
		}
		
		if (subscription.isScreenNotify())
		{
			if (notifers.containsKey(screenClass))
				notifier = notifers.get(screenClass);
			else
			{
				notifier = new ScreenNotifier(dbConnection);
				notifers.put(screenClass, notifier);
			}
			
			hookData = new HashMap<String, String>();
			hookData.put(INotifier.NOTOFICATION_ID, "" + countRecords);
			hookData.put(INotifier.RECIPIENT_NAME, recipientName);
			hookData.put(INotifier.ENTITY_CODE, recipient.getRecipient());
			hookData.put(INotifier.CLIENT_CODE, recipient.getClient());
			hookData.put(INotifier.TO_EMAIL_ID, recipient.getMailId());
			hookData.put(INotifier.FROM_MAIL_ID, fromMailId);
			hookData.put(INotifier.EVENT_JOURNAL_NMBR, jobData.getJournalNmbr());
			hookData.put(INotifier.EVENT_NAME, jobData.getEventName());
			hookData.put(INotifier.EVENT_SOURCE, jobData.getEventSource());
			hookData.put(INotifier.EVENT_DATE, jobData.getEventDate());
			hookData.put(INotifier.SCREEN_NAME, jobData.getFormId());
			hookData.put(INotifier.REMARKS, null);
			hookData.put(INotifier.SENDER_NAME, "System");
			tempMessage = subscription.getScreenMessage();
			tempSubject = subscription.getScreenSubject();
			hookData.put(INotifier.MESSAGE, tempMessage);
			hookData.put(INotifier.SUBJECT, tempSubject);
			hookData.put(INotifier.SUBSCRIPTION_NAME, subscription.getName());
			notifier.notify(hookData, jobData);
		}
		
		if (subscription.isAttachmentNotify())
		{
			if (notifers.containsKey(attachhmentClass))
				notifier = notifers.get(attachhmentClass);
			else
			{
				notifier = new WithAttachmentNotifier(dbConnection);
				notifers.put(attachhmentClass, notifier);
			}
			
			hookData = new HashMap<String, String>();
			
			hookData.put(INotifier.NOTOFICATION_ID, "" + countRecords);
			hookData.put(INotifier.RECIPIENT_NAME, recipientName);
			hookData.put(INotifier.ENTITY_CODE, recipient.getRecipient());
			hookData.put(INotifier.CLIENT_CODE, recipient.getClient());
			hookData.put(INotifier.TO_EMAIL_ID, recipient.getMailId());
			hookData.put(INotifier.FROM_MAIL_ID, fromMailId);
			hookData.put(INotifier.EVENT_JOURNAL_NMBR, jobData.getJournalNmbr());
			hookData.put(INotifier.EVENT_NAME, jobData.getEventName());
			hookData.put(INotifier.EVENT_SOURCE, jobData.getEventSource());
			hookData.put(INotifier.EVENT_DATE, jobData.getEventDate());
			hookData.put(INotifier.REPORT_CODE, subscription.getAttachmentReportName());
			hookData.put(INotifier.REPORT_LANGUAGE, subscription.getLanguage());
			
			hookData.put(INotifier.PDF_PASS_REQUIRED, subscription.getIsPDFPassword());
			hookData.put(INotifier.PASSWORD, subscription.getPassword());
			tempMessage = subscription.getAttachmentMessage();
			tempSubject = subscription.getAttachmentSubject();
			hookData.put(INotifier.MESSAGE, tempMessage);
			hookData.put(INotifier.SUBJECT, tempSubject);
			hookData.put(INotifier.SUBSCRIPTION_NAME, subscription.getName());
			notifier.notify(hookData, jobData);
		}
		
		if (subscription.isFaxNotify())
		{
			
		}
		
		if (subscription.isSmsNotify())
		{
			if (notifers.containsKey(smsClass))
				notifier = notifers.get(smsClass);
			else
			{
				notifier = new SMSNotifier(dbConnection);
				notifers.put(smsClass, notifier);
			}
			
			hookData = new HashMap<String, String>();
			hookData.put(INotifier.NOTOFICATION_ID, "" + countRecords);
			hookData.put(INotifier.EVENT_JOURNAL_NMBR, jobData.getJournalNmbr());
			hookData.put(INotifier.EVENT_DATE, jobData.getEventDate());
			hookData.put(INotifier.EVENT_NAME, jobData.getEventName());
			hookData.put(INotifier.EVENT_SOURCE, jobData.getEventSource());
			hookData.put(INotifier.RECIPIENT_NAME, recipientName);
			hookData.put(INotifier.ENTITY_CODE, recipient.getRecipient());
			hookData.put(INotifier.CLIENT_CODE, recipient.getClient());
			tempMessage = subscription.getSmsMessage();
			hookData.put(INotifier.MESSAGE, tempMessage);
			hookData.put(INotifier.RECIPIENT_NMBR, recipient.getMobile());
			hookData.put(INotifier.SENDER_NMBR, senderMobile);
			hookData.put(INotifier.SUBSCRIPTION_NAME, subscription.getName());
			notifier.notify(hookData, jobData);
		}
		
		if (subscription.isInterfaceNotify())
		{
			if (notifers.containsKey(interfaceClass))
				notifier = notifers.get(interfaceClass);
			else
			{
				notifier = new InterfaceNotifier(dbConnection);
				notifers.put(interfaceClass, notifier);
			}
			
			hookData = new HashMap<String, String>();
			hookData.put(INotifier.NOTOFICATION_ID, "" + countRecords);
			hookData.put(INotifier.RECIPIENT_NAME, recipientName);
			hookData.put(INotifier.ENTITY_CODE, recipient.getRecipient());
			hookData.put(INotifier.CLIENT_CODE, recipient.getClient());
			hookData.put(INotifier.TO_EMAIL_ID, recipient.getMailId());
			hookData.put(INotifier.FROM_MAIL_ID, fromMailId);
			hookData.put(INotifier.EVENT_JOURNAL_NMBR, jobData.getJournalNmbr());
			hookData.put(INotifier.EVENT_NAME, jobData.getEventName());
			hookData.put(INotifier.EVENT_SOURCE, jobData.getEventSource());
			hookData.put(INotifier.EVENT_DATE, jobData.getEventDate());
			hookData.put(INotifier.MAP_CODE, subscription.getInterfaceRefName());
			hookData.put(INotifier.ZIP_REQUIRED, subscription.getIsZipRequired());
			hookData.put(INotifier.PASSWORD, subscription.getPassword());
			tempMessage = subscription.getInterfaceMessage();
			tempSubject = subscription.getInterfaceSubject();
			hookData.put(INotifier.MESSAGE, tempMessage);
			hookData.put(INotifier.SUBJECT, tempSubject);
			hookData.put(INotifier.SUBSCRIPTION_NAME, subscription.getName());
			notifier.notify(hookData, jobData);
		}
	}
	
}
