/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : EventSubscriptionRulesPlugin.java
 * CREATED: Jul 9, 2014 2:28:54 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.plugins;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.IRecipient;
import com.fundtech.iris.admin.event.data.Subscription;
import com.fundtech.iris.admin.event.data.rules.Rule;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: EventSubscriptionRulesPlugin.java,v 1.6 2015/07/22 11:39:59 ramap Exp $
 */
public class EventSubscriptionRulesPlugin extends IrisAdminPlugin
{
	
	private Logger logger = LoggerFactory.getLogger(EventSubscriptionRulesPlugin.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		EventProcessJob jobData = null;
		Map<String, List<IRecipient>> probableRecipients = null;
		List<IRecipient> tempRecipiennts = null;
		List<IRecipient> recipiennts = null;
		
		jobData = (EventProcessJob) params.get(IPlugin.EXECUTION_DATA);
		probableRecipients = jobData.getProbableRecipients();
		for (Map.Entry<String, List<IRecipient>> entry : probableRecipients.entrySet())
		{
			tempRecipiennts = entry.getValue();
			recipiennts = checkSubscriptionRules(tempRecipiennts, jobData);
			probableRecipients.put(entry.getKey(), recipiennts);
		}
		return null;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param tempRecipiennts
	 * @param jobData
	 * @return
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @throws ExecutionException
	 */
	private List<IRecipient> checkSubscriptionRules (List<IRecipient> tempRecipiennts, EventProcessJob jobData) throws ExecutionException
	{
		List<IRecipient> recipiennts = null;
		List<Subscription> tempSubscriptions = null;
		List<Subscription> subscriptions = null;
		List<Rule> rules = null;
		boolean isMatches = true;
		
		recipiennts = new ArrayList<IRecipient>();
		for (IRecipient recipient : tempRecipiennts)
		{
			tempSubscriptions = recipient.getSubscriptions();
			subscriptions = new ArrayList<Subscription>();
			for (Subscription subscription : tempSubscriptions)
			{
				rules = subscription.getRules();
				for (Rule rule : rules)
				{
					isMatches = rule.matches(jobData);
					if (!isMatches)
					{
						logger.warn("Rule Failed to match, so ignoring the subscription:" + subscription.getName() + "  for recipient:"
								+ recipient.getRecipient());
						break;
					}
				}

				if (isMatches)
					subscriptions.add(subscription);
				isMatches = true;
			}
			
			if (!subscriptions.isEmpty())
			{
				recipient.setSubscriptions(subscriptions);
				recipiennts.add(recipient);
			}
			
		}
		
		return recipiennts;
	}
	
}
