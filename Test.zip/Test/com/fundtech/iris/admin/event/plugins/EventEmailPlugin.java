/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.plugins
 * FILE   : EventEmailPlugin.java
 * CREATED: Sep 9, 2014 6:10:43 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.plugins;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.util.Map;

import javax.mail.MessagingException;

import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.channel.mail.IrisAdminMailService;
import com.fundtech.iris.admin.event.EventExecutionJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EventEmailPlugin.java,v 1.1 2015/12/24 04:26:47 ramap Exp $
 */
public class EventEmailPlugin extends IrisAdminPlugin
{

	public static final org.slf4j.Logger logger = LoggerFactory.getLogger(EventEmailPlugin.class);
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		EventExecutionJob jobData = null;
		 Map<String, String> staticProperties = null;
		 String emailBeanName = null;
		 ContextManager contextManager = null;
		 IrisAdminMailService mailService = null;
		 ExecutionException eExp = null;
		
		 try
		 {
			 jobData = (EventExecutionJob) params.get(IPlugin.EXECUTION_DATA);
			 staticProperties = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			 emailBeanName = staticProperties.get(IPlugin.RESOURCE_BEAN_NAME);
			 contextManager = ContextManager.getInstance();
			 mailService = (IrisAdminMailService) contextManager.getBeanObject(emailBeanName);
			 mailService.setFromAddress(jobData.getFromMailId());
			 mailService.setToAddresses(jobData.getToEmailId());
			 mailService.setSubject(jobData.getEmailSubject());
			 mailService.setMessageBody(jobData.getEmailMessage());
			 mailService.sendMail();
			 jobData.setStatus("C");
		 }
		catch (FileNotFoundException exp)
		{
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( BeanConfigException exp)
		 {
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		 }
		catch (MessagingException exp)
		{
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			 
		}
		
		return null;
	}
	
}
