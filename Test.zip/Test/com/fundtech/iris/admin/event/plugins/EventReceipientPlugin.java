/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : ReportZipPlugin.java
 * CREATED: Jun 13, 2014 7:01:39 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.plugins;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.IRecipientProvider;
import com.fundtech.iris.admin.event.data.EventRecipientDef;
import com.fundtech.iris.admin.event.data.IRecipient;
import com.fundtech.iris.admin.event.data.RecipientDef;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EventReceipientPlugin.java,v 1.6 2016/06/08 08:08:48 ramap Exp $
 */
public class EventReceipientPlugin extends IrisAdminPlugin
{
	private Logger logger = LoggerFactory.getLogger(EventReceipientPlugin.class);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		
		ExecutionException eExp = null;
		
		try
		{
			loadValidRecipiennts(dbConnection, params);
			
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.event", new Object[] {}, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		return null;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param params
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private void loadValidRecipiennts (Connection dbConnection, Map<String, Object> params) throws ExecutionException
	{
		EventProcessJob jobData = null;
		ExecutionException eExp = null;
		Map<String, EventRecipientDef> eventRecipientDefs;
		EventRecipientDef eventRecipienntDef = null;
		RecipientDef recipientDef = null;
		String providerClass = null;
		Class<?> clazz = null;
		IRecipientProvider iProvider = null;
		List<IRecipient> recipientsLst = null;
		
		try
		{
			jobData = (EventProcessJob) params.get(IPlugin.EXECUTION_DATA);
			eventRecipientDefs = jobData.getEventDef().geteventRecipientDefs();
			for (Map.Entry<String, EventRecipientDef> entry : eventRecipientDefs.entrySet())
			{
				eventRecipienntDef = entry.getValue();
				recipientDef = eventRecipienntDef.getRecipientDef();
				providerClass = recipientDef.getProviderClass();
				clazz = Class.forName(providerClass);
				iProvider = (IRecipientProvider) clazz.newInstance();
				recipientsLst = iProvider.getProbableRecipients(dbConnection, jobData, recipientDef);
				jobData.addtProbableRecipient(recipientDef.getName(), recipientsLst);
			}
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.event", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
		}
	}
	
}
