/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.plugins
 * FILE   : InterfaceStatusUpdate.java
 * CREATED: Mar 10, 2014 10:35:48 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.plugins;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: EventProcessStatusUpdate.java,v 1.8 2016/01/12 06:48:52 ramap Exp $
 */
public class EventProcessStatusUpdate extends IrisAdminPlugin
{
	private static Logger logger = LoggerFactory.getLogger(EventProcessStatusUpdate.class);
	private static final String updateSql = "UPDATE EVENT_TXN T SET t.status = ?, T.END_DATE = SYSDATE WHERE T.EVENT_JOURNAL_NMBR =?";
	
	public EventProcessStatusUpdate()
	{
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		EventProcessJob jobData = null;
		
		jobData = (EventProcessJob) params.get(IrisAdminConstants.EXECUTION_DATA);
		updateJobStatus(dbConnection, jobData);
		
		return null;
	}
	
	private void updateJobStatus (Connection dbConnection, EventProcessJob jobData) throws ExecutionException
	{
		PreparedStatement updateSt = null;
		int status = 0;
		ExecutionException eExp = null;
		String executionId = null;
		String jobStatus = null;
		String errorMsg = null;
		
		try
		{
			
			executionId = jobData.getJournalNmbr();
			jobStatus = jobData.getStatus();
			updateSt = dbConnection.prepareStatement(updateSql);
			updateSt.clearParameters();
			updateSt.setString(1, jobStatus);
			updateSt.setString(2, executionId);
			status = updateSt.executeUpdate();
			
			if (status < 0)
				logger.warn("Job:" + executionId + " record not available for status update");
			else if (logger.isTraceEnabled())
				logger.debug("Job:" + executionId + " Record status updated");
			dbConnection.commit();
		}
		catch (SQLException exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]
			{ errorMsg, updateSql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			errorMsg = "Not able to notify job Status:" + jobData.getStatus();
			eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]
			{ errorMsg, updateSql }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(updateSt);
		}
		
	}
	
}
