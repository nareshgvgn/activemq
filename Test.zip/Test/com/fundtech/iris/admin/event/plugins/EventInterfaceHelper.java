/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.plugins
 * FILE   : EventInterfaceHelper.java
 * CREATED: Oct 13, 2016 4:36:01 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.plugins;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.util.IRISLogger;
import com.dh.iris.admin.channels.iris.IDataObject;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.Identifier;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.SecurityProfile;
import com.fundtech.iris.admin.event.EventExecutionJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.exceptions.LoadingException;
import com.fundtech.iris.admin.util.FileUtils;
import com.fundtech.iris.admin.util.HelperUtils;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EventInterfaceHelper.java,v 1.2 2016/10/27 07:19:39 ramap Exp $
 */
public class EventInterfaceHelper extends IrisAdminPlugin
{
	private ApplicationContext applicationContext;
	private IDataObject dataObjectHelper = null;
	private Identifier procIdentifier = null;
	private String ftpProperty = null;
	private static Logger logger = LoggerFactory.getLogger(EventInterfaceHelper.class);
	
	public EventInterfaceHelper()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public ExecutionJobData execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		ActivatorHelper activatorHelper = null;
		Map<String, Object> inputParms = null;
		ExecutionJobData jobData = null;
		EventExecutionJob eventJob = null;
		ExecutionException eExp = null;
		String ftpPath = null;
		List<String> filesList = null;
		
		
		try
		{
			ftpPath = getFtpPath(dbConnection);
			eventJob = (EventExecutionJob) params.get(IrisAdminConstants.EVENT_EXECUTION_JOB);
			activatorHelper = new ActivatorHelper();
			activatorHelper.initialize(dbConnection, getApplicationContext());
			inputParms = new HashMap<String, Object>();
			inputParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, getProcIdentifier());
			inputParms.put(IrisAdminConstants.CHANNEL, IrisAdminConstants.MEDIA_EVENT_RQ);
			inputParms.put(IrisAdminConstants.EVENT_EXECUTION_JOB, eventJob);
			inputParms.put(IrisAdminConstants.MEDIA_DETAIL, ftpPath);
			inputParms.put(IrisAdminConstants.FILTER_PARMS, eventJob.getFilterParameters());
			inputParms.put(IrisAdminConstants.DATAOBJECT_HELPER, getDataObjectHelper());
			jobData = activatorHelper.runProcess(inputParms, IrisAdminConstants.MEDIA_EVENT_RQ, true, ftpPath);
			
			if (! isSecurityAttached(jobData))
			{
				filesList  = jobData.getSplitFileList();
				if ( filesList != null)
					jobData.setMediaDetails(ZipFile(filesList.get(0), eventJob));
			}
			return jobData;
		}
		catch ( ExecutionException exp)
		{
			throw exp;
		}
		catch ( Exception exp)
		{
			eExp = new ExecutionException("error.app.unknnown", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * @return
	 * </pre></p>
	 */
	private boolean isSecurityAttached (ExecutionJobData jobData)
	{
		SecurityProfile profile = null;
		
		profile = jobData.getInterfaceMap().getSecurityProfile();
		if ( profile == null)
			return false;
		
		if ( "P".equals(profile.getZipType()))
			return true;
		
		return false;
	}

	/**
	 * @return the applicationContext
	 */
	public ApplicationContext getApplicationContext ()
	{
		return applicationContext;
	}

	/**
	 * @param applicationContext the applicationContext to set
	 */
	public void setApplicationContext (ApplicationContext applicationContext)
	{
		this.applicationContext = applicationContext;
	}

	/**
	 * @return the dataObjectHelper
	 */
	public IDataObject getDataObjectHelper ()
	{
		return dataObjectHelper;
	}

	/**
	 * @param dataObjectHelper the dataObjectHelper to set
	 */
	public void setDataObjectHelper (IDataObject dataObjectHelper)
	{
		this.dataObjectHelper = dataObjectHelper;
	}

	/**
	 * @return the procIdentifier
	 */
	public Identifier getProcIdentifier ()
	{
		return procIdentifier;
	}

	/**
	 * @param procIdentifier the procIdentifier to set
	 */
	public void setProcIdentifier (Identifier procIdentifier)
	{
		this.procIdentifier = procIdentifier;
	}
	
	public String ZipFile (String orgFile, EventExecutionJob jobData) throws  ExecutionException
	{
		File file = null;
		ZipFile zipFile = null;
		ZipParameters parameters = null;
		String outFileName = null;
		ExecutionException eExp = null;
		
		try
		{
			if ( ! jobData.isZipRequired() || jobData.getPassword() == null)
				return orgFile;
			file = new File(orgFile);
			if ( ! file.isFile())
				return orgFile;
			
			outFileName = file.getParent() + File.separator + FileUtils.getBaseName(file.getName()) + ".zip";
			zipFile = new ZipFile(outFileName);
			parameters = new ZipParameters();
			parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
			parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
			parameters.setEncryptFiles(true);
			parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
			parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
			parameters.setPassword(jobData.getPassword());
			zipFile.addFile(file, parameters);
			file.delete();
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.event.zip", new Object[]{ orgFile }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		return outFileName;
	}
	
	private String getFtpPath (Connection dbConnection) throws LoadingException
	{
		String sql = "SELECT PARAMETER_VALUE FROM SYSTEM_PARAMETERS_MST WHERE PARAMETER_CODE =?";
		PreparedStatement statement = null;
		ResultSet rSet = null;
		File ftpFile = null;
		String ftpPath = null;
		LoadingException lExp = null;
		
		try
		{
			statement = dbConnection.prepareStatement(sql);
			statement.clearParameters();
			statement.setString(1, ftpProperty);
			rSet = statement.executeQuery();
			if (rSet.next())
			{
				ftpPath = rSet.getString("PARAMETER_VALUE");
				ftpFile = new File(ftpPath);
				ftpPath = ftpFile.getAbsolutePath();
			}
			else
			{
				lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "FTP path not found"}, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
		}
		catch (SQLException exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new LoadingException("error.admin.ftpPath", new Object[]{ "FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rSet);
			HelperUtils.doClose(statement);
			ftpFile = null;
		}
		
		return ftpPath;
	}

	/**
	 * @return the ftpProperty
	 */
	public String getFtpProperty ()
	{
		return ftpProperty;
	}

	/**
	 * @param ftpProperty the ftpProperty to set
	 */
	public void setFtpProperty (String ftpProperty)
	{
		this.ftpProperty = ftpProperty;
	}

	
}
