/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.plugins
 * FILE   : EventInterfacePlugin.java
 * CREATED: Oct 13, 2016 4:23:35 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.plugins;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.util.Map;

import javax.mail.MessagingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.channel.mail.IrisAdminMailService;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.event.EventExecutionJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EventInterfacePlugin.java,v 1.1 2016/10/19 14:04:55 ramap Exp $
 */
public class EventInterfacePlugin extends IrisAdminPlugin
{
	private final static String EVENT_INT_BEAN_NAME = "EVENT_INT_BEAN_NAME";
	public static final Logger logger = LoggerFactory.getLogger(EventInterfacePlugin.class);
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public EventInterfacePlugin()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		EventExecutionJob jobData = null;
		Map<String, String> staticProperties = null;
		String emailBeanName = null;
		ContextManager contextManager = null;
		IrisAdminMailService mailService = null;
		ExecutionException eExp = null;
		String attachmentName = null;
		String interfaceBeanName = null;
		IPlugin interfaceBean = null;
		ExecutionJobData intJobData = null;
		File file = null;
		
		try
		{
			jobData = (EventExecutionJob) params.get(IPlugin.EXECUTION_DATA);
			staticProperties = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			contextManager = ContextManager.getInstance();
			interfaceBeanName = staticProperties.get(EVENT_INT_BEAN_NAME);
			interfaceBean = (IPlugin) contextManager.getBeanObject(interfaceBeanName);
			params.put(IrisAdminConstants.EVENT_EXECUTION_JOB, jobData);
			intJobData = ( ExecutionJobData)  interfaceBean.execute(dbConnection, params);
			file = new File(intJobData.getMediaDetails());
			jobData.setIntJobData(intJobData);
			
			if ( !file.isFile() )
			{
				eExp = new ExecutionException("error.iris.admin.event.filenotgenerated", new Object[] {}, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
				
			emailBeanName = staticProperties.get(IPlugin.RESOURCE_BEAN_NAME);
			mailService = (IrisAdminMailService) contextManager.getBeanObject(emailBeanName);
			mailService.setFromAddress(jobData.getFromMailId());
			mailService.setToAddresses(jobData.getToEmailId());
			mailService.setSubject(jobData.getEmailSubject());
			mailService.setMessageBody(jobData.getEmailMessage());
			attachmentName = jobData.getOutFileName();
			mailService.sendMail();
			jobData.setStatus("C");
			
			
				
		}
		catch ( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (FileNotFoundException exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( BeanConfigException exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (MessagingException exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		catch (Exception exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			
			if ( attachmentName != null)
				cleanFile(attachmentName);
			
		}
		
		
		return null;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param attachmentName
	 * </pre></p>
	 */
	private void cleanFile (String attachmentName)
	{
		File file = null;
		
		try
		{
			file = new File(attachmentName);
			if ( file.exists())
				file.delete();
		}
		catch ( Exception exp)
		{
			logger.error("Not able to delete file", exp);
			// do not thorw this exception
		}
		
	}

}
