/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.plugins
 * FILE   : EventEmailWithAttchPlugin.java
 * CREATED: Dec 18, 2015 4:31:59 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.plugins;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.mail.MessagingException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminPlugin;
import com.fundtech.iris.admin.channel.mail.IrisAdminMailService;
import com.fundtech.iris.admin.event.EventExecutionJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EventEmailWithAttchPlugin.java,v 1.5 2016/10/19 14:04:55 ramap Exp $
 */
public class EventEmailWithAttchPlugin extends IrisAdminPlugin
{

	public static final Logger logger = LoggerFactory.getLogger(EventEmailWithAttchPlugin.class);
	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.functions.IFunction#execute(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		EventExecutionJob jobData = null;
		Map<String, String> staticProperties = null;
		String emailBeanName = null;
		ContextManager contextManager = null;
		IrisAdminMailService mailService = null;
		ExecutionException eExp = null;
		String servletURL = null;
		String reportURL = null;
		URL url = null;
		HttpURLConnection httpConnection = null;
		int responseCode = 0;
		String cType = null;
		int cntLen = -1;
		boolean isHtml = false;
		String outType = null;
		String paramString = null;
		String attachmentName = null;
		
		try
		{
			jobData = (EventExecutionJob) params.get(IPlugin.EXECUTION_DATA);
			paramString = jobData.getParamString();
			staticProperties = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			servletURL = staticProperties.get("ORACLE_REPORT_URL");
			
			if (servletURL != null)
			{
				reportURL = formatURL(servletURL, jobData, paramString);
				logger.debug("Report URL: {}", reportURL);
				url = new URL(reportURL);
				httpConnection = getHttpConnection(url);
				responseCode = httpConnection.getResponseCode();
				logger.info("ResponseCode:{}", responseCode);
				logger.info("Response Message:{}", httpConnection.getResponseMessage());
				if (responseCode != HttpURLConnection.HTTP_OK)
				{
					String error = "Report Execution Failed. For more details check report Server logs" + responseCode;
					eExp = new ExecutionException("err.app.reportExecutionFailed", new Object[] {error} , null);
					logger.error(IRISLogger.getText(eExp));
					throw eExp;
				}
				else
				{
					cType = httpConnection.getContentType();
					cntLen = httpConnection.getContentLength();
					outType = "pdf";
					
					if ("HTML".equals(outType))
						isHtml = true;
					
					if (cntLen > 0)
						logger.info("Expecting {} bytes in response!", Integer.valueOf(cntLen));
					
					if ((!isHtml && (cType != null && cType.startsWith("text/html")) || null == cType))
					{
						writeFile(httpConnection, jobData, true);
						jobData.setStatus("E");
						logger.error("Error while generatinng report. Please check:" + jobData.getOutFileName() + ".html");
						eExp = new ExecutionException("error.iris.admin.errorreport", new Object[]{ jobData.getOutFileName() }, null);
						logger.error(IRISLogger.getText(eExp));
						throw eExp;
					}
					else
						writeFile(httpConnection, jobData, false);
				}
				
				emailBeanName = staticProperties.get(IPlugin.RESOURCE_BEAN_NAME);
				contextManager = ContextManager.getInstance();
				mailService = (IrisAdminMailService) contextManager.getBeanObject(emailBeanName);
				mailService.setFromAddress(jobData.getFromMailId());
				mailService.setToAddresses(jobData.getToEmailId());
				mailService.setSubject(jobData.getEmailSubject());
				mailService.setMessageBody(jobData.getEmailMessage());
				attachmentName = jobData.getOutFileName();
				mailService.sendMail(attachmentName);
				jobData.setStatus("C");
			}
		}
		catch ( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (FileNotFoundException exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( BeanConfigException exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (MessagingException exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (MalformedURLException exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IOException exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception exp)
		{
			jobData.setStatus("E");
			eExp = new ExecutionException("error.iris.admin.event.whilesendingemail", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			if (httpConnection != null)
				httpConnection.disconnect();
			httpConnection = null;
			
			if ( attachmentName != null)
				cleanFile(attachmentName);
			
			
		}
		
		
		return null;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param attachmentName
	 * </pre></p>
	 */
	private void cleanFile (String attachmentName)
	{
		File file = null;
		
		try
		{
			file = new File(attachmentName);
			if ( file.exists())
				file.delete();
		}
		catch ( Exception exp)
		{
			logger.error("Not able to delete file", exp);
			// do not thorw this exception
		}
		
	}

	private String getDbConnectionString (EventExecutionJob jobData)
	{
		String userId = null;
		String dbPass = null;
		String serverName = null;
		String connectionString = null;
		
		userId = jobData.getDbUser();
		dbPass = jobData.getDbPass();
		serverName = jobData.getRepDdUrl();
		if (serverName == null)
			serverName = jobData.getDbUrl();
		
		connectionString = "userid=" + IrisAdminUtils.encode(userId) + "/" + IrisAdminUtils.encode(dbPass) + "@" + IrisAdminUtils.encode(serverName);
		return connectionString;
	}
	
	private String setOracleParams (EventExecutionJob jobData, String paramString) throws ExecutionException
	{
		StringBuilder tempStr = null;
		String defaultValue = null;
		ExecutionException nodeExp = null;
		String parmCode = null;
		
		try
		{
			tempStr = new StringBuilder();
			tempStr.append(paramString);
			defaultValue = jobData.getReportLanguage();
			defaultValue = IrisAdminUtils.getCorrectLocale(defaultValue);
			parmCode = "ENVID";
			tempStr.append("&" + parmCode + "=" + IrisAdminUtils.encode(defaultValue));
			
			parmCode = "CUSTOMIZE";
			defaultValue = jobData.getReportCode() + "_"+ defaultValue + ".xml";
			tempStr.append("&" + parmCode + "=" + IrisAdminUtils.encode(defaultValue));
			return tempStr.toString();
		}
		catch (Exception e)
		{
			nodeExp = new ExecutionException("error.rm.CreateReportParameters", new Object[]
			{ "process_hooks", }, e);
			logger.error(IRISLogger.getText(nodeExp));
			throw nodeExp;
		}
		finally
		{
		}
	}
	
	/**
	 * The purpose of this method is to form the report file name.
	 * 
	 * @param dataObject
	 * @return
	 * @throws NodeProcessingException
	 */
	private String getReportFileName (EventExecutionJob jobData, String fileNameExtn) throws ExecutionException
	{
		String time = null;
		String sysDate = null;
		String fileName = null;
		String entityCode = null;
		String reportCode = null;
		String executionId = null;
		File file = null;
		ExecutionException eExp = null;
		
		try
		{
			// sysDate = getFormatedDateTime("yyMMdd", getDate(jobData.getSysParameter(IrisAdminConstants.SYS_APP_DATE)));
			sysDate = getFormatedDateTime("yyMMdd", Calendar.getInstance().getTime());
			time = getFormatedDateTime("hhmmss", new Date(System.currentTimeMillis()));
			executionId = jobData.getJournalNmbr();
			entityCode = jobData.getEntityCode();
			reportCode = jobData.getEventName();
			
			// Replace Spaces and brackets from EntityCode
			if (entityCode != null)
			{
				entityCode = entityCode.replace('(', '_');
				entityCode = entityCode.replace(')', '_');
				entityCode = entityCode.replaceAll(" ", "");
			}
			else
			{
				entityCode = "";
			}
			
			String tDir = System.getProperty("java.io.tmpdir");
			File dir = new File(tDir);
			fileName = entityCode + reportCode + sysDate + time + "_" + executionId  + "." + fileNameExtn;
			file = new File(dir, fileName);
			jobData.setOutFileName(file.getAbsolutePath());
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.genFileName", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			time = null;
			sysDate = null;
			reportCode = null;
		}
		return fileName;
	}
	
	private String getFormatedDateTime (String format, java.util.Date date)
	{
		SimpleDateFormat dateformatter = new SimpleDateFormat(format);
		return dateformatter.format(date);
		
	}
	
	/**
	 * <p>This helper formats the URL
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param reportURL
	 * @param jobData
	 * @param paramString
	 * @return
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private String formatURL (String reportURL, EventExecutionJob jobData, String paramString) throws ExecutionException
	{
		StringBuilder sBuffer = null;
		String objConnectString = null;
		String pdfPass = null;
		ExecutionException eExp = null;
		String fileName = null;
		String output = null;
		
		try
		{
			sBuffer = new StringBuilder();
			sBuffer.append("cmdkey=");
			sBuffer.append(IrisAdminUtils.encode(jobData.getReportCode()));
			sBuffer.append("&desformat=PDF&destype=FILE&");
			fileName = getReportFileName(jobData,"pdf");
			
			if ( jobData.isPDFPasswordRequired())
				pdfPass = jobData.getPassword();
			if (!StringUtils.isEmpty(pdfPass))
			{
				if (logger.isInfoEnabled())
					logger.info("User password is supplied, will password protect the PDF!");
				sBuffer.append("PDFUSER");
				sBuffer.append("=");
				sBuffer.append(pdfPass);
				sBuffer.append("&");
			}
			sBuffer.append(setOracleParams(jobData, paramString));
			objConnectString = getDbConnectionString(jobData);
			sBuffer.append("&");
			sBuffer.append(objConnectString);
			output  = reportURL + "?" + sBuffer.toString();
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.formattingURL", new Object[]{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(sBuffer);
		}
		
		return output;
	}
	
	/**
	 * <p>This helper method creates http connection
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param url
	 * @return
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private HttpURLConnection getHttpConnection (URL url) throws ExecutionException
	{
		HttpURLConnection httpConnection = null;
		ExecutionException eExp = null;
		try
		{
			httpConnection = (HttpURLConnection) url.openConnection();
			httpConnection.setRequestMethod("GET");
			httpConnection.setDoOutput(true);
			httpConnection.setConnectTimeout(10000);
			httpConnection.setReadTimeout(1000000);
			httpConnection.connect();
		}
		catch (SocketTimeoutException ex)
		{
			eExp = new ExecutionException("error.iris.admin.report.HTTPConnectionTimeout", new Object[] {}, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (IOException ex)
		{
			eExp = new ExecutionException("error.iris.admin.report.createHTTPConnection", new Object[] {}, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.report.unknown", new Object[] {}, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
		return httpConnection;
	}
	
	/**
	 * <p> This helper method create report file in temp  location
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param httpConnection
	 * @param jobData
	 * @param isError
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private void writeFile (HttpURLConnection httpConnection, EventExecutionJob jobData, boolean isError) throws ExecutionException
	{
		FileOutputStream outStream = null;
		BufferedOutputStream out = null;
		InputStream in = null;
		ExecutionException eExp = null;
		String fileName = null;
		try
		{
			in = httpConnection.getInputStream();
			fileName = jobData.getOutFileName();
			if ( isError)
				fileName = fileName + ".html";
			
			outStream = new FileOutputStream(fileName);
			out = new BufferedOutputStream(outStream);
			int i = 0;
			while ((i = in.read()) != -1)
			{
				out.write(i);
				out.flush();
			}
		}
		catch (Exception ex)
		{
			eExp = new ExecutionException("error.iris.admin.reort.writetoFile", new Object[]
			{ jobData.toString() }, ex);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(in);
			HelperUtils.doClose(out);
			HelperUtils.doClose(outStream);
		}
	}
}
