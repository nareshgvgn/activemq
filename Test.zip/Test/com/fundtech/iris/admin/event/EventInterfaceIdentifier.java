/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event
 * FILE   : EventInterfaceIdentifier.java
 * CREATED: Oct 17, 2016 5:08:51 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event;

import java.util.HashMap;
import java.util.Map;

import com.cashtech.iris.exceptions.ConfigurationException;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.Identifier;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EventInterfaceIdentifier.java,v 1.1 2016/10/19 14:04:55 ramap Exp $
 */
public class EventInterfaceIdentifier implements Identifier
{
	private Map<String, String> properties = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public EventInterfaceIdentifier()
	{
		
	}
	
	/**
	 * @param parameters
	 *            the parameters to set
	 */
	public void setProperties (Map<String, String> properties)
	{
		this.properties = properties;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.spring.Identifier#initialize()
	 */
	@Override
	public void initialize () throws ConfigurationException
	{
		// BABU Auto-generated method stub
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.spring.Identifier#identify(java.lang.Object)
	 */
	@Override
	public Map<String, String> identify (Object source) throws ExecutionException
	{
		Map<String, String> outData = null;
		String mapName = null;
		String processName = null;
		String entityType = null;
		String entityCode = null;
		EventExecutionJob eventJob = null;
		Map<String, Object> sourceData = null;
		
		sourceData = (Map<String, Object>) source;
		eventJob = (EventExecutionJob) sourceData.get(IrisAdminConstants.EVENT_EXECUTION_JOB);
		
		processName = properties.get("ExecuteIRISProcess");
		mapName = eventJob.getMapCode();
		entityType = eventJob.getEntityType();
		entityCode = eventJob.getEntityCode();
		outData = new HashMap<String, String>();
		outData.put(IrisAdminConstants.MAP_NAME, mapName);
		outData.put(IrisAdminConstants.ENTITY_TYPE, entityType);
		outData.put(IrisAdminConstants.ENTITY_CODE, entityCode);
		outData.put(IrisAdminConstants.EXECUTE_PROCESS, processName);
		
		return outData;
	}
	
}
