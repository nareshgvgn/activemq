/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.event.data
 * FILE   : EventProcessJob.java
 * CREATED: Mar 18, 2014 3:36:55 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fundtech.iris.admin.event.data.DataFormatValue;
import com.fundtech.iris.admin.event.data.EventDef;
import com.fundtech.iris.admin.event.data.IRecipient;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: EventProcessJob.java,v 1.5 2016/10/27 09:01:16 ramap Exp $
 */
public class EventProcessJob implements EventJob
{
	private int txnCode = 0;
	private String notificationId="0";
	private String journalNmbr = null;
	private String eventDate = null;
	private String eventSource = null;
	private String eventName = null;
	private String tableName = null;
	private String clientCode = null;
	private String sellerCode = null;
	private String coordinatorCode = null;
	private String corpCode = null;
	private String courierCode = null;
	private String dispatchBankCode = null;
	private String beneficiaryCode = null;
	private String drawerCode = null;
	private String emailId = null;
	private String mobile = null;
	private String fax = null;
	private String adhocEmailId = null;
	private String adhocMobile = null;
	private String adhocFax = null;
	private String makerCode = null;
	private String formId = null;
	private int formWeight = -1 ;
	private String rowKeyField = null;
	private String confidential_flag = null;
	private String erType = null;
	private Map<String, DataFormatValue> valueMap = new HashMap<String, DataFormatValue>();
	private Map<String, String> reportParameters = new HashMap<String, String>();
	private Map<String, String> intParameters = new HashMap<String, String>();
	private Map<String, Object> dataMappings = new HashMap<String, Object>();
	private EventDef eventDef = null;
	private String status = null;
	
	private Map<String, List<IRecipient>> probableRecipients = new HashMap<String, List<IRecipient>>();
	
	/**
	 * @return the journalNmbr
	 */
	public String getJournalNmbr ()
	{
		return journalNmbr;
	}
	
	/**
	 * @param journalNmbr
	 *            the journalNmbr to set
	 */
	public void setJournalNmbr (String journalNmbr)
	{
		this.journalNmbr = journalNmbr;
	}
	
	/**
	 * @return the eventSource
	 */
	public String getEventSource ()
	{
		return eventSource;
	}
	
	/**
	 * @param eventSource
	 *            the eventSource to set
	 */
	public void setEventSource (String eventSource)
	{
		this.eventSource = eventSource;
	}
	
	/**
	 * @return the eventName
	 */
	public String getEventName ()
	{
		return eventName;
	}
	
	/**
	 * @param eventName
	 *            the eventName to set
	 */
	public void setEventName (String eventName)
	{
		this.eventName = eventName;
	}
	
	/**
	 * @return the tableName
	 */
	public String getTableName ()
	{
		return tableName;
	}
	
	/**
	 * @param tableName
	 *            the tableName to set
	 */
	public void setTableName (String tableName)
	{
		this.tableName = tableName;
	}
	
	/**
	 * @return the clientCode
	 */
	public String getClientCode ()
	{
		return clientCode;
	}
	
	/**
	 * @param clientCode
	 *            the clientCode to set
	 */
	public void setClientCode (String clientCode)
	{
		this.clientCode = clientCode;
	}
	
	/**
	 * @return the sellerCode
	 */
	public String getSellerCode ()
	{
		return sellerCode;
	}
	
	/**
	 * @param sellerCode
	 *            the sellerCode to set
	 */
	public void setSellerCode (String sellerCode)
	{
		this.sellerCode = sellerCode;
	}
	
	/**
	 * @return the coordinatorCode
	 */
	public String getCoordinatorCode ()
	{
		return coordinatorCode;
	}
	
	/**
	 * @param coordinatorCode
	 *            the coordinatorCode to set
	 */
	public void setCoordinatorCode (String coordinatorCode)
	{
		this.coordinatorCode = coordinatorCode;
	}
	
	/**
	 * @return the courierCode
	 */
	public String getCourierCode ()
	{
		return courierCode;
	}
	
	/**
	 * @param courierCode
	 *            the courierCode to set
	 */
	public void setCourierCode (String courierCode)
	{
		this.courierCode = courierCode;
	}
	
	/**
	 * @return the dispatchBankCode
	 */
	public String getDispatchBankCode ()
	{
		return dispatchBankCode;
	}
	
	/**
	 * @param dispatchBankCode
	 *            the dispatchBankCode to set
	 */
	public void setDispatchBankCode (String dispatchBankCode)
	{
		this.dispatchBankCode = dispatchBankCode;
	}
	
	/**
	 * @return the beneficiaryCode
	 */
	public String getBeneficiaryCode ()
	{
		return beneficiaryCode;
	}
	
	/**
	 * @param beneficiaryCode
	 *            the beneficiaryCode to set
	 */
	public void setBeneficiaryCode (String beneficiaryCode)
	{
		this.beneficiaryCode = beneficiaryCode;
	}
	
	/**
	 * @return the drawerCode
	 */
	public String getDrawerCode ()
	{
		return drawerCode;
	}
	
	/**
	 * @param drawerCode
	 *            the drawerCode to set
	 */
	public void setDrawerCode (String drawerCode)
	{
		this.drawerCode = drawerCode;
	}
	
	/**
	 * @return the emailId
	 */
	public String getEmailId ()
	{
		return emailId;
	}
	
	/**
	 * @param emailId
	 *            the emailId to set
	 */
	public void setEmailId (String emailId)
	{
		this.emailId = emailId;
	}
	
	/**
	 * @return the mobile
	 */
	public String getMobile ()
	{
		return mobile;
	}
	
	/**
	 * @param mobile
	 *            the mobile to set
	 */
	public void setMobile (String mobile)
	{
		this.mobile = mobile;
	}
	
	/**
	 * @return the fax
	 */
	public String getFax ()
	{
		return fax;
	}
	
	/**
	 * @param fax
	 *            the fax to set
	 */
	public void setFax (String fax)
	{
		this.fax = fax;
	}
	
	/**
	 * @return the adhocEmailId
	 */
	public String getAdhocEmailId ()
	{
		return adhocEmailId;
	}
	
	/**
	 * @param adhocEmailId
	 *            the adhocEmailId to set
	 */
	public void setAdhocEmailId (String adhocEmailId)
	{
		this.adhocEmailId = adhocEmailId;
	}
	
	/**
	 * @return the adhocMobile
	 */
	public String getAdhocMobile ()
	{
		return adhocMobile;
	}
	
	/**
	 * @param adhocMobile
	 *            the adhocMobile to set
	 */
	public void setAdhocMobile (String adhocMobile)
	{
		this.adhocMobile = adhocMobile;
	}
	
	/**
	 * @return the adhocFax
	 */
	public String getAdhocFax ()
	{
		return adhocFax;
	}
	
	/**
	 * @param adhocFax
	 *            the adhocFax to set
	 */
	public void setAdhocFax (String adhocFax)
	{
		this.adhocFax = adhocFax;
	}
	
	/**
	 * @return the makerCode
	 */
	public String getMakerCode ()
	{
		return makerCode;
	}
	
	/**
	 * @param makerCode
	 *            the makerCode to set
	 */
	public void setMakerCode (String makerCode)
	{
		this.makerCode = makerCode;
	}
	
	/**
	 * @return the formId
	 */
	public String getFormId ()
	{
		return formId;
	}
	
	/**
	 * @param formId
	 *            the formId to set
	 */
	public void setFormId (String formId)
	{
		this.formId = formId;
	}
	
	/**
	 * @return the rowKeyField
	 */
	public String getRowKeyField ()
	{
		return rowKeyField;
	}
	
	/**
	 * @param rowKeyField
	 *            the rowKeyField to set
	 */
	public void setRowKeyField (String rowKeyField)
	{
		this.rowKeyField = rowKeyField;
	}
	
	/**
	 * @return the confidential_flag
	 */
	public String getConfidential_flag ()
	{
		return confidential_flag;
	}
	
	/**
	 * @param confidential_flag
	 *            the confidential_flag to set
	 */
	public void setConfidential_flag (String confidential_flag)
	{
		this.confidential_flag = confidential_flag;
	}
	
	/**
	 * @return the erType
	 */
	public String getErType ()
	{
		return erType;
	}
	
	/**
	 * @param erType
	 *            the erType to set
	 */
	public void setErType (String erType)
	{
		this.erType = erType;
	}
	
	/**
	 * @return the eventDef
	 */
	public EventDef getEventDef ()
	{
		return eventDef;
	}
	
	/**
	 * @param eventDef
	 *            the eventDef to set
	 */
	public void setEventDef (EventDef eventDef)
	{
		this.eventDef = eventDef;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus ()
	{
		return status;
	}
	
	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus (String status)
	{
		this.status = status;
	}
	
	/**
	 * @return the probableRecipients
	 */
	public Map<String, List<IRecipient>> getProbableRecipients ()
	{
		return probableRecipients;
	}
	
	/**
	 * @param probableRecipients
	 *            the probableRecipients to set
	 */
	public void setProbableRecipients (Map<String, List<IRecipient>> probableRecipients)
	{
		this.probableRecipients = probableRecipients;
	}
	
	/**
	 * 
	 * @see java.util.Map#clear()
	 */
	public void clearProbableRecipients ()
	{
		probableRecipients.clear();
	}
	
	/**
	 * @param key
	 * @return
	 * @see java.util.Map#containsKey(java.lang.Object)
	 */
	public boolean containsProbableRecipient (Object key)
	{
		return probableRecipients.containsKey(key);
	}
	
	/**
	 * @param key
	 * @return
	 * @see java.util.Map#get(java.lang.Object)
	 */
	public List<?> getProbableRecipient (Object key)
	{
		return probableRecipients.get(key);
	}
	
	/**
	 * @param key
	 * @param value
	 * @return
	 * @see java.util.Map#put(java.lang.Object, java.lang.Object)
	 */
	public List<?> addtProbableRecipient (String key, List<IRecipient> value)
	{
		return probableRecipients.put(key, value);
	}
	
	/**
	 * @return the valueMap
	 */
	public Map<String, DataFormatValue> getDataFormatValues ()
	{
		return valueMap;
	}
	
	/**
	 * @param valueMap
	 *            the valueMap to set
	 */
	public void setDataFormatValues (Map<String, DataFormatValue> valueMap)
	{
		this.valueMap = valueMap;
	}
	
	/**
	 * @param valueMap
	 *            the valueMap to set
	 */
	public void addDataFormatValue (String key, DataFormatValue value)
	{
		this.valueMap.put(key, value);
	}
	
	public DataFormatValue getDataFormatValue (String key)
	{
		return valueMap.get(key);
	}
	
	/**
	 * @return the reportParameters
	 */
	public Map<String, String> getReportParameters ()
	{
		return reportParameters;
	}
	
	/**
	 * @return the intParameters
	 */
	public Map<String, String> getIntParameters ()
	{
		return intParameters;
	}
	
	/**
	 * @param reportParameters
	 *            the reportParameters to set
	 */
	public void setReportParameters (Map<String, String> reportParameters)
	{
		this.reportParameters = reportParameters;
	}
	
	public void setIntParameters (Map<String, String>intParameters)
	{
		this.intParameters = intParameters;
	}
	
	public void addReportParameter(String key, String value)
	{
		reportParameters.put(key, value);
	}
	
	public void addIntParameter(String key, String value)
	{
		intParameters.put(key, value);
	}
	
	/**
	 * @return the dataMappings
	 */
	public Map<String, Object> getDataMappings ()
	{
		return dataMappings;
	}
	
	/**
	 * @return the dataMappings
	 */
	public Object getDataMappingValue(String key)
	{
		return dataMappings.get(key);
	}
	
	/**
	 * @param dataMappings
	 *            the dataMappings to set
	 */
	public void setDataMappings (Map<String, Object> dataMappings)
	{
		this.dataMappings = dataMappings;
	}
	
	public void addDataMapping (String key, Object dataMapping)
	{
		this.dataMappings.put(key, dataMapping);
	}
	
	/**
	 * @return the eventDate
	 */
	public String getEventDate ()
	{
		return eventDate;
	}
	
	/**
	 * @param eventDate
	 *            the eventDate to set
	 */
	public void setEventDate (String eventDate)
	{
		this.eventDate = eventDate;
	}
	
	/**
	 * @return the corpCode
	 */
	public String getCorpCode ()
	{
		return corpCode;
	}
	
	/**
	 * @param corpCode
	 *            the corpCode to set
	 */
	public void setCorpCode (String corpCode)
	{
		this.corpCode = corpCode;
	}

	/**
	 * @return the formWeight
	 */
	public int getFormWeight ()
	{
		return formWeight;
	}

	/**
	 * @param formWeight the formWeight to set
	 */
	public void setFormWeight (int formWeight)
	{
		this.formWeight = formWeight;
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.event.EventJob#cleanup()
	 */
	@Override
	public void cleanup ()
	{
		journalNmbr = null;
		eventDate = null;
		eventSource = null;
		eventName = null;
		tableName = null;
		clientCode = null;
		sellerCode = null;
		coordinatorCode = null;
		corpCode = null;
		courierCode = null;
		dispatchBankCode = null;
		beneficiaryCode = null;
		drawerCode = null;
		emailId = null;
		mobile = null;
		fax = null;
		adhocEmailId = null;
		adhocMobile = null;
		adhocFax = null;
		makerCode = null;
		formId = null;
		formWeight = -1 ;
		rowKeyField = null;
		confidential_flag = null;
		erType = null;
		status = null;
		eventDef = null;
		CleanUpUtils.doClean(valueMap);
		CleanUpUtils.doClean(reportParameters);
		CleanUpUtils.doClean(dataMappings);
		CleanUpUtils.doClean(probableRecipients);
	}

	/**
	 * @return the txnCode
	 */
	public int getTxnCode ()
	{
		return txnCode;
	}

	/**
	 * @param txnCode the txnCode to set
	 */
	public void setTxnCode (int txnCode)
	{
		this.txnCode = txnCode;
	}

	/**
	 * @return the notificationId
	 */
	public String getNotificationId ()
	{
		return notificationId;
	}

	/**
	 * @param notificationId the notificationId to set
	 */
	public void setNotificationId (String notificationId)
	{
		this.notificationId = notificationId;
	}

}
