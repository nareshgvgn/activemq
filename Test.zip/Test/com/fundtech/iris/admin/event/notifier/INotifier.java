/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.execution
 * FILE   : INotifier.java
 * CREATED: Jul 11, 2014 7:57:37 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.notifier;

import java.util.Map;

import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import java.io.Closeable;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: INotifier.java,v 1.8 2016/10/19 14:04:55 ramap Exp $
 */
public interface INotifier extends Closeable
{
	public final static String NOTOFICATION_ID = "NOTOFICATION_ID";
	public final static String EVENT_JOURNAL_NMBR = "EVENT_JOURNAL_NMBR";
	public final static String EVENT_NAME = "EVENT_NAME";
	public final static String EVENT_SOURCE = "EVENT_SOURCE";
	public final static String EVENT_DATE = "EVENT_DATE";
	public final static String RECIPIENT_NAME = "RECIPIENT_NAME";
	public final static String ENTITY_CODE = "ENTITY_CODE";
	public final static String CLIENT_CODE = "CLIENT_CODE";
	public final static String SUBJECT = "SUBJECT";
	public final static String MESSAGE = "MESSAGE";
	public final static String FROM_MAIL_ID = "FROM_MAIL_ID";
	public final static String TO_EMAIL_ID = "TO_EMAIL_ID";
	public final static String CC_EMAIL_ID = "CC_EMAIL_ID";
	public final static String BCC_EMAIL_ID = "BCC_EMAIL_ID";
	public final static String SCREEN_NAME = "SCREEN_NAME";
	public final static String REMARKS = "REMARKS";
	public final static String SENDER_NAME = "SENDER_NAME";
	public final static String SENDER_NMBR = "SENDER_NMBR";
	public final static String RECIPIENT_NMBR = "RECIPIENT_NMBR";
	public final static String SUBSCRIPTION_NAME = "SUBSCRIPTION_NAME";
	public static final String REPORT_CODE = "REPORT_CODE";
	public static final String MAP_CODE = "MAP_CODE";
	public static final String INT_PARMS = "INT_PARMS";
	public static final String REPORT_PARMS = "REPORT_PARMS";
	public static final String REPORT_LANGUAGE = "REPORT_LANGUAGE";
	public static final String ZIP_REQUIRED = "ZIP_REQUIRED";
	public static final String PDF_PASS_REQUIRED = "PDF_PASS_REQUIRED";
	public static final String PASSWORD = "PASSWORD";
	
	public Object notify (Map<String, String> data, EventProcessJob jobData) throws ExecutionException;
}
