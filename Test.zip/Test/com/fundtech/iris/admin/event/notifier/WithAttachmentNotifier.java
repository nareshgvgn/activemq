/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.notifier
 * FILE   : WithAttachmentNotifier.java
 * CREATED: Dec 16, 2015 11:14:47 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.notifier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: WithAttachmentNotifier.java,v 1.6 2016/10/28 09:15:49 ramap Exp $
 */
public class WithAttachmentNotifier extends AbstractNotifier
{
	private Logger logger = LoggerFactory.getLogger(WithAttachmentNotifier.class);
	private final static String attachSQL = "insert into EVENT_ATTACHMENT_NOTIFICATION (NOTOFICATION_ID, EVENT_JOURNAL_NMBR, EVENT_DATE, EVENT_NAME, EVENT_SOURCE, "
			+ " RECIPIENT_NAME, ENTITY_CODE, CLIENT_CODE, ATTACHMENT_SUBJECT, ATTACHMENT_MESSAGE, REPORT_CODE, REPORT_PARAMETER, REPORT_LANGUAGE, FROM_MAIL_ID, "
			+ " TO_EMAIL_ID, CC_EMAIL_ID, BCC_EMAIL_ID, STATUS, CREATED_DATE, SUBSCRIPTION_NAME, PASSWORD_FLAG , PDF_PASSWORD) "
			+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'N', SYSDATE, ?,?,?)";
	
	private Connection dbConnection = null;
	private PreparedStatement attachStmt = null;
	
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public WithAttachmentNotifier(Connection dbConnection)
	{
		this.dbConnection = dbConnection;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.INotifier#notify(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object notify (Map<String, String> params, EventProcessJob jobData) throws ExecutionException
	{
		String tempMessage = null;
		String tempSubject = null;
		String subject = null;
		String message = null;
		String repParms = null;
		String isPDFPasswordRequired = null;
		String pdfPassword = null;
		try
		{
			isPDFPasswordRequired = params.get(INotifier.PDF_PASS_REQUIRED);
			if ( IrisAdminConstants.CONSTANT_Y.equals(isPDFPasswordRequired))
				pdfPassword = getPasswordValues(jobData, params.get(INotifier.PASSWORD));
			
			tempMessage = params.get(INotifier.MESSAGE);
			tempSubject = params.get(INotifier.SUBJECT);
			message = getMessageTemplateWithValues(jobData, tempMessage);
			subject = getSubjectWithValues(jobData, tempSubject);
			repParms = getReportParameter(jobData);
			params.put(INotifier.PASSWORD, pdfPassword);
			params.put(INotifier.REPORT_PARMS, repParms);
			params.put(INotifier.MESSAGE, message);
			params.put(INotifier.SUBJECT, subject);
			insertRecord(params);
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (Exception e)
		{
			jobData.setStatus("E");
			ExecutionException eExp = null;
			eExp = new ExecutionException("error.iris.admin.event.insertemail", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		return null;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @param message
	 * @param subject
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @throws ExecutionException
	 */
	private void insertRecord (Map<String, String> params) throws ExecutionException
	{
		
		try
		{
			if (attachStmt == null)
				attachStmt = dbConnection.prepareStatement(attachSQL);
			
			attachStmt.clearParameters();
			attachStmt.setInt(1, Integer.parseInt(params.get(INotifier.NOTOFICATION_ID)));
			attachStmt.setString(2, params.get(INotifier.EVENT_JOURNAL_NMBR));
			attachStmt.setString(3, params.get(INotifier.EVENT_DATE));
			attachStmt.setString(4, params.get(INotifier.EVENT_NAME));
			attachStmt.setString(5, params.get(INotifier.EVENT_SOURCE));
			attachStmt.setString(6, params.get(INotifier.RECIPIENT_NAME)); // recipient Name
			attachStmt.setString(7, params.get(INotifier.ENTITY_CODE));// entity code
			attachStmt.setString(8, params.get(INotifier.CLIENT_CODE));
			attachStmt.setString(9, params.get(INotifier.SUBJECT));
			attachStmt.setString(10, params.get(INotifier.MESSAGE));
			attachStmt.setString(11, params.get(INotifier.REPORT_CODE));
			attachStmt.setString(12, params.get(INotifier.REPORT_PARMS));
			attachStmt.setString(13, params.get(INotifier.REPORT_LANGUAGE));
			attachStmt.setString(14, params.get(INotifier.FROM_MAIL_ID)); // FROM_ID
			attachStmt.setString(15, params.get(INotifier.TO_EMAIL_ID)); // TO
			attachStmt.setString(16, params.get(INotifier.CC_EMAIL_ID)); // CC
			attachStmt.setString(17, params.get(INotifier.BCC_EMAIL_ID)); // BCC 
			attachStmt.setString(18, params.get(INotifier.SUBSCRIPTION_NAME)); // SUBSCRIPTION_NAME
			attachStmt.setString(19, params.get(INotifier.PDF_PASS_REQUIRED)); // zip required 
			attachStmt.setString(20, params.get(INotifier.PASSWORD)); // zip password
			attachStmt.executeUpdate();
		}
		catch (SQLException e)
		{
			ExecutionException eExp = null;
			eExp = new ExecutionException("error.iris.admin.event.insertemail", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.INotifier#cleanup()
	 */
	@Override
	public void close ()
	{
		HelperUtils.doClose(attachStmt);
		attachStmt = null;
	}
	
}
