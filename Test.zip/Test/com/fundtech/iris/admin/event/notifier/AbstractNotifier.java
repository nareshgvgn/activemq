/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.execution
 * FILE   : AbstractNotifier.java
 * CREATED: Jul 11, 2014 8:00:05 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.notifier;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.event.data.DataAttribute;
import com.fundtech.iris.admin.event.data.DataFormatValue;
import com.fundtech.iris.admin.event.data.EventDataMapping;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: AbstractNotifier.java,v 1.12 2016/10/28 09:15:49 ramap Exp $
 */
public abstract class AbstractNotifier implements INotifier
{
	private Logger logger = LoggerFactory.getLogger(AbstractNotifier.class);
	
	/**
	 * @see com.cashtech.iris.event.media.NotificationMedia#getMessageTemplateWithValues(com.cashtech.iris.core.processor.Packet,
	 *      com.cashtech.iris.event.data.Event)
	 */
	public String getMessageTemplateWithValues (EventProcessJob jobData, String messageTemplate) throws ExecutionException
	{
		String replacableKey = null;
		int currIndex = 0;
		int fromIndex = 0;
		DataFormatValue dataFormatValue = null;
		String valueConfidential = null;
		String dataType = null;
		String mask = null;
		
		while (currIndex != -1)
		{
			currIndex = messageTemplate.indexOf('<', fromIndex);
			if (currIndex >= 0)
			{
				replacableKey = messageTemplate.substring(currIndex + 1, messageTemplate.indexOf('>', currIndex));
				valueConfidential = messageTemplate.substring(currIndex, messageTemplate.indexOf('>', currIndex) + 1);
				
				Object value = null;
				dataFormatValue = jobData.getDataFormatValue(replacableKey);
				if (dataFormatValue != null)
				{
					value = dataFormatValue.getValue();
					if (value != null)
					{
						mask =  dataFormatValue.getMask();
						dataType = dataFormatValue.getDataType();
						if (dataType.equals("Date") || dataType.equals("Timestamp"))
						{
							String format = dataFormatValue.getFormat();
							if (format != null)
							{
								SimpleDateFormat dateFormat = new SimpleDateFormat(format);
								value = dateFormat.format(value);
							}
							else
							{
								SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
								value = dateFormat.format(value);
								if (logger.isDebugEnabled())
									logger.debug("Format not Specified. So using a Default Format for Date :: " + value);
							}
						}
						else if (dataType.equals("BigDecimal") && !valueConfidential.trim().equalsIgnoreCase("-CONFIDENTIAL-"))
						{
							String format = dataFormatValue.getFormat();
							if (format != null)
							{
								NumberFormat numberFormat = new DecimalFormat(format);
								value = numberFormat.format(value);
							}
						}
						
						value = maskValue(mask, dataType, value, IrisAdminConstants.CONSTANT_N);
						messageTemplate = messageTemplate.replace(messageTemplate.substring(currIndex, messageTemplate.indexOf('>', currIndex) + 1),
								String.valueOf(value));
						fromIndex = currIndex;
						
					}
					else
					{
						messageTemplate = messageTemplate.replace(messageTemplate.substring(currIndex, messageTemplate.indexOf('>', currIndex) + 1),
								"");
						
						logger.error("No value found in event for : " + replacableKey + " therefore replacing by space");
						// Incrementing the fromIndex by 1....so that it does not return the same key
						// fromIndex = currIndex + 1;
						fromIndex = currIndex;
					}
				}
				else
				{
					
					messageTemplate = messageTemplate.replace(messageTemplate.substring(currIndex, messageTemplate.indexOf('>', currIndex) + 1), "");
					
					logger.error("No mapping found for : " + replacableKey + " therefore replacing by space. "
							+ "Please check if the display names match");
					
					// Incrementing the fromIndex by 1....so that it does not return the same key
					// fromIndex = currIndex + 1;
					fromIndex = currIndex;
					
				}
			}
		}
		
		return messageTemplate;
	}
	
	
	/**
	 * 
	 * <p>Helper method for reportparameter
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param jobData
	 * @return
	 * </pre></p>
	 */
	public String getReportParameter (EventProcessJob jobData)
	{
		Map<String, Object> dataMappingMap = null;
		StringBuilder reportParameter = null;
		String dataKeyColumnName = null;
		String reportParameterCode = null;
		String reportParameterValue = null;
		EventDataMapping dataMapping  = null;
		Map<String, DataAttribute> dataAttributes= null;
		DataAttribute dataAttribute = null;
		
		dataMapping =  jobData.getEventDef().getEventDataMapping();
		dataMappingMap = jobData.getDataMappings();
		if ( dataMapping == null)
			return null;
		dataAttributes = dataMapping.getDataAttributes();
		
		for (Map.Entry<String, DataAttribute> entry : dataAttributes.entrySet())
		{
			dataKeyColumnName = entry.getKey();
			dataAttribute = entry.getValue();
			if (dataAttribute != null)
			{
				reportParameterCode = dataAttribute.getRepParameterName();
				
				if ( reportParameterCode == null)
					continue;
				reportParameterValue = (String) dataMappingMap.get(dataKeyColumnName);
				if (reportParameterValue == null)
					reportParameterValue = "%";
				
				if (reportParameter == null)
					reportParameter = new StringBuilder();
				else
					reportParameter.append("&");
				
				reportParameter.append(reportParameterCode);
				reportParameter.append("=");
				reportParameter.append(IrisAdminUtils.encode(reportParameterValue));
			}
		}
		
		if ( reportParameter != null)
			return reportParameter.toString();
		else
			return null;
	}
	
	public String getPasswordValues(EventProcessJob event, String passwordStr)
	{
		String password = null;
		
		password = getSubjectWithValues(event, passwordStr);
		return password;
	}
	/**
	 * This helper method replaces all replaceable fields from subject
	 * 
	 * @param event
	 * @return subject
	 */
	public String getSubjectWithValues (EventProcessJob event, String subject)
	{
		
		String replacableKey = null;
		int currIndex = 0;
		int fromIndex = 0;
		DataFormatValue dataFormatValue = null;
		String dataType = null;
		String mask = null;
		
		if (subject != null)
		{
			while (currIndex != -1)
			{
				currIndex = subject.indexOf('<', fromIndex);
				if (currIndex >= 0)
				{
					replacableKey = subject.substring(currIndex + 1, subject.indexOf('>', currIndex));
					
					Object value = null;
					dataFormatValue = event.getDataFormatValue(replacableKey);
					if (dataFormatValue != null)
					{
						value = dataFormatValue.getValue();
						if (value != null)
						{
							mask =  dataFormatValue.getMask();
							dataType = dataFormatValue.getDataType();
							if (dataType.equals("Date") || dataType.equals("Timestamp"))
							{
								String format = dataFormatValue.getFormat();
								if (format != null)
								{
									SimpleDateFormat dateFormat = new SimpleDateFormat(format);
									value = dateFormat.format(value);
								}
								else
								{
									SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
									value = dateFormat.format(value);
									if (logger.isDebugEnabled())
										logger.debug("Format not Specified. So using a Default Format for Date :: " + value);
								}
							}
							else if (dataType.equals("BigDecimal"))
							{
								String format = dataFormatValue.getFormat();
								if (format != null)
								{
									NumberFormat numberFormat = new DecimalFormat(format);
									value = numberFormat.format(value);
								}
							}
							
							value = maskValue(mask, dataType, value, IrisAdminConstants.CONSTANT_N);
							subject = subject.replace(subject.substring(currIndex, subject.indexOf('>', currIndex) + 1), String.valueOf(value));
							fromIndex = currIndex;
						}
						else
						{
							subject = subject.replace(subject.substring(currIndex, subject.indexOf('>', currIndex) + 1), "");
							
							logger.error("No value found in event for : " + replacableKey + " therefore replacing by space");
							// Incrementing the fromIndex by 1....so that it does not return the same key
							// fromIndex = currIndex + 1;
							fromIndex = currIndex;
						}
					}
					else
					{
						
						subject = subject.replace(subject.substring(currIndex, subject.indexOf('>', currIndex) + 1), "");
						
						logger.error("No mapping found for : " + replacableKey + " therefore replacing by space. "
								+ "Please check if the display names match");
						
						// Incrementing the fromIndex by 1....so that it does not return the same key
						// fromIndex = currIndex + 1;
						fromIndex = currIndex;
						
					}
				}
			}
		}
		
		logger.trace("Final Message String {}" , subject);
		return subject;
	}
	
	/**
	 * 
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param mask
	 * @param dataType
	 * @param orgvalue
	 * @param confidentialFlag
	 * @return
	 * </pre></p>
	 */
	private Object maskValue (String mask, String dataType, Object orgvalue, String confidentialFlag)
	{
		String[] side = null;
		StringBuilder sb = null;
		int numPosition = 0;
		String result = null;
		String value = null;
		String flag = null;
		
		if ( mask == null)
			return orgvalue;
		if (dataType.equals("Date") || dataType.equals("Timestamp"))// || dataType.equals("BigDecimal"))
			return orgvalue;
		
		if (dataType.equals("BigDecimal"))// Changes done by Renu for GCPANZ-6565
		{
			value = orgvalue.toString();
		}
		else
		{
			value = (String) orgvalue;
		}
		side = mask.split("[,]");
		if (side.length == 2)
		{
			sb = new StringBuilder(value.length());
			numPosition = Integer.parseInt(side[1]);
			if (value.length() <= numPosition)
				return value;
			
			if (side[0].equalsIgnoreCase("LP"))
			{
				for (int i = 0; i < value.length(); i++)
				{
					if (i < numPosition)
					{
						sb.append('X');
					}
					else
					{
						sb.append(value.charAt(i));
					}
				}
				result = sb.toString();
			}
			else if (side[0].equalsIgnoreCase("RP"))
			{
				for (int i = 0; i < value.length(); i++)
				{
					if (i >= (value.length() - numPosition))
					{
						sb.append('X');
					}
					else
					{
						sb.append(value.charAt(i));
					}
				}
				result = sb.toString();
			}
			else if (side[0].equalsIgnoreCase("LD"))
			{
				for (int i = 0; i < value.length(); i++)
				{
					if (i >= numPosition)
					{
						sb.append('X');
					}
					else
					{
						sb.append(value.charAt(i));
					}
				}
				result = sb.toString();
			}
			else if (side[0].equalsIgnoreCase("RD"))
			{
				for (int i = 0; i < value.length(); i++)
				{
					if (i >= (value.length() - numPosition))
					{
						sb.append(value.charAt(i));
					}
					else
					{
						sb.append('X');
					}
				}
				result = sb.toString();
			}
			else if (side[0].equalsIgnoreCase("CC"))// Changes done by Renu for GCPANZ-6565
			{
				if (confidentialFlag.equalsIgnoreCase(IrisAdminConstants.CONSTANT_Y))
				{
					sb.append("-CONFIDENTIAL-");
					result = sb.toString();
				}
				else
					result = value;
			}
			value = result;
		}
		return value;
	}
}
