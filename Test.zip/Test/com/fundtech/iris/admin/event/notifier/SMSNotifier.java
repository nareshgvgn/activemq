/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.execution
 * FILE   : EmailNotifier.java
 * CREATED: Jul 12, 2014 2:06:45 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.notifier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.HelperUtils;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: SMSNotifier.java,v 1.8 2016/10/12 06:12:26 ramap Exp $
 */
public class SMSNotifier extends AbstractNotifier
{
	
	private Logger logger = LoggerFactory.getLogger(SMSNotifier.class);
	private final static String screenSQL = "insert into EVENT_SMS_NOTIFICATION (NOTOFICATION_ID, EVENT_JOURNAL_NMBR, EVENT_DATE, EVENT_NAME, EVENT_SOURCE, RECIPIENT_NAME, "
			+ " ENTITY_CODE, CLIENT_CODE, SMS_MESSAGE, SENDER_NMBR, RECIPIENT_NMBR, SUBSCRIPTION_NAME)" + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	private Connection dbConnection = null;
	private PreparedStatement screenStmt = null;
	
	public SMSNotifier(Connection dbConnection)
	{
		this.dbConnection = dbConnection;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.INotifier#notify(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object notify (Map<String, String> params, EventProcessJob jobData) throws ExecutionException
	{
		String tempMessage = null;
		String message = null;
		try
		{
			tempMessage = params.get(INotifier.MESSAGE);
			message = getMessageTemplateWithValues(jobData, tempMessage);
			params.put(INotifier.MESSAGE, message);
			insertRecord(params);
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (Exception e)
		{
			jobData.setStatus("E");
			ExecutionException eExp = null;
			eExp = new ExecutionException("error.iris.admin.event.insertemail", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		return null;
	}
	
	/**
	 * <p>
	 * TODO - The description and purpose of this method goes here
	 * <p>
	 * <i> TODO Additional info if any</i>
	 * </p>
	 * <h3>Signature of the method</h3>
	 * 
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @param message
	 * @param subject
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @throws ExecutionException
	 */
	private void insertRecord (Map<String, String> params) throws ExecutionException
	{
		
		try
		{
			if (screenStmt == null)
				screenStmt = dbConnection.prepareStatement(screenSQL);
			
			screenStmt.clearParameters();
			screenStmt.setInt(1, Integer.parseInt(params.get(INotifier.NOTOFICATION_ID)));
			screenStmt.setString(2, params.get(INotifier.EVENT_JOURNAL_NMBR));
			screenStmt.setString(3, params.get(INotifier.EVENT_DATE));
			screenStmt.setString(4, params.get(INotifier.EVENT_NAME));
			screenStmt.setString(5, params.get(INotifier.EVENT_SOURCE));
			screenStmt.setString(6, params.get(INotifier.RECIPIENT_NAME)); // recipient Name
			screenStmt.setString(7, params.get(INotifier.ENTITY_CODE));// entity code
			screenStmt.setString(8, params.get(INotifier.CLIENT_CODE));
			screenStmt.setString(9, params.get(INotifier.MESSAGE));
			screenStmt.setString(10, params.get(INotifier.SENDER_NMBR));
			screenStmt.setString(11, params.get(INotifier.RECIPIENT_NMBR));
			screenStmt.setString(12, params.get(INotifier.SUBSCRIPTION_NAME)); // SUBSCRIPTION_NAME
			screenStmt.executeUpdate();
		}
		catch (SQLException e)
		{
			ExecutionException eExp = null;
			eExp = new ExecutionException("error.iris.admin.event.inserteonscreen", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.INotifier#cleanup()
	 */
	@Override
	public void close ()
	{
		HelperUtils.doClose(screenStmt);
		screenStmt = null;
	}
	
}
