/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.event.notifier
 * FILE   : InterfaceNotifier.java
 * CREATED: Oct 9, 2016 11:10:32 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.fundtech.iris.admin.event.notifier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.event.EventProcessJob;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: InterfaceNotifier.java,v 1.3 2016/10/28 09:15:49 ramap Exp $
 */
public class InterfaceNotifier extends AbstractNotifier
{
	private Logger logger = LoggerFactory.getLogger(InterfaceNotifier.class);
	
	private final static String attachSQL = "insert into EVENT_INTERFACE_NOTIFICATION (NOTOFICATION_ID, EVENT_JOURNAL_NMBR, EVENT_DATE, EVENT_NAME, EVENT_SOURCE, "
			+ "RECIPIENT_NAME, ENTITY_TYPE, ENTITY_CODE, CLIENT_CODE, INT_SUBJECT, INT_MESSAGE, MAP_CODE, FROM_MAIL_ID, TO_EMAIL_ID, CC_EMAIL_ID, BCC_EMAIL_ID, STATUS,"
			+ " CREATED_DATE, SUBSCRIPTION_NAME, ZIP_FLAG, ZIP_PASSWORD)"
			+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'N', SYSDATE, ?,?,?)";
	private final static String parmsSql = "insert into EVENT_INT_PARM_TXN (NOTOFICATION_ID, EVENT_JOURNAL_NMBR, PARAMETER_TYPE, PARAMETER_NAME, PARAMETER_VALUE) "
			+ " values (?, ?, ?, ?, ?)" ;
	
	private Connection dbConnection = null;
	private PreparedStatement attachStmt = null;
	private PreparedStatement parmsStmt = null;
	private static final String JOB_TYPE ="JOB";
	private static final String ENTITY_TYPE = "CLIENT";
	
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public InterfaceNotifier(Connection dbConnection)
	{
		this.dbConnection = dbConnection;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.INotifier#notify(java.sql.Connection, java.util.Map)
	 */
	@Override
	public Object notify (Map<String, String> params, EventProcessJob jobData) throws ExecutionException
	{
		String tempMessage = null;
		String tempSubject = null;
		String subject = null;
		String message = null;
		String isZipRequired = null;
		String zipPassword = null;
		try
		{
			isZipRequired = params.get(INotifier.ZIP_REQUIRED);
			if ( IrisAdminConstants.CONSTANT_Y.equals(isZipRequired))
				zipPassword = getPasswordValues(jobData, params.get(INotifier.PASSWORD));
			tempMessage = params.get(INotifier.MESSAGE);
			tempSubject = params.get(INotifier.SUBJECT);
			message = getMessageTemplateWithValues(jobData, tempMessage);
			subject = getSubjectWithValues(jobData, tempSubject);
			params.put(INotifier.PASSWORD, zipPassword);
			params.put(INotifier.MESSAGE, message);
			params.put(INotifier.SUBJECT, subject);
			insertRecord(params);
			insertParmRecord(params, jobData);
		}
		catch (ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		catch (Exception e)
		{
			jobData.setStatus("E");
			ExecutionException eExp = null;
			eExp = new ExecutionException("error.iris.admin.event.insertemail", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		return null;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param params
	 * @param jobData
	 * </pre></p>
	 */
	private void insertParmRecord (Map<String, String> params, EventProcessJob jobData)  throws ExecutionException
	{
		Map<String, String> intParms = null;
		String dataKeyColumnName = null;
		Map<String, Object> mappingValuesMap = null;
		String dataValue = null;
		String intParmName = null;
		int notifId = 0;
		String jrnNumber = null;
		
		try
		{
			intParms = jobData.getIntParameters();
			if ( intParms == null) 
				return;
			
			if (parmsStmt == null)
				parmsStmt = dbConnection.prepareStatement(parmsSql);
			
			mappingValuesMap = jobData.getDataMappings();
			notifId = Integer.parseInt(params.get(INotifier.NOTOFICATION_ID));
			jrnNumber =  params.get(INotifier.EVENT_JOURNAL_NMBR);
			
			for ( Map.Entry<String, String> entry : intParms.entrySet())
			{
				dataKeyColumnName = entry.getKey();
				intParmName = entry.getValue();
				dataValue = (String) mappingValuesMap.get(dataKeyColumnName);
				
				parmsStmt.clearParameters();
				parmsStmt.setInt(1, notifId);
				parmsStmt.setString(2, jrnNumber);
				parmsStmt.setString(3, JOB_TYPE);
				parmsStmt.setString(4, intParmName);
				parmsStmt.setString(5, dataValue);
				parmsStmt.addBatch();
			}
			parmsStmt.executeBatch();
		}
		catch (SQLException e)
		{
			ExecutionException eExp = null;
			eExp = new ExecutionException("error.iris.admin.event.insertemail", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param params
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private void insertRecord (Map<String, String> params) throws ExecutionException
	{
		
		try
		{
			if (attachStmt == null)
				attachStmt = dbConnection.prepareStatement(attachSQL);
			
			attachStmt.clearParameters();
			attachStmt.setInt(1, Integer.parseInt(params.get(INotifier.NOTOFICATION_ID)));
			attachStmt.setString(2, params.get(INotifier.EVENT_JOURNAL_NMBR));
			attachStmt.setString(3, params.get(INotifier.EVENT_DATE));
			attachStmt.setString(4, params.get(INotifier.EVENT_NAME));
			attachStmt.setString(5, params.get(INotifier.EVENT_SOURCE));
			attachStmt.setString(6, params.get(INotifier.RECIPIENT_NAME)); // recipient Name
			attachStmt.setString(7, ENTITY_TYPE); // recipient Name
			attachStmt.setString(8, params.get(INotifier.ENTITY_CODE));// entity code
			attachStmt.setString(9, params.get(INotifier.CLIENT_CODE));
			attachStmt.setString(10, params.get(INotifier.SUBJECT));
			attachStmt.setString(11, params.get(INotifier.MESSAGE));
			attachStmt.setString(12, params.get(INotifier.MAP_CODE));
			attachStmt.setString(13, params.get(INotifier.FROM_MAIL_ID)); // FROM_ID
			attachStmt.setString(14, params.get(INotifier.TO_EMAIL_ID)); // TO
			attachStmt.setString(15, params.get(INotifier.CC_EMAIL_ID)); // CC
			attachStmt.setString(16, params.get(INotifier.BCC_EMAIL_ID)); // BCC 
			attachStmt.setString(17, params.get(INotifier.SUBSCRIPTION_NAME)); // SUBSCRIPTION_NAME
			attachStmt.setString(18, params.get(INotifier.ZIP_REQUIRED)); // zip required 
			attachStmt.setString(19, params.get(INotifier.PASSWORD)); // zip password
			attachStmt.executeUpdate();
		}
		catch (SQLException e)
		{
			ExecutionException eExp = null;
			eExp = new ExecutionException("error.iris.admin.event.insertemail", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.event.execution.INotifier#cleanup()
	 */
	@Override
	public void close ()
	{
		HelperUtils.doClose(attachStmt);
		HelperUtils.doClose(parmsStmt);
		parmsStmt = null;
		attachStmt = null;
	}
	
}
