/*
 * Copyright 2007-2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations
 * under the License.
 */

package com.dh.iris.admin.channel.http;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.util.CleanUpUtils;

public class HttpClientTemplate extends AbstractHttpClientTemplate
{
	
	private final Logger logger = LoggerFactory.getLogger(HttpClientTemplate.class);
	
	public HttpClientTemplate()
	{
	}
	
	public HttpClientTemplate(String defaultUri)
	{
		super(defaultUri);
	}
	
	public Map<String, Object> sendAndReceive(String uri, RequestCallback requestCallback,	ResponseCallback responseCallback) throws IOException
	{
		HttpPost post = null;
		Map<String, Object> returnObject = null;
		HttpEntity requestPayload = null;
		
		logger.trace("URI using as:{}", uri);
		post = new HttpPost(uri);
		requestPayload = (HttpEntity)requestCallback.doWithRequest(null);
		if (requestPayload != null)
		{
			post.setEntity(requestPayload);
		}
		returnObject = processResponse(post, responseCallback);
		return returnObject;
	}
	
	public Map<String, Object> processResponse(HttpUriRequest httpMethod, ResponseCallback responseCallBack)
	{
		Map<String, Object> returnObject = null;
		CloseableHttpResponse response = null;
		try
		{
			
			response = (CloseableHttpResponse)getClient().execute(httpMethod);
			returnObject = (Map<String, Object>)responseCallBack.doWithResponse(response);
		}
		catch (IOException e)
		{
			throw new HttpAccessException(e.getMessage(), e);
		}
		finally
		{
			CleanUpUtils.doClose(response);
		}
		
		return returnObject;
	}
	
	
	@Override
	public void destroy () throws Exception
	{
	}
	
	
	public static void main(String[] args) throws UnsupportedEncodingException, FileNotFoundException
	{
		//http://requestb.in/1nbx3s91
		//http://httpbin.org/get
		//http://httpbin.org/post
		
//		ApplicationContext appContext = new ClassPathXmlApplicationContext(	new String[] { "new 2.xml" });
//		HttpClientTemplate tmp = appContext.getBean(HttpClientTemplate.class);
//		String content = new Scanner(new File("c:/temp/BANKIDBBTREQ16061300147O.xml")).useDelimiter("\\Z").next();
//		System.out.println(content);
//		tmp.executePostMethod(content);
	}

	/* (non-Javadoc)
	 * @see org.springbyexample.httpclient.AbstractHttpClientTemplate#createRequest(org.apache.http.client.methods.HttpUriRequest, org.springbyexample.httpclient.RequestCallback)
	 */
	@Override
	public Object createRequest (HttpUriRequest httpMethod, RequestCallback requestCallback)
	{
		return null;
	}
}
