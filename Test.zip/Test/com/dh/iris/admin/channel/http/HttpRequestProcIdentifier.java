/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.http
 * FILE   : HttpRequestProcIdentifier.java
 * CREATED: Dec 8, 2015 5:08:27 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.exceptions.ConfigurationException;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.Identifier;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: HttpRequestProcIdentifier.java,v 1.6 2016/07/15 09:36:59 ramap Exp $
 */
public class HttpRequestProcIdentifier implements Identifier
{
	
	private Map<String, String> properties = null;
	private static Logger logger =  LoggerFactory.getLogger(HttpRequestProcIdentifier.class);
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public HttpRequestProcIdentifier()
	{
		
	}
	
	/**
	 * @param parameters
	 *            the parameters to set
	 */
	public void setProperties (Map<String, String> properties)
	{
		this.properties = properties;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.spring.Identifier#initialize()
	 */
	@Override
	public void initialize () throws ConfigurationException
	{
		// BABU Auto-generated method stub
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fundtech.iris.admin.spring.Identifier#identify(java.lang.Object)
	 */
	@Override
	public Map<String, Object> identify (Object source) throws ExecutionException
	{
		Map<String, Object> sourceData = null;
		Map<String, Object> outData = null;
		String mapName = null;
		String processName = null;
		String entityType = null;
		String entityCode = null;
		Map<String, Object> inputparms = null;
		String[] retVal = null;
		
		sourceData = (Map<String, Object>) source;
		inputparms = (Map<String, Object>)sourceData.get(IrisAdminConstants.FILTER_PARMS);
		processName = properties.get("ExecuteIRISProcess");
		
		if ( inputparms.containsKey("ProcessId"))
		{
			retVal = (String[]) inputparms.get("ProcessId");
			mapName = retVal[0];
			if ( mapName.equals("CUSTONBOARD"))
			{
				processName = mapName;
				entityCode = "BANK";
				entityType = "BANK";
			}
			else if ( mapName.equals("BANKREPEXPORT"))
			{
				processName = mapName;
				entityCode = "BANK";
				entityType = "BANK";
			}
			else if ( mapName.equals("FEDWIREEXPORT"))
			{
//				processName = mapName;
				entityCode = "BANK";
				entityType = "BANK";
			}
			else
			{
				retVal = (String[]) inputparms.get("Client");
				entityCode = retVal[0];
				entityType = properties.get("EntityType");
			}
		}
		else
		{
			mapName = properties.get("MapName");
			entityCode = properties.get("EntityCode");
		}
		outData = new HashMap<String, Object>();
		outData.put(IrisAdminConstants.ENTITY_TYPE, entityType);
		outData.put(IrisAdminConstants.EXECUTE_PROCESS, processName);
		outData.put(IrisAdminConstants.ENTITY_CODE, entityCode);
		outData.put(IrisAdminConstants.MAP_NAME, mapName);
		outData.put(IrisAdminConstants.FILTER_PARMS, inputparms);
		return outData;
	}
	
}
