/*------------------------------------------------------------------------------
 * PACKAGE: org.springbyexample.httpclient
 * FILE   : AbstractRequestCallback.java
 * CREATED: Jun 14, 2016 5:37:20 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http;

import java.io.IOException;
import java.sql.Connection;
import java.util.Map;

import org.apache.commons.io.Charsets;
import org.apache.http.entity.StringEntity;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AbstractRequestCallback.java,v 1.1 2016/06/20 04:57:40 ramap Exp $
 */
public abstract class AbstractRequestCallback implements RequestCallback
{
	
	private ExecutionJobData jobData = null;
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public AbstractRequestCallback()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see org.springbyexample.httpclient.RequestCallback#initialize(java.sql.Connection, java.util.Map)
	 */
	@Override
	public void initialize (Connection dbConnection, Map<String, Object> parms) throws Exception
	{
		doInitialize(dbConnection, parms);
		jobData = (ExecutionJobData)parms.get(IrisAdminConstants.EXECUTION_DATA);
		
	}
	
	/* (non-Javadoc)
	 * @see org.springbyexample.httpclient.RequestCallback#doWithRequest(java.lang.Object)
	 */
	@Override
	public Object doWithRequest (Object entity) throws IOException
	{
		StringEntity requestPayload = null;
		String requestMessage = null;
		
		requestMessage = (String)jobData.getDataObject();
		requestPayload = new StringEntity(requestMessage, Charsets.UTF_8);
		requestPayload.setChunked(true);
		requestPayload = (StringEntity) makeRequestObject(requestPayload);
		return requestPayload;
	}
	
	public abstract void doInitialize(Connection dbConnection, Map<String, Object> parms);
	public abstract Object makeRequestObject(Object parms) ;
	
}
