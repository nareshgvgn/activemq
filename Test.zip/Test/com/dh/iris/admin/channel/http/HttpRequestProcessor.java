/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.http
 * FILE   : HttpRequestProcessor.java
 * CREATED: Nov 21, 2015 11:57:00 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.dh.iris.admin.channel.http.service.HTTPRequest;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractActivator;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.ReferencesEnum;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here test6
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: HttpRequestProcessor.java,v 1.10 2016/06/20 04:53:20 ramap Exp $
 */
public class HttpRequestProcessor extends AbstractActivator
{
	private static Logger logger = LoggerFactory.getLogger(HttpRequestProcessor.class);
	
	public ExecutionJobData process(HTTPRequest input) throws Exception
	{
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		Map<String, Object> inputParms = null;
		ConnectionProvider dbProvider = null;
		ExecutionJobData jobData = null;
		String dbResourceName = null;
		
		try
		{
			
			if ( input.getHeaders() == null)  // to block favicon.ico call 
				return null;
			
			activatorHelper = new ActivatorHelper();
			dbResourceName = getReferences().get(ReferencesEnum.DB_CONN);
			dbProvider = IrisAdminUtils.getDBProvider(dbResourceName, getApplicationContext());
			dbConnection = dbProvider.getConnection();
			activatorHelper.initialize(dbConnection, getApplicationContext());
			inputParms = new HashMap<String, Object>();
			inputParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, getProcIdentifier());
			inputParms.put(IrisAdminConstants.CHANNEL, IrisAdminConstants.MEDIA_HTTP_CW);
			inputParms.put(IrisAdminConstants.FILTER_PARMS, input.getParameterMap());
			inputParms.put(IrisAdminConstants.DATAOBJECT_HELPER, getDataObjectHelper());
			jobData = activatorHelper.runProcess(inputParms, IrisAdminConstants.MEDIA_HTTP_CW, isAccumulateErrors(), null);
		}
		catch ( Exception exp)
		{
			logger.error("Error:", exp);
		}
		finally
		{
			if ( activatorHelper != null)
				activatorHelper.cleanUp();
			IrisAdminUtils.cleanup(dbProvider, dbConnection);
		}
		if ( jobData == null)
			jobData = new ExecutionJobData();
		return jobData;
		
	}
	
	@Override
	public void afterPropertiesSet ()
	{
	}
	
}
