/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.http
 * FILE   : HttpResponseSerializer.java
 * CREATED: Nov 21, 2015 1:44:25 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http.service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Properties;

import org.springframework.core.serializer.Serializer;

import com.cashtech.iris.core.processor.activators.response.IrisResponse;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.Property;
import com.cashtech.iris.patterns.sdo.Type;
import com.cashtech.iris.util.Constants;
import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: HttpResponseSerializer.java,v 1.8 2016/05/05 12:37:19 ramap Exp $
 */
public class HttpResponseSerializer implements Serializer<ExecutionJobData>
{
	
	/* (non-Javadoc)
	 * @see org.springframework.core.serializer.Serializer#serialize(java.lang.Object, java.io.OutputStream)
	 */
	@Override
	public void serialize (ExecutionJobData jobData, OutputStream outputStream) throws IOException
	{
		String srcSubType = null;
		IrisResponse irisResponse = null;
		HTTPResponse httpResp = null;
		String output = null;
		DataObject outDO = null;
		Type irisType = null;
		List<Property> retTypes = null;
		 Object value = null;
		
		try
		{
			
			irisResponse  = new IrisResponse();
			httpResp = new HTTPResponse(outputStream);
			if ( jobData.getStatus() == null || ! "C".equals(jobData.getStatus()))
			{
				irisResponse.setStatus("");
				irisResponse.setErrorMessage("Error While Executiong");
				httpResp.addHeader("ERROR", irisResponse.getXMLResponse());
				httpResp.sendResponse("500", Constants.HTTP_INTERNALERROR);
			}
			else if ("C".equals(jobData.getStatus()))
			{
				srcSubType = jobData.getSrcSubType();
				if ("IRIS".equals(srcSubType))
				{
					outDO = (DataObject)jobData.getIrisDataObject();
					irisType = outDO.getType();
					retTypes = irisType.getProperties();
					Properties pros = new Properties();
					
					for (Property retProp : retTypes)
					{
						// set it to null as this will get reused
					    value = null;

					    if (outDO.getType().containsProperty(retProp.getName()))
					        value = outDO.getValue(retProp.getName());
					    if (value == null) value = retProp.getDefault();

						/* if both runtime value & default value not provided put
	                     * empty string else Peoperties.put() will throw
	                     * NullPointerException
						 */
					    if (value == null) value = "";

					    pros.put(retProp.getName(), "<![CDATA[" + value + "]]>");
					}
					if (  jobData.getRespExecutionId() != null)
						pros.put("RESPONSE_EXECUTION_ID", jobData.getRespExecutionId());
					if (jobData.getExecutionId() != null )
						pros.put("REQUEST_EXECUTION_ID", jobData.getExecutionId());
					irisResponse.setStatus(IrisResponse.STATUS_SUCCESS);
					irisResponse.setData(pros);
					httpResp.sendResponse(irisResponse.getXMLResponse(), Constants.HTTP_OK);
				}
				else
				{
					irisResponse.setStatus(IrisResponse.STATUS_SUCCESS);
					output = (String)jobData.getMessageData();
					if ( output == null)
						output = "#### No Data to download ####";
					Properties pros = new Properties();
					pros.setProperty("DATA", output);
					if (  jobData.getRespExecutionId() != null)
						pros.put("RESPONSE_EXECUTION_ID", jobData.getRespExecutionId());
					if (jobData.getExecutionId() != null )
						pros.put("REQUEST_EXECUTION_ID", jobData.getExecutionId());
					irisResponse.setData(pros);
					httpResp.sendResponse(irisResponse.getXMLResponse(), Constants.HTTP_OK);
				}
			}
			else
			{
				irisResponse.setStatus("");
				irisResponse.setErrorMessage("Error While Executiong");
				httpResp.addHeader("ERROR", irisResponse.getXMLResponse());
				httpResp.sendResponse("500", Constants.HTTP_INTERNALERROR);
			}
		}
		catch ( Exception e)
		{
			
		}
		
	}
	
}
