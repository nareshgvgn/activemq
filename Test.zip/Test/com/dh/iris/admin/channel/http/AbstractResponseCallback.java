/*------------------------------------------------------------------------------
 * PACKAGE: org.springbyexample.httpclient
 * FILE   : AbstractResponseCallback.java
 * CREATED: Jun 14, 2016 5:56:48 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http;

import java.io.IOException;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.Charsets;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.iris.admin.IrisAdminConstants;


/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AbstractResponseCallback.java,v 1.1 2016/06/20 04:57:40 ramap Exp $
 */
public abstract class AbstractResponseCallback implements ResponseCallback
{
	
	private final Logger logger = LoggerFactory.getLogger(AbstractResponseCallback.class);
	
	public AbstractResponseCallback()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see org.springbyexample.httpclient.ResponseCallback#initialize(java.sql.Connection, java.util.Map)
	 */
	@Override
	public void initialize (Connection dbConnection, Map<String, Object> parms) throws Exception
	{
		// BABU Auto-generated method stub
		
	}
	
	/* (non-Javadoc)
	 * @see org.springbyexample.httpclient.ResponseCallback#doWithResponse(java.lang.Object)
	 */
	@Override
	public Object doWithResponse (Object parms) throws IOException
	{
		String responseStr = null;
		HttpEntity responseEntity = null;
		Map<String, Object> output = new HashMap<String, Object>();
		HttpResponse response = (HttpResponse)parms;
		int status = -1;
		
		status = response.getStatusLine().getStatusCode();
		
		logger.debug("Response Code Received:{}", status);
		output.put(ResponseCallback.HTTP_REQAUEST_STATUS, "" + status);
		responseEntity = response.getEntity();
		responseStr = EntityUtils.toString(responseEntity,Charsets.UTF_8);
		logger.trace("Message received:-\n{}" , responseStr);
		output.put(IrisAdminConstants.HTTP_RESPONSE_MESSAGE,responseStr);
		output = extractMessage(output);
		return output;
	}
	
//	private String read (InputStream in) throws IOException
//	{
//		StringBuilder sb = new StringBuilder();
//		BufferedReader r = new BufferedReader(new InputStreamReader(in), 1000);
//		for (String line = r.readLine(); line != null; line = r.readLine())
//		{
//			sb.append(line);
//		}
//		in.close();
//		return sb.toString();
//	}
	
	public abstract void doInitialize(Connection dbConnection, Map<String, Object> parms);
	public abstract Map<String, Object> extractMessage(Map<String, Object> parms) ;
	
}
