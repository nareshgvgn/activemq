/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.http
 * FILE   : HttpRequestReceiver.java
 * CREATED: Jun 14, 2016 12:41:24 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.dh.iris.admin.channel.ws.SOAPWebServiceHelper;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractRequestReceiver;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.IAuditHandler;
import com.fundtech.iris.admin.channel.IRetryHandler;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: HttpRequestReceiver.java,v 1.1 2016/06/20 04:53:20 ramap Exp $
 */
public class HttpRequestReceiver extends AbstractRequestReceiver implements InitializingBean
{
	private static Logger logger = LoggerFactory.getLogger(SOAPWebServiceHelper.class);
	
	private HttpClientTemplate httpClientTemplate = null;
	private RequestCallback requestCallback = null;
	private ResponseCallback responseCallBack = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public HttpRequestReceiver()
	{
		// BABU Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.fundtech.iris.admin.channel.IRequestReceiver#sendMessage(java.util.Map)
	 */
	@Override
	public void sendMessage( Map<String, Object> inputParms) throws ExecutionException
	{
		String receivedMessage = null;
		ExecutionException eExp = null;
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		ExecutionJobData jobData = null;
		Map<String, Object> outputParms = null;
		Map<String, Object> auditParms = null;
		IAuditHandler auditHandler = null;
		String message = null;
		String requestService = null;
		Map<String, Object> serviceOutput = null;
		String serviceStatus = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		String threadIdName = null;
		ExecutionJobData responseJobData = null;

		try
		{
			jobData = (ExecutionJobData) inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			requestService = jobData.getFilterParameter(IrisAdminConstants.HTTP_REQUEST_URI);
			threadIdName = Thread.currentThread().getName();
			if ( requestService == null)
			{
				requestService = httpClientTemplate.getDefaultUri();
				logger.warn("Web Servuce URI not configured for the Service, so usinng default one: {} , so please configure: {}" , 
																			requestService, IrisAdminConstants.HTTP_REQUEST_URI);
			}
			dbConnection = getDBProvider().getConnection();
			message = (String)jobData.getDataObject();
			auditHandler = getAuditHandler();
			auditParms = new HashMap<String, Object>();
			auditParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
			auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, message);
			auditHandler.audit(auditParms, IAuditHandler.REQUEST_TYPE);
			
			serviceOutput = callHTTPservice(requestService, jobData, dbConnection);
			serviceStatus = (String) serviceOutput.get(ResponseCallback.HTTP_REQAUEST_STATUS);
			
			if ( (""+HttpStatus.SC_OK).equals(serviceStatus))
			{
				receivedMessage = (String) serviceOutput.get(IrisAdminConstants.HTTP_RESPONSE_MESSAGE);
			}
			else
			{
				receivedMessage = (String) serviceOutput.get(IrisAdminConstants.HTTP_RESPONSE_MESSAGE);
				
				logger.error("Error Message Received:-{} with status code:{}",receivedMessage, serviceStatus);
				auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, receivedMessage);
				auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
				eExp = new ExecutionException("error.iris.admin.webservice.error", new Object[] {serviceStatus, receivedMessage}, null);
				
				jobData.setStatus("E");
				error = IrisAdminUtils.createInterError("999", receivedMessage, serviceStatus, null);
				irisError = IrisAdminUtils.createIrisError(IrisAdminConstants.MEDIA_WEBSERVICE,IrisAdminConstants.MEDIA_WEBSERVICE, receivedMessage);
				jobData.addIrisError(irisError);
				jobData.addError(error);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			
			if ( receivedMessage != null)
			{
				
				auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, receivedMessage);
				auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
				activatorHelper = new ActivatorHelper();
				
				activatorHelper.initialize(dbConnection, getApplicationContext());
				outputParms = new HashMap<String, Object>();
				outputParms.put(IrisAdminConstants.HTTP_RESPONSE_MESSAGE, receivedMessage);
				outputParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, getProcIdentifier());
				outputParms.put(IrisAdminConstants.REQUEST_JOB_DATA, jobData);
				outputParms.put(IrisAdminConstants.CHANNEL, IrisAdminConstants.MEDIA_HTTP_RESPONSE);
				responseJobData = activatorHelper.runProcess(outputParms, IrisAdminConstants.MEDIA_HTTP_RESPONSE, jobData.isAccumulateErros(), null);
				jobData.setRespExecutionId(responseJobData.getExecutionId());
			}
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.timeout", new Object[] {}, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch ( ExecutionException exp)
		{
			if ( "error.iris.admin.chain.timeout".equals(exp.getKey()))
				throw exp;
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.process", new Object[] {}, exp);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch (SystemException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (SQLException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			logger.info("Changing thread name back from [{}] to [{}]", Thread.currentThread().getName(), threadIdName);
			Thread.currentThread().setName(threadIdName);
			CleanUpUtils.doClean(auditParms);
			CleanUpUtils.doClean(inputParms);
			CleanUpUtils.doClean(outputParms);
			if ( activatorHelper != null)
				activatorHelper.cleanUp();
			cleanup(dbConnection);
		}
	}
	
	private Map<String, Object> callHTTPservice(String uri,  ExecutionJobData jobData, Connection dbConnection)  throws ExecutionException
	{
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		int continueRetry = IRetryHandler.CONTINUE_RETRY;
		Map<String, Object> retryInput = null;
		IRetryHandler retryHandler = null;
		String requestCallBackBeanName = null;
		RequestCallback requestCallBack = null;
		String responseCallBackBeanName = null;
		ResponseCallback responseCallBack = null;
		Map<String, Object> serviceOutput = null;
		Map<String, Object> actionDataMap = null;
		
		
		retryInput = new HashMap<String, Object>();
		retryInput.put(IrisAdminConstants.EXECUTION_DATA, jobData);
		retryHandler = getRetryHandler();
		
		requestCallBackBeanName = jobData.getFilterParameter(IrisAdminConstants.HTTP_REQUEST_CALLBACK);
		if ( requestCallBackBeanName == null)
			requestCallBack = getRequestCallback();
		else
			requestCallBack = (RequestCallback)getBean(requestCallBackBeanName);
		
		responseCallBackBeanName = jobData.getFilterParameter(IrisAdminConstants.HTTP_RESPONSE_CALLBACK);
		if ( responseCallBackBeanName == null)
			responseCallBack = getResponseCallBack();
		else
			responseCallBack = (ResponseCallback) getBean(responseCallBackBeanName);
		
		
		while( continueRetry == IRetryHandler.CONTINUE_RETRY)
		{
			try
			{
				actionDataMap = new HashMap<String, Object>();
				actionDataMap.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				requestCallBack.initialize(dbConnection, actionDataMap);
				responseCallBack.initialize(dbConnection, actionDataMap);
				
				serviceOutput = httpClientTemplate.sendAndReceive(uri,  requestCallBack, responseCallBack);
				retryInput.put(IRetryHandler.RECEIVED_MESSAGE, serviceOutput);
				continueRetry = (Integer) retryHandler.retry(retryInput);
				retryInput.clear();
				if ( IRetryHandler.STOP_RETRY == continueRetry)
				{
					errorMsg = "Re-try handler thrown error, Stop Retry invoked!!";
					eExp = new ExecutionException("error.iris.admin.socketerror", new Object[]	{ errorMsg }, null);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw eExp;
				}
				else if (  IRetryHandler.CONTINUE_RETRY == continueRetry)
					logger.error("Re-try Handler thrownn error, so re-tryinng again");
						
			}
			catch ( ExecutionException exp)
			{
				throw exp;
			}
			catch ( Exception exp)
			{
				errorMsg = exp.getMessage();
				retryInput.put(IRetryHandler.ERROR_MESSAGE, errorMsg);
				
				continueRetry = (Integer) retryHandler.retry(retryInput);
				if ( continueRetry != IRetryHandler.CONTINUE_RETRY)
				{
					retryInput.clear();
					errorMsg = "not abble to connect server after re-try count" ;
					eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "webservice error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw eExp;
				}
			}
			finally
			{
				CleanUpUtils.doClean(actionDataMap);
			}
		}
		return serviceOutput;
	}

	/**
	 * @return the httpClientTemplate
	 */
	public HttpClientTemplate getHttpClientTemplate ()
	{
		return httpClientTemplate;
	}

	/**
	 * @param httpClientTemplate the httpClientTemplate to set
	 */
	public void setHttpClientTemplate (HttpClientTemplate httpClientTemplate)
	{
		this.httpClientTemplate = httpClientTemplate;
	}

	/**
	 * @return the requestCallback
	 */
	public RequestCallback getRequestCallback ()
	{
		if ( requestCallback == null)
			requestCallback = new SysHttpRequestCallback();
		return requestCallback;
	}

	/**
	 * @param requestCallback the requestCallback to set
	 */
	public void setRequestCallback (RequestCallback requestCallback)
	{
		this.requestCallback = requestCallback;
	}

	/**
	 * @return the responseCallBack
	 */
	public ResponseCallback getResponseCallBack ()
	{
		if ( responseCallBack == null)
			responseCallBack = new SysHttpResponseCallback();
		return responseCallBack;
	}

	/**
	 * @param responseCallBack the responseCallBack to set
	 */
	public void setResponseCallBack (ResponseCallback responseCallBack)
	{
		this.responseCallBack = responseCallBack;
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet () throws Exception
	{
		if (httpClientTemplate == null)
			throw new Exception("Http Client template not configured");
		
	}
	
}
