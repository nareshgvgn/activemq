/*
 * Copyright 2007-2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations
 * under the License.
 */

package com.dh.iris.admin.channel.http;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.Charsets;
import org.apache.http.HttpException;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public abstract class AbstractHttpClientTemplate implements InitializingBean, DisposableBean
{
	private HttpClient client = null;
	private String defaultUri = null;
	
	public AbstractHttpClientTemplate()
	{
	}
	
	public AbstractHttpClientTemplate(String defaultUri)
	{
		try
		{
			afterPropertiesSet();
		}
		catch (Exception e)
		{
			throw new HttpAccessException(e.getMessage(), e);
		}
	}
	
	/**
	 * Gets http client.
	 */
	public HttpClient getClient ()
	{
		return client;
	}
	
	/**
	 * Sets http client.
	 */
	public void setClient (CloseableHttpClient client)
	{
		this.client = client;
	}
	
	
	/**
	 * Gets default uri.
	 */
	public String getDefaultUri ()
	{
		return defaultUri;
	}
	
	/**
	 * Sets default uri.
	 */
	public void setDefaultUri (String defaultUri)
	{
		this.defaultUri = defaultUri;
	}
	
	public void afterPropertiesSet () throws Exception
	{
		// make sure credentials are properly set
		
		if (client == null)
		{
			throw new HttpException("HttpClient is null", null);
		}
	}
	
	
	
	
	
	public abstract Map<String, Object> sendAndReceive (String uri, RequestCallback requestCallback, ResponseCallback responseCallback) throws Exception ;
	public abstract Map<String, Object> processResponse (HttpUriRequest httpMethod, ResponseCallback callback);
	public abstract Object createRequest(HttpUriRequest httpMethod, RequestCallback requestCallback);
	
	
	protected void processHttpPostMethodParams (Object httpMethod, Map<String, String> hParams) throws UnsupportedEncodingException
	{
		List<NameValuePair> lParams =  null;
		if (hParams != null)
		{
			lParams = new ArrayList<NameValuePair>();
			
			for (Object key : hParams.keySet())
			{
				Object value = hParams.get(key);
				
				lParams.add(new BasicNameValuePair(key.toString(), value.toString()));
			}
		}
			((HttpPost) httpMethod).setEntity(new UrlEncodedFormEntity(lParams,Charsets.UTF_8));
	}
}
