/*------------------------------------------------------------------------------
 * PACKAGE : com.cashtech.iris.core.processor.activators.http.service
 * FILE    : HTTPRequest.java
 * CREATED : 
 *------------------------------------------------------------------------------
 * Copyright (c) 2001-2004, Russell Gold
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy 
 * of this software and associated documentation files (the "Software"), to deal 
 * in the Software without restriction, including without limitation the rights 
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
 * copies of the Software, and to permit persons to whom the Software is furnished 
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all 
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS 
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER 
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN 
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *------------------------------------------------------------------------------
 * Copied directly from following files of project 
 * <a href="http://www.sourceforge.net/projects/httpunit">HttpUnit</a>
 * 1. com.meterware.pseudoserver.HttpRequest
 * 2. com.meterware.pseudoserver.ReceivedHttpMessage
 * 3. com.meterware.httpunit.HttpUnitUtils 
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.net.URLCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class manages the headers and content of a HTTP request. It can be used 
 * for receiving or generating requests.
 * @author vijayb
 * @author Prasad P. Khandekar
 * @version $Id: HTTPRequest.java,v 1.2 2015/12/09 05:02:45 ramap Exp $
 */
public class HTTPRequest
{
	private static final Logger logger = LoggerFactory.getLogger(HTTPRequest.class);

    private static final int CR = 13;
    private static final int LF = 10;

	/**
	 * HTTP <code>method</code> with which this request was made, for example, 
	 * GET, POST, HEAD
	 */
	private String _method = null;
	
	/**
	 * the part of this request's URL from the protocol name up to the query
	 * string in the first line of the HTTP request
	 * e.g.
	 * <pre>
	 * POST /some/path.html HTTP/1.1  /some/path.html
	 * GET http://foo.bar/a.html HTTP/1.0  
	 * </pre>
	 */
	private String _uri = null;

	/**
	 * The HTTP protocol and it's version e.g. HTTP/1.0 or HTTP/1.1
	 */
	private String _protocol = null;

	/**
	 * Map of <code>headers</code> from the http request
	 */
	private Map<String, String> _headers = null;
	
	/**
	 * Map of parameters contained in http request
	 */
	private Map<String, Object> _params = null;
	
    /**
     * Holds the raw data received as a part of HTTP request.
     */
    private ByteArrayOutputStream _rawData = null;

    /**
     * The request body contents
     */
    private byte[] _body = null;

	/**
	 * Constructor constructs <code>HTTPRequest</code> object, which accepts 
	 * <code>InputStream</code> as parameter which contains request from client
	 * @param is contains request from client
	 * @throws Exception 
	 */
	public HTTPRequest(InputStream is) throws IOException
	{
		String hdrLine = null;

		_rawData = new ByteArrayOutputStream(4096);
		hdrLine = readHeaderLine(is);
//		if ( !hdrLine.contains("ProcessId"))
//			return;
		interpretMessageHeader(hdrLine);
		_headers = readHeaders(is);
		readMessageBody(is);
		if (_method.equalsIgnoreCase("GET") || _method.equalsIgnoreCase("HEAD"))
			_params = readParameters(getParameterString(_uri));
		else
			_params = readParameters(new String(_body));
		_rawData.flush();
		
	}

	/**
	 * Returns the name of the HTTP method with which this request
	 * was made, for example, GET, POST, HEAD, PUT, OPTIONS, TRACE, CONNECT,
	 * DELETE, MOVE
	 * @return method - Returns the name of the HTTP method
	 */
	public String getMethod()
	{
		return _method;
	}

	/**
	 * Returns the protocol string received as part of this request.
	 * @return the protocol string.
	 */
	public String getProtocol()
	{
		return _protocol;
	}

	/**
	 * Returns the raw body as received in the request.
	 * @return the raw body contents.
	 */
	public String getBody()
	{
		if (_body != null)
			return new String(_body);
		return null;
	}

	/**
	 * Returns the part of this request's URL from the protocol name
	 * up to the query string in the first line of the HTTP request.
	 * The web container does not decode this String.
	 * For example:
	 * <pre>
	 *   <B>First line of HTTP request	Returned Value</B>
	 *   POST /some/path.html HTTP/1.1	/some/path.html
	 *   GET http://foo.bar/a.html HTTP/1.0	/a.html
	 *   HEAD /xyz?a=b HTTP/1.1		/xyz
	 * </pre>
	 * 
	 * @return requestURI - a String containing the part of the URL from
	 * the protocol name up to the query string
	 */
	public String getRequestURI()
	{
		return _uri;
	}

	/**
	 * Returns the Map of the headers
	 * @return headers - Map of the headers
	 */
	public Map<String, String> getHeaders()
	{
		if (_headers != null)
			return Collections.unmodifiableMap(_headers);
		return null;
	}

	/**
	 * Returns a <code>Map</code> of the parameters of this request.
	 * Request parameters are extra information sent with the request.
	 * For HTTP, parameters are contained in the query string or posted form data.
	 * @return A <code>Map</code> containing parameter names
	 * as keys and parameter values as map values
	 */
	public Map<String, Object> getParameterMap()
	{
		if (_params != null)
			return Collections.unmodifiableMap(_params);
		return null;
	}

	/**
	 * Returns the value of a request parameter as a String, or null
	 * if the parameter does not exist
	 * @param name - a String specifying the name of the parameter 
	 * @return a String representing the single value of the parameter
	 */
	public String getParameter(String name)
	{
		String[] retVal = null;

		if (_params != null && _params.containsKey(name))
		{
			retVal = (String[]) _params.get(name); 
			return retVal[0];
		}
		return null;
	}
	
	/**
	 * Returns the value of a request header as a String, or null
	 * if the parameter does not exist
	 * @param name - a String specifying the name of the header parameter 
	 * @return a String representing the single value of the header parameter
	 */
	public String getHeader(String name)
	{
		if(_headers != null)
			return _headers.get(name);
		return null;
	}
	
	/**
	 * Returns the <code>Set</code> which contains name of parameters
	 * @return Returns the <code>Set</code> which contains name of parameters 
	 */
	public Set<String> getParameterNames()
    {
        if (_params != null)
        	return Collections.unmodifiableSet(_params.keySet());
        return null;
    }
	
	/**
	 * Returns the <code>Set</code> which contains name of headers
	 * @return Returns the <code>Set</code> which contains name of headers 
	 */
	public Set<String> getHeaderNames()
    {
        if (_headers != null)
        	return Collections.unmodifiableSet(_headers.keySet());
        return null;
    }

	/**
	 * Returns content length of request body
	 * @return an integer containing the length of the request body
	 * or -1 if the length is not known
	 */
	public int getContentLength()
	{
		if (_headers.containsKey("Content-Length"))
			return Integer.parseInt(_headers.get("Content-Length"));
		return -1;
	}

	/**
	 * Returns the MIME type of the body of the request, or null if the type is 
	 * not known.
	 * @return A String containing the name of the MIME type of the request,
	 * or null if the type is not known
	 */
	public String getContentType()
	{
		if (_headers.containsKey("Content-Type"))
			return _headers.get("Content-Type");
		return null;
	}

    /**
     * Returns raw contents of the HTTP request.
     * @return The raw contents of HTTP request
     */
    public String getRawRequest()
    {
    	if (_rawData != null)
    		return _rawData.toString();
    	return null;
    }
	
/*------------------------------------------------------------------------------
 * HELPERS
 *----------------------------------------------------------------------------*/
    private String readHeaderLine(InputStream inputStream) throws IOException
    {
        return new String(readDelimitedChunk(inputStream));
    }

    private byte[] readDelimitedChunk(InputStream inputStream) throws IOException
    {
    	int b = -1;
        ByteArrayOutputStream baos = null;

        baos = new ByteArrayOutputStream();
        b = inputStream.read();
        while (b != CR)
        {
        	_rawData.write(b);
            baos.write(b);
            b = inputStream.read();
        }

        b = inputStream.read();
        if (b != LF) throw new IOException( "Bad header line termination: " + b);
        _rawData.write(b);
        _rawData.flush();
        baos.flush();
        return baos.toByteArray();
    }

    private void interpretMessageHeader(String messageHeader)
    {
        StringTokenizer st = new StringTokenizer(messageHeader);
        _method = st.nextToken();
        _uri= st.nextToken();
        _protocol = st.nextToken();
        if (logger.isInfoEnabled())
        	logger.info("Http '" + _method + " method is used!");
        st = null;
    }

    private Map<String, String> readHeaders(InputStream inputStream) 
    throws IOException
    {
    	int pos = -1;
    	String header = null;
        String lastHeader = null;
        Map<String, String> hdrs = null;

        hdrs = new Hashtable<String, String>();
        header = readHeaderLine(inputStream);
        while (header.length() > 0)
        {
        	if (logger.isDebugEnabled())
        		logger.debug("Reading header - " + header);
    	    if (header.charAt(0) <= ' ')
    	    {
    	        if (lastHeader == null) continue;
    	        hdrs.put(lastHeader, _headers.get(lastHeader) + header.trim());
    	    }
    	    else
    	    {
    	    	pos = header.indexOf(':');
    	        lastHeader = header.substring(0, pos);
    	        hdrs.put(lastHeader, header.substring(pos + 1).trim());
    	    }
            header = readHeaderLine( inputStream );
        }
        if (logger.isInfoEnabled())
        	logger.info("Read '" + hdrs.size() + "' headers!");
        return hdrs;
    }

    private void readMessageBody(InputStream inputStream) throws IOException
    {
        int total = 0;
        int count = -1;
    	int totalExpected = -1;
    	byte[] buffer = null;
    	ByteArrayOutputStream baos = null;

    	if (logger.isDebugEnabled())
    		logger.debug("Reading body contents!");

        if ("chunked".equalsIgnoreCase(getHeader("Transfer-Encoding")))
        {
        	if (logger.isDebugEnabled())
        		logger.debug("Reading body contents using chunked transfer encoding!");
        	
            baos = new ByteArrayOutputStream();
            while (getNextChunkLength(inputStream) > 0)
            {
                baos.write(readDelimitedChunk(inputStream));
            }
            flushChunkTrailer(inputStream);
            baos.flush();
            _body = baos.toByteArray();
        }
        else
        {
            totalExpected = getContentLength();
            if ( totalExpected > 0)
            {
            	baos = new ByteArrayOutputStream(totalExpected);
            }
            else
            {
            	
            	baos = new ByteArrayOutputStream();
            }
            buffer = new byte[1024];
            while ((total < totalExpected) && 
            		((count = inputStream.read(buffer)) != -1))
            {
                baos.write(buffer, 0, count);
                _rawData.write(buffer, 0, count);
                total += count;
            }
            _rawData.flush();
            baos.flush();
            _body = baos.toByteArray();
        }
    }

    private void flushChunkTrailer(InputStream inputStream) throws IOException
    {
        byte[] line = null;

        do
        {
        	line = readDelimitedChunk(inputStream);
    	} while (line.length > 0);
    }

    private int getNextChunkLength(InputStream inputStream) throws IOException
    {
        try
        {
            return Integer.parseInt(readHeaderLine(inputStream));
        }
        catch (NumberFormatException e)
        {
            throw new IOException("Unabled to read chunk length : " + e);
        }
    }

    private Map<String, Object> readParameters(String content)
    {
    	String name = null;
    	StringTokenizer st = null;
        Map<String, Object> params = null;

	    if (content == null || content.trim().length() == 0) return null;

	    params = new Hashtable<String, Object>();
        st = new StringTokenizer(content, "&=");
        while (st.hasMoreTokens())
        {
            name = st.nextToken();
            if (logger.isDebugEnabled())
            	logger.debug("Reading parameter '" + name + "'");
            if (st.hasMoreTokens())
            {
            	addParameter(params, decode(name), decode(st.nextToken()));
            }
        }
        if (logger.isInfoEnabled())
        	logger.info("Read '" + params.size() + "' parameters!");
        return params;
    }

    private void addParameter(Map<String, Object> parameters, 
    							String name, String value)
    {
        String[] oldValues = (String[]) parameters.get(name);
        if (oldValues == null)
        {
            parameters.put(name, new String[] {value});
        }
        else
        {
            String[] values = new String[oldValues.length + 1];
            System.arraycopy(oldValues, 0, values, 0, oldValues.length);
            values[oldValues.length] = value;
            parameters.put(name, values);
        }
    }

    /**
     * Returns an interpretation of the specified URL-encoded string, using 
     * the iso-8859-1 character set.
     **/
    private String decode(String byteString)
    {
        return decode(byteString, "iso-8859-1");
    }

    /**
     * Decodes a URL safe string into its original form using the specified 
     * character set. Escaped characters are converted back to their original
     * representation.
     * @param string URL safe string to convert into its original form
     * @return original string
     * @throws RuntimeException if unable to decode the supplied string
     */
    private String decode(String string, String charset)
    {
        try
        {
            if (string == null) return null;

            return new String(URLCodec.decodeUrl(string.getBytes("US-ASCII")), 
            					charset);
        }
        catch (DecoderException e)
        {
            throw new RuntimeException(e.toString());
        }
		catch (UnsupportedEncodingException ex)
		{
			throw new RuntimeException(ex.toString());
		}
    }

    /**
     * Helper method to retrieve the query string from url.
     * @param uri The url used for calling the execution.
     * @return The portion of query string containing parameter information.
     */
    private String getParameterString(String uri)
    {
    	if (null == uri) return null; 
        return uri.indexOf('?') < 0 ? "" : uri.substring(uri.indexOf('?') + 1);
    }
    
    public void clearRawData() 
    {
    	try
    	{
    		if ( _rawData != null)
    			_rawData.close();
    	}
    	catch ( Exception e)
    	{
    		logger.error(e.getMessage());
    	}
    	finally
    	{
    		_rawData = null;
    	}
    }

}
