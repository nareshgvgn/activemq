/*------------------------------------------------------------------------------
 * PACKAGE: org.springbyexample.httpclient
 * FILE   : HttpShortKeepAliveStrategy.java
 * CREATED: Jun 14, 2016 10:59:42 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http;

import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: HttpShortKeepAliveStrategy.java,v 1.1 2016/06/20 04:57:40 ramap Exp $
 */
public class HttpShortKeepAliveStrategy implements ConnectionKeepAliveStrategy
{
	
	/**
	 *
	 * @param response
	 * @param context
	 * @return
	 */
	@Override
	public long getKeepAliveDuration (HttpResponse response, HttpContext context)
	{
		
		// Honor 'keep-alive' header
		HeaderElementIterator it = new BasicHeaderElementIterator(response.headerIterator(HTTP.CONN_KEEP_ALIVE));
		while (it.hasNext())
		{
			HeaderElement he = it.nextElement();
			String param = he.getName();
			String value = he.getValue();
			if (value != null && param.equalsIgnoreCase("timeout"))
			{
				try
				{
					return Long.parseLong(value) * 100;
				}
				catch (NumberFormatException ignore)
				{
				}
			}
		}
		
		HttpHost target = (HttpHost) context.getAttribute(HttpClientContext.HTTP_TARGET_HOST);
		if ("www.mydomain.com".equalsIgnoreCase(target.getHostName()))
		{
			
			// Keep alive for 5 seconds only
			return 5 * 1000;
		}
		else
		{
			
			// otherwise keep alive for 1 seconds
			return 1 * 1000;
		}
	}
	
}