/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.standard.admin.channnel.mapidentifier
 * FILE   : IrisAdminDataObjectHelper.java
 * CREATED: Dec 25, 2015 6:34:24 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http.dataobject;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.contexts.ContextManager;
import com.cashtech.iris.exceptions.BeanConfigException;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.message.detailers.LogMessageDetailer;
import com.cashtech.iris.patterns.sdo.DataObject;
import com.dh.iris.admin.channels.iris.IDataObject;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Sachin Kadam
 * @version $Id: IrisAdminDataObjectHelper.java,v 1.1 2016/04/28 07:06:26 ramap Exp $
 */
public class IrisAdminDataObjectHelper implements IDataObject
{
	private static Logger logger = LoggerFactory.getLogger(IrisAdminDataObjectHelper.class);
	private Map<String, String> properties = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisAdminDataObjectHelper()
	{
	}

	/**
	 * @param parameters
	 *            the parameters to set
	 */
	public void setProperties (Map<String, String> properties)
	{
		this.properties = properties;
	}
	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
	}

	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channels.iris.IDataObject#createDataObject(java.util.Map)
	 */
	@Override
	public DataObject createDataObject (Map<String, Object> parms) 
	{
		DataObject inDo = null;
		NodeProcessingException nodeEx = null;
		String beanName = null;
		
		try
		{
			beanName =  properties.get("bankReporExport");
			inDo = getDataObject(beanName, parms);
		}
		catch (Exception e)
		{
			nodeEx = new NodeProcessingException("error.app.PAYplusJMSAckProcIdentifier", new Object[] { "source object is null" }, null);			
			logger.error(new LogMessageDetailer().getText(nodeEx));
					//throw nodeEx; //-- Need to ask to Babu
		}
		return inDo;
	}
	
	private DataObject getDataObject ( String beanName, Map<String, Object> parms) throws BeanConfigException, FileNotFoundException, ExecutionException
	{
		IDataObject inputDO = null;
		DataObject inDo = null;
		
		inputDO = (IDataObject) ContextManager.getInstance().getBeanObject(beanName);
		inDo = inputDO.createDataObject(parms);
		return inDo;
		
	}
	
}
