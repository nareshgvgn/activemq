/*------------------------------------------------------------------------------
 * PACKAGE: org.springbyexample.httpclient
 * FILE   : RequestCallback.java
 * CREATED: Jun 13, 2016 12:44:17 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.http;

import java.io.IOException;
import java.sql.Connection;
import java.util.Map;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: RequestCallback.java,v 1.1 2016/06/20 04:57:40 ramap Exp $
 * @param <K>
 */
public interface RequestCallback
{
	public void initialize (Connection dbConnection, Map<String, Object> parms) throws Exception ;
	public Object doWithRequest(Object entity)  throws IOException;
}
