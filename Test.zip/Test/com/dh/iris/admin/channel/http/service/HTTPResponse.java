/*
 * (C) CashTech Solutions India Private Limited
 * Use strictly pursuant to license conditions only
 */

package com.dh.iris.admin.channel.http.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.URLConnection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.util.IRISLogger;

/**
 * This class manages the headers and content streams of a HTTP response.
 * It can be used for receiving or generating response.
 * 
 * @author vijayb
 * @version $Id: HTTPResponse.java,v 1.1 2015/11/28 08:08:01 ramap Exp $ 
 */
public class HTTPResponse
{
	/**
	 * MIME type of content, e.g. "text/plain", "text/html",
	 * with default value "text/plain"
	 */
	private String mimeType = "text/plain";

	/**
	 * Headers for the HTTP response. Use addHeader()
	 * to add lines.
	 */
	private Map<String,String> header;
	
	/**
	 * <code>OutputStream</code> of the socket on which response is to be sent
	 */
	private OutputStream output;
	
	private String outputStreamCharSet = null;
	
	/**
	 * Responsible for logging errors / events that occur during the execution of the application
	 */
	private static Logger logger = LoggerFactory.getLogger(HTTPResponse.class.getName());
	
	/**
	 * GMT date formatter
	 */
	private static java.text.SimpleDateFormat gmtFrmt;
	
	static
	{
		// create gmt format
		gmtFrmt = new java.text.SimpleDateFormat( "E, d MMM yyyy HH:mm:ss 'GMT'", Locale.US);
		gmtFrmt.setTimeZone(TimeZone.getTimeZone("GMT"));
	}
	
	/**
	 * Basic Constructor constructs <code>HTTPResponse</code> object with
	 * OutputStream object & default MIME type "text/plain"
	 * 
	 * @param output - OutputStream object on which response is to be sent
	 */
	public HTTPResponse(OutputStream output)
	{
		this.output = output;
	}
	
	/**
	 * Basic Constructor constructs <code>HTTPResponse</code> object with
	 * OutputStream & provided MIME type
	 * 
	 * @param output - OutputStream object on which response is to be sent
	 * @param mimeType of the response e.g. "text/html", "text/plain"
	 */
	public HTTPResponse(OutputStream output, String mimeType)
	{
		this.output = output;
		this.mimeType = mimeType;
	}

	/**
	 * Adds given name & value pair to the header.
	 * 
	 * @param name of the header parameter
	 * @param value of parameter <b>name</b>
	 */
	public void addHeader( String name, String value )
	{
		if(header == null)
		{
			header = new LinkedHashMap<String,String>();
		}
		header.put( name, value );
	}

	/**
	 * Sends given <b>responseString</b> to the socket, with provided <b>status</b>
	 * 
	 * @param responseString which is to be sent to the client
	 * @param status of the response e.g. "200 OK", "500 Internal Server Error"
	 * @throws NodeProcessingException 
	 */
	public void sendResponse(String responseString, String status) throws NodeProcessingException
	{
		try
		{
			if ( status == null )
			{
				throw new NullPointerException( "sendResponse(): Status can't be null." );
			}
			
			PrintWriter pw = null;
			if( null != outputStreamCharSet && !"".equals(outputStreamCharSet) )
			{
				pw = new PrintWriter( new OutputStreamWriter(output, outputStreamCharSet), true); 
			}
			else
			{
				pw = new PrintWriter(output);
			}

			new PrintWriter( output );
			pw.print("HTTP/1.0 " + status + " \r\n");
			if ( mimeType != null )
			{
				pw.print("Content-Type: " + mimeType + "\r\n");
			}
			
			if( responseString != null)
			{
				pw.print("Content-Length: " + responseString.length() + "\r\n");
			}
			
			if ( header == null || header.get( "Date" ) == null )
			{
				pw.print( "Date: " + gmtFrmt.format( new Date()) + "\r\n");
			}
			
			if ( header != null )
			{
				Iterator iterator = header.entrySet().iterator();
				Map.Entry entry = null;
				while (iterator.hasNext())
				{
					entry = (Map.Entry) iterator.next();
					pw.print( entry.getKey() + ": " + entry.getValue() + "\r\n");
				}
			}
			
			pw.print("\r\n" + responseString );
			pw.print("\r\n");
			pw.flush();
			
			output.flush();
		}
		catch( Exception e )
		{
			NodeProcessingException npEx =  
				IRISLogger.getNodeProcEx("error.app.errorSendingHTTPResponse",
						new Object[] {this.getClass().getName()}, e);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}
	}
	
	/**
	 * @param responseString
	 * @param status
	 * @throws NodeProcessingException
	 */
	public void sendMultiPartedResponse(String responseString, String status) throws NodeProcessingException
	{
		String boundary = Long.toHexString(System.currentTimeMillis()); // Just generate some unique random value.
		String CRLF = "\r\n"; // Line separator required by multipart/form-data.
		File binaryFile = null;
	    InputStream input = null;
	    byte[] buffer = new byte[1024];

		try
		{
			if ( status == null )
			{
				throw new NullPointerException( "sendMultiPartedResponse(): Status can't be null." );
			}//if
			
			if( null == responseString || "".equals(responseString) )
			{
				throw new NullPointerException(
						"sendMultiPartedResponse(): File Name can't be null.");
			}//if
			
			binaryFile = new File(responseString);
			
			if(!binaryFile.exists())
			{
				throw new NullPointerException(
						"sendMultiPartedResponse(): File does not exists.  "
								+ responseString);
			}//if
			
			PrintWriter writer = null;
			if( null != outputStreamCharSet && !"".equals(outputStreamCharSet) )
			{
				writer = new PrintWriter( new OutputStreamWriter(output, outputStreamCharSet), true);
			}
			else
			{
				writer = new PrintWriter(output);
			}
			writer.print("HTTP/1.0 " + status + " \r\n");
			
		    writer.append("--" + boundary).append(CRLF);
		    writer.append("Content-Disposition: form-data; name=\"binaryFile\"; filename=\"" + binaryFile.getName() + "\"").append(CRLF);
		    writer.append("Content-Type: " + URLConnection.guessContentTypeFromName(binaryFile.getName())).append(CRLF);
		    writer.append("Content-Transfer-Encoding: binary").append(CRLF);
		    writer.append(CRLF).flush();
		
		    input = new FileInputStream(binaryFile);
	        for (int length = 0; (length = input.read(buffer)) > 0;) 
	        {
	            output.write(buffer, 0, length);
	        }//for
	            
		    writer.append(CRLF).flush(); 

		    writer.append("--" + boundary + "--").append(CRLF);
		    
	        output.flush(); 

		}//try
		catch( Exception e )
		{
			NodeProcessingException npEx =  
				IRISLogger.getNodeProcEx("error.app.errorSendingHTTPResponse",
						new Object[] {this.getClass().getName()}, e);
			logger.error(IRISLogger.getText(npEx));
			throw npEx;
		}//catch
		finally
		{
			if( null != input)
			{
				try
				{
					input.close();
				}//try
				catch (IOException e)
				{
					logger.error("IOException occured while closing the input stream. Consuming this exception.");
				}//catch
			}//if
		}//finally
	}
    /**
     * Sends only  headers to the socket with HTTP 1.1 version
     * @param status
     * @throws IOException
     */
    public void sendHeaders(String status) throws IOException 
    {
        PrintStream pw = new PrintStream(
             new BufferedOutputStream(output, 1024), false);

        pw.print("HTTP/1.1 " + status + " \r\n");
        if ( header != null )
        {
            Iterator iterator = header.entrySet().iterator();
            Map.Entry entry = null;
            while (iterator.hasNext())
            {
                entry = (Map.Entry) iterator.next();
                pw.print( entry.getKey() + ": " + entry.getValue() + "\r\n");
            }
        }
        pw.flush();
        pw.close() ;
    }

	public void setOutputStreamCharSet(String outputStreamCharSet)
	{
		this.outputStreamCharSet = outputStreamCharSet;
	}
}
