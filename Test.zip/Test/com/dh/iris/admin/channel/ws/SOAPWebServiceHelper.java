/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws
 * FILE   : SOAPWebServiceHelper.java
 * CREATED: Nov 20, 2015 12:05:37 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.dom4j.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.dh.iris.admin.channel.ws.callback.IServiceCallBack;
import com.dh.iris.admin.channel.ws.callback.IServiceMessageExtractor;
import com.dh.iris.admin.channel.ws.callback.SysSoapMessageExtractor;
import com.dh.iris.admin.channel.ws.callback.SysWebServiceCallBack;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractRequestReceiver;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.IAuditHandler;
import com.fundtech.iris.admin.channel.IRetryHandler;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: SOAPWebServiceHelper.java,v 1.9 2016/10/27 06:08:13 ramap Exp $
 */
public class SOAPWebServiceHelper extends AbstractRequestReceiver
{
	private static Logger logger = LoggerFactory.getLogger(SOAPWebServiceHelper.class);
	private WebServiceTemplate webServiceTemplate = null;
	private IServiceCallBack actionServiceCallBack = null;
	private IServiceMessageExtractor serviceMessageExtractor = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public SOAPWebServiceHelper()
	{
		// BABU Auto-generated constructor stub
	}
	
	public void sendMessage( Map<String, Object> inputParms) throws ExecutionException
	{
		String receivedMessage = null;
		ExecutionException eExp = null;
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		ExecutionJobData jobData = null;
		Map<String, Object> outputParms = null;
		Map<String, Object> auditParms = null;
		IAuditHandler auditHandler = null;
		Document message = null;
		String requestService = null;
		Map<String, Object> serviceOutput = null;
		String serviceStatus = null;
		String  faultCode = null;
		String faultReason = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		String threadIdName = null;
		ExecutionJobData responseJobData = null;

		try
		{
			jobData = (ExecutionJobData) inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			requestService = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_URI);
			threadIdName = Thread.currentThread().getName();
			if ( requestService == null)
			{
				requestService = webServiceTemplate.getDefaultUri();
				logger.warn("Web Servuce URI not configured for the Service, so usinng default one: {} , so please configure: {}" , 
																			requestService, IrisAdminConstants.WEBSERVICE_URI);
			}
			dbConnection = getDBProvider().getConnection();
			message = (Document)jobData.getDataObject();
			auditHandler = getAuditHandler();
			auditParms = new HashMap<String, Object>();
			auditParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
			auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, message.asXML());
			auditHandler.audit(auditParms, IAuditHandler.REQUEST_TYPE);
			
			serviceOutput = callWebservice(requestService, jobData, dbConnection);
			serviceStatus = (String) serviceOutput.get(IServiceMessageExtractor.WEBSERVICE_STATUS);
			
			if ( IServiceMessageExtractor.WEBSERVICE_SUCESS.equals(serviceStatus))
			{
				receivedMessage = (String) serviceOutput.get(IrisAdminConstants.WEBSERVICE_MESSAGE);
			}
			else
			{
				receivedMessage = (String) serviceOutput.get(IrisAdminConstants.WEBSERVICE_MESSAGE);
				logger.error("Error Message Received:-{}",receivedMessage);
				faultCode = (String) serviceOutput.get(IServiceMessageExtractor.WEBSERVICE_FAULT_CODE);
				faultReason = (String) serviceOutput.get(IServiceMessageExtractor.WEBSERVICE_FAULT_REASON);
				auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, receivedMessage);
				auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
				eExp = new ExecutionException("error.iris.admin.webservice.error", new Object[] {faultCode, faultReason}, null);
				
				jobData.setStatus("E");
				error = IrisAdminUtils.createInterError("999", faultReason, faultCode, null);
				irisError = IrisAdminUtils.createIrisError(IrisAdminConstants.MEDIA_WEBSERVICE,IrisAdminConstants.MEDIA_WEBSERVICE, faultReason);
				jobData.addIrisError(irisError);
				jobData.addError(error);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			
			if ( receivedMessage != null)
			{
				
				logger.debug("Message received:-\n{}" , receivedMessage);
				auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, receivedMessage);
				auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
				activatorHelper = new ActivatorHelper();
				
				activatorHelper.initialize(dbConnection, getApplicationContext());
				outputParms = new HashMap<String, Object>();
				outputParms.put(IrisAdminConstants.WEBSERVICE_MESSAGE, receivedMessage);
				outputParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, getProcIdentifier());
				outputParms.put(IrisAdminConstants.REQUEST_JOB_DATA, jobData);
				outputParms.put(IrisAdminConstants.CHANNEL, "WebService");
				responseJobData = activatorHelper.runProcess(outputParms, IrisAdminConstants.MEDIA_WEBSERVICE, jobData.isAccumulateErros(), null);
				if ( responseJobData != null)
					jobData.setRespExecutionId(responseJobData.getExecutionId());
			}
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.timeout", new Object[] {}, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch ( ExecutionException exp)
		{
			if ( "error.iris.admin.chain.timeout".equals(exp.getKey()))
				throw exp;
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.process", new Object[] {}, exp);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch (SystemException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (SQLException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			logger.info("Changing thread name back from [{}] to [{}]", Thread.currentThread().getName(), threadIdName);
			Thread.currentThread().setName(threadIdName);
			CleanUpUtils.doClean(auditParms);
			CleanUpUtils.doClean(inputParms);
			CleanUpUtils.doClean(outputParms);
			if ( activatorHelper != null)
				activatorHelper.cleanUp();
			cleanup(dbConnection);
			
		}
		
	}
	
	private Map<String, Object> callWebservice(String uri,  ExecutionJobData jobData, Connection dbConnection)  throws ExecutionException
	{
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		int continueRetry = IRetryHandler.CONTINUE_RETRY;
		Map<String, Object> retryInput = null;
		IRetryHandler retryHandler = null;
		String actionCallBackBeanName = null;
		IServiceCallBack soapHeaderBean = null;
		String messageExtractorBeanName = null;
		IServiceMessageExtractor messageExtractorBean = null;
		Map<String, Object> serviceOutput = null;
		Map<String, Object> actionDataMap = null;
		
		
		retryInput = new HashMap<String, Object>();
		retryInput.put(IrisAdminConstants.EXECUTION_DATA, jobData);
		retryHandler = getRetryHandler();
		
		actionCallBackBeanName = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_ACTION_BEAN);
		if ( actionCallBackBeanName == null)
			soapHeaderBean = getActionServiceCallBack();
		else
			soapHeaderBean = (IServiceCallBack)getBean(actionCallBackBeanName);
		
		messageExtractorBeanName = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_EXTRACTOR_BEAN);
		if ( messageExtractorBeanName == null)
			messageExtractorBean = getServiceMessageExtractor();
		else
			messageExtractorBean = (IServiceMessageExtractor) getBean(messageExtractorBeanName);
		
		
		while( continueRetry == IRetryHandler.CONTINUE_RETRY)
		{
			try
			{
				actionDataMap = new HashMap<String, Object>();
				actionDataMap.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				soapHeaderBean.initialize(dbConnection, actionDataMap);
				messageExtractorBean.initialize(dbConnection, actionDataMap);
				
				serviceOutput = webServiceTemplate.sendAndReceive(uri,  soapHeaderBean, messageExtractorBean);
				retryInput.put(IRetryHandler.RECEIVED_MESSAGE, serviceOutput);
				continueRetry = (Integer) retryHandler.retry(retryInput);
				retryInput.clear();
				if ( IRetryHandler.STOP_RETRY == continueRetry)
				{
					errorMsg = "Re-try handler thrown error, Stop Retry invoked!!";
					eExp = new ExecutionException("error.iris.admin.socketerror", new Object[]	{ errorMsg }, null);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw eExp;
				}
				else if (  IRetryHandler.CONTINUE_RETRY == continueRetry)
					logger.error("Re-try Handler thrownn error, so re-tryinng again");
						
			}
			catch ( ExecutionException exp)
			{
				throw exp;
			}
			catch ( Exception exp)
			{
				errorMsg = exp.getMessage();
				retryInput.put(IRetryHandler.ERROR_MESSAGE, errorMsg);
				
				continueRetry = (Integer) retryHandler.retry(retryInput);
				if ( continueRetry != IRetryHandler.CONTINUE_RETRY)
				{
					retryInput.clear();
					errorMsg = "not abble to connect server after re-try count" ;
					eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "webservice error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw eExp;
				}
			}
			finally
			{
				CleanUpUtils.doClean(actionDataMap);
			}
		}
		return serviceOutput;
	}
			
	

	/**
	 * @return the webServiceTemplate
	 */
	public WebServiceTemplate getWebServiceTemplate ()
	{
		return webServiceTemplate;
	}

	/**
	 * @param webServiceTemplate the webServiceTemplate to set
	 */
	public void setWebServiceTemplate (WebServiceTemplate webServiceTemplate)
	{
		this.webServiceTemplate = webServiceTemplate;
	}

	/**
	 * @return the actionServiceCallBack
	 */
	public IServiceCallBack getActionServiceCallBack ()
	{
		if ( actionServiceCallBack == null)
			actionServiceCallBack = new SysWebServiceCallBack();
		return actionServiceCallBack;
	}

	/**
	 * @param actionServiceCallBack the actionServiceCallBack to set
	 */
	public void setActionServiceCallBack (IServiceCallBack actionServiceCallBack)
	{
		this.actionServiceCallBack = actionServiceCallBack;
	}

	/**
	 * @return the serviceMessageExtractor
	 */
	public IServiceMessageExtractor getServiceMessageExtractor ()
	{
		if ( serviceMessageExtractor == null)
			serviceMessageExtractor = new SysSoapMessageExtractor();
		return serviceMessageExtractor;
	}

	/**
	 * @param serviceMessageExtractor the serviceMessageExtractor to set
	 */
	public void setServiceMessageExtractor (IServiceMessageExtractor serviceMessageExtractor)
	{
		this.serviceMessageExtractor = serviceMessageExtractor;
	}
	
}
