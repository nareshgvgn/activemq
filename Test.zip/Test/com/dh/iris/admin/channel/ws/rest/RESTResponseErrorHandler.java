/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws.rest
 * FILE   : RESTResponseErrorHandler.java
 * CREATED: Jan 3, 2017 10:16:06 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws.rest;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import com.fundtech.iris.admin.util.RestUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: RESTResponseErrorHandler.java,v 1.1 2017/01/30 04:50:14 ramap Exp $
 */
public class RESTResponseErrorHandler implements ResponseErrorHandler
{
	private static final Logger logger = LoggerFactory.getLogger(RESTResponseErrorHandler.class);
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public RESTResponseErrorHandler()
	{
		// BABU Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.client.ResponseErrorHandler#hasError(org.springframework.http.client.ClientHttpResponse)
	 */
	@Override
	public boolean hasError (ClientHttpResponse response) throws IOException
	{
		return RestUtils.isError(response.getStatusCode());
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.client.ResponseErrorHandler#handleError(org.springframework.http.client.ClientHttpResponse)
	 */
	@Override
	public void handleError (ClientHttpResponse response) throws IOException
	{
		logger.error("Response error: {} {}", response.getStatusCode(), response.getStatusText());
		
	}
	
}
