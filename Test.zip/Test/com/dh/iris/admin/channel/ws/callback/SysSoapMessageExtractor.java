/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws.callback
 * FILE   : SysSoapMessageExtractor.java
 * CREATED: Dec 2, 2015 12:34:41 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws.callback;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.util.Map;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: SysSoapMessageExtractor.java,v 1.1 2015/12/03 06:16:12 ramap Exp $
 */
public class SysSoapMessageExtractor extends AbstractServiceExtractor
{

	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.callback.AbstractServiceExtractor#doInitialize(java.sql.Connection, java.util.Map)
	 */
	@Override
	public void doInitialize (Connection dbConnection, Map<String, Object> parms)
	{
		// BABU Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.callback.AbstractServiceExtractor#extractMessage(java.util.Map)
	 */
	@Override
	public Map<String, Object> extractMessage (Map<String, Object> parms, SaajSoapMessage saajSoapMessage)
	{
		
		return parms;
	}
	
}
