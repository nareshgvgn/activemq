/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws
 * FILE   : RESTServiceHelper.java
 * CREATED: Dec 29, 2016 5:31:01 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws.rest;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cashtech.iris.message.messages.SystemException;
import com.cashtech.iris.util.IRISLogger;
import com.dh.iris.admin.channel.ws.rest.callback.IRestServiceExtractor;
import com.dh.iris.admin.channel.ws.rest.callback.IRestServiceRequestCallBack;
import com.dh.iris.admin.channel.ws.rest.callback.RestJsonCallBack;
import com.dh.iris.admin.channel.ws.rest.callback.RestJsonExtractor;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.channel.AbstractRequestReceiver;
import com.fundtech.iris.admin.channel.ActivatorHelper;
import com.fundtech.iris.admin.channel.IAuditHandler;
import com.fundtech.iris.admin.channel.IRetryHandler;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.data.IrisAdminError;
import com.fundtech.iris.admin.data.IrisError;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

import net.minidev.json.JSONObject;


/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: RESTServiceHelper.java,v 1.2 2017/02/27 13:21:08 ramap Exp $
 */
public class RESTServiceHelper extends AbstractRequestReceiver
{
	
	private static Logger logger = LoggerFactory.getLogger(RESTServiceHelper.class);
	private RestTemplate restServiceTemplate = null;
	private IRestServiceRequestCallBack<JSONObject> requestServiceCallBack = null;
	private IRestServiceExtractor<String> serviceMessageExtractor = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public RESTServiceHelper()
	{
		// BABU Auto-generated constructor stub
	}
	
	public void sendMessage( Map<String, Object> inputParms) throws ExecutionException
	{
		String receivedMessage = null;
		String strMessage = null;
		ExecutionException eExp = null;
		ActivatorHelper activatorHelper = null;
		Connection dbConnection = null;
		ExecutionJobData jobData = null;
		Map<String, Object> outputParms = null;
		Map<String, Object> auditParms = null;
		IAuditHandler auditHandler = null;
		JSONObject message = null;
		String requestService = null;
		Map<String, Object> serviceOutput = null;
		HttpStatus serviceStatus = null;
		String  faultCode = null;
		String faultReason = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		String threadIdName = null;
		ExecutionJobData responseJobData = null;

		try
		{
			jobData = (ExecutionJobData) inputParms.get(IrisAdminConstants.EXECUTION_DATA);
			requestService = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_URI);
//			requestService = "http://ftlt322:8080/post";
			threadIdName = Thread.currentThread().getName();
			dbConnection = getDBProvider().getConnection();
			message = (JSONObject)jobData.getDataObject();
			auditHandler = getAuditHandler();
			auditParms = new HashMap<String, Object>();
			auditParms.put(IrisAdminConstants.EXECUTION_DATA, jobData);
			auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA,message.toJSONString());
			auditHandler.audit(auditParms, IAuditHandler.REQUEST_TYPE);
			
			serviceOutput = callWebservice(requestService, jobData, dbConnection);
			serviceStatus = (HttpStatus) serviceOutput.get(IRestServiceExtractor.WEBSERVICE_STATUS);
			receivedMessage = (String) serviceOutput.get(IrisAdminConstants.WEBSERVICE_MESSAGE);
			
			if ( ! HttpStatus.OK.equals(serviceStatus))
			{
				receivedMessage = (String) serviceOutput.get(IrisAdminConstants.WEBSERVICE_MESSAGE);
				logger.error("Error Message Received:-{}",receivedMessage);
				faultCode = (String) serviceStatus.name();
				faultReason = (String) serviceStatus.getReasonPhrase();
				auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, receivedMessage);
				auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
				eExp = new ExecutionException("error.iris.admin.webservice.error", new Object[] {faultCode, faultReason}, null);
				
				jobData.setStatus("E");
				error = IrisAdminUtils.createInterError("999", faultReason, faultCode, null);
				irisError = IrisAdminUtils.createIrisError(IrisAdminConstants.MEDIA_WEBSERVICE,IrisAdminConstants.MEDIA_WEBSERVICE, faultCode + faultReason);
				jobData.addIrisError(irisError);
				jobData.addError(error);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			
			if ( receivedMessage != null)
			{
				logger.debug("Message received:-\n{}" , receivedMessage);
				auditParms.put(IAuditHandler.AUDIT_SOURCE_DATA, strMessage);
				auditHandler.audit(auditParms, IAuditHandler.RESPONSE_TYPE);
				activatorHelper = new ActivatorHelper();
				
				activatorHelper.initialize(dbConnection, getApplicationContext());
				outputParms = new HashMap<String, Object>();
				outputParms.put(IrisAdminConstants.WEBSERVICE_MESSAGE, receivedMessage);
				outputParms.put(IrisAdminConstants.PROCESS_IDENTIFIER, getProcIdentifier());
				outputParms.put(IrisAdminConstants.REQUEST_JOB_DATA, jobData);
				outputParms.put(IrisAdminConstants.CHANNEL, "WebService");
				responseJobData = activatorHelper.runProcess(outputParms, IrisAdminConstants.MEDIA_WEBSERVICE, jobData.isAccumulateErros(), null);
				if ( responseJobData != null)
					jobData.setRespExecutionId(responseJobData.getExecutionId());
			}
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.timeout", new Object[] {}, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch ( ExecutionException exp)
		{
			if ( "error.iris.admin.chain.timeout".equals(exp.getKey()))
				throw exp;
			else
			{
				eExp = new ExecutionException("error.iris.admin.chain.process", new Object[] {}, exp);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
		}
		catch (SystemException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch (SQLException e)
		{
			eExp = new ExecutionException("error.iris.admin.chain.dbConnection", new Object[] {}, e);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			logger.info("Changing thread name back from [{}] to [{}]", Thread.currentThread().getName(), threadIdName);
			Thread.currentThread().setName(threadIdName);
			CleanUpUtils.doClean(auditParms);
			CleanUpUtils.doClean(inputParms);
			CleanUpUtils.doClean(outputParms);
			if ( activatorHelper != null)
				activatorHelper.cleanUp();
			cleanup(dbConnection);
			
		}
	}
	
	private Map<String, Object> callWebservice(String uri,  ExecutionJobData jobData, Connection dbConnection)  throws ExecutionException
	{
		ExecutionException eExp = null;
		String errorMsg = null;
		IrisAdminError error = null;
		IrisError irisError = null;
		int continueRetry = IRetryHandler.CONTINUE_RETRY;
		Map<String, Object> retryInput = null;
		IRetryHandler retryHandler = null;
		String actionCallBackBeanName = null;
		String messageExtractorBeanName = null;
		ResponseEntity<String> responseEntity = null;
		Map<String, Object> actionDataMap = null;
		Map<String, Object> serviceOutput = null;
		HttpEntity<JSONObject> requestEntity = null;
		
		
		retryInput = new HashMap<String, Object>();
		retryInput.put(IrisAdminConstants.EXECUTION_DATA, jobData);
		retryHandler = getRetryHandler();
		
		actionCallBackBeanName = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_ACTION_BEAN);
		if ( actionCallBackBeanName == null)
			requestServiceCallBack = getRequestServiceCallBack();
		else
			requestServiceCallBack = (IRestServiceRequestCallBack<JSONObject>)getBean(actionCallBackBeanName);
		
		messageExtractorBeanName = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_EXTRACTOR_BEAN);
		if ( messageExtractorBeanName == null)
			serviceMessageExtractor = getServiceMessageExtractor();
		else
			serviceMessageExtractor = (IRestServiceExtractor<String>) getBean(messageExtractorBeanName);
		
		while( continueRetry == IRetryHandler.CONTINUE_RETRY)
		{
			try
			{
				actionDataMap = new HashMap<String, Object>();
				actionDataMap.put(IrisAdminConstants.EXECUTION_DATA, jobData);
				requestServiceCallBack.initialize(dbConnection, actionDataMap);
				requestEntity = requestServiceCallBack.doWithdoWithMessage(actionDataMap);
				responseEntity = restServiceTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class);
				
				serviceMessageExtractor.initialize(dbConnection, actionDataMap);
				serviceOutput = serviceMessageExtractor.doWithdoWithMessage(responseEntity);
				retryInput.put(IRetryHandler.RECEIVED_MESSAGE, serviceOutput);
				continueRetry = (Integer) retryHandler.retry(retryInput);
				retryInput.clear();
				if ( IRetryHandler.STOP_RETRY == continueRetry)
				{
					errorMsg = "Re-try handler thrown error, Stop Retry invoked!!";
					eExp = new ExecutionException("error.iris.admin.socketerror", new Object[]	{ errorMsg }, null);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "socket error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw eExp;
				}
				else if (  IRetryHandler.CONTINUE_RETRY == continueRetry)
					logger.error("Re-try Handler thrownn error, so re-tryinng again");
						
			}
			catch ( ExecutionException exp)
			{
				throw exp;
			}
			catch ( HttpStatusCodeException exp)
			{
				exp.printStackTrace();
			}
			catch ( RestClientException exp)
			{
				errorMsg = exp.getMessage();
				retryInput.put(IRetryHandler.ERROR_MESSAGE, errorMsg);
				
				continueRetry = (Integer) retryHandler.retry(retryInput);
				if ( continueRetry != IRetryHandler.CONTINUE_RETRY)
				{
					retryInput.clear();
					errorMsg = "not abble to connect server after re-try count" ;
					eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "webservice error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw eExp;
				}
			}
			catch ( Exception exp)
			{
				errorMsg = exp.getMessage();
				retryInput.put(IRetryHandler.ERROR_MESSAGE, errorMsg);
				
				continueRetry = (Integer) retryHandler.retry(retryInput);
				if ( continueRetry != IRetryHandler.CONTINUE_RETRY)
				{
					retryInput.clear();
					errorMsg = "not abble to connect server after re-try count" ;
					eExp = new ExecutionException("error.iris.admin.notifystatus", new Object[]	{ errorMsg }, exp);
					logger.error(IRISLogger.getText(eExp));
					jobData.setStatus("E");
					error = IrisAdminUtils.createInterError("999", errorMsg, "webservice error", null);
					irisError = IrisAdminUtils.createIrisError(IrisError.FILE, IrisError.FILE, errorMsg);
					jobData.addIrisError(irisError);
					jobData.addError(error);
					throw eExp;
				}
			}
			finally
			{
				CleanUpUtils.doClean(actionDataMap);
			}
		}
		return serviceOutput;
	}
			
	


	/**
	 * @return the requestServiceCallBack
	 */
	public IRestServiceRequestCallBack<JSONObject> getRequestServiceCallBack ()
	{
		if ( requestServiceCallBack == null)
			requestServiceCallBack = new RestJsonCallBack();
		return requestServiceCallBack;
	}

	/**
	 * @param requestServiceCallBack the requestServiceCallBack to set
	 */
	public void setRequestServiceCallBack (IRestServiceRequestCallBack<JSONObject> requestServiceCallBack)
	{
		this.requestServiceCallBack = requestServiceCallBack;
	}

	/**
	 * @return the serviceMessageExtractor
	 */
	public IRestServiceExtractor<String> getServiceMessageExtractor ()
	{
		if ( serviceMessageExtractor == null)
			serviceMessageExtractor = new RestJsonExtractor();
		return serviceMessageExtractor;
	}

	/**
	 * @param serviceMessageExtractor the serviceMessageExtractor to set
	 */
	public void setServiceMessageExtractor (IRestServiceExtractor<String> serviceMessageExtractor)
	{
		this.serviceMessageExtractor = serviceMessageExtractor;
	}

	/**
	 * @return the restServiceTemplate
	 */
	public RestTemplate getRestServiceTemplate ()
	{
		return restServiceTemplate;
	}

	/**
	 * @param restServiceTemplate the restServiceTemplate to set
	 */
	public void setRestServiceTemplate (RestTemplate restServiceTemplate)
	{
		this.restServiceTemplate = restServiceTemplate;
	}
}