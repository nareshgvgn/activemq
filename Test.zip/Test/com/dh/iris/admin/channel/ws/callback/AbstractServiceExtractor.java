/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws.callback
 * FILE   : AbstractServiceExtractor.java
 * CREATED: Dec 2, 2015 7:38:56 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws.callback;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.util.HelperUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AbstractServiceExtractor.java,v 1.2 2015/12/09 05:02:45 ramap Exp $
 */
public abstract class AbstractServiceExtractor implements IServiceMessageExtractor
{
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public AbstractServiceExtractor()
	{
		// BABU Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.ws.client.core.WebServiceMessageExtractor#extractData(org.springframework.ws.WebServiceMessage)
	 */
	@Override
	public Map<String, Object> extractData (WebServiceMessage message) throws IOException, TransformerException
	{
		StreamResult result = null;
		ByteArrayOutputStream outStream = null;
		Transformer transformer = null;
		SaajSoapMessage saajSoapMessage = null;
		Source source =  null;
		Map<String, Object> output = new HashMap<String, Object>();
		try
		{
			saajSoapMessage = ((SaajSoapMessage)message);
			outStream = new ByteArrayOutputStream();
			result = new StreamResult(outStream);
			source = saajSoapMessage.getSoapBody().getPayloadSource();
			transformer =  TransformerFactory.newInstance().newTransformer();
			transformer.transform(source, result );
			output.put(IrisAdminConstants.WEBSERVICE_MESSAGE, outStream.toString());
			if (saajSoapMessage.hasFault() )
			{
				output.put(IServiceMessageExtractor.WEBSERVICE_STATUS, IServiceMessageExtractor.WEBSERVICE_FAILURE);
				output.put(IServiceMessageExtractor.WEBSERVICE_FAULT_CODE, saajSoapMessage.getFaultCode().getLocalPart());
				output.put(IServiceMessageExtractor.WEBSERVICE_FAULT_REASON, saajSoapMessage.getFaultReason());
				return output;
			}
			
			output = extractMessage(output, saajSoapMessage);
			output.put(IServiceMessageExtractor.WEBSERVICE_STATUS, IServiceMessageExtractor.WEBSERVICE_SUCESS);
		}
		finally
		{
			HelperUtils.doClose(outStream);
		}
		
		return output;
	}
	
	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.callback.IServiceMessageExtractor#initialize(java.sql.Connection, java.util.Map)
	 */
	@Override
	public void initialize (Connection dbConnection, Map<String, Object> parms)
	{
		// BABU Auto-generated method stub
		
	}
	
	public abstract void doInitialize(Connection dbConnection, Map<String, Object> parms);
	public abstract Map<String, Object> extractMessage(Map<String, Object> parms, SaajSoapMessage saajSoapMessage) ;
	
}
