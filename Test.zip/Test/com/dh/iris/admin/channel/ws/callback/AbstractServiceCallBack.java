/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws
 * FILE   : AbstractServiceCallBack.java
 * CREATED: Nov 27, 2015 1:52:23 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws.callback;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.sql.Connection;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerException;

import org.dom4j.io.DOMWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AbstractServiceCallBack.java,v 1.5 2017/03/21 12:10:00 ramap Exp $
 */
public abstract class AbstractServiceCallBack implements IServiceCallBack
{
	private Document document = null;
	private static Logger logger = LoggerFactory.getLogger(AbstractServiceCallBack.class);
	
	/* (non-Javadoc)
	 * @see org.springframework.ws.client.core.WebServiceMessageCallback#doWithMessage(org.springframework.ws.WebServiceMessage)
	 */
	@Override
	public void doWithMessage (WebServiceMessage message) throws IOException, TransformerException
	{
		SaajSoapMessage saajSoapMessage = null;
		SOAPMessage soapMessage =  null;
		
		try
		{
			saajSoapMessage = ((SaajSoapMessage)message);
			modifyMessage(saajSoapMessage);
			soapMessage = saajSoapMessage.getSaajMessage();
			soapMessage.getSOAPBody().addDocument(document);
			
			logger.trace("Sending Message:- {}",soapMessage.toString());
		}
		catch (Exception e)
		{
			throw new IOException(e);
		}
	}


	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.IServiceCallBack#initialize(java.sql.Connection, java.util.Map)
	 */
	@Override
	public void initialize (Connection dbConnection, Map<String, Object> parms) throws Exception
	{
		ExecutionJobData jobData = null;
		DOMWriter domWriter = new DOMWriter();
		
		jobData = (ExecutionJobData)parms.get(IrisAdminConstants.EXECUTION_DATA);
		document =  domWriter.write((org.dom4j.Document)jobData.getDataObject());
//		document = converttoDoc();// this is only for test
		doInitialize(dbConnection, parms);
	}
	
	
	private static Document convertStringToDocument(String xmlStr) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
        DocumentBuilder builder;  
        try 
        {  
            builder = factory.newDocumentBuilder();  
            Document doc = builder.parse( new InputSource( new StringReader( xmlStr ) ) ); 
            return doc;
        } catch (Exception e) {  
            e.printStackTrace();  
        } 
        return null;
    }
	/**
	 * This is method is only for testing
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @return
	 * </pre></p>
	 */
	@SuppressWarnings("unused")
	private static Document converttoDoc() 
	{
		Document doc = null;
		FileInputStream stream = null;
		DocumentBuilder parser;
		try
		{
			stream = new FileInputStream(new File("C:\\temp\\test1.xml"));
			parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			doc = parser.parse( new InputSource(stream) );
		}
		catch (ParserConfigurationException e)
		{
			// BABU Auto-generated catch block
			e.printStackTrace();
		}
		catch (FileNotFoundException e)
		{
			// BABU Auto-generated catch block
			e.printStackTrace();
		}
		catch (SAXException e)
		{
			// BABU Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// BABU Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			CleanUpUtils.doClose(stream);
		}
			    
		return doc;
	}
	
	public abstract void doInitialize(Connection dbConnection, Map<String, Object> parms);
	public abstract void modifyMessage(SaajSoapMessage saajSoapMessage) ;
}
