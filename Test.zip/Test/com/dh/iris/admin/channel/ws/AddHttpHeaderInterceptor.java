/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws
 * FILE   : AddHttpHeaderInterceptor.java
 * CREATED: Mar 21, 2017 2:24:00 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws;

import java.util.Map;

import org.apache.http.client.methods.HttpPost;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.transport.context.TransportContext;
import org.springframework.ws.transport.context.TransportContextHolder;
import org.springframework.ws.transport.http.HttpComponentsConnection;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AddHttpHeaderInterceptor.java,v 1.1 2017/03/21 12:10:00 ramap Exp $
 */
public class AddHttpHeaderInterceptor implements ClientInterceptor
{
	private Map<String, String> staticHeaders = null;
	
	public boolean handleFault (MessageContext messageContext) throws WebServiceClientException
	{
		return true;
	}
	
	public boolean handleRequest (MessageContext messageContext) throws WebServiceClientException
	{
		TransportContext context = null;
		HttpComponentsConnection connection = null;
		HttpPost postMethod = null;
		
		if (staticHeaders != null && ! staticHeaders.isEmpty())
		{
			context = TransportContextHolder.getTransportContext();
			connection = (HttpComponentsConnection) context.getConnection();
			postMethod = connection.getHttpPost();
			addHeader(postMethod);
		}
		return true;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param postMethod
	 * </pre></p>
	 */
	private void addHeader (HttpPost postMethod)
	{
		for (Map.Entry<String, String> entry : staticHeaders.entrySet())
			postMethod.addHeader(entry.getKey(), entry.getValue());
		
	}

	public boolean handleResponse (MessageContext messageContext) throws WebServiceClientException
	{
		return true;
	}
	
	

	/* (non-Javadoc)
	 * @see org.springframework.ws.client.support.interceptor.ClientInterceptor#afterCompletion(org.springframework.ws.context.MessageContext, java.lang.Exception)
	 */
	@Override
	public void afterCompletion (MessageContext messageContext, Exception ex) throws WebServiceClientException
	{
		
	}

	/**
	 * @return the staticHeaders
	 */
	public Map<String, String> getStaticHeaders ()
	{
		return staticHeaders;
	}

	/**
	 * @param staticHeaders the staticHeaders to set
	 */
	public void setStaticHeaders (Map<String, String> staticHeaders)
	{
		this.staticHeaders = staticHeaders;
	}
	
}
