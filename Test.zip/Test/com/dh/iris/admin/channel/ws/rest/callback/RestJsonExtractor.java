/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws.rest.callback
 * FILE   : RestJsonExtractor.java
 * CREATED: Jan 2, 2017 10:53:32 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws.rest.callback;

import java.sql.Connection;
import java.util.Map;

import org.springframework.http.ResponseEntity;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: RestJsonExtractor.java,v 1.1 2017/01/30 04:50:14 ramap Exp $
 */
public class RestJsonExtractor extends AbstractRestServiceExtractor<String>
{

	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.rest.callback.AbstractRestServiceExtractor#doInitialize(java.sql.Connection, java.util.Map)
	 */
	@Override
	public void doInitialize (Connection dbConnection, Map<String, Object> parms)
	{
		
	}

	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.rest.callback.AbstractRestServiceExtractor#extractMessage(org.springframework.http.ResponseEntity)
	 */
	@Override
	public void extractMessage (ResponseEntity<String> responseEntity, Map<String, Object> response) 
	{
//		ObjectMapper objectMapper = null;
//		JSONObject jsonObject = null;
//		
//		try
//		{
//			if ( HttpStatus.OK.equals(responseEntity.getStatusCode()))
//			{
//				objectMapper = new ObjectMapper();
//				
//				jsonObject = objectMapper.readValue(responseEntity.getBody(), JSONObject.class);
//				response.put(IrisAdminConstants.WEBSERVICE_MESSAGE, jsonObject);
//			}
//		}
//		catch (JsonParseException e)
//		{
//			// BABU Auto-generated catch block
//			e.printStackTrace();
//		}
//		catch (JsonMappingException e)
//		{
//			// BABU Auto-generated catch block
//			e.printStackTrace();
//		}
//		catch (IOException e)
//		{
//			// BABU Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	
}
