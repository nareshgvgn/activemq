/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws.rest.callback
 * FILE   : AbstractRestServiceExtractor.java
 * CREATED: Jan 2, 2017 10:49:13 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws.rest.callback;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.fundtech.iris.admin.IrisAdminConstants;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * {@code TODO - Put bean configuration xml snippet here (if applicable)
 * }
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: AbstractRestServiceExtractor.java,v 1.1 2017/01/30 04:50:14 ramap Exp $
 */
public abstract class AbstractRestServiceExtractor<T> implements IRestServiceExtractor<T>
{

	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.rest.callback.IRestServiceExtractor#initialize(java.sql.Connection, java.util.Map)
	 */
	@Override
	public void initialize (Connection dbConnection, Map<String, Object> parms) throws Exception
	{
		doInitialize(dbConnection, parms);
		
	}

	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.rest.callback.IRestServiceExtractor#doWithdoWithMessage(org.springframework.http.ResponseEntity)
	 */
	@Override
	public Map<String, Object> doWithdoWithMessage (ResponseEntity<T> responseEntity) throws Exception
	{
		Map<String, Object> response = null;
		
		response = new HashMap<String, Object>();
		response.put(IrisAdminConstants.WEBSERVICE_MESSAGE, responseEntity.getBody());
		response.put(IRestServiceExtractor.WEBSERVICE_STATUS, responseEntity.getStatusCode());
		response.put(IRestServiceExtractor.WEBSERVICE_HEADERS, responseEntity.getHeaders());
		extractMessage(responseEntity, response);
		return response;
	}
	
	public abstract void doInitialize(Connection dbConnection, Map<String, Object> parms);
	public abstract void extractMessage(ResponseEntity<T> responseEntity, Map<String , Object> response) throws Exception;	
}
