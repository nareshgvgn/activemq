/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channel.ws
 * FILE   : SoapActionCallBack.java
 * CREATED: Nov 27, 2015 11:59:27 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.ws.callback;

import java.sql.Connection;
import java.util.Map;

import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;

/**
 * <p>This bean keeps the soap action which is configured at Interface level.
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * Configure P_SOAP_ACTION filter parameter as internal parameter and access in this class by using IrisAdminConstants.WEBSERVICE_SOAP_ACTION
 * </pre></p>
 * <p>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: SoapActionCallBack.java,v 1.5 2015/12/09 05:02:45 ramap Exp $
 */
public class SoapActionCallBack extends AbstractServiceCallBack
{
	
	private String soapAction = null;


	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.callback.IServiceCallBack#doInitialize(java.sql.Connection, java.util.Map)
	 */
	@Override
	public void doInitialize (Connection dbConnection, Map<String, Object> parms)
	{
		ExecutionJobData jobData = null;
		
		jobData = (ExecutionJobData)parms.get(IrisAdminConstants.EXECUTION_DATA);
		soapAction = jobData.getFilterParameter(IrisAdminConstants.WEBSERVICE_SOAP_ACTION);
		
//		soapAction = "http://jackhenry.com/ws/AcctHistSrch";
		
	}


	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channel.ws.callback.IServiceCallBack#modifyMessage(org.springframework.ws.soap.saaj.SaajSoapMessage)
	 */
	@Override
	public void modifyMessage (SaajSoapMessage saajSoapMessage)
	{
			saajSoapMessage.setSoapAction(soapAction);
	}
}
