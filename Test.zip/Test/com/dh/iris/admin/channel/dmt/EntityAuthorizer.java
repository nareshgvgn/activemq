/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : EntityAuthorizer.java
 * CREATED: Jul 5, 2016 6:49:39 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.dmt;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.exceptions.FormatException;
import com.fundtech.iris.admin.plugins.IPlugin;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

import net.minidev.json.JSONObject;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;



/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: EntityAuthorizer.java,v 1.13 2017/02/27 13:21:08 ramap Exp $
 */
public class EntityAuthorizer implements IPlugin
{
	private static Logger logger = LoggerFactory.getLogger(EntityAuthorizer.class.getName());
	private static String ACTION = "ACTION";
	private static String CLIENT_MASK_AUTH = "CLIENT_MASK_AUTH";
	private static String ROLE_MASK_AUTH = "ROLE_MASK_AUTH";
	private static String USER_AUTH = "USER_AUTH";
	private static String CUSTREPORT_AUTH = "CUSTREPORT_AUTH";
	private static String DELETE = "DELETE";
	
	private final String clientAuthProc = " pkg_client_setup.p_authorise_service";
	private final String roleAuthProc = " pkg_role_setup.p_authorise_role_service";
	private final String userAuthProc = " pkg_user_setup.p_authorise_user_service";
	private final String custReportAuthProc = " pkg_dmt_client_others.p_authorise_report_service";
	private final String clientDeleteProc = " PKG_DMT_CLIENT_OTHERS.P_DELETE_HU_DMT_DATA";
	private ClientMaskCreator clientMask = null;
	private RoleMaskCreator roleMask = null;
	
	public void initialize () throws FormatException, ExecutionException
	{}
	
	public Object execute (Connection dbConnection, Map<String, Object> params) throws FormatException, ExecutionException
	{
		Object retObj = null;
		Map<String, String> staticProps = null;
		String action = null;
		String parentExecutionId = null;
		ExecutionJobData jobData = null;
		String reportPath = null;
		
		try
		{
			
			staticProps = (Map<String, String>) params.get(IPlugin.EXECUTION_STATIC_PROPS);
			action = staticProps.get(ACTION);
			reportPath = staticProps.get("REPORT_PATH");
			jobData = (ExecutionJobData) params.get(IPlugin.EXECUTION_DATA);
			parentExecutionId = jobData.getParentExecutionId();
			
			if ( CLIENT_MASK_AUTH.equals(action) )
			{
				clientMask = new ClientMaskCreator(dbConnection);
				createClientMaskData(dbConnection, params);
				authorizeEntity(dbConnection,parentExecutionId, clientAuthProc);
				createDMTReportOutput(dbConnection,parentExecutionId, reportPath, "CUSTOMER");
			}
			else if (ROLE_MASK_AUTH.equals(action))
			{
				roleMask = new RoleMaskCreator(dbConnection);
				createCorpMaskData(dbConnection, params);
				authorizeEntity(dbConnection,parentExecutionId, roleAuthProc);
				createDMTReportOutput(dbConnection,parentExecutionId, reportPath, "ROLE");
			}
			else if (USER_AUTH.equals(action))
			{
				authorizeEntity(dbConnection,parentExecutionId, userAuthProc);
				createDMTReportOutput(dbConnection,parentExecutionId, reportPath, "USER");
			}				
			else if (CUSTREPORT_AUTH.equals(action))
				authorizeEntity(dbConnection,parentExecutionId, custReportAuthProc);
			else if (DELETE.equals(action))
				deleteData(dbConnection,jobData);
			
			return retObj;
		}
		catch ( ExecutionException exp)
		{
			jobData.setStatus("E");
			throw exp;
		}
		finally
		{
			CleanUpUtils.doClose(clientMask);
			CleanUpUtils.doClose(roleMask);
		}
		
	}
	

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param parentExecutionId
	 * </pre></p>
	 */
	private void createDMTReportOutput (Connection dbConnection, String parentExecutionId, String reportPath, String outputType )
	{
		String fileName = null;		
		Date date = new Date() ;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss") ;
		fileName =  dateFormat.format(date) + ".tsv";
		File success = new File(reportPath,"SUCCESS_" + outputType + "_" + fileName) ;
		createDMTReportSuccessFile(dbConnection, parentExecutionId, outputType, success.getAbsolutePath());
		File error = new File(reportPath,"ERROR_" + outputType + "_" + fileName) ;
		createDMTReportErrorFile(dbConnection, parentExecutionId, outputType, error.getAbsolutePath());
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param parentExecutionId
	 * </pre></p>
	 */
	private void createDMTReportErrorFile (Connection dbConnection, String parentExecutionId, String outputType, String reportPath)
	{
		String sql = null;
		if (outputType.equals("CUSTOMER"))
		{
			sql = "SELECT REGEXP_SUBSTR(p.reference_key, 'Client Short Name = ([[:alnum:]]*)|Client Short Name=([[:alnum:]]*)',1) Client_Name, "
				+ " (SELECT show_description(r.src_name,'interface_name','interface_desc','iris_int_mst')  from DUAL) services, p.record_nmbr,"
                + " r.execution_id,p.reference_key,"
				+ " p.Reject_Reason,r.execution_date FROM int_monitoring_errors p,iris_job_history r WHERE p.execution_id = r.execution_id"
				+ " AND (r.execution_id= ? OR r.parent_execution_id = ?)"
				+ " AND r.status ='E' ORDER BY p.execution_id ";
		}
		
		else if (outputType.equals("ROLE"))	
		{
			sql = " SELECT NVL(REGEXP_SUBSTR(p.reference_key, 'Role Name = ([[:alnum:]]*)|Role Name=([[:alnum:]]*)', 1), "
                + " REGEXP_SUBSTR(p.reference_key, 'Role Code/Name = ([[:alnum:]]*)|Role Code/Name=([[:alnum:]]*)', 1)) Client_Name, "
                + " (SELECT show_description(r.src_name, 'interface_name', 'interface_desc', 'iris_int_mst') FROM DUAL) services, p.record_nmbr,"
                + " r.execution_id, p.reference_key, p.Reject_Reason, r.execution_date FROM int_monitoring_errors p, iris_job_history r "
                + " WHERE p.execution_id = r.execution_id AND (r.execution_id = ? OR r.parent_execution_id = ?) "
                + " AND r.status = 'E' ORDER BY p.execution_id ";
		}
		
		else if (outputType.equals("USER"))
		{
			sql = " SELECT REGEXP_SUBSTR(p.reference_key, 'Login Id = ([[:alnum:]]*)|Login Id=([[:alnum:]]*)', 1)  Client_Name,"
                + " (SELECT show_description(r.src_name, 'interface_name', 'interface_desc', 'iris_int_mst') FROM DUAL) services, p.record_nmbr,"
                + " r.execution_id, p.reference_key, p.Reject_Reason, r.execution_date"
                + " FROM int_monitoring_errors p, iris_job_history r WHERE p.execution_id = r.execution_id"
                + " AND (r.execution_id = ? OR r.parent_execution_id = ?) AND r.status = 'E' ORDER BY p.execution_id ";
		}
		
		PreparedStatement stmt =  null;
		ResultSet rs = null;
		ExecutionException eExp = null;
		File file = null;
		BufferedWriter bw = null;
		FileWriter fileWriter= null;
		String TAB = "\t";
		String NEWLINE = "\r\n";
		try
		{
			file = new File(reportPath); 
			fileWriter = new FileWriter(file);
			bw = new BufferedWriter(fileWriter);
			stmt = dbConnection.prepareStatement(sql);
			stmt.clearParameters();
			stmt.setString(1, parentExecutionId);
			stmt.setString(2, parentExecutionId);
			rs = stmt.executeQuery();
			while ( rs.next())
			{
				bw.write(rs.getString(1));
				bw.write(TAB);
				bw.write(rs.getString(2));
				bw.write(TAB);
				bw.write(rs.getString(3));
				bw.write(TAB);
				bw.write(rs.getString(4));
				bw.write(TAB);
				bw.write(rs.getString(5));
				bw.write(TAB);
				bw.write(rs.getString(6));
				bw.write(NEWLINE);
				bw.flush();
			}
		}
		catch ( SQLException exp)
		{
			logger.error("Exception{} ", exp.getMessage());
			eExp = new ExecutionException("iris.admin.error.errorReport", new Object[]{ parentExecutionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			// do not throw error
		}
		catch ( Exception exp)
		{
			logger.error("Exception{} ", exp.getMessage());
			eExp = new ExecutionException("iris.admin.error.errorReport", new Object[]{ parentExecutionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			// do not throw error
		}
		finally
		{
			CleanUpUtils.doClean(rs);
			CleanUpUtils.doClean(stmt);
			CleanUpUtils.doClose(fileWriter);
			CleanUpUtils.doClose(bw);
		}
		
		
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param parentExecutionId
	 * </pre></p>
	 */
	private void createDMTReportSuccessFile (Connection dbConnection, String parentExecutionId, String outputType, String reportPath)
	{
		String sql = null;
		if (outputType.equals("CUSTOMER"))
		{
			sql = "SELECT (SELECT show_description(t.client_id,'client_id','client_short_name','client_service_setup') from DUAL) Client_Name, "
				+ " (SELECT show_description(r.src_name,'interface_name','interface_desc','iris_int_mst')  from DUAL) services,t.execution_id,t.status Operation,"
				+ " r.execution_date,'Processed Successfully' status FROM bu_client_service_audit t, iris_job_history r WHERE t.parent_execution_id = "
				+ " CASE WHEN r.src_name ='CUSTOMER' THEN r.execution_id ELSE r.parent_execution_id END AND t.execution_id=r.execution_id and "
				+ " (r.execution_id = ? or r.parent_execution_id = ?) ORDER BY r.execution_id ";
		}
	
		else if (outputType.equals("ROLE"))	
		{
			sql = " SELECT (SELECT show_description(t.client_id, 'client_id', 'client_short_name', 'client_service_setup') FROM DUAL) Client_Name, "
                + " (SELECT show_description(r.src_name, 'interface_name', 'interface_desc', 'iris_int_mst') FROM DUAL) services, "
                + " t.execution_id, t.status Operation, r.execution_date, 'Processed Successfully' status "
                + " FROM bu_role_service_audit t, iris_job_history r WHERE t.parent_execution_id = "
                + " CASE WHEN r.src_name = 'ROLE' THEN r.execution_id ELSE r.parent_execution_id END "
                + " AND t.execution_id = r.execution_id AND (r.execution_id = ? OR r.parent_execution_id = ?) ORDER BY r.execution_id ";
		}
	
		else if (outputType.equals("USER"))
		{
			sql = " SELECT (SELECT show_description(t.client_id, 'client_id', 'client_short_name', 'client_service_setup') FROM DUAL) Client_Name, "
                + " (SELECT show_description(r.src_name, 'interface_name', 'interface_desc', 'iris_int_mst') FROM DUAL) services, "
                + " t.execution_id, t.status Operation, r.execution_date, 'Processed Successfully' status "
                + " FROM bu_user_service_audit t, iris_job_history r WHERE t.parent_execution_id = "
                + " CASE WHEN r.src_name = 'USER' THEN r.execution_id ELSE r.parent_execution_id END "
                + " AND t.execution_id = r.execution_id AND (r.execution_id = ? OR r.parent_execution_id = ?) ORDER BY r.execution_id ";
		}
				
		PreparedStatement stmt =  null;
		ResultSet rs = null;
		File file = null;
		ExecutionException eExp = null;
		BufferedWriter bw = null;
		FileWriter fileWriter= null;
		String TAB = "\t";
		String NEWLINE = "\r\n";
		try
		{
			file = new File(reportPath); 
			fileWriter = new FileWriter(file);
			bw = new BufferedWriter(fileWriter);
			stmt = dbConnection.prepareStatement(sql);
			stmt.clearParameters();
			stmt.setString(1, parentExecutionId);
			stmt.setString(2, parentExecutionId);
			rs = stmt.executeQuery();
			while ( rs.next())
			{
				bw.write(rs.getString(1));
				bw.write(TAB);
				bw.write(rs.getString(2));
				bw.write(TAB);
				bw.write(rs.getString(3));
				bw.write(TAB);
				bw.write(rs.getString(4));
				bw.write(TAB);
				bw.write(rs.getString(5));
				bw.write(TAB);
				bw.write(rs.getString(6));
				bw.write(NEWLINE);
				bw.flush();
			}
		}
		catch ( SQLException exp)
		{
			logger.error("Exception{} ", exp.getMessage());
			eExp = new ExecutionException("iris.admin.error.successReport", new Object[]{ parentExecutionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			// do not throw error
		}
		catch ( Exception exp)
		{
			logger.error("Exception{} ", exp.getMessage());
			eExp = new ExecutionException("iris.admin.error.successReport", new Object[]{ parentExecutionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			// do not throw error
		}
		finally
		{
			CleanUpUtils.doClean(rs);
			CleanUpUtils.doClean(stmt);
			CleanUpUtils.doClose(fileWriter);
			CleanUpUtils.doClose(bw);
		}
		
	}
    
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param jobData
	 * @param string
	 * </pre></p>
	 * @throws ExecutionException 
	 */
	private void deleteData (Connection dbConnection, ExecutionJobData jobData) throws ExecutionException
	{
		String sql = "{CALL " + clientDeleteProc +" (?, ?,?)}";
		CallableStatement cStmt = null;
		String procRetVal = null;
		String procRetMsg = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		String fileName = null;
		String deleteType = null;
		OracleConnection oraConnection = null;
		ARRAY array = null;
		File file = null;
		ExecutionException eExp = null;
		String[] parmStrings = null;
		
		try
		{
			fileName = jobData.getFilterParameter(IrisAdminConstants.FILE_NAME);
			deleteType = jobData.getFilterParameter(IrisAdminConstants.DELETE_TYPE);
			
			if (fileName == null || deleteType == null)
			{
				logger.error("File Name:{} and DeleteType:{} can be null  ", fileName, deleteType);
				eExp = new ExecutionException("iris.admin.error.procCall", new Object[]{ fileName, deleteType }, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			
			file = new File(fileName);
			fileName = file.getName();
			
			parmStrings = new String[] {deleteType, fileName};
			oraConnection = IrisAdminUtils.getOracleConnection(dbConnection);
			array =  HelperUtils.createTypeValue(oraConnection, OracleTypes.ARRAY, "ARRAY_TABLE", parmStrings);
			cStmt = oraConnection.prepareCall(sql);
			cStmt.setObject(1, array, OracleTypes.ARRAY);
			cStmt.registerOutParameter(2, Types.VARCHAR);
			cStmt.registerOutParameter(3, Types.VARCHAR);
			cStmt.executeUpdate();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing " + clientDeleteProc + "' StoredProcedure: " + delta);
			procRetVal = cStmt.getString(2);
			procRetMsg = cStmt.getString(3);
			
			if (procRetVal != null || procRetMsg != null)
			{
				logger.error("Procedure {} has Error:{}  {} ", clientDeleteProc, procRetVal, procRetMsg);
				eExp = new ExecutionException("iris.admin.error.procCall", new Object[]{ procRetMsg, procRetVal, clientDeleteProc }, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			dbConnection.commit();
		}
		catch ( ExecutionException exp)
		{
			throw exp;
		}
		catch ( SQLException exp)
		{
			logger.error("Procedure {} has Error:{}  {} ", clientDeleteProc, procRetVal, procRetMsg);
			eExp = new ExecutionException("iris.admin.error.procCall", new Object[]{ procRetMsg, procRetVal, clientDeleteProc }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(cStmt);
		}
		
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param parentExecutionId
	 * @param clientAuthProc2
	 * </pre></p>
	 * @throws ExecutionException 
	 */
	private void authorizeEntity (Connection dbConnection, String parentExecutionId, String routinueName) throws ExecutionException
	{
		String sql = "{CALL " + routinueName +" (?, ?,?)}";
		CallableStatement cStmt = null;
		String procRetVal = null;
		String procRetMsg = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		ExecutionException eExp = null;
		
		try
		{
			cStmt = dbConnection.prepareCall(sql);
			cStmt.setString(1, parentExecutionId);
			cStmt.registerOutParameter(2, Types.VARCHAR);
			cStmt.registerOutParameter(3, Types.VARCHAR);
			cStmt.executeUpdate();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
			if (logger.isDebugEnabled())
				logger.debug("Time taken for executing " + routinueName + "' StoredProcedure: " + delta);
			procRetVal = cStmt.getString(2);
			procRetMsg = cStmt.getString(3);
			
			if (procRetVal != null || procRetMsg != null)
			{
				logger.error("Procedure {} has Error:{}  {} ", routinueName, procRetVal, procRetMsg);
				eExp = new ExecutionException("iris.admin.error.procCall", new Object[]{ procRetMsg, procRetVal, routinueName }, null);
				logger.error(IRISLogger.getText(eExp));
				throw eExp;
			}
			dbConnection.commit();
		}
		catch ( ExecutionException exp)
		{
			throw exp;
		}
		catch ( SQLException exp)
		{
			logger.error("Procedure {} has Error:{}  {} ", routinueName, procRetVal, procRetMsg);
			eExp = new ExecutionException("iris.admin.error.procCall", new Object[]{ procRetMsg, procRetVal, routinueName }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(cStmt);
		}
		
		
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param params
	 * </pre></p>
	 * @throws ExecutionException 
	 */
	private void createClientMaskData (Connection dbConnection, Map<String, Object> params) throws ExecutionException
	{
		PreparedStatement updateMaskStmt = null;
		String clientShortName = null;
		ExecutionException eExp = null;
		String mask = null;
		String updateSql = "UPDATE client_service_setup t  SET t.client_mask = ? WHERE t.client_short_name = ?";
		int batchcount = 1;
		Map<String, String> clientsMask = null;
		int count[] = null;
		
		try
		{
			clientsMask = clientMask.getClienMasktData(params);
			updateMaskStmt = dbConnection.prepareStatement(updateSql);
			for(Map.Entry<String, String> entry :  clientsMask.entrySet())
			{
				try
				{
					clientShortName = entry.getKey();
					logger.debug("updating mask for client: {}", clientShortName);
					mask = entry.getValue();
					updateMaskStmt.clearParameters();
					updateMaskStmt.setString(1, mask);
					updateMaskStmt.setString(2, clientShortName);
					updateMaskStmt.addBatch();
					
					if ( batchcount == 1000 || clientsMask.size() == batchcount)
					{
						count = updateMaskStmt.executeBatch();
						logger.debug("Mask updated for {} clients", count.length);
						dbConnection.commit();
						updateMaskStmt.clearBatch();
						batchcount = 1;
					}
					batchcount++;
				}
				catch ( SQLException exp)
				{
					logger.error("Error While updating client mask for {} . Ignoring record", clientShortName, exp);
					//ignore the error
					batchcount++;
				}
			}
		}
		catch ( ExecutionException exp)
		{
			throw exp;
		}
		catch ( SQLException exp)
		{
			eExp = new ExecutionException("iris.admin.client.rolesdata", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(updateMaskStmt);
			CleanUpUtils.doClean(clientsMask);
		}
	}

	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param parms
	 * @throws ExecutionException
	 * </pre></p>
	 */
	private void createCorpMaskData(Connection dbConnection, Map<String, Object> parms) throws ExecutionException
	{
		JSONObject allCorpRights = null;
		String currCorpCode =  null;
		JSONObject corpRights = null;
		ExecutionException eExp = null;
		
		try
		{
			allCorpRights = roleMask.getRoleMaskData(parms);
			for ( Map.Entry<String, Object> entry : allCorpRights.entrySet())
			{
				currCorpCode = entry.getKey();
				corpRights = (JSONObject)entry.getValue();
				createRoleMaskData(dbConnection, corpRights, currCorpCode);
			}
			dbConnection.commit();
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("iris.admin.client.rolesdata", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			if ( corpRights != null)
				corpRights.clear();
			
			if (allCorpRights != null)
				allCorpRights.clear();
			
			allCorpRights = null;
			corpRights = null;
		}
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param dbConnection
	 * @param corpRights
	 * @param currCorpCode
	 * </pre></p>
	 */
	private void createRoleMaskData (Connection dbConnection, JSONObject corpRights, String currCorpCode) throws ExecutionException
	{
		String currCatCode = null;
		JSONObject catRights = null;
		int count[] = null; 
		String view = null;
		String edit = null;
		String auth = null;
		PreparedStatement updateStmt = null;
		ExecutionException eExp = null;
		String sql = "update categorymaster t set t.catviewmask =?, t.cateditmask=?, t.catauthmask=? where t.catcorporation=? and t.catcategory=?";
		
		try
		{
			updateStmt = dbConnection.prepareStatement(sql);
			
			for ( Map.Entry<String, Object> entry : corpRights.entrySet())
			{
				currCatCode = entry.getKey();
				catRights = (JSONObject)entry.getValue();
				
				view = roleMask.getUpdatedMask((JSONObject)catRights.get(RoleMaskCreator.VIEW_RIGHTS), (String)catRights.get(RoleMaskCreator.OLD_VIEW_RIGHTS));
				edit = roleMask.getUpdatedMask((JSONObject)catRights.get(RoleMaskCreator.EDIT_RIGHTS), (String)catRights.get(RoleMaskCreator.OLD_EDIT_RIGHTS));
				auth = roleMask.getUpdatedMask((JSONObject)catRights.get(RoleMaskCreator.AUTH_RIGHTS),(String) catRights.get(RoleMaskCreator.OLD_AUTH_RIGHTS));
				
				updateStmt.clearParameters();
				updateStmt.setString(1, view);
				updateStmt.setString(2, edit);
				updateStmt.setString(3, auth);
				updateStmt.setString(4, currCorpCode);
				updateStmt.setString(5, currCatCode);
				updateStmt.addBatch();
			}
			count = updateStmt.executeBatch();
			logger.debug("Mask updated for {} clients", count.length);
		}
		catch (SQLException exp)
		{
			eExp = new ExecutionException("iris.admin.client.rolesdata", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( Exception exp)
		{
			eExp = new ExecutionException("iris.admin.client.rolesdata", new Object[] {}, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(updateStmt);
		}
	}
}
