/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : ClientServiceSetup.java
 * CREATED: Jul 14, 2016 3:45:28 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.dmt;

import com.fundtech.iris.admin.IrisAdminConstants;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: ClientServiceSetup.java,v 1.2 2016/10/19 14:04:55 ramap Exp $
 */
public class ClientServiceSetup
{
	private String recordKeyNo = null;
	private String clientMask = null;
	private String executionId = null;
	private String clientShortName = null;
	private String clientType = "M";
	private String corporationName = null;
	private boolean brEnable = false;
	private boolean paymentEnable = false;
	private boolean forecastEnable = false;
	private boolean collectionEnable = false;
	private boolean adminEnable = false;
	private boolean positivePayEnable = false;
	private boolean checksEnable = false;
	private boolean liquidityEnable = false;
	private boolean fscEnable = false;
	private boolean depositsEnable = false;
	private boolean tradeEnable = false;
	private boolean portalEnable = false;
	private boolean loanEnable = false;
	private boolean mobileEnable = false;
	/**
	 * @return the recordKeyNo
	 */
	public String getRecordKeyNo ()
	{
		return recordKeyNo;
	}
	/**
	 * @param recordKeyNo the recordKeyNo to set
	 */
	public void setRecordKeyNo (String recordKeyNo)
	{
		this.recordKeyNo = recordKeyNo;
	}
	/**
	 * @return the executionId
	 */
	public String getExecutionId ()
	{
		return executionId;
	}
	/**
	 * @param executionId the executionId to set
	 */
	public void setExecutionId (String executionId)
	{
		this.executionId = executionId;
	}
	/**
	 * @return the clientType
	 */
	public String getClientType ()
	{
		return clientType;
	}
	/**
	 * @param clientType the clientType to set
	 */
	public void setClientType (String clientType)
	{
		this.clientType = clientType;
	}
	/**
	 * @return the corporationName
	 */
	public String getCorporationName ()
	{
		return corporationName;
	}
	/**
	 * @param corporationName the corporationName to set
	 */
	public void setCorporationName (String corporationName)
	{
			this.corporationName = corporationName;
	}
	/**
	 * @return the brEnable
	 */
	public boolean isBrEnable ()
	{
		return brEnable;
	}
	/**
	 * @param brEnable the brEnable to set
	 */
	public void setBrEnable (String brEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(brEnable))
			this.brEnable = true;
	}
	/**
	 * @return the paymentEnable
	 */
	public boolean isPaymentEnable ()
	{
		return paymentEnable;
	}
	/**
	 * @param paymentEnable the paymentEnable to set
	 */
	public void setPaymentEnable (String paymentEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(paymentEnable))
			this.paymentEnable = true;
	}
	/**
	 * @return the forecastEnable
	 */
	public boolean isForecastEnable ()
	{
		return forecastEnable;
	}
	/**
	 * @param forecastEnable the forecastEnable to set
	 */
	public void setForecastEnable (String forecastEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(forecastEnable))
			this.forecastEnable = true;
	}
	/**
	 * @return the collectionEnable
	 */
	public boolean isCollectionEnable ()
	{
		return collectionEnable;
	}
	/**
	 * @param collectionEnable the collectionEnable to set
	 */
	public void setCollectionEnable (String collectionEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(collectionEnable))
			this.collectionEnable = true;
	}
	/**
	 * @return the adminEnable
	 */
	public boolean isAdminEnable ()
	{
		return adminEnable;
	}
	/**
	 * @param adminEnable the adminEnable to set
	 */
	public void setAdminEnable (String adminEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(adminEnable))
			this.adminEnable = true;
	}
	/**
	 * @return the positivePayEnable
	 */
	public boolean isPositivePayEnable ()
	{
		return positivePayEnable;
	}
	/**
	 * @param positivePayEnable the positivePayEnable to set
	 */
	public void setPositivePayEnable (String positivePayEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(positivePayEnable))
			this.positivePayEnable = true;
	}
	/**
	 * @return the checksEnable
	 */
	public boolean isChecksEnable ()
	{
		return checksEnable;
	}
	/**
	 * @param checksEnable the checksEnable to set
	 */
	public void setChecksEnable (String checksEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(checksEnable))
			this.checksEnable = true;
	}
	/**
	 * @return the liquidityEnable
	 */
	public boolean isLiquidityEnable ()
	{
		return liquidityEnable;
	}
	/**
	 * @param liquidityEnable the liquidityEnable to set
	 */
	public void setLiquidityEnable (String liquidityEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(liquidityEnable))
			this.liquidityEnable = true;
	}
	/**
	 * @return the fscEnable
	 */
	public boolean isFscEnable ()
	{
		return fscEnable;
	}
	/**
	 * @param fscEnable the fscEnable to set
	 */
	public void setFscEnable (String fscEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(fscEnable))
			this.fscEnable = true;
	}
	/**
	 * @return the depositsEnable
	 */
	public boolean isDepositsEnable ()
	{
		return depositsEnable;
	}
	/**
	 * @param depositsEnable the depositsEnable to set
	 */
	public void setDepositsEnable (String depositsEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(depositsEnable))
			this.depositsEnable = true;
	}
	/**
	 * @return the tradeEnable
	 */
	public boolean isTradeEnable ()
	{
		return tradeEnable;
	}
	/**
	 * @param tradeEnable the tradeEnable to set
	 */
	public void setTradeEnable (String tradeEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(tradeEnable))
			this.tradeEnable = true;
	}
	/**
	 * @return the portalEnable
	 */
	public boolean isPortalEnable ()
	{
		return portalEnable;
	}
	/**
	 * @param portalEnable the portalEnable to set
	 */
	public void setPortalEnable (String portalEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(portalEnable))
			this.portalEnable = true;
	}
	/**
	 * @return the loanEnable
	 */
	public boolean isLoanEnable ()
	{
		return loanEnable;
	}
	/**
	 * @param loanEnable the loanEnable to set
	 */
	public void setLoanEnable (String loanEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(loanEnable))
			this.loanEnable =true;;
		
	}
	/**
	 * @return the mobileEnable
	 */
	public boolean isMobileEnable ()
	{
		return mobileEnable;
	}
	/**
	 * @param mobileEnable the mobileEnable to set
	 */
	public void setMobileEnable (String mobileEnable)
	{
		if (IrisAdminConstants.CONSTANT_Y.equals(mobileEnable))
			this.mobileEnable =true;;
	}
	/**
	 * @return the clientShortName
	 */
	public String getClientShortName ()
	{
		return clientShortName;
	}
	/**
	 * @param clientShortName the clientShortName to set
	 */
	public void setClientShortName (String clientShortName)
	{
		this.clientShortName = clientShortName;
	}
	/**
	 * @return the clientMask
	 */
	public String getClientMask ()
	{
		return clientMask;
	}
	/**
	 * @param clientMask the clientMask to set
	 */
	public void setClientMask (String clientMask)
	{
		this.clientMask = clientMask;
	}

}
	
   

