/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : RoleMaskCreator.java
 * CREATED: Jul 30, 2016 11:21:49 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.dmt;

import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.core.util.EncodeUtils;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;

import net.minidev.json.JSONObject;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: RoleMaskCreator.java,v 1.5 2016/10/19 14:04:55 ramap Exp $
 */
public class RoleMaskCreator implements Closeable
{
	private static Logger logger = LoggerFactory.getLogger(RoleMaskCreator.class.getName());
	private int categoryMaxMaskLength = 256;
	public static String VIEW_RIGHTS = "VIEW_RIGHTS";
	public static String EDIT_RIGHTS = "EDIT_RIGHTS";
	public static String AUTH_RIGHTS = "AUTH_RIGHTS";
	public static String OLD_VIEW_RIGHTS = "OLD_VIEW_RIGHTS";
	public static String OLD_EDIT_RIGHTS = "OLD_EDIT_RIGHTS";
	public static String OLD_AUTH_RIGHTS = "OLD_AUTH_RIGHTS";
	private Connection dbConnection = null;
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public RoleMaskCreator(Connection dbConnection)
	{
		this.dbConnection = dbConnection;
	}
	
	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		
	}
	
	public JSONObject getRoleMaskData(Map<String, Object> parms) throws ExecutionException
	{
		String sql = "select t.corporation_code, t.category_code, c.catviewmask, c.cateditmask, c.catauthmask, t.view_permissions, t.edit_permissions, t.auth_permissions,"
				+ " t.form_weight from UPLOAD_ROLE_PERMISSIONS t, categorymaster c "
				+ " where c.catcorporation = t.corporation_code and c.catcategory = t.category_code and t.parent_execution_id =?"
				+ " order by t.corporation_code, t.category_code, t.form_weight";
		String currCorpCode =  null;
		String currCatCode = null;
		String isView = null;
		String isEdit = null;
		String isAuth = null;
		String weight = null;
		String parentRecordKey = null;
		JSONObject viewRights = null;
		JSONObject authRights = null;
		JSONObject editRights = null;
		JSONObject catRights = null;
		JSONObject corpRights = null;
		JSONObject allCorpRights = null;
		PreparedStatement permissionsStmt = null;
		ResultSet permissionsRs = null;
		ExecutionException lExp = null;
		ExecutionJobData jobData = null;
		
		 try
		 {

			 jobData = (ExecutionJobData)parms.get(IrisAdminConstants.EXECUTION_DATA);
			 parentRecordKey = jobData.getParentExecutionId();
			 permissionsStmt = dbConnection.prepareStatement(sql);
			 permissionsStmt.clearParameters();
			 permissionsStmt.setString(1, parentRecordKey);
			 permissionsRs = permissionsStmt.executeQuery();
			 allCorpRights = new JSONObject();
			 
			 while(permissionsRs.next())
			 {
				 currCorpCode = permissionsRs.getString("corporation_code");
				 currCatCode = permissionsRs.getString("category_code");
				 
				 if ( allCorpRights.containsKey(currCorpCode))
				 {
					 corpRights = (JSONObject) allCorpRights.get(currCorpCode);
				 }
				 else
				 {
					 corpRights = new JSONObject();
					 allCorpRights.put(currCorpCode, corpRights);
				 }
					
				 if ( corpRights.containsKey(currCatCode))
				 {
					 catRights = (JSONObject) corpRights.get(currCatCode);
					 viewRights = (JSONObject) catRights.get(VIEW_RIGHTS);
					 editRights = (JSONObject) catRights.get(EDIT_RIGHTS);
					 authRights = (JSONObject) catRights.get(AUTH_RIGHTS);
				 }
				 else
				 {
					 catRights = new JSONObject();
					 viewRights = new JSONObject();
					 authRights = new JSONObject();
					 editRights = new JSONObject(); 
					 
					 catRights.put(VIEW_RIGHTS, viewRights);
					 catRights.put(OLD_VIEW_RIGHTS, permissionsRs.getString("catviewmask"));
					 catRights.put(EDIT_RIGHTS, editRights);
					 catRights.put(OLD_EDIT_RIGHTS, permissionsRs.getString("cateditmask"));
					 catRights.put(AUTH_RIGHTS, authRights);
					 catRights.put(OLD_AUTH_RIGHTS, permissionsRs.getString("catauthmask"));
					 corpRights.put(currCatCode, catRights);
				 }
				 
				 isView = permissionsRs.getString("view_permissions");
				 isEdit = permissionsRs.getString("edit_permissions");
				 isAuth = permissionsRs.getString("auth_permissions");
				 weight  = permissionsRs.getString("form_weight");
				 
				 if ( IrisAdminConstants.CONSTANT_Y.equals(isView))
					 viewRights.put(weight, "true");
				 else if ( IrisAdminConstants.CONSTANT_N.equals(isView))
					 viewRights.put(weight, "false");
				 
				 if ( IrisAdminConstants.CONSTANT_Y.equals(isEdit))
					 editRights.put(weight, "true");
				 else if ( IrisAdminConstants.CONSTANT_N.equals(isEdit))
					 editRights.put(weight, "false");
				
				 if ( IrisAdminConstants.CONSTANT_Y.equals(isAuth))
					 authRights.put(weight, "true");
				 else if ( IrisAdminConstants.CONSTANT_N.equals(isAuth))
					 authRights.put(weight, "false");
					 
			 }
		 }
		 catch ( SQLException exp)
		 {
			 lExp = new ExecutionException("iris.admin.client.rolesdata", new Object[] {parentRecordKey,sql}, exp);
			 logger.error(IRISLogger.getText(lExp));
			 throw lExp;
		 }
		 finally
		 {
			 CleanUpUtils.doClean(permissionsRs);
			 CleanUpUtils.doClean(permissionsStmt);
		 }
		 return allCorpRights;
	}
	
	
	public String getUpdatedMask(JSONObject strACLSerials, String strHexMask) throws ExecutionException
	{
		int intWeight = 0;
		String strTemp = "";
		StringBuilder sbBinaryMask = null;
		ExecutionException lExp = null;
		String value = null;
		
		Assert.notNull(strACLSerials, "ACL Serials can not be null, can not provide new mask!");
		
		try
		{
			if (null == strHexMask)
			{
				strTemp = StringUtils.leftPad(strTemp, categoryMaxMaskLength * 4, '0');
				sbBinaryMask = new StringBuilder(strTemp);
				sbBinaryMask = sbBinaryMask.reverse();
			}
			else
			{
			    strTemp = EncodeUtils.hexToBinary(strHexMask);
			    strTemp = StringUtils.leftPad(strTemp, categoryMaxMaskLength * 4, '0');
			    sbBinaryMask = new StringBuilder(strTemp);
			}

			if (strACLSerials.isEmpty())
			{
				if (null == strHexMask)
					return EncodeUtils.binaryToHex(sbBinaryMask.toString());
				else
					return strHexMask;
			}

			sbBinaryMask = sbBinaryMask.reverse();

			for(String objKey : strACLSerials.keySet())
			{
				value = strACLSerials.getAsString(objKey);
				intWeight = Integer.parseInt(objKey);
				
				if (Boolean.parseBoolean(value) )
				{
					
					if( intWeight > 0 )
					{
						sbBinaryMask.setCharAt(intWeight-1, '1');
					}
				}
				else
				{
					if( intWeight > 0 )
					{
						sbBinaryMask.setCharAt(intWeight-1, '0');
					}
				}
			}
				
			sbBinaryMask = sbBinaryMask.reverse();
			value = EncodeUtils.binaryToHex(sbBinaryMask.toString());
		}
		catch ( Exception exp)
		{
			 lExp = new ExecutionException("iris.admin.client.rolesdata", new Object[] {}, exp);
			 logger.error(IRISLogger.getText(lExp));
			 throw lExp;
		}
		finally
		{
			CleanUpUtils.doClean(sbBinaryMask);
		}
		
		return value;
	}
	
}
