/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.util
 * FILE   : ClientMaskCreator.java
 * CREATED: Jul 30, 2016 11:11:08 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channel.dmt;

import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.data.ExecutionJobData;
import com.fundtech.iris.admin.exceptions.ExecutionException;
import com.fundtech.iris.admin.util.CleanUpUtils;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: ClientMaskCreator.java,v 1.4 2017/01/30 04:50:14 ramap Exp $
 */
public class ClientMaskCreator implements Closeable
{
	private static Logger logger = LoggerFactory.getLogger(ClientMaskCreator.class.getName());
	private Connection dbConnection = null;
	private int categoryMaxMaskLength = 256;
	private String modulePrvWeightsSql = " SELECT rl.rmweight as weight FROM feature_repository fr, feature_rights_linkage rl  WHERE fr.feature_id = rl.feature_id AND "
			+ " fr.applicable_flag = 'Y' AND fr.module_code = ? ";
	
	private PreparedStatement corpPrvWeightsStmt = null;
	private PreparedStatement  modulePrvWeightsStmt = null;
	private Map<String, PreparedStatement> corpPrvWeightsStmtMap = new HashMap<String, PreparedStatement>();
	private Map<String, PreparedStatement> prvDetailsStmtMap = new HashMap<String, PreparedStatement>();
	
	public ClientMaskCreator(Connection dbConnection)
	{
		this.dbConnection = dbConnection;
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		CleanUpUtils.doClean(corpPrvWeightsStmt);
		CleanUpUtils.doClean(modulePrvWeightsStmt);
		
		for ( Map.Entry<String, PreparedStatement> entry : prvDetailsStmtMap.entrySet())
		{
			CleanUpUtils.doClean(entry.getValue());
		}
		for ( Map.Entry<String, PreparedStatement> entry : corpPrvWeightsStmtMap.entrySet())
		{
			CleanUpUtils.doClean(entry.getValue());
		}
		
	}
	
	public Map<String, String> getClienMasktData( Map<String, Object> params) throws ExecutionException 
	{
		List<ClientServiceSetup> clientList = null;
		ClientServiceSetup clientSetupBean = null;
		PreparedStatement clientMstStmt = null;
		ResultSet clietMstRs = null;
		Map<String, String> clientMask = null;
		String clientShortName = null;
		ExecutionException lExp = null;
		ExecutionJobData jobData = null;
		
		String parentRecordKey = null;// Need to get from caller
		String sql = "select  t.client_mask, t.record_key_no, t.corporation_code, t.client_type,t.br_enable, t.payment_enable, t.collection_enable, t.lms_enable, t.fsc_enable, t.trade_enable,t.deposit_enable, "
				+ "t.coordinator_enable,t.remit_enable, t.forecast_enable, t.positive_pay_enable, t.checks_enable, t.admin_enable, 'N' as mobile_enable, t.loans_enable, "
				+ " t.portal_enable,t.client_short_name  from client_service_setup  t where EXISTS (SELECT 1  FROM bu_client_service_audit a  WHERE  a.client_id = t.client_id"
				+ "  AND a.parent_execution_id = ? )";
		try
		{
			jobData = (ExecutionJobData)params.get(IrisAdminConstants.EXECUTION_DATA);
			parentRecordKey = jobData.getParentExecutionId();
			clientMstStmt = dbConnection.prepareStatement(sql);
			clientMstStmt.clearParameters();
			clientMstStmt.setString(1, parentRecordKey);
			clietMstRs = clientMstStmt.executeQuery();
			clientList = new ArrayList<ClientServiceSetup>();
			clientMask = new HashMap<String, String>();
			while ( clietMstRs.next())
			{
				clientShortName = clietMstRs.getString("client_short_name");
				clientSetupBean = new ClientServiceSetup();
				clientSetupBean.setClientMask(clietMstRs.getString("client_mask"));
				clientSetupBean.setRecordKeyNo(clietMstRs.getString("record_key_no"));
				clientSetupBean.setClientType(clietMstRs.getString("client_type"));
				clientSetupBean.setClientShortName(clientShortName);
				clientSetupBean.setCorporationName(clietMstRs.getString("corporation_code"));
				clientSetupBean.setBrEnable(clietMstRs.getString("br_enable"));
				clientSetupBean.setForecastEnable(clietMstRs.getString("forecast_enable"));
				clientSetupBean.setPaymentEnable(clietMstRs.getString("payment_enable"));
				clientSetupBean.setCollectionEnable(clietMstRs.getString("collection_enable"));
				clientSetupBean.setAdminEnable(clietMstRs.getString("admin_enable"));
				clientSetupBean.setPositivePayEnable(clietMstRs.getString("positive_pay_enable"));
				clientSetupBean.setChecksEnable(clietMstRs.getString("checks_enable"));
				clientSetupBean.setLiquidityEnable(clietMstRs.getString("lms_enable"));
				clientSetupBean.setFscEnable(clietMstRs.getString("fsc_enable"));
				clientSetupBean.setDepositsEnable(clietMstRs.getString("deposit_enable"));
				clientSetupBean.setTradeEnable(clietMstRs.getString("trade_enable"));
				clientSetupBean.setPortalEnable(clietMstRs.getString("portal_enable"));
				clientSetupBean.setLoanEnable(clietMstRs.getString("loans_enable"));
				clientSetupBean.setMobileEnable(clietMstRs.getString("mobile_enable"));
				clientList.add(clientSetupBean);
			}
			
			for (ClientServiceSetup client : clientList)
			{
				try
				{
					clientShortName = client.getClientShortName();
					String mask = generateMask(client);
					clientMask.put(clientShortName,mask);
					
				}
				catch ( ExecutionException exp)
				{
					logger.error("Exceltopn came while generating mask for: {} ignorning this record.", clientShortName );
				}
			}
		}
		catch ( SQLException exp)
		{
			lExp = new ExecutionException("iris.admin.client.modelPrevialges", new Object[] {parentRecordKey,sql}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			CleanUpUtils.doClean(clietMstRs);
			CleanUpUtils.doClean(clientMstStmt);
		}
		
		return clientMask;
	}
	
	
	private  String generateMask(ClientServiceSetup clientSetupBean) throws ExecutionException
	{
		String clientMask = null; 
		final BitSet bsClient = new BitSet();
		
		// fetch the Privilege features for BR
		if (clientSetupBean.isBrEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_BR_DTL_TBL, IrisAdminConstants.MODULE_BR);
		
		// fetch the Privilege features for FORECAST
		if (clientSetupBean.isForecastEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_FORECAST_DTL_TBL, IrisAdminConstants.MODULE_FORECAST);
		
		// fetch the Privilege features for PAYMENT
		if (clientSetupBean.isPaymentEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_PAYMENT_DTL_TBL, IrisAdminConstants.MODULE_PAYMENT);
		
		// fetch the Privilege features for COLLECTION
		if (clientSetupBean.isCollectionEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_COLLECTION_DTL_TBL, IrisAdminConstants.MODULE_COLLECTION);
		
		// fetch the Privilege features for ADMIN
		if (clientSetupBean.isAdminEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_ADM_DTL_TBL, IrisAdminConstants.MODULE_ADMIN);
		
		// fetch the Privilege features for POSITIVE PAY
		if (clientSetupBean.isPositivePayEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_POSITIVEPAY_DTL_TBL, IrisAdminConstants.MODULE_POSITIVE_PAY);
		
		// fetch the Privilege features for CHECKS
		if (clientSetupBean.isChecksEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_CHECKS_DTL_TBL, IrisAdminConstants.MODULE_CHECKS);
		
		// fetch the Privilege features for LIQUIDITY
		if (clientSetupBean.isLiquidityEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_LIQUIDITY_DTL_TBL, IrisAdminConstants.MODULE_LIQUIDITY);
		
		// fetch the Privilege features for FSC
		if (clientSetupBean.isFscEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_FSC_DTL_TBL, IrisAdminConstants.MODULE_FSC);
		
		// fetch the Privilege features for DEPOSIT VIEW
		if (clientSetupBean.isDepositsEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_DEPOSIT_VIEW_DTL_TBL, IrisAdminConstants.MODULE_DEPOSIT_VIEW);
		
		// fetch the Privilege features for eTrade
		if (clientSetupBean.isTradeEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_TRADE_DTL_TBL, IrisAdminConstants.MODULE_TRADE);
		
		// fetch the Privilege features for PORTAL
		if (clientSetupBean.isPortalEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_PORTAL_DTL_TBL, IrisAdminConstants.MODULE_PORTAL);
		
		// fetch the Privilege features for LOAN
		if (clientSetupBean.isLoanEnable())
			setFeatureWeights(bsClient, clientSetupBean, IrisAdminConstants.CPON_LOAN_DTL_TBL, IrisAdminConstants.MODULE_LOAN);
		
		// fetch the Privilege features for MOBILE BANKING 
		if (clientSetupBean.isMobileEnable())
			setPrivilegeWeights( bsClient, IrisAdminConstants.MODULE_MOBILE);
		
		clientMask = toHex(bsClient);
		clientMask = StringUtils.leftPad(clientMask, categoryMaxMaskLength,'0');
		return clientMask;
	}
	
	private void setFeatureWeights( BitSet bsClient, ClientServiceSetup clientSetupBean, String dtlTableName,String moduleCode) throws ExecutionException
	{
		boolean isAllPresent = false;
		Map< String, Integer > details = null;
		String recordkey = null; 
		String corporationName = null; 
		String clientType = null;
		ClientServiceSetup parentClientSetupBean  = null;
		List<Integer> features = null;
		
		try
		{
			clientType = clientSetupBean.getClientType();
			corporationName = clientSetupBean.getCorporationName();
			recordkey  = clientSetupBean.getRecordKeyNo();
			details = getPrivilegeDetails( dtlTableName,recordkey);
			
			if( details.containsKey( "ALL" ) )
				isAllPresent = true;
			
			for ( Map.Entry<String, Integer> entry :  details.entrySet())
			{
				if ( ! isAllPresent)
					bsClient.set((Integer) entry.getValue(), true );
			}
			
			if( isAllPresent )
			{
				if( "S".equals( String.valueOf( clientType ) ) ) // fetch the corporation record and replace the bean
				{
					parentClientSetupBean = findClientServiceSetup( corporationName, null);
					recordkey = parentClientSetupBean.getRecordKeyNo();
					details = getPrivilegeDetails( dtlTableName, recordkey);
					
					if( details.containsKey( "ALL" ) )
					{
						features = getModulePopupPrivilegeWeights( moduleCode);
						for( Integer entity : features )
						{
							bsClient.set(entity, true);
						}
					}
					else //fetch perticular privileges on popup that assigned to corporation
					{
						features = getCorporationPopupPrivilegeWeights( dtlTableName,recordkey);
						for( Integer entity : features )
						{
							bsClient.set( entity, true );
						}
					}
				}
				else
				{
					features = getModulePopupPrivilegeWeights(moduleCode);
					for( Integer entity : features )
					{
						bsClient.set( entity, true );
					}
				}
			}
		}
		catch (ExecutionException exp)
		{
			throw exp;
		}
		finally
		{
			CleanUpUtils.doClean(features);
			parentClientSetupBean = null;
		}
	}
	
	private List< Integer > getCorporationPopupPrivilegeWeights( String tableName, String parentRecordKeyNo) throws ExecutionException
	{
		List< Integer > results = null;
		ResultSet prvRs = null;
		String sql = null;
		Integer featureWeight = null;
		PreparedStatement corpPrvWeightsStmt = null;
		ExecutionException lExp = null;
		
		try
		{
			if (!corpPrvWeightsStmtMap.containsKey(tableName))
			{
				sql = getCorpPrvWeightsSQL(tableName);
				corpPrvWeightsStmt = dbConnection.prepareStatement(sql);
				corpPrvWeightsStmtMap.put(tableName, corpPrvWeightsStmt);
			}
			else
				corpPrvWeightsStmt = corpPrvWeightsStmtMap.get(tableName);
			
			corpPrvWeightsStmt.clearParameters();
			corpPrvWeightsStmt.setString(1, parentRecordKeyNo);
			results = new ArrayList<Integer>();
			prvRs = corpPrvWeightsStmt.executeQuery();
			while(prvRs.next())
			{
				featureWeight = prvRs.getInt("weight");
				results.add(featureWeight);
			}
		}
		catch(SQLException exp)
		{
			lExp = new ExecutionException("iris.admin.client.modelPrevialges", new Object[] {parentRecordKeyNo,getCorpPrvWeightsSQL(tableName)}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			CleanUpUtils.doClean(prvRs);
		}
		return results;
	}
	
	
	private List< Integer > getModulePopupPrivilegeWeights( String moduleCode) throws ExecutionException
	{
		List< Integer > results = null;
		ResultSet prvRs = null;
		Integer featureWeight = null;
		ExecutionException lExp = null;
		
		try
		{
			if (modulePrvWeightsStmt == null )
				modulePrvWeightsStmt = dbConnection.prepareStatement(modulePrvWeightsSql);
			
			modulePrvWeightsStmt.clearParameters();
			modulePrvWeightsStmt.setString(1,moduleCode);
			results = new ArrayList<Integer>();
			prvRs = modulePrvWeightsStmt.executeQuery();
			while(prvRs.next())
			{
				featureWeight = prvRs.getInt("weight");
				results.add(featureWeight);
			}
		}
		catch(SQLException exp)
		{
			lExp = new ExecutionException("iris.admin.client.modelPrevialges", new Object[] {moduleCode,modulePrvWeightsSql}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			CleanUpUtils.doClean(prvRs);
		}
		
		return results;
	}

	
	
	private ClientServiceSetup findClientServiceSetup (String corporationName, Object object) throws ExecutionException
	{
		ClientServiceSetup clientSetupBean = null;
		String sql = "select t.record_key_no, t.corporation_code, t.br_enable, t.payment_enable, t.collection_enable, t.lms_enable, t.fsc_enable, t.trade_enable,t.deposit_enable, "
				+ "t.coordinator_enable,t.remit_enable, t.forecast_enable, t.positive_pay_enable, t.checks_enable, t.admin_enable, t.mobile_enable, t.loans_enable, "
				+ " t.portal_enable,t.client_short_name"
				+ " from client_service_setup "
				+ " t where t.branding_pkg_type ='N' and t.record_key_no = ?";
		
		PreparedStatement clientMstStmt = null;
		ResultSet clietMstRs = null;
		ExecutionException lExp = null;
		
		try
		{
			clientMstStmt = dbConnection.prepareStatement(sql);
			clientMstStmt.setString(1, corporationName);
			clietMstRs = clientMstStmt.executeQuery();
			while ( clietMstRs.next())
			{
				clientSetupBean = new ClientServiceSetup();
				clientSetupBean.setRecordKeyNo(clietMstRs.getString("record_key_no"));
				clientSetupBean.setClientShortName(clietMstRs.getString("client_short_name"));
				clientSetupBean.setCorporationName(clietMstRs.getString("corporation_code"));
				clientSetupBean.setBrEnable(clietMstRs.getString("br_enable"));
				clientSetupBean.setForecastEnable(clietMstRs.getString("forecast_enable"));
				clientSetupBean.setPaymentEnable(clietMstRs.getString("payment_enable"));
				clientSetupBean.setCollectionEnable(clietMstRs.getString("collection_enable"));
				clientSetupBean.setAdminEnable(clietMstRs.getString("admin_enable"));
				clientSetupBean.setPositivePayEnable(clietMstRs.getString("positive_pay_enable"));
				clientSetupBean.setChecksEnable(clietMstRs.getString("checks_enable"));
				clientSetupBean.setLiquidityEnable(clietMstRs.getString("lms_enable"));
				clientSetupBean.setFscEnable(clietMstRs.getString("fsc_enable"));
				clientSetupBean.setDepositsEnable(clietMstRs.getString("deposit_enable"));
				clientSetupBean.setTradeEnable(clietMstRs.getString("trade_enable"));
				clientSetupBean.setPortalEnable(clietMstRs.getString("portal_enable"));
				clientSetupBean.setLoanEnable(clietMstRs.getString("loans_enable"));
				clientSetupBean.setMobileEnable(clietMstRs.getString("mobile_enable"));
			}
			
		}
		catch ( SQLException exp)
		{
			lExp = new ExecutionException("iris.admin.client.corporation", new Object[] {corporationName,sql}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			CleanUpUtils.doClean(clietMstRs);
			CleanUpUtils.doClean(clientMstStmt);
		}
		return clientSetupBean;
	}
	
	private void setPrivilegeWeights(BitSet bsClient, String moduleCode) throws ExecutionException
	{
		List< Integer > features = getModulePopupPrivilegeWeights( moduleCode);
		for( Integer entity : features )
		{
			bsClient.set( entity, true );
		}
	}
	
	private Map<String,Integer> getPrivilegeDetails( String tableName, String parentRecordKey) throws ExecutionException
	{
		Map<String, Integer> results = null;
		ResultSet prvRs = null;
		String sql = null;
		String featureId = null;
		Integer featureWeight = null;
		PreparedStatement  prvDetailsStmt = null;
		ExecutionException lExp = null;
		
		try
		{
			if (!prvDetailsStmtMap.containsKey(tableName))
			{
				sql = getSQL(tableName);
				prvDetailsStmt = dbConnection.prepareStatement(sql);
				prvDetailsStmtMap.put(tableName, prvDetailsStmt);
			}
			else
				prvDetailsStmt = prvDetailsStmtMap.get(tableName);
			
			prvDetailsStmt.clearParameters();
			prvDetailsStmt.setString(1,parentRecordKey);
			prvDetailsStmt.setString(2,parentRecordKey);
			results = new HashMap<String, Integer>();
			prvRs = prvDetailsStmt.executeQuery();
			while(prvRs.next())
			{
				featureId = prvRs.getString("feature_id");
				featureWeight = prvRs.getInt("weight");
				results.put(featureId, featureWeight);
			}
		}
		catch(SQLException exp)
		{
			lExp = new ExecutionException("iris.admin.client.previlage", new Object[] {getSQL(tableName)}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			CleanUpUtils.doClean(prvRs);
			sql = null;
		}
		return results;
	}
	
	
	private String toHex(BitSet mask) {
		int i = 0;
		int len = 0;
		int msk = 0;
		int rem = 0;
		int bitCntr = 0;
		char[] chars = null;

		try {
			len = mask.length();
			if (len < 1)
				return null;
			i = len % 4;
			if (i != 0)
				len = len + (4 - i);
			bitCntr = len / 4;
			chars = new char[bitCntr];
			for (i = 0; i < len; i++) {
				rem = i % 4;
				if (mask.get(i + 1))
					msk = msk | getWeight(rem);
				if (rem == 3) {
					chars[bitCntr - 1] = Integer.toString(msk, 16).charAt(0);
					msk = 0;
					bitCntr--;
				}
			}
			return String.valueOf(chars);
		} finally {
			if (chars != null)
				chars = null;
		}
	}
	
	private int getWeight(int bitPos) {
		int retVal = 0;
		Assert.isTrue((bitPos > -1 && bitPos < 8), "Invalid bit position "
				+ bitPos);
		switch (bitPos) {
		case 0:
			retVal = 1;
			break;
		case 1:
			retVal = 2;
			break;
		case 2:
			retVal = 4;
			break;
		case 3:
			retVal = 8;
			break;
		case 4:
			retVal = 16;
			break;
		case 5:
			retVal = 32;
			break;
		case 6:
			retVal = 64;
			break;
		case 7:
			retVal = 128;
			break;
		}
		return retVal;
	}
	
	private String getSQL(String tableName)
	{
		StringBuilder sqlSb = null;
		String returnSQL = null;
		
		sqlSb = new StringBuilder( 512 );
		sqlSb.append( " SELECT TO_CHAR( rl.rmweight ) AS feature_id, rl.rmweight as weight FROM " );
		sqlSb.append( tableName );
		sqlSb.append( " dtl, feature_repository fr, feature_rights_linkage rl WHERE fr.applicable_flag = 'Y' " );
		sqlSb.append( " AND ( dtl.feature_id = fr.feature_id AND rl.feature_id = fr.feature_id ) " );
		sqlSb.append( " AND dtl.parent_record_key = ? " );
		sqlSb.append( " UNION " );
		sqlSb.append( " SELECT dtl.feature_id, 0 AS rmweight FROM " );
		sqlSb.append( tableName );
		sqlSb.append( " dtl WHERE dtl.feature_id = 'ALL' AND dtl.parent_record_key = ? " );
		
		returnSQL = sqlSb.toString();
		CleanUpUtils.doClean(sqlSb);
		return returnSQL;
	}
	
	private String getCorpPrvWeightsSQL(String tableName)
	{
		StringBuilder sqlSb = null;
		String returnSQL = null;
		
		sqlSb = new StringBuilder( 512 );
		sqlSb.append( " SELECT rl.rmweight as weight FROM " );
		sqlSb.append(tableName);
		sqlSb.append( " dtl, feature_repository fr, feature_rights_linkage rl " );
		sqlSb.append( " WHERE fr.feature_id = rl.feature_id AND dtl.feature_id = fr.feature_id " );
		sqlSb.append( " AND fr.applicable_flag = 'Y' AND dtl.parent_record_key = ? " );
		
		returnSQL = sqlSb.toString();
		CleanUpUtils.doClean(sqlSb);
		return returnSQL;
	}
}
