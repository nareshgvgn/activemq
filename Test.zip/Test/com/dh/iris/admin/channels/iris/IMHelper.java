/*------------------------------------------------------------------------------
 * PACKAGE: com.fundtech.iris.admin.activator
 * FILE   : IMHelper.java
 * CREATED: Jul 2, 2014 10:13:18 AM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channels.iris;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;
import java.util.UUID;

import javax.sql.PooledConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.cashtech.iris.contexts.ExecutionContext;
import com.cashtech.iris.core.processor.IMAuditHandler;
import com.cashtech.iris.core.processor.resource.ResourceTypeEnum;
import com.cashtech.iris.core.processor.resource.dbutils.ConnectionProviderAdapter;
import com.cashtech.iris.exceptions.NodeProcessingException;
import com.cashtech.iris.util.IRISLogger;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.HelperUtils;
import com.fundtech.iris.admin.util.OracleType;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.CLOB;

/**
 * <p>
 * TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * 
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre>
 * 
 * </p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Module</td>
 * <td style="border:1px dotted silver;">TODO - Module Name</td>
 * </tr>
 * <tr>
 * <td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 * <td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 * </tr>
 * </table>
 * </p>
 * 
 * @author Babu Paluri
 * @version $Id: IMHelper.java,v 1.7 2015/11/13 04:57:15 ramap Exp $
 */
public class IMHelper implements IMAuditHandler
{
	private static Logger logger = LoggerFactory.getLogger(IMHelper.class);
	private String dbResourceName = null;
	private ApplicationContext applicationContext = null;
	private int srNumber = 1; 
	private static final String insSql = "INSERT INTO iris_audit_activity (audit_id, process_name, execution_id,  ENTITY_CODE, audit_type, audit_data)"
			+ " VALUES (?, ?, ?, ?, ?, ?)";
	
	public IMHelper()
	{
		
	}
	
	public  String createJob (Map<String, String> helperData) throws NodeProcessingException
	{
		String executionId = null;
		CallableStatement stProc = null;
		String procName = "{CALL pkg_integrate_gcp.h2h_upload(?,?,?,?,?,?,?,?,?,?)}";
		String entityType = null;
		String entityCode = null;
		String mediaType = null;
		String mapName = null;
		String errorVal = null;
		String errorMsg = null;
		String messageId = null;
		String parentExecutionId = null;
		OracleType runtimeParms = null;
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		NodeProcessingException lExp = null;
		OracleConnection oraConnection = null;
		PooledConnection pooledConnection = null;
		ARRAY array = null;
		OracleType[] types = new OracleType[1];
		
		try
		{
			dbProvider = getDBProvider();
			dbConnection = dbProvider.getConnection();
			entityType = helperData.get(ENTITY_TYPE);
			entityCode = helperData.get(ENTITY_CODE);
			mapName = helperData.get(MAP_NAME);
			messageId = helperData.get(MEDIA_DETAIL);
			mediaType = helperData.get(CHANNEL);
			parentExecutionId = helperData.get(PARENT_EXECUTION_ID);
			runtimeParms = new OracleType(null, null, null);
			types[0] = runtimeParms;
			pooledConnection = (PooledConnection) dbConnection;
			oraConnection = (OracleConnection) pooledConnection.getConnection();
			array =  HelperUtils.createTypeValue(oraConnection, OracleTypes.ARRAY, "NT_KEY_VALUE_PAIR", types);
			stProc = oraConnection.prepareCall(procName);
			stProc.setString(1, mediaType);
			stProc.setString(2, messageId);
			stProc.setString(3, entityType);
			stProc.setString(4, entityCode);
			stProc.setString(5, mapName);
			stProc.setString(6,parentExecutionId);
			stProc.setObject(7, array, OracleTypes.ARRAY);
			stProc.registerOutParameter(8, Types.VARCHAR);
			stProc.registerOutParameter(9, Types.VARCHAR);
			stProc.registerOutParameter(10, Types.VARCHAR);
			stProc.executeUpdate();
			executionId = stProc.getString(8);
			errorVal = stProc.getString(9);
			errorMsg = stProc.getString(10);
			
			if (executionId == null)
			{
				logger.error("Error Code:" + errorVal + "  Error Message:" + errorMsg);
				lExp = new NodeProcessingException("error.admin.createjob", new Object[]{ procName, mediaType, messageId, entityType, entityCode, mapName, runtimeParms }, null);
				logger.error(IRISLogger.getText(lExp));
				throw lExp;
			}
			
			dbConnection.commit(); // commit it so that process gets execution data.
		}
		catch (NodeProcessingException exp)
		{
			throw exp;
		}
		catch (SQLException exp)
		{
			lExp = new NodeProcessingException("error.admin.createjob", new Object[] { procName, mediaType, messageId, entityType, entityCode, mapName, runtimeParms }, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new NodeProcessingException("error.admin.createjob", new Object[] { procName, mediaType, messageId, entityType, entityCode, mapName, runtimeParms }, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(stProc);
			CleanUpUtils.doClean(dbProvider, dbConnection);
			stProc = null;
		}
		
		return executionId;
	}
	
	public void updateJobStatus (String status, String errorCode, String errorMsg, String mediaDetails, String executionId) throws NodeProcessingException
	{
		PreparedStatement updateSt = null;
		String sql = "UPDATE IRIS_JOB_QUEUE  SET STATUS = ? , SYS_END_DATE = SYSDATE, END_DATE = pk_timezone.get_seller_time(?) , ERROR_CODE = ?, ERROR_MSG = ? , "
				+ " MEDIA_DTLS = ? WHERE EXECUTION_ID = ?";
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		NodeProcessingException eExp = null;
		int updateCount = 0;
		String sellerCode = null;
		
		try
		{
			dbProvider = getDBProvider();
			dbConnection = dbProvider.getConnection();
			sellerCode = getSellerCode(executionId, dbConnection);
			updateSt = dbConnection.prepareStatement(sql);
			updateSt.setString(1, status);
			updateSt.setString(2, sellerCode);
			updateSt.setString(3, errorCode);
			updateSt.setString(4, errorMsg);
			updateSt.setString(5, mediaDetails);
			updateSt.setString(6, executionId);
			
			updateCount = updateSt.executeUpdate();
			
			if (updateCount < 0)
				logger.warn("Job:{} record not available for status update", executionId);
			else if (logger.isTraceEnabled())
				logger.debug("Job:" + executionId + " Record status updated");
			dbConnection.commit();
		}
		catch( NodeProcessingException exp)
		{
			throw exp;
		}
		catch (SQLException exp)
		{
			eExp = new NodeProcessingException("error.iris.admin.statusupdate", new Object[]	{ "ExecutionId:" + executionId, "JobStatus:" + status, sql }, exp);
			IRISLogger.getText(eExp);
			throw eExp;
		}
		catch (Exception exp)
		{
			eExp = new NodeProcessingException("error.iris.admin.statusupdate", new Object[]	{ "ExecutionId:" + executionId, "JobStatus:" + status, sql }, exp);
			IRISLogger.getText(eExp);
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(updateSt);
			sql = null;
			CleanUpUtils.doClean(dbProvider, dbConnection);
		}
		
	}
	
	private String getSellerCode( String executionId, Connection dbConnection) throws NodeProcessingException
	{
		String sellerCode = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		NodeProcessingException eExp = null;
		String sql = "select t.seller_code from iris_job_queue t where t.execution_id=?";
		
		try
		{
			stmt = dbConnection.prepareStatement(sql);
			stmt.setString(1, executionId);
			rs = stmt.executeQuery();
			if ( rs.next())
			{
				sellerCode = rs.getString("seller_code");
				return sellerCode;
			}
			else
				eExp = new NodeProcessingException("error.iris.admin.sellercodeNotfound", new Object[]	{ "ExecutionId:" + executionId,  sql }, null);
				IRISLogger.getText(eExp);
				throw eExp;
		}
		catch ( NodeProcessingException exp)
		{
			throw exp;
		}
		catch ( Exception exp)
		{
			eExp = new NodeProcessingException("error.iris.admin.statusupdate", new Object[]	{ "ExecutionId:" + executionId,  sql }, exp);
			IRISLogger.getText(eExp);
			throw eExp;
		}
		finally
		{
			CleanUpUtils.doClean(rs);
			CleanUpUtils.doClean(stmt);
		}
		
		
	}
	
	public  void finishJob (Map<String, String> helperData) throws NodeProcessingException
	{
		CallableStatement cStmt = null;
		String sql = null;
		long startTime = 0;
		long endTime = 0;
		double delta = 0;
		NodeProcessingException eExp = null;
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		String executionId = null;
		
		try
		{
			dbProvider = getDBProvider();
			dbConnection = dbProvider.getConnection();
			startTime = System.currentTimeMillis();
			sql = "{CALL pkg_iris_admin.finish_iris_job (?, ?, ?, ?,?)}";
			cStmt = dbConnection.prepareCall(sql);
			executionId = helperData.get(EXECUTION_ID);
			cStmt.setString(1, executionId);
			cStmt.setString(2,  helperData.get(REF_ID));
			cStmt.setString(3,  helperData.get(STATUS));
			cStmt.setString(4,  helperData.get(ERROR_CODE));
			cStmt.setString(5,  helperData.get(ERROR_DESC));
			
			cStmt.executeUpdate();
			dbConnection.commit();
			
			endTime = System.currentTimeMillis();
			delta = (endTime - startTime) / 1000.00;
				logger.debug("Time taken for executing pkg_iris_admin.finish_iris_job  StoredProcedure: {}" , delta);
		}
		catch (SQLException exp)
		{
			eExp = new NodeProcessingException("error.iris.admin.finishjobproc", new Object[]	{ executionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		catch ( Exception exp)
		{
			eExp = new NodeProcessingException("error.iris.admin.finishjobproc", new Object[]	{ executionId }, exp);
			logger.error(IRISLogger.getText(eExp));
			throw eExp;
		}
		finally
		{
			HelperUtils.doClose(cStmt);
			cStmt = null;
			CleanUpUtils.doClean(dbProvider, dbConnection);
		}
	}
	
	public void insertError(Map<String, String> helperData) throws NodeProcessingException
	{
		String sql = "INSERT INTO INT_MONITORING_ERRORS(execution_id, sr_nmbr,record_level, record_nmbr, reference_key, reject_reason) values(?,?,?,?,?,?)";
		PreparedStatement statement = null;
		NodeProcessingException lExp = null;
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		int recordNumber = 0;
		
		try
		{
			dbProvider = getDBProvider();
			dbConnection = dbProvider.getConnection();
			statement = dbConnection.prepareStatement(sql);
			statement.setString(1, helperData.get(EXECUTION_ID));
			
			if (helperData.containsKey(SR_NUMBER) )
				srNumber = Integer.parseInt(helperData.get(SR_NUMBER));
			
			statement.setInt(2, srNumber);
			statement.setString(3, helperData.get(RECORD_LEVEL));
			if (helperData.containsKey(RECORD_NUMBER) )
				recordNumber = Integer.parseInt(helperData.get(RECORD_NUMBER));
			statement.setInt(4, recordNumber);
			statement.setString(5, helperData.get(ERROR_CODE));
			statement.setString(6, helperData.get(ERROR_DESC));
			statement.executeUpdate();
			dbConnection.commit();
			srNumber ++;
		}
		catch (SQLException exp)
		{
			lExp = new NodeProcessingException("error.admin.ftpPath", new Object[]{ "FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new NodeProcessingException("error.admin.ftpPath", new Object[]{"FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(statement);
			statement = null;
			CleanUpUtils.doClean(dbProvider, dbConnection);
		}
	}
	
	public String getFtpPath (String ftpProperty) throws NodeProcessingException
	{
		String sql = "SELECT PARAMETER_VALUE FROM SYSTEM_PARAMETERS_MST WHERE PARAMETER_CODE =?";
		PreparedStatement statement = null;
		ResultSet rSet = null;
		File ftpFile = null;
		String ftpPath = null;
		NodeProcessingException lExp = null;
		Connection dbConnection = null;
		ConnectionProvider dbProvider = null;
		
		try
		{
			dbProvider = getDBProvider();
			dbConnection = dbProvider.getConnection();
			statement = dbConnection.prepareStatement(sql);
			statement.clearParameters();
			statement.setString(1, ftpProperty);
			rSet = statement.executeQuery();
			if (rSet.next())
			{
				ftpPath = rSet.getString("PARAMETER_VALUE");
				ftpFile = new File(ftpPath);
				ftpPath = ftpFile.getAbsolutePath();
			}
		}
		catch (SQLException exp)
		{
			lExp = new NodeProcessingException("error.admin.ftpPath", new Object[]{ "FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		catch (Exception exp)
		{
			lExp = new NodeProcessingException("error.admin.ftpPath", new Object[]{"FTP path not found"}, exp);
			logger.error(IRISLogger.getText(lExp));
			throw lExp;
		}
		finally
		{
			HelperUtils.doClose(rSet);
			rSet = null;
			HelperUtils.doClose(statement);
			statement = null;
			ftpFile = null;
			CleanUpUtils.doClean(dbProvider, dbConnection);
		}
		
		return ftpPath;
	}
	
	
	public void auditRecord(ExecutionContext helperData, int type)
	{
		
		Clob clob = null;
		String message = null;
		PreparedStatement psInsert = null;
		ConnectionProvider dbProvider = null;
		Connection dbConnection = null;
		String mapName = null;
		String executionId = null;
		String entityCode = null;
		try
		{
			
			message =  (String) helperData.get(AUDIT_SOURCE_DATA);
			entityCode = (String)helperData.get(ENTITY_CODE);
			mapName = (String) helperData.get(MAP_NAME);
			executionId = (String) helperData.get(EXECUTION_ID);
			dbProvider = getDBProvider();
			dbConnection = dbProvider.getConnection();
			psInsert = dbConnection.prepareStatement(insSql);
			psInsert.clearParameters();
			psInsert.setString(1, createID());
			psInsert.setString(2, mapName);
			psInsert.setString(3,executionId);
			psInsert.setString(4, entityCode);
			psInsert.setInt(5, type);
			clob = clob(message, dbConnection);
			psInsert.setClob(6, clob);
			psInsert.executeUpdate();
			dbConnection.commit();
		}
		catch (SQLException e)
		{
			logger.warn("Not able to audit the record coz:{}", e.getMessage(), e);
		}
		catch ( Exception exp)
		{
			logger.warn("Not able to audit the record coz:{}", exp.getMessage(), exp);
		}
		finally
		{
			free(clob);
			HelperUtils.doClose(psInsert);
			psInsert = null;
			CleanUpUtils.doClean(dbProvider, dbConnection);
			message = null;
		}
	}
	
	
	private final void free(Clob clob)
	{
		try
		{
			if ( clob != null)
				clob.free();
		}
		catch (Exception e)
		{
			logger.error("Error:",e);
			//do nothing
		}
	}
	private final Clob clob(String string, Connection dbConnection)   throws SQLException 
	{
		       
		Clob clob = null;
		PooledConnection pooledConnection = null;
		OracleConnection oraConnection = null;
		
		pooledConnection = (PooledConnection) dbConnection;
		oraConnection = (OracleConnection) pooledConnection.getConnection();
		clob = CLOB.createTemporary(oraConnection, false, CLOB.DURATION_SESSION);
		clob.setString(1, string);
		return clob;
	}
		 
	

	public static String createID()
	{
	    return UUID.randomUUID().toString();
	}
	
	public  void setThreadId (String prefix, String executionId)
	{
		String pidRet = null;
		
		try
		{
			pidRet = prefix + "_" + executionId;
		}
		finally
		{
		}
		
		if (logger.isInfoEnabled())
			logger.info("Changing thread name [" + Thread.currentThread().getName() + "] to [" + pidRet + "]");
		
		Thread.currentThread().setName(pidRet);
	}
	
	/**
	 * This method creates a dedicated DB Connection
	 * 
	 * @return DBConnection
	 */
	private ConnectionProvider getDBProvider () throws Exception
	{
		ConnectionProvider dbProvider = null;
		try
		{
				if (dbResourceName != null)
					dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN, dbResourceName);
				else
					dbProvider = new ConnectionProviderAdapter(applicationContext.getResourceFinder(), ResourceTypeEnum.DB_CONN,ResourceTypeEnum.IRIS_DATABASE);
				
		}
		catch (Exception e)
		{
			throw e;
		}
		return dbProvider;
	}
	
	
	
	

	/**
	 * @param dbResourceName the dbResourceName to set
	 */
	public void setDbResourceName (String dbResourceName)
	{
		this.dbResourceName = dbResourceName;
	}

	/**
	 * @param applicationContext the applicationContext to set
	 */
	public void setApplicationContext (ApplicationContext applicationContext)
	{
		this.applicationContext = applicationContext;
	}
}
