/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channels.iris
 * FILE   : IDataObject.java
 * CREATED: Sep 13, 2015 1:26:42 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channels.iris;

import java.io.Closeable;
import java.util.Map;

import com.cashtech.iris.patterns.sdo.DataObject;
import com.fundtech.iris.admin.IrisAdminConstants;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IDataObject.java,v 1.6 2016/08/04 19:07:37 ramap Exp $
 */
public interface IDataObject extends Closeable
{
	public static final String JMS_MESSAGE = "JMS_MESSAGE";
	public static final String JMS_HEADER_DATA = "JMS_HEADER_DATA";
	public static final String MEDIA_DETAIL = "MEDIA_DETAIL";
	public static final String MAP_NAME = "MAP_NAME";
	public static final String DB_CONNECTION = "DB_CONNECTION";
	public static final String EXECUTION_ID = "EXECUTION_ID";
	public static final String PARENT_EXECUTION_ID = IrisAdminConstants.PARENT_EXECUTION_ID;
	public static final String SCHEDULE_ID = "SCHEDULE_ID";
	public static final String HTTP_PARMS = "HTTP_PARMS";

	public DataObject createDataObject(Map<String, Object>  parms) throws ExecutionException;
	
}
