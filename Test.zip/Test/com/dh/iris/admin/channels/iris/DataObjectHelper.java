/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channels.iris
 * FILE   : DataObjectHelper.java
 * CREATED: Sep 13, 2015 1:30:04 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channels.iris;

import java.io.IOException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.MapDataObject;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: DataObjectHelper.java,v 1.3 2015/10/19 12:16:37 ramap Exp $
 */
public class DataObjectHelper implements IDataObject
{
	private Map<String, String> properties = null;
	private static Logger logger = LoggerFactory.getLogger(DataObjectHelper.class);
	
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public DataObjectHelper()
	{
		// BABU Auto-generated constructor stub
	}
	
	/**
	 * @param parameters
	 *            the parameters to set
	 */
	public void setProperties (Map<String, String> properties)
	{
		this.properties = properties;
	}
	
	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channels.iris.IDataObject#createDataObject(java.util.Map)
	 */
	@Override
	public DataObject createDataObject (Map<String, Object> parms)
	{
		DataObject inDo = null;
		String executionId = null;
		
		try
		{
			executionId = (String) parms.get(IDataObject.EXECUTION_ID);
			inDo  = new MapDataObject("FileInfo");
			inDo.setValue("FileName",(String) parms.get(IDataObject.MEDIA_DETAIL));
			inDo.setValue("pov_execution_id", executionId);
		}
		catch ( Exception exp)
		{
			logger.error("Error:", exp);
		}
		return inDo;
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		// BABU Auto-generated method stub
		
	}
	
}
