/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.channels.iris
 * FILE   : IrisDataObject.java
 * CREATED: Aug 4, 2016 11:14:01 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.channels.iris;

import java.io.IOException;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cashtech.iris.patterns.sdo.DataObject;
import com.cashtech.iris.patterns.sdo.MapDataObject;
import com.fundtech.iris.admin.exceptions.ExecutionException;

/**
 * <p>TODO - The description and purpose of this class goes here
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * TODO - Put bean configuration xml snippet here (if applicable)
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Module</td>
 *		<td style="border:1px dotted silver;">TODO - Module Name</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>TODO - XML Configuration file name</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisDataObject.java,v 1.2 2016/08/12 09:19:09 ramap Exp $
 */
public class IrisDataObject implements IDataObject
{
	
	private Map<String, String> properties = null;
	private static Logger logger = LoggerFactory.getLogger(IrisDataObject.class);
	/**
	 * TODO Please insert Type's purpose and description.
	 */
	public IrisDataObject()
	{
		// BABU Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	@Override
	public void close () throws IOException
	{
		// BABU Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see com.dh.iris.admin.channels.iris.IDataObject#createDataObject(java.util.Map)
	 */
	@Override
	public DataObject createDataObject (Map<String, Object> parms) throws ExecutionException
	{
		DataObject inDo = null;
		String dataObjectType = null;
		
		try
		{
			dataObjectType = properties.get("dataObjectType");
			inDo  = new MapDataObject(dataObjectType);
		}
		catch ( Exception exp)
		{
			logger.error("Error:", exp);
		}
		return inDo;
	}
	
	/**
	 * @param parameters
	 *            the parameters to set
	 */
	public void setProperties (Map<String, String> properties)
	{
		this.properties = properties;
	}
	
}
