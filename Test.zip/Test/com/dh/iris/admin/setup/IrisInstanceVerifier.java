/*------------------------------------------------------------------------------
 * PACKAGE: com.dh.iris.admin.setup
 * FILE   : IrisInstanceVerifier.java
 * CREATED: Dec 10, 2015 6:39:54 PM
 *------------------------------------------------------------------------------
 * Change Log:
 *----------------------------------------------------------------------------*/
package com.dh.iris.admin.setup;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.cashtech.iris.aspect.persistence.connection.ConnectionProvider;
import com.cashtech.iris.contexts.ApplicationContext;
import com.fundtech.iris.admin.channel.ReferencesEnum;
import com.fundtech.iris.admin.util.CleanUpUtils;
import com.fundtech.iris.admin.util.IrisAdminUtils;

/**
 * <p> This verification bean checks given Iris Instance is authorized or not
 * <h3>Configuration</h3>
 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
 * &lt;bean id="verification" class="com.dh.iris.admin.setup.IrisInstanceVerifier" scope="singleton" init-method="verify"&gt; 
		&lt;property name="references"&gt;
			&lt;util:map id="references" key-type="com.fundtech.iris.admin.channel.ReferencesEnum"&gt;
        		&lt;entry key="DB_CONN" value="IRIS_DB"/&gt;
			&lt;/util:map&gt;
		&lt;/property&gt;
		&lt;property name="applicationContext" ref="ApplicationContext"/&gt;
		&lt;!-- 
			At Least one verifier must configure
		 --&gt;
		&lt;property name="ipVerification" value="true"/&gt;
		&lt;property name="hostNameVerification" value="true"/&gt;
		&lt;property name="dnsNameVerification" value="true"/&gt;
&lt;/bean&gt;
 * </pre></p>
 * <p>
 * <h3>References</h3>
 * <table style="background-color:white;border:1px solid silver;border-collapse:collapse;" cellpadding="4">
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">IRIS verification</td>
 *		<td style="border:1px dotted silver;">SETUP</td>
 *  </tr>
 * 	<tr>
 * 		<td style="background-color: silver;border:1px dotted silver;">Configuration File</td>
 *		<td style="border:1px dotted silver;"><code>IrisContext.xml</code></td>
 *  </tr>
 * </table></p>
 * @author Babu Paluri
 * @version $Id: IrisInstanceVerifier.java,v 1.7 2016/10/03 07:50:21 ramap Exp $
 */
public class IrisInstanceVerifier implements InitializingBean
{
	private static Logger operator = LoggerFactory.getLogger("com.cashtech.iris.customLogger.Operator");
	private Map<ReferencesEnum, String> references = new HashMap<ReferencesEnum, String>();
	private ApplicationContext applicationContext;
	private boolean ipVerification = false;
	private boolean hostNameVerification = false;
	private boolean dnsNameVerification = false;
	private boolean macAddressVerification = false;
	private static final String UN_KNOWN = "UN_KNOWN";
	
	
	/**
	 * <p>This method verifies IRIS Server IP or host name or DNS name matches with configured 
	 * <p> <i> This verification coz of to eliminates unknowing iris instances connected to same database </i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * </pre></p>
	 */
	public void verify()
	{
		String myHostname = null;
		String myIp = null;
		String myDnsName = null;
		ConnectionProvider dbProvider = null;
		Connection dbConnection = null;
		String dbResourceName = null;
		String verifySql = "select t.parameter_code, t.parameter_value from system_parameters_mst t where t.parameter_code in "
				+ "								('IRIS_ALLOWED_IPS','IRIS_ALLOWED_HOSTNAMES','IRIS_ALLOWED_DNS_NAMES', 'IRIS_ALLOWED_MAC_NAMES')";
		PreparedStatement verifySt = null;
		ResultSet verifyRs = null;
		String ipAddresses = null;
		String hostNames = null;
		String dnsNames = null;
		boolean isVerified = false;
		InetAddress inet;
		String parmCode = null;
		String myMacAddress = null;
		String macAddresses = null;
		
       
		try
		{
			dbResourceName = getReferences().get(ReferencesEnum.DB_CONN);
			dbProvider = IrisAdminUtils.getDBProvider(dbResourceName, getApplicationContext());
			dbConnection = dbProvider.getConnection();
			verifySt  = dbConnection.prepareStatement(verifySql);
			verifyRs = verifySt.executeQuery();
			inet = InetAddress.getLocalHost();
			myIp = getMyIp(inet);
			myHostname = getMyHostName(inet);
			myDnsName = getMyDNSName(inet);
			myMacAddress  = getMyMacAddress(inet);
			while ( verifyRs.next())
			{
				parmCode = verifyRs.getString("parameter_code");
				if ( "IRIS_ALLOWED_IPS".equals(parmCode))
					ipAddresses = verifyRs.getString("parameter_value");
				else if ( "IRIS_ALLOWED_HOSTNAMES".equals(parmCode))
				hostNames = verifyRs.getString("parameter_value");
				else if ( "IRIS_ALLOWED_DNS_NAMES".equals(parmCode))
				dnsNames = verifyRs.getString("parameter_value");
				else if ( "IRIS_ALLOWED_MAC_NAMES".equals(parmCode))
					macAddresses = verifyRs.getString("parameter_value");
			}
			
			if ( isIpVerification() && ! isVerified )
				isVerified = verify(ipAddresses, myIp);
			
			if ( isHostNameVerification() && ! isVerified)
				isVerified = verify(hostNames, myHostname);
			
			if ( isDnsNameVerification() && ! isVerified)
				isVerified = verify(dnsNames, myDnsName);
			
			if (isMacAddressVerification() && ! isVerified)
				isVerified = verify(macAddresses, myMacAddress);
			
			if ( !isVerified)
			{
				if(myIp.equals(UN_KNOWN))
					myIp = "Not known!";
				if(myHostname.equals(UN_KNOWN))
					myHostname = "Not known!";
				if(myDnsName.equals(UN_KNOWN))
					myDnsName = "Not known!";
				if(myMacAddress.equals(UN_KNOWN))
					myMacAddress = "Not known!";
				
				operator.error("################Instance IP:{} or Host:{} or DNS Name:{} or MAC:{} not matching################", myIp, myHostname, myDnsName,myMacAddress);
				operator.error("!!!!!! SYSTEM WILL SHUT DOWNN  !!!!!!");
				System.exit(0);
			}
			
			operator.info("################################# Instance verified ########################");
		}
		catch ( Exception exp)
		{
			operator.error("Not able to verify the instance coz of {}" , exp.getMessage(), exp);
			System.exit(0);
		}
		finally
		{
			CleanUpUtils.doClean(verifyRs);
			CleanUpUtils.doClean(verifySt);
			IrisAdminUtils.cleanup(dbProvider, dbConnection);
		}
	}
	
	private String getMyDNSName(InetAddress inet)
	{
		String returnVal = null;
		try
		{
			returnVal = inet.getCanonicalHostName();
		}
		catch( Exception exp)
		{
			operator.error("DNS Address Not able to get {}", exp.getMessage());
			returnVal = UN_KNOWN;
		}
		return returnVal;
	}
	
	private String getMyHostName(InetAddress inet)
	{
		String returnVal = null;
		try
		{
			returnVal = inet.getHostName();
		}
		catch( Exception exp)
		{
			operator.error("Host Name Not able to get {}", exp.getMessage());
			returnVal = UN_KNOWN;
		}
		return returnVal;
	}
	
	private String getMyIp(InetAddress inet)
	{
		String returnVal = null;
		try
		{
			returnVal = inet.getHostAddress();
		}
		catch( Exception exp)
		{
			operator.error("MAC Address Not able to get {}", exp.getMessage());
			returnVal = UN_KNOWN;
		}
		return returnVal;
	}
	
	private String getMyMacAddress(InetAddress ip)
	{
		NetworkInterface network = null;
		StringBuilder sb = null;
		byte[] mac = null;
		String returnVal = null;
		
		try
		{
			sb = new StringBuilder();
			network = NetworkInterface.getByInetAddress(ip);
			mac = network.getHardwareAddress();
			
			for (int i = 0; i < mac.length; i++) 
			{
				sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));		
			}
			returnVal = sb.toString();
		}
		catch( Exception exp)
		{
			operator.error("MAC Address Not able to get {}", exp.getMessage());
			returnVal = UN_KNOWN;
		}
		finally
		{
			CleanUpUtils.doClean(sb);
		}
		return returnVal;
	}
	
	/**
	 * <p>TODO - The description and purpose of this method goes here
	 * <p> <i> TODO Additional info if any</i> </p>
	 * <h3>Signature of the method</h3>
	 * <pre style="padding:2px;margin:0px;border:1px dotted #0A246A;background-color:white;font-family:Consolas,monospace;">
	 * @param ipAddresses
	 * @return
	 * </pre></p>
	 */
	private boolean verify (String value1, String value2)
	{
		String[] values = null;
		boolean isverified = false;
		
		if (value1 ==  null)
			return isverified;
		if ( value2 == null)
			return isverified;
		
		values = StringUtils.split(value1, ",");
		
		for (String s : values)
		{
			if ( s.equalsIgnoreCase(value2))
			{
				isverified = true;
				break;
			}
		}
		return isverified;
	}

	/**
	 * @return the references
	 */
	public Map<ReferencesEnum, String> getReferences ()
	{
		return references;
	}
	/**
	 * @param references the references to set
	 */
	public void setReferences (Map<ReferencesEnum, String> references)
	{
		this.references = references;
	}
	/**
	 * @return the ipVerification
	 */
	public boolean isIpVerification ()
	{
		return ipVerification;
	}
	/**
	 * @param ipVerification the ipVerification to set
	 */
	public void setIpVerification (boolean ipVerification)
	{
		this.ipVerification = ipVerification;
	}
	
	/**
	 * @return the dnsNameVerification
	 */
	public boolean isDnsNameVerification ()
	{
		return dnsNameVerification;
	}
	/**
	 * @param dnsNameVerification the dnsNameVerification to set
	 */
	public void setDnsNameVerification (boolean dnsNameVerification)
	{
		this.dnsNameVerification = dnsNameVerification;
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet () throws Exception
	{
		if (! isDnsNameVerification() && ! isHostNameVerification() && ! isIpVerification())
		{
			String message = " ######  None of the verifier configured.. we must configure atleast one verifier ######";
			RuntimeException exp =  new RuntimeException(message);
			operator.error(message, exp);
			throw exp;
		}
		
	}

	/**
	 * @return the applicationContext
	 */
	public ApplicationContext getApplicationContext ()
	{
		return applicationContext;
	}

	/**
	 * @param applicationContext the applicationContext to set
	 */
	public void setApplicationContext (ApplicationContext applicationContext)
	{
		this.applicationContext = applicationContext;
	}

	/**
	 * @return the hostNameVerification
	 */
	public boolean isHostNameVerification ()
	{
		return hostNameVerification;
	}

	/**
	 * @param hostNameVerification the hostNameVerification to set
	 */
	public void setHostNameVerification (boolean hostNameVerification)
	{
		this.hostNameVerification = hostNameVerification;
	}

	/**
	 * @return the macAddressVerification
	 */
	public boolean isMacAddressVerification ()
	{
		return macAddressVerification;
	}

	/**
	 * @param macAddressVerification the macAddressVerification to set
	 */
	public void setMacAddressVerification (boolean macAddressVerification)
	{
		this.macAddressVerification = macAddressVerification;
	}
	
	
}
