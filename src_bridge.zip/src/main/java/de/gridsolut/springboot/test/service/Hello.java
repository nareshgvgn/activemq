package de.gridsolut.springboot.test.service;

import javax.jms.JMSException;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.gridsolut.springboot.test.util.SimpleMessageProducer;

//http://www.vogella.com/tutorials/REST/article.html
@Component
@Path("/")
public class Hello {

	final static Logger logger = Logger.getLogger(Hello.class);
	
	@Autowired
	SimpleMessageProducer producer;
	
	@GET
    //@Path("/post/{id}")
    @Produces("application/json")
    public String getCustomerId() {
		String id = "DON";
		try {
			producer.sendMessages(id);
		} catch (JMSException e) {
			e.printStackTrace();
		}
		return id;
    }
	
	@PUT
    public String getCustomer() {
		System.out.println("Receive Message");
		return "";
    }
	
	@GET
    @Path("/post")
    @Produces("application/json")
    public String getCustomerIds() {
		String id = "DON";
		System.out.println("****************************");
		System.out.println("Server 2");
		System.out.println("****************************");
		
		logger.debug("Received the Message");
		return id;
    }
}
