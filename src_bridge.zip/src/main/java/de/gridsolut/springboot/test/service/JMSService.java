package de.gridsolut.springboot.test.service;

import javax.jws.Oneway;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.gridsolut.springboot.test.util.SimpleMessageProducer;

//http://www.vogella.com/tutorials/REST/article.html
@Component
@Path("/")
public class JMSService {

	@Autowired
	SimpleMessageProducer producer;
	
	@PUT
    @Oneway
    public String getCustomer() {
		System.out.println("Receive");
		return "Rece";
    }
}
