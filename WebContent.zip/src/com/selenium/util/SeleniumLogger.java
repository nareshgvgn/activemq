package com.selenium.util;

import net.sf.json.JSONObject;

import org.springframework.stereotype.Component;

import com.selenium.bean.DetailInfo;
import com.selenium.bean.TestCaseStep;
import com.selenium.bean.TestStepResultBean;

@Component
public class SeleniumLogger {
	
	public void log(TestStepResultBean step)
	{
		
	}
	
	public String toJSONString(DetailInfo info) 
	{
		JSONObject obj = new JSONObject();
		obj.put("description", info.getDescription());
		if(null != info.getImagePath()){
			obj.put("imagePath", info.getImagePath());
		}
		return obj.toString();
	}
	
	public DetailInfo fromJSON(String jsonData) 
	{
		JSONObject obj = JSONObject.fromObject(jsonData);
		DetailInfo detailInfo = new DetailInfo();
		detailInfo.setDescription(obj.getString("description"));
		if(obj.has("imagePath"))
		detailInfo.setImagePath(obj.getString("imagePath"));
		return detailInfo;
	}

	public DetailInfo logElementNotFound(TestStepResultBean testStepResultBean,	TestCaseStep step) 
	{
		// TODO Auto-generated method stub
		return null;
	}

	public DetailInfo logSuccess(TestStepResultBean testStepResultBean,	TestCaseStep step) 
	{
		DetailInfo dtlInfo = new DetailInfo();
		
		return null;
	}

}
